' ScreenFleet autozip.brs
' BrightSign OS detects this file inside autorun.zip,
' extracts all files to SD card root, then reboots into autorun.brs.
' DO NOT ADD API CALLS HERE - keep this file minimal.
Sub Main()
    print "ScreenFleet: autozip extraction complete"
End Sub
