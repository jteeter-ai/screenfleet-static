' ScreenFleet autozip.brs
' BrightSign OS 9.x - explicit reboot required after zip extraction
Sub Main()
    print "ScreenFleet: autozip.brs running - rebooting into autorun.brs"
    RebootSystem()
End Sub
