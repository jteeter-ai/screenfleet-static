
// ScreenFleet V2 Service Worker — cache-first media delivery
const CACHE_NAME = 'sf-v2-media';

self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(clients.claim()); });

self.addEventListener('fetch', event => {
  const url = event.request.url;
  // Only intercept media fetches (images/videos from remote hosts)
  if (!url.startsWith('http')) return;
  const ext = url.split('?')[0].split('.').pop().toLowerCase();
  const isMedia = ['jpg','jpeg','png','gif','webp'].includes(ext); // videos served from sd:// local pool, not SW
  if (!isMedia) return;

  event.respondWith(
    caches.open(CACHE_NAME).then(cache =>
      cache.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          if (response.ok) cache.put(event.request, response.clone());
          return response;
        });
      })
    )
  );
});

// Message: preload manifest
self.addEventListener('message', async event => {
  if (event.data?.type !== 'PRELOAD_MANIFEST') return;
  const { items, oldChecksums } = event.data;
  const cache = await caches.open(CACHE_NAME);

  // Download new/changed files
  for (const item of items) {
    const req = new Request(item.url);
    const existing = await cache.match(req);
    if (!existing) {
      try {
        const res = await fetch(req);
        if (res.ok) await cache.put(req, res);
      } catch (e) { console.warn('[SW] Failed to cache', item.url); }
    }
  }

  // Orphan cleanup: delete URLs no longer in manifest
  const activeUrls = new Set(items.map(i => i.url));
  const keys = await cache.keys();
  for (const key of keys) {
    if (!activeUrls.has(key.url)) await cache.delete(key);
  }

  event.source?.postMessage({ type: 'PRELOAD_DONE' });
});
