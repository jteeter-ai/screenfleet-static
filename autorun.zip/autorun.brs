' ScreenFleet Native Partner App - autorun.brs
' BrightSign OS 9.x compatible - pure ASCII only
' v12 - Built on v8 working foundation
'
' KEY ARCHITECTURE DECISIONS vs v9-v11:
'   1. roHtmlWidget launches IMMEDIATELY - no blocking network calls before h.Show()
'   2. Wait(0, msgPort) - blocks indefinitely, never starves the widget
'   3. No module-level variable assignments (OS 9.x parse error)
'   4. HDMI activated AFTER h.Show() so widget is already running
'   5. Media download happens AFTER h.Show() via async approach
'   6. Version polling uses roDateTime but only checked on widget events (not on timer)
'   7. g_vp/g_vi stored as roRegistrySection workaround - kept in Sub scope via closure

' -- ReadConfig --
Function ReadConfig() As Object
    result = Invalid
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl("file:///config.json")
    raw = xfer.GetToString()
    If raw = "" Or raw = Invalid Then
        Print "[SF] ERROR: config.json not found"
        Return result
    End If
    cfg = ParseJson(raw)
    If cfg = Invalid Then
        Print "[SF] ERROR: config.json parse failed"
        Return result
    End If
    Print "[SF] Config loaded. token=" + cfg.screenToken
    Return cfg
End Function

' -- HttpPost: async POST returning response body string --
' PostFromString on OS 9.x returns Integer (status code), not body.
' Use AsyncPostFromString + roUrlEvent to get the response body.
Function HttpPost(url As String, body As String) As String
    result = ""
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl(url)
    xfer.AddHeader("Content-Type", "application/json")
    port = CreateObject("roMessagePort")
    xfer.SetPort(port)
    xfer.AsyncPostFromString(body)
    msg = Wait(15000, port)
    If Type(msg) = "roUrlEvent" Then
        result = msg.GetString()
        If result = Invalid Then result = ""
    Else
        Print "[SF] HTTP POST timeout or no response: " + url
    End If
    Return result
End Function

' -- FetchPayload: synchronous POST to screenPayload --
' Call this AFTER h.Show() to avoid blocking the display
Function FetchPayload(apiOrigin As String, screenToken As String) As Object
    result = Invalid
    Print "[SF] Fetching screenPayload..."
    q = Chr(34)
    body = "{" + q + "screenId" + q + ":" + q + screenToken + q + "," + q + "native_mode" + q + ":true}"
    resp = HttpPost(apiOrigin + "/functions/screenPayload", body)
    If resp = "" Then
        Print "[SF] ERROR: screenPayload request failed"
        Return result
    End If
    payload = ParseJson(resp)
    If payload = Invalid Then
        Print "[SF] ERROR: screenPayload parse failed"
        Return result
    End If
    If payload.status <> "ok" Then
        Print "[SF] ERROR: screenPayload status not ok"
        Return result
    End If
    zoneCount = 0
    If payload.zones <> Invalid Then zoneCount = payload.zones.Count()
    Print "[SF] Payload OK. zones=" + Str(zoneCount)
    Return payload
End Function

' -- SaveManifest: write payload JSON to SD --
Sub SaveManifest(payload As Object)
    json = FormatJson(payload)
    If json = "" Or json = Invalid Then
        Print "[SF] ERROR: FormatJson failed"
        Return
    End If
    ok = WriteAsciiFile("sd:/sf-manifest.json", json)
    If ok Then
        Print "[SF] Manifest saved"
    Else
        Print "[SF] ERROR: WriteAsciiFile failed"
    End If
End Sub

' -- LoadManifest: read saved manifest from SD --
Function LoadManifest() As Object
    result = Invalid
    Print "[SF] Loading saved manifest..."
    xfer = CreateObject("roUrlTransfer")
    xfer.SetUrl("file:///sf-manifest.json")
    raw = xfer.GetToString()
    If raw = "" Or raw = Invalid Then
        Print "[SF] No saved manifest found"
        Return result
    End If
    manifest = ParseJson(raw)
    If manifest = Invalid Then
        Print "[SF] ERROR: manifest parse failed"
        Return result
    End If
    zoneCount = 0
    If manifest.zones <> Invalid Then zoneCount = manifest.zones.Count()
    Print "[SF] Manifest loaded. zones=" + Str(zoneCount)
    Return manifest
End Function

' -- DownloadMedia: download playlist media to sd:/pool/ --
Sub DownloadMedia(zones As Object)
    Print "[SF-MEDIA] Starting media download..."
    CreateDirectory("sd:/pool")
    CreateDirectory("sd:/media")
    pool = CreateObject("roAssetPool", "sd:/pool")
    If pool = Invalid Then
        Print "[SF-MEDIA] ERROR: roAssetPool failed"
        Return
    End If
    col = CreateObject("roAssetCollection")
    fileCount = 0
    For Each zone In zones
        If zone.content_source_type = "playlist" Then
            If zone.playback_track <> Invalid Then
                items = zone.playback_track.items
                If items <> Invalid Then
                    For Each item In items
                        hasUrl = item.file_url <> Invalid And item.file_url <> ""
                        hasName = item.local_name <> Invalid And item.local_name <> ""
                        If hasUrl And hasName Then
                            entry = {}
                            entry.Name = item.local_name
                            entry.Link = item.file_url
                            col.AddAsset(entry)
                            fileCount = fileCount + 1
                            Print "[SF-MEDIA] Queued: " + item.local_name
                        End If
                    Next
                End If
            End If
        End If
    Next
    If fileCount = 0 Then
        Print "[SF-MEDIA] No media to download"
        Return
    End If
    Print "[SF-MEDIA] Downloading " + Str(fileCount) + " files..."
    dlPort = CreateObject("roMessagePort")
    fetcher = CreateObject("roAssetFetcher", pool)
    fetcher.SetPort(dlPort)
    fetcher.Download(col)
    startSecs = CreateObject("roDateTime").AsSeconds()
    done = false
    While Not done
        dlMsg = Wait(5000, dlPort)
        nowSecs = CreateObject("roDateTime").AsSeconds()
        If (nowSecs - startSecs) > 300 Then
            Print "[SF-MEDIA] Download timeout"
            done = true
        Else If Type(dlMsg) = "roAssetFetcherEvent" Then
            Print "[SF-MEDIA] Done. Success=" + Str(dlMsg.GetSuccessCount())
            realizer = CreateObject("roAssetRealizer", pool, "sd:/media")
            If realizer <> Invalid Then
                realizer.Realize(col)
                Print "[SF-MEDIA] Files at sd:/media"
            End If
            done = true
        End If
    End While
End Sub

' -- ActivateHdmiZone --
' NOTE: vp and vi are returned so caller can store them in Main scope
' preventing garbage collection. Do NOT let them go out of scope.
Function ActivateHdmiZone(zone As Object) As Object
    result = Invalid
    Print "[SF-HDMI] Activating: " + zone.name
    vi = CreateObject("roVideoInput")
    If vi = Invalid Then
        Print "[SF-HDMI] FAIL: roVideoInput=Invalid - not XT series"
        Return result
    End If
    vp = CreateObject("roVideoPlayer")
    If vp = Invalid Then
        Print "[SF-HDMI] FAIL: roVideoPlayer=Invalid"
        Return result
    End If
    pcmOutputs = CreateObject("roArray", 2, false)
    compOutputs = CreateObject("roArray", 2, false)
    audioMode = "aux"
    If zone.canvas_creative_data <> Invalid Then
        If zone.canvas_creative_data.audioOutput <> Invalid Then
            If zone.canvas_creative_data.audioOutput <> "" Then
                audioMode = zone.canvas_creative_data.audioOutput
            End If
        End If
    End If
    Print "[SF-HDMI] Audio: " + audioMode
    If audioMode = "hdmi" Then
        pcmOutputs.Push({AudioOutput: "HDMI"})
        compOutputs.Push({AudioOutput: "HDMI"})
    Else If audioMode = "both" Then
        pcmOutputs.Push({AudioOutput: "AnalogAudio"})
        pcmOutputs.Push({AudioOutput: "HDMI"})
        compOutputs.Push({AudioOutput: "HDMI"})
    Else
        pcmOutputs.Push({AudioOutput: "AnalogAudio"})
    End If
    vp.SetPcmAudioOutputs(pcmOutputs)
    If compOutputs.Count() > 0 Then
        vp.SetCompressedAudioOutputs(compOutputs)
    End If
    rect = CreateObject("roRectangle", zone.x, zone.y, zone.width, zone.height)
    vp.SetRectangle(rect)
    vp.SetVideoZOrder(zone.z_index)
    vp.PlayFile(vi)
    Print "[SF-HDMI] HDMI Input active"
    ' Return AA containing both objects so caller can keep them alive
    hdmi = {}
    hdmi.vp = vp
    hdmi.vi = vi
    Return hdmi
End Function

' -- CheckVersion --
Function CheckVersion(apiOrigin As String, screenToken As String, currentVersion As String) As Boolean
    result = false
    q = Chr(34)
    body = "{" + q + "screenId" + q + ":" + q + screenToken + q + "}"
    resp = HttpPost(apiOrigin + "/functions/screenVersionCheck", body)
    If resp = "" Then Return result
    data = ParseJson(resp)
    If data = Invalid Then Return result
    newVer = data.content_version
    If newVer <> Invalid And newVer <> "" And newVer <> currentVersion Then
        Print "[SF] Version changed -> " + newVer
        Return true
    End If
    Return result
End Function

' -- Main --
Sub Main()
    Print "[SF] ScreenFleet v12 starting"

    cfg = ReadConfig()
    If cfg = Invalid Then
        Print "[SF] FATAL: Cannot read config.json"
        Return
    End If

    token = cfg.screenToken
    apiOrigin = cfg.apiOrigin
    playerAppUrl = cfg.playerAppUrl

    Print "[SF] Token: " + token
    Print "[SF] API: " + apiOrigin
    Print "[SF] Player: " + playerAppUrl

    ' -- 1: Launch player IMMEDIATELY --
    ' v8 pattern: show first, do everything else after.
    ' This ensures no black screen on boot.
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, 1920, 1080)
    playerUrl = playerAppUrl + "/screen/" + token
    Print "[SF] Launching player: " + playerUrl
    hCfg = {url: playerUrl, javascript_enabled: true}
    h = CreateObject("roHtmlWidget", r, hCfg)
    h.SetPort(msgPort)
    h.Show()
    Print "[SF] Player shown. Now syncing content in background..."

    ' -- 2: Fetch payload and download media --
    ' Now that the player is visible, we can do blocking network calls.
    ' The player is already showing content from the live URL.
    payload = FetchPayload(apiOrigin, token)
    currentVersion = ""

    If payload <> Invalid Then
        Print "[SF] Syncing media and manifest..."
        DownloadMedia(payload.zones)
        SaveManifest(payload)
        If payload.content_version <> Invalid Then
            currentVersion = payload.content_version
        End If
    Else
        Print "[SF] No network - loading saved manifest"
        payload = LoadManifest()
        If payload <> Invalid Then
            If payload.content_version <> Invalid Then
                currentVersion = payload.content_version
            End If
        Else
            Print "[SF] WARNING: No manifest available - playing live URL only"
        End If
    End If

    ' -- 3: Activate HDMI zones --
    ' Keep hdmi objects in Main scope to prevent garbage collection.
    ' Using an array to hold all active HDMI zone objects.
    hdmiObjects = CreateObject("roArray", 4, false)

    If payload <> Invalid Then
        For Each zone In payload.zones
            If zone.content_source_type = "hdmi_input" Then
                hdmiObj = ActivateHdmiZone(zone)
                If hdmiObj <> Invalid Then
                    hdmiObjects.Push(hdmiObj)
                    Print "[SF-HDMI] Zone kept alive in Main scope"
                End If
            End If
        Next
    End If

    Print "[SF] Entering message loop. HDMI zones active=" + Str(hdmiObjects.Count())

    ' -- 4: Event loop --
    ' Use Wait(0,...) like v8 - blocks indefinitely, never starves widget.
    ' Version check only happens on each loop iteration after 60s elapsed.
    lastCheckSecs = CreateObject("roDateTime").AsSeconds()
    checkInterval = 60

    While true
        ' Wait indefinitely for next event (v8 pattern - critical)
        msg = Wait(0, msgPort)

        ' After each event, check if version poll interval elapsed
        nowSecs = CreateObject("roDateTime").AsSeconds()
        If (nowSecs - lastCheckSecs) >= checkInterval Then
            lastCheckSecs = nowSecs
            If currentVersion <> "" Then
                If CheckVersion(apiOrigin, token, currentVersion) Then
                    Print "[SF] New version detected - rebooting"
                    RebootSystem()
                    Return
                End If
            End If
        End If

        ' Handle widget events
        If Type(msg) = "roHtmlWidgetEvent" Then
            data = msg.GetData()
            If Type(data) = "roAssociativeArray" Then
                reason = data.reason
                If reason = "load-error" Then
                    Print "[SF] Player load error - retrying in 10s"
                    Sleep(10000)
                    h.SetUrl(playerUrl)
                Else If reason = "load-complete" Then
                    Print "[SF] Player loaded OK"
                End If
            End If
        End If
    End While
End Sub
