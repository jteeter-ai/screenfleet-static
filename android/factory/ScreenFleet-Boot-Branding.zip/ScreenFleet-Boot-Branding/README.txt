ScreenFleet boot branding for the ZX5M (Android 14)        v1.0 · Nov 12, 2026
=========================================================================

1. BOOT LOGO (the first image the TV shows after power-on, before Android starts)
   bootup-1920x1080.bmp   24-bit BMP, 1920x1080 - use this for the U-Boot logo (logo partition)
   bootup-1280x720.bmp    24-bit BMP, 1280x720  - only if your boot logo is output at 720p
   bootlogo-*.png         same images as PNG
   Background colour: #122849 (navy). Please also set any boot/no-signal background to #122849.

2. BOOT ANIMATION (plays while Android starts)
   bootanimation.zip      standard Android format, files STORED (no compression) - do not re-zip.
   Install as /product/media/bootanimation.zip  (or /system/media/bootanimation.zip on your build)
   desc.txt: 1920 1080 30 / "c 1 0 part0" (logo builds once, 2.6 s) / "p 0 0 part1" (loops until boot completes)
   The last frame matches the boot logo and the ScreenFleet Player's own start screen,
   so the TV goes logo -> animation -> player with no jump.
   No boot sound.

   ScreenFleet-boot-animation-preview.mp4 is a preview only - do not install it.

3. Please send a short phone video of a sample unit booting so we can approve it.

Logo artwork (c) Legion LED Trucks, LLC. Confidential - for units ordered by Legion LED Trucks, LLC only.
