ScreenFleet V2 BrightSign Package
==================================
Asset:      XT1145 Spare
Screen:     Home Outdoor TV
Resolution: 640x384
Player:     XT1145
API Origin: https://app.screenfleet.io
Generated:  Tue, 12 May 2026 00:05:52 GMT

SETUP
-----
1. Format SD card as FAT32 (16GB+ recommended)
2. Extract ALL files to the ROOT of the SD card
3. Insert SD card into BrightSign player and power on

FILES
-----
autozip.brs  - BSN.cloud extraction trigger (do not rename)
autorun.brs  - BrightSign boot script (do not rename)
sf-setup.html- First-boot provisioning page (launched when no token found)
index.html   - Player shell (launched after provisioning)
player.js    - V2 local-first playback engine
sw.js        - Service worker (cache-first image delivery)
config.json  - Asset configuration (assetId, API origin, no screenId)
README.txt   - This file

PLAYBACK BEHAVIOR
-----------------
- On first boot: fetches V2 screenPayload from https://app.screenfleet.io
- Downloads all media files to browser cache (via service worker)
- Subsequent boots: plays from cache immediately, checks for updates in background
- If network unavailable: plays cached payload indefinitely
- Version polling: every 60 seconds (checks content_version only)
- On version change: downloads only new/changed files (by checksum)

PAYLOAD API
-----------
Version check: POST https://app.screenfleet.io/functions/screenVersionCheck { screenId }
Full payload:  POST https://app.screenfleet.io/functions/screenPayload      { screenId }

RUNTIME ARCHITECTURE
---------------------
This package is STRICTLY SCREEN-SCOPED.
At runtime, player.js calls: screenPayload({ screenId: '69d24c31b8a684cebacd8fef' })
The HTML canvas and BrightScript HDMI bridge both use this SAME payload.
One zone manifest, not two. If HDMI is missing, check publishAsset RuntimeZones.
See [Player-MANIFEST] logs on device for full zone diagnostics.

DO NOT test HDMI via BrightAuthor HTML feed (Mode B). Only this package (Mode A) can
activate roVideoPlayer.PlayFile(roVideoInput).

SCREEN ID
---------
69d24c31b8a684cebacd8fef

ASSET ID
--------
69c206e32a609433ec805b6d
