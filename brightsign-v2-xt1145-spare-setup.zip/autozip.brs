' ScreenFleet autozip.brs
' This file triggers BrightSign OS to extract the autorun.zip on first boot.
' After extraction the player reboots and executes autorun.brs.
' DO NOT RENAME THIS FILE — BrightSign OS looks for autozip.brs inside the zip.
Sub Main()
End Sub
