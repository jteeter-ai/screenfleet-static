'use strict';
/**
 * A pretend VX controller for testing without hardware.
 * Speaks the real binary protocol on TCP, keeps byte-addressable register memory
 * (one for the controller, one shared by the receiving cards), and can be told
 * to reject registers or stay silent so error paths get exercised.
 *
 * Like a real controller in auto-brightness mode, it overrides manual brightness
 * writes with the value from its light-sensor curve until switched to manual.
 *
 *   node sim/vx-simulator.js --model vx600 --port 5200
 */
const net = require('net');
const { Code, DeviceType, parseFrame, buildResponse, REQ_HEADER } = require('../lib/protocol');
const { REG } = require('../lib/registers');

const MODEL_ID_BYTES = { vx600: [0x0e, 0x62], vx1000: [0x0c, 0x62], vx400: [0x11, 0x62] };

class Memory {
  constructor() { this.bytes = new Map(); }
  write(addr, data) { for (let i = 0; i < data.length; i++) this.bytes.set(addr + i, data[i]); }
  read(addr, len) { const b = Buffer.alloc(len); for (let i = 0; i < len; i++) b[i] = this.bytes.get(addr + i) ?? 0; return b; }
}

class VxSimulator {
  constructor({
    model = 'vx600', firmware = [4, 6, 2, 0], rejectRegisters = [], silentRegisters = [],
    autoMode = 'manual', sensorLux = 800, autoBrightnessRaw = 0x40, sensorPresent = true,
  } = {}) {
    this.model = model;
    this.controller = new Memory();
    this.receivers = new Memory();
    this.rejectRegisters = new Set(rejectRegisters);
    this.silentRegisters = new Set(silentRegisters);
    this.autoBrightnessRaw = autoBrightnessRaw; // what the stored curve yields at the current light level
    this.log = [];
    this.controller.write(REG.MODEL_ID, MODEL_ID_BYTES[model] || [0x00, 0x00]);
    this.controller.write(REG.FIRMWARE, firmware);
    this.controller.write(REG.INPUT_SIGNAL, [0x01]);
    this.controller.write(REG.OUTPUT_MODE, [0x03, 0x00]);
    this.controller.write(REG.AUTO_MODE, [autoMode === 'auto' ? 0x7d : 0xff]);
    // A recognisable fake curve after the mode byte, so snapshot/diff can be exercised.
    this.controller.write(REG.AUTO_BLOCK + 1, [0x03, 0x01, 0x00, 0x01, 0x64, 0x00, 0x05, 0x88, 0x13, 0x64]);
    const lux = sensorPresent ? sensorLux : 0xffff;
    this.controller.write(REG.SENSOR_LUX, [lux & 0xff, (lux >> 8) & 0xff]);
    this.controller.write(0x02000028, [0x00, 0x00, 0x00, 0x00]); // a start X/Y candidate
    this.receivers.write(REG.BRIGHTNESS, [0xff, 0xff, 0xff, 0xff, 0xff]);
    this.receivers.write(REG.RX_BLACK, [0x00, 0x00, 0x00]);
  }

  get autoOn() { return this.controller.read(REG.AUTO_MODE, 1)[0] === 0x7d; }

  /** Current simple view of the "screen" for assertions. */
  state() {
    const rx = this.receivers.read(REG.RX_BLACK, 3);
    return {
      brightness_raw: this.receivers.read(REG.BRIGHTNESS, 1)[0],
      receiver_black: rx[0] === 0xff,
      receiver_freeze: rx[2] === 0xff,
      output_mode: this.controller.read(REG.OUTPUT_MODE, 2),
      preset: this.controller.bytes.has(REG.PRESET_RECALL) ? this.controller.read(REG.PRESET_RECALL, 1)[0] + 1 : null,
      layer1_source: this.controller.bytes.has(REG.LAYER_SOURCE[0]) ? this.controller.read(REG.LAYER_SOURCE[0], 1)[0] : null,
      auto_mode: this.autoOn,
    };
  }

  /** Simulate a change made in NovaLCT (for snapshot/diff tests). */
  setController(addr, bytes) { this.controller.write(addr, bytes); }

  handle(req) {
    this.log.push({ code: req.code, deviceType: req.deviceType, register: req.register, data: req.data });
    if (this.silentRegisters.has(req.register)) return null;
    if (this.rejectRegisters.has(req.register)) return buildResponse({ request: req, ack: 0x02 });
    const mem = req.deviceType === DeviceType.RECEIVING_CARD ? this.receivers : this.controller;
    if (req.code === Code.WRITE) {
      mem.write(req.register, req.data);
      return buildResponse({ request: req, ack: 0 });
    }
    // In auto mode the controller keeps driving brightness from its light sensor.
    if (this.autoOn) this.receivers.write(REG.BRIGHTNESS, [this.autoBrightnessRaw]);
    return buildResponse({ request: req, ack: 0, data: mem.read(req.register, req.length) });
  }

  listen(port = 0, host = '127.0.0.1') {
    return new Promise((resolve) => {
      this.server = net.createServer((sock) => {
        let buf = Buffer.alloc(0);
        sock.on('data', (chunk) => {
          buf = Buffer.concat([buf, chunk]);
          for (;;) {
            const { frame, rest } = parseFrame(buf, REQ_HEADER);
            buf = rest;
            if (!frame) break;
            const resp = this.handle(frame);
            if (resp) sock.write(resp);
          }
        });
        sock.on('error', () => {});
      });
      this.server.listen(port, host, () => resolve(this.server.address().port));
    });
  }

  close() { return new Promise((r) => (this.server ? this.server.close(() => r()) : r())); }
}

if (require.main === module) {
  const args = process.argv.slice(2);
  const get = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
  const sim = new VxSimulator({ model: get('--model', 'vx600'), autoMode: get('--auto', 'manual') });
  sim.listen(Number(get('--port', 5200)), get('--host', '127.0.0.1')).then((p) => {
    console.log(`Simulated ${sim.model.toUpperCase()} listening on port ${p}`);
    setInterval(() => console.log(JSON.stringify(sim.state())), 5000);
  });
}

module.exports = { VxSimulator };
