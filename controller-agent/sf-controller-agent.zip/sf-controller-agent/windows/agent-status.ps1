<#
  ScreenFleet Controller Agent - show whether it is running and the latest log lines.
#>
$TaskName = 'ScreenFleet Controller Agent'
$AgentDir = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
$LogFile  = Join-Path $AgentDir 'logs\agent.log'

$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if (-not $task) {
  Write-Host 'Auto-start is NOT installed. Run "Install auto-start.bat".' -ForegroundColor Yellow
} else {
  $info = Get-ScheduledTaskInfo -TaskName $TaskName
  Write-Host "Auto-start installed. State: $($task.State)"
  Write-Host "Last started: $($info.LastRunTime)   Last result: $($info.LastTaskResult)"
}
$procs = Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*agent.js*' }
Write-Host "Agent processes running: $(@($procs).Count)"
if (@($procs).Count -gt 1) { Write-Host 'WARNING: more than one agent is running. Close any start-agent.bat windows.' -ForegroundColor Yellow }
if (Test-Path $LogFile) {
  Write-Host ''
  Write-Host "--- last 25 lines of $LogFile ---"
  Get-Content $LogFile -Tail 25
} else {
  Write-Host 'No log file yet.'
}
Read-Host 'Press Enter to close'
