<#
  ScreenFleet Controller Agent - install auto-start on Windows.

  Creates a Windows scheduled task that:
    * starts the agent when the PC powers on (no one has to log in)
    * runs as the built-in SYSTEM account (works with the network and USB)
    * restarts it every minute if it ever stops
    * writes its log to  <agent folder>\logs\agent.log

  Run by double-clicking "Install auto-start.bat" in the agent folder.
#>
param([switch]$NoStart)

$ErrorActionPreference = 'Stop'
$TaskName = 'ScreenFleet Controller Agent'

# --- Re-launch as administrator if needed -------------------------------------
$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host 'Asking Windows for administrator permission...'
  $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
  if ($NoStart) { $argList += '-NoStart' }
  Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList
  exit
}

function Fail($msg) {
  Write-Host ''
  Write-Host "ERROR: $msg" -ForegroundColor Red
  Write-Host ''
  Read-Host 'Press Enter to close'
  exit 1
}

$AgentDir = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
$AgentJs  = Join-Path $AgentDir 'agent.js'
$Config   = Join-Path $AgentDir 'sf-controller-agent.json'
$LogDir   = Join-Path $AgentDir 'logs'
$LogFile  = Join-Path $LogDir 'agent.log'

Write-Host ''
Write-Host 'ScreenFleet Controller Agent - auto-start setup' -ForegroundColor Cyan
Write-Host "Agent folder: $AgentDir"

# --- Checks ---------------------------------------------------------------------
if (-not (Test-Path $AgentJs)) { Fail "agent.js not found in $AgentDir. Run this from inside the unzipped agent folder." }
# Config: use the one in the agent folder, or pick up the newest one downloaded from ScreenFleet.
if (-not (Test-Path $Config)) {
  $dl = @()
  foreach ($d in @("$env:USERPROFILE\Downloads", "$env:USERPROFILE\Desktop", "$env:USERPROFILE\OneDrive\Downloads", "$env:USERPROFILE\OneDrive\Desktop")) {
    if (Test-Path $d) { $dl += Get-ChildItem -Path $d -Filter 'sf-controller-agent*.json' -ErrorAction SilentlyContinue }
  }
  $newest = $dl | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($newest) {
    Copy-Item $newest.FullName $Config -Force
    Write-Host "Using config from $($newest.FullName)"
  }
}
if (-not (Test-Path $Config))  { Fail "sf-controller-agent.json is missing. In ScreenFleet open Controls > (this truck) > LED controller > Setup, click 'Generate agent key' on this PC (it saves to Downloads), then run this again." }
try { $null = Get-Content $Config -Raw | ConvertFrom-Json } catch { Fail "sf-controller-agent.json is not valid JSON: $($_.Exception.Message)" }

$node = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $node) {
  foreach ($p in @("$env:ProgramFiles\nodejs\node.exe", "${env:ProgramFiles(x86)}\nodejs\node.exe")) {
    if (Test-Path $p) { $node = Get-Item $p; break }
  }
}
if (-not $node) {
  # Install Node.js 20 LTS (official installer from nodejs.org, checksum verified).
  Write-Host 'Node.js is not installed - downloading Node.js 20 LTS from nodejs.org...'
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $base = 'https://nodejs.org/dist/latest-v20.x/'
    $sums = (Invoke-WebRequest -UseBasicParsing ($base + 'SHASUMS256.txt')).Content
    $line = ($sums -split "`n") | Where-Object { $_ -match 'node-v20\.[0-9.]+-x64\.msi' } | Select-Object -First 1
    $msi = ($line -split '\s+')[1]
    $dst = Join-Path $env:TEMP $msi
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -UseBasicParsing ($base + $msi) -OutFile $dst
    $hash = (Get-FileHash $dst -Algorithm SHA256).Hash.ToLower()
    if ($line -notmatch $hash) { throw "checksum mismatch for $msi" }
    Write-Host "Installing $msi (silent)..."
    Start-Process msiexec.exe -Wait -ArgumentList '/i', "`"$dst`"", '/qn', '/norestart'
  } catch { Fail "Could not install Node.js automatically ($($_.Exception.Message)). Install Node.js 20 LTS from https://nodejs.org and run this again." }
  foreach ($p in @("$env:ProgramFiles\nodejs\node.exe")) { if (Test-Path $p) { $node = Get-Item $p } }
  if (-not $node) { Fail 'Node.js install did not complete. Install Node.js 20 LTS from https://nodejs.org and run this again.' }
}
$NodeExe = if ($node.Source) { $node.Source } else { $node.FullName }
$nodeVersion = & $NodeExe --version
Write-Host "Node.js: $NodeExe ($nodeVersion)"
if ([int]($nodeVersion.TrimStart('v').Split('.')[0]) -lt 18) { Fail "Node.js $nodeVersion is too old. Install Node.js 20 LTS or newer." }

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

# --- Remove any older copy -----------------------------------------------------
$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
  Write-Host 'Replacing the existing auto-start task...'
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}
# Stop a copy started by hand with start-agent.bat, so two agents don't fight over the controller.
Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*agent.js*' } |
  ForEach-Object { Write-Host "Stopping a running agent (pid $($_.ProcessId))"; Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

# --- Create the task -----------------------------------------------------------
$action = New-ScheduledTaskAction -Execute $NodeExe `
  -Argument "`"$AgentJs`" --config `"$Config`" --log `"$LogFile`"" `
  -WorkingDirectory $AgentDir

$trigger = New-ScheduledTaskTrigger -AtStartup
$trigger.Delay = 'PT30S'   # give the network a moment to come up after boot

$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest

$settings = New-ScheduledTaskSettingsSet `
  -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -StartWhenAvailable `
  -RestartCount 9999 -RestartInterval (New-TimeSpan -Minutes 1) `
  -ExecutionTimeLimit ([TimeSpan]::Zero) `
  -MultipleInstances IgnoreNew

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
  -Description 'Lets ScreenFleet control the NovaStar LED controller on this truck. Installed by install-autostart.ps1.' | Out-Null

Write-Host 'Auto-start task created.' -ForegroundColor Green

if (-not $NoStart) {
  Start-ScheduledTask -TaskName $TaskName
  Write-Host 'Agent started. Waiting for its first check-in...'
  Start-Sleep -Seconds 8
  $info = Get-ScheduledTaskInfo -TaskName $TaskName
  $state = (Get-ScheduledTask -TaskName $TaskName).State
  Write-Host "Task state: $state"
  if (Test-Path $LogFile) {
    Write-Host ''
    Write-Host '--- last log lines ---'
    Get-Content $LogFile -Tail 12
  }
}

# --- Sleep check -----------------------------------------------------------------
$standby = (powercfg /query SCHEME_CURRENT SUB_SLEEP STANDBYIDLE 2>$null | Select-String 'Current AC Power Setting Index' | ForEach-Object { ($_ -split ':')[-1].Trim() } | Select-Object -First 1)
if ($standby -and ([Convert]::ToInt32($standby, 16) -gt 0)) {
  Write-Host ''
  Write-Host 'NOTE: this PC is set to go to sleep when idle. While it sleeps ScreenFleet cannot reach the controller.' -ForegroundColor Yellow
  Write-Host '      To keep it awake on AC power run:  powercfg /change standby-timeout-ac 0' -ForegroundColor Yellow
}

Write-Host ''
Write-Host 'Done. The agent will now start by itself every time this PC turns on.' -ForegroundColor Green
Write-Host "Log file: $LogFile"
Write-Host 'To remove it later, run "Remove auto-start.bat".'
Read-Host 'Press Enter to close'
