# ScreenFleet Controller Agent

This small program runs on the truck's Windows PC. It lets ScreenFleet control the NovaStar VX600 / VX1000 / VX400 on that truck: brightness, auto/manual brightness, black/freeze/normal, preset recall, input switching and test patterns. After every change it reads the controller back, so ScreenFleet shows what the screen is actually doing.

**NovaLCT is not needed.** The agent talks to the controller directly. Keep NovaLCT closed while the agent runs, because over USB only one program can hold the controller at a time. Open NovaLCT only for occasional setup work (screen mapping, receiving cards, firmware), then close it again.

The agent only makes **outbound** HTTPS calls to ScreenFleet. You don't need to open any ports on the truck.

## Quick setup (most trucks)

1. In ScreenFleet, open **Controls**, pick the truck, open **LED controller → Setup**, enter the controller's model and IP, and click **Save**.
2. On the truck PC, click **Download agent** on that Setup screen and unzip it to `C:\ScreenFleet\controller-agent`.
3. Still on the truck PC, click **Generate agent key**. The config file saves to Downloads.
4. Close NovaLCT, then double-click **Install auto-start.bat** and click **Yes**. It installs Node.js 20 if needed, picks up the config from Downloads, and starts the agent.

The truck shows **Online** in ScreenFleet within about a minute.

For USB control instead of the network, also run `npm install` in the agent folder once (adds USB support).

## Step 1: Bench test (no ScreenFleet involved)

Close NovaLCT first.

```
node cli.js discover                          find controllers on the LAN, list COM ports
node cli.js probe  --host 192.168.0.10        read everything + safe brightness re-write
node cli.js status --host 192.168.0.10
node cli.js lux    --host 192.168.0.10        light sensor present? its reading + auto/manual mode
node cli.js brightness 40 --host 192.168.0.10
node cli.js mode black  --host 192.168.0.10   then: mode normal
node cli.js preset 1    --host 192.168.0.10
node cli.js pattern red --host 192.168.0.10   then: pattern off
node cli.js input 1 hdmi1 --host 192.168.0.10
node cli.js automode manual --host 192.168.0.10 --unverified    then: automode auto --unverified
```

To use USB instead of the network, replace `--host <ip>` with `--usb COM3`. `discover` shows which COM port the controller is on.

Add `--debug` to any command to print the raw bytes. That's what I need if something doesn't respond.

### Finding where a setting lives (snapshot + diff)

These commands only read from the controller. They never write.

```
node cli.js snapshot before.json --host 192.168.0.10
   ...open NovaLCT, change ONE setting (e.g. screen start X to 100), save it to the controller, close NovaLCT...
node cli.js snapshot after.json  --host 192.168.0.10
node cli.js diff before.json after.json
```

The diff lists exactly which bytes changed. Send me the two .json files.

## Step 2: Connect to ScreenFleet

1. In ScreenFleet, go to **Assets**, click **Controller** on the truck, and open **Setup**.
2. Pick the model, choose Network or USB, enter the IP or COM port, and click **Save**.
3. Click **Generate agent key**. Save the config it shows as `sf-controller-agent.json` in this folder. There's an example file next to it.
4. To try it by hand, double-click `start-agent.bat`. The Controller panel should switch to **Online** within about 15 seconds. Close that window when you're done trying it.

Settings under `"controller"` in `sf-controller-agent.json` override what's saved in ScreenFleet. That's useful when the truck's IP is different from what was entered.

## Step 3: Start automatically at power-on

Double-click **`Install auto-start.bat`** and click **Yes** when Windows asks for permission. That's it. From then on the agent:

- starts by itself every time the PC turns on, **before anyone logs in**
- restarts itself within a minute if it ever stops
- writes its log to `logs\agent.log`, keeping the latest ~5 MB

To check it: **`Agent status.bat`**. To turn it off: **`Remove auto-start.bat`**.

**Keep the PC awake.** While it sleeps, ScreenFleet can't reach the controller. The installer warns you if the PC is set to sleep.

## For developers

```
npm test          32 automated tests against a simulated VX (no hardware)
npm run sim       a pretend VX600 on port 5200 you can point cli.js at
```
