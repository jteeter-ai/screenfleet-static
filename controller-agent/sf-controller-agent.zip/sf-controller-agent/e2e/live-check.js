'use strict';
/**
 * Live end-to-end check against the real ScreenFleet endpoint, with a simulated VX
 * standing in for the hardware.
 *
 *   node e2e/live-check.js keygen            -> writes .e2e-key, prints ONLY its SHA-256 hash
 *   node e2e/live-check.js run [seconds]     -> starts a simulated VX600 and runs the agent against ScreenFleet
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { VxSimulator } = require('../sim/vx-simulator');
const { Agent } = require('../agent');
const { CloudClient } = require('../lib/cloud');

const KEY_FILE = path.join(__dirname, '.e2e-key');
const CLOUD = process.env.SF_CLOUD_URL || 'https://app.screenfleet.io';

async function main() {
  const [mode, secs] = process.argv.slice(2);
  if (mode === 'keygen') {
    const key = 'sfc_' + crypto.randomBytes(24).toString('hex');
    fs.writeFileSync(KEY_FILE, key);
    console.log('hash', crypto.createHash('sha256').update(key).digest('hex'));
    console.log('prefix', key.slice(0, 10));
    return;
  }
  if (mode === 'run') {
    const key = fs.readFileSync(KEY_FILE, 'utf8').trim();
    const sim = new VxSimulator({ model: process.env.SIM_MODEL || 'vx600' });
    const port = await sim.listen(0);
    const cloud = new CloudClient({ cloudUrl: CLOUD, agentKey: key, agentVersion: 'e2e' });
    const agent = new Agent({
      config: { controller: { connection_type: 'tcp', host: '127.0.0.1', port }, command_timeout_ms: 1000 },
      cloud,
      log: (...m) => console.log(new Date().toISOString().slice(11, 19), ...m),
    });
    const end = Date.now() + Number(secs || 20) * 1000;
    let n = 0;
    while (Date.now() < end) {
      const wait = await agent.cycle();
      n++;
      console.log(`cycle ${n}: next in ${wait} ms, poll=${agent.remote.next_poll_ms}, sim=${JSON.stringify(sim.state())}`);
      await new Promise((r) => setTimeout(r, Math.min(wait, 3000)));
    }
    await agent.stop();
    await sim.close();
    return;
  }
  console.log('usage: keygen | run [seconds]');
}

main().catch((e) => { console.error('E2E error:', e.message, e.status || ''); process.exit(1); });
