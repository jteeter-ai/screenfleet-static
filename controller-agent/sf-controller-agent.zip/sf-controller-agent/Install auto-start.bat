@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\install-autostart.ps1"
