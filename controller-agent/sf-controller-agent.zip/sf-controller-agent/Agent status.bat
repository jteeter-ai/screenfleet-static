@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\agent-status.ps1"
