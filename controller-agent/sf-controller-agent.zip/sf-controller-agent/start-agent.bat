@echo off
title ScreenFleet Controller Agent
cd /d "%~dp0"
if not exist sf-controller-agent.json (
  echo sf-controller-agent.json is missing. Copy sf-controller-agent.example.json, paste your agent key, and try again.
  pause
  exit /b 1
)
:loop
node agent.js --config sf-controller-agent.json
echo Agent stopped. Restarting in 10 seconds...
timeout /t 10 /nobreak >nul
goto loop
