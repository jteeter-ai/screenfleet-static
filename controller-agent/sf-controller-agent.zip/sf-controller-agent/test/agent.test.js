'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { VxSimulator } = require('../sim/vx-simulator');
const { Agent } = require('../agent');

/** Fake ScreenFleet: hands out queued commands once, records what the agent reports. */
function fakeCloud({ controller, commands = [], failTimes = 0 }) {
  const calls = [];
  let queue = [...commands];
  let fails = failTimes;
  return {
    calls,
    push(cmd) { queue.push(cmd); },
    async sync(body) {
      calls.push(JSON.parse(JSON.stringify(body)));
      if (fails > 0) { fails--; throw new Error('network down'); }
      const out = { ok: true, controller, commands: queue, next_poll_ms: 5000, status_interval_ms: 60000 };
      queue = [];
      return out;
    },
  };
}

async function setup(simOpts, controller, commands, cloudOpts = {}) {
  const sim = new VxSimulator(simOpts);
  const port = await sim.listen(0);
  const cloud = fakeCloud({ controller: { connection_type: 'tcp', host: '127.0.0.1', port, ...controller }, commands, ...cloudOpts });
  const agent = new Agent({ config: { command_timeout_ms: 500 }, cloud, log: () => {} });
  return { sim, cloud, agent, done: async () => { await agent.stop(); await sim.close(); } };
}

const future = () => new Date(Date.now() + 60000).toISOString();

test('agent runs queued commands, then reports results and fresh status immediately', async () => {
  const t = await setup({ model: 'vx600' }, { model: 'vx600' }, [
    { id: 'c1', command_type: 'set_brightness', params: { percent: 30 }, expires_at: future() },
    { id: 'c2', command_type: 'set_display_mode', params: { mode: 'black' }, expires_at: future() },
  ]);
  try {
    // First cycle: agent has no remote config yet, so status read fails; it syncs and receives config + commands.
    const w1 = await t.agent.cycle();
    assert.strictEqual(w1, 0, 'reports back right away after running commands');
    assert.strictEqual(t.sim.state().brightness_raw, 77);
    assert.strictEqual(t.sim.state().receiver_black, true);
    await t.agent.cycle();
    const report = t.cloud.calls[1];
    assert.deepStrictEqual(report.acks.map((a) => [a.command_id, a.ok]), [['c1', true], ['c2', true]]);
    assert.strictEqual(report.status.display_mode, 'black');
    assert.strictEqual(report.status.model_detected, 'vx600');
  } finally { await t.done(); }
});

test('expired commands are not applied to the screen', async () => {
  const t = await setup({ model: 'vx1000' }, { model: 'vx1000' }, [
    { id: 'old', command_type: 'set_brightness', params: { percent: 5 }, expires_at: new Date(Date.now() - 1000).toISOString() },
  ]);
  try {
    await t.agent.cycle();
    await t.agent.cycle();
    assert.strictEqual(t.sim.state().brightness_raw, 255, 'brightness untouched');
    const ack = t.cloud.calls[1].acks[0];
    assert.strictEqual(ack.ok, false);
    assert.strictEqual(ack.expired, true);
  } finally { await t.done(); }
});

test('results are kept and re-sent if ScreenFleet is unreachable', async () => {
  const t = await setup({ model: 'vx600' }, { model: 'vx600' }, [
    { id: 'c1', command_type: 'recall_preset', params: { preset: 2 }, expires_at: future() },
  ]);
  try {
    await t.agent.cycle(); // gets + runs command
    t.cloud.sync = (() => { const real = t.cloud.sync; let n = 1; return async (b) => { if (n-- > 0) { t.cloud.calls.push(b); throw new Error('network down'); } return real.call(t.cloud, b); }; })();
    const wait = await t.agent.cycle(); // fails
    assert.ok(wait >= 10000, 'backs off');
    await t.agent.cycle(); // succeeds
    const last = t.cloud.calls[t.cloud.calls.length - 1];
    assert.deepStrictEqual(last.acks.map((a) => a.command_id), ['c1']);
  } finally { await t.done(); }
});

test('a command id is never executed twice even if ScreenFleet re-sends it', async () => {
  const t = await setup({ model: 'vx1000' }, { model: 'vx1000' }, [
    { id: 'dup', command_type: 'recall_preset', params: { preset: 4 }, expires_at: future() },
  ]);
  try {
    await t.agent.cycle();
    t.cloud.push({ id: 'dup', command_type: 'recall_preset', params: { preset: 4 }, expires_at: future() });
    const writesBefore = t.sim.log.filter((l) => l.code === 1).length;
    await t.agent.cycle();
    const writesAfter = t.sim.log.filter((l) => l.code === 1).length;
    assert.strictEqual(writesAfter, writesBefore);
  } finally { await t.done(); }
});

test('unreachable controller is reported as a connection error, commands fail cleanly', async () => {
  const cloud = fakeCloud({
    controller: { connection_type: 'tcp', host: '127.0.0.1', port: 1, model: 'vx600' },
    commands: [{ id: 'x', command_type: 'set_brightness', params: { percent: 50 }, expires_at: future() }],
  });
  const agent = new Agent({ config: { command_timeout_ms: 300 }, cloud, log: () => {} });
  try {
    await agent.cycle();
    await agent.cycle();
    const report = cloud.calls[1];
    assert.strictEqual(report.acks[0].ok, false);
    assert.ok(report.connection.error, 'connection error reported');
  } finally { await agent.stop(); }
});

test('local config overrides the connection ScreenFleet has on file', async () => {
  const agent = new Agent({ config: { controller: { host: '10.0.0.9' } }, cloud: {}, log: () => {} });
  agent.remote = { controller: { connection_type: 'tcp', host: '192.168.1.5', model: 'vx600' } };
  const c = agent.connection();
  assert.strictEqual(c.host, '10.0.0.9');
  assert.strictEqual(c.model, 'vx600');
});
