'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { VxSimulator } = require('../sim/vx-simulator');
const { TcpTransport } = require('../lib/transports');
const { NovaStarClient } = require('../lib/client');
const { Controller } = require('../lib/controller');
const { REG } = require('../lib/registers');

async function rig(simOpts = {}, ctlOpts = {}) {
  const sim = new VxSimulator(simOpts);
  const port = await sim.listen(0);
  const client = new NovaStarClient(new TcpTransport({ host: '127.0.0.1', port }), { timeoutMs: 500 });
  const ctl = new Controller(client, ctlOpts);
  return { sim, client, ctl, done: async () => { await client.close(); await sim.close(); } };
}

test('identifies a VX600 and reads status', async () => {
  const r = await rig({ model: 'vx600' }, { model: 'vx600' });
  try {
    const s = await r.ctl.getStatus();
    assert.strictEqual(s.model_detected, 'vx600');
    assert.strictEqual(s.firmware, '4.6.2.0');
    assert.strictEqual(s.brightness_percent, 100);
    assert.strictEqual(s.display_mode, 'normal');
    assert.strictEqual(s.model_mismatch, false);
    assert.deepStrictEqual(s.errors, {});
  } finally { await r.done(); }
});

test('flags a model mismatch (configured VX1000, device is VX600)', async () => {
  const r = await rig({ model: 'vx600' }, { model: 'vx1000' });
  try {
    const s = await r.ctl.getStatus();
    assert.strictEqual(s.model_mismatch, true);
    assert.strictEqual(r.ctl.model, 'vx600', 'detected model wins');
  } finally { await r.done(); }
});

test('sets brightness and confirms by read-back', async () => {
  const r = await rig({ model: 'vx1000' }, { model: 'vx1000' });
  try {
    const res = await r.ctl.setBrightness(40);
    assert.strictEqual(r.sim.state().brightness_raw, 102);
    assert.strictEqual(res.confirmed, true);
    assert.ok(Math.abs(res.brightness_percent - 40) <= 0.5);
    await assert.rejects(() => r.ctl.setBrightness(140), /0-100/);
  } finally { await r.done(); }
});

test('VX600 black/freeze use receiver registers and normal clears everything', async () => {
  const r = await rig({ model: 'vx600' }, { model: 'vx600' });
  try {
    await r.ctl.setDisplayMode('black');
    assert.strictEqual(r.sim.state().receiver_black, true);
    assert.strictEqual((await r.ctl.getStatus()).display_mode, 'black');
    await r.ctl.setDisplayMode('normal');
    assert.strictEqual(r.sim.state().receiver_black, false);
    await r.ctl.setDisplayMode('freeze');
    assert.strictEqual(r.sim.state().receiver_freeze, true);
    await r.ctl.setDisplayMode('normal');
    assert.strictEqual(r.sim.state().receiver_freeze, false);
    assert.deepStrictEqual([...r.sim.state().output_mode], [0x03, 0x00]);
  } finally { await r.done(); }
});

test('VX1000 black uses the controller output-mode register', async () => {
  const r = await rig({ model: 'vx1000' }, { model: 'vx1000' });
  try {
    await r.ctl.setDisplayMode('black');
    assert.deepStrictEqual([...r.sim.state().output_mode], [0x05, 0x00]);
    await r.ctl.setDisplayMode('normal');
    assert.deepStrictEqual([...r.sim.state().output_mode], [0x03, 0x00]);
  } finally { await r.done(); }
});

test('normal still succeeds if the controller rejects the output-mode register', async () => {
  const r = await rig({ model: 'vx600', rejectRegisters: [REG.OUTPUT_MODE] }, { model: 'vx600' });
  try {
    await r.ctl.setDisplayMode('black');
    await r.ctl.setDisplayMode('normal');
    assert.strictEqual(r.sim.state().receiver_black, false);
  } finally { await r.done(); }
});

test('recalls presets and switches inputs', async () => {
  const r = await rig({ model: 'vx1000' }, { model: 'vx1000' });
  try {
    await r.ctl.recallPreset(3);
    assert.strictEqual(r.sim.state().preset, 3);
    await assert.rejects(() => r.ctl.recallPreset(11), /1-10/);
    await r.ctl.setInput(1, 'hdmi2');
    assert.strictEqual(r.sim.state().layer1_source, 1);
    await assert.rejects(() => r.ctl.setInput(1, 'vga'), /Unknown source/);
  } finally { await r.done(); }
});

test('rejected writes surface as clear errors', async () => {
  const r = await rig({ model: 'vx1000', rejectRegisters: [REG.PRESET_RECALL] }, { model: 'vx1000' });
  try {
    await assert.rejects(() => r.ctl.recallPreset(1), /rejected the command/);
  } finally { await r.done(); }
});

test('silent controller times out instead of hanging', async () => {
  const r = await rig({ model: 'vx1000', silentRegisters: [REG.PRESET_RECALL] }, { model: 'vx1000' });
  try {
    await assert.rejects(() => r.ctl.recallPreset(1), /did not answer/);
    // The client recovers for the next command.
    await r.ctl.setBrightness(10);
  } finally { await r.done(); }
});

test('VX400 commands are blocked until verified, allowed in hardware-test mode', async () => {
  const r = await rig({ model: 'vx400' }, { model: 'vx400' });
  try {
    await assert.rejects(() => r.ctl.setBrightness(50), /not been verified/);
    r.ctl.allowUnverified = true;
    await r.ctl.setBrightness(50);
    assert.strictEqual(r.sim.state().brightness_raw, 128);
  } finally { await r.done(); }
});

test('run() dispatches ScreenFleet command objects', async () => {
  const r = await rig({ model: 'vx600' }, { model: 'vx600' });
  try {
    await r.ctl.run('set_test_pattern', { pattern: 'red' });
    assert.deepStrictEqual([...r.sim.state().output_mode], [0x06, 0x01]);
    await r.ctl.run('set_test_pattern', { pattern: 'off' });
    assert.deepStrictEqual([...r.sim.state().output_mode], [0x03, 0x00]);
    await assert.rejects(() => r.ctl.run('format_disk', {}), /Unknown command/);
  } finally { await r.done(); }
});
