'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { VxSimulator } = require('../sim/vx-simulator');
const { TcpTransport } = require('../lib/transports');
const { NovaStarClient } = require('../lib/client');
const { Controller, diffSnapshots } = require('../lib/controller');
const { REG } = require('../lib/registers');

async function rig(simOpts = {}, ctlOpts = {}) {
  const sim = new VxSimulator(simOpts);
  const port = await sim.listen(0);
  const client = new NovaStarClient(new TcpTransport({ host: '127.0.0.1', port }), { timeoutMs: 500 });
  const ctl = new Controller(client, ctlOpts);
  return { sim, ctl, done: async () => { await client.close(); await sim.close(); } };
}

test('status reports brightness mode and sensor lux', async () => {
  const r = await rig({ model: 'vx600', autoMode: 'auto', sensorLux: 1234 }, { model: 'vx600' });
  try {
    const s = await r.ctl.getStatus();
    assert.strictEqual(s.brightness_mode, 'auto');
    assert.strictEqual(s.sensor_lux, 1234);
  } finally { await r.done(); }
});

test('brightness mode switching is locked until verified, then works with read-back', async () => {
  const r = await rig({ model: 'vx1000', autoMode: 'auto' }, { model: 'vx1000' });
  try {
    await assert.rejects(() => r.ctl.setBrightnessMode('manual'), /not been verified/);
    r.ctl.allowUnverified = true;
    const res = await r.ctl.setBrightnessMode('manual');
    assert.deepStrictEqual(res, { brightness_mode: 'manual', confirmed: true });
    assert.strictEqual(r.sim.state().auto_mode, false);
    await r.ctl.setBrightnessMode('auto');
    assert.strictEqual(r.sim.state().auto_mode, true);
    await assert.rejects(() => r.ctl.setBrightnessMode('schedule'), /auto or manual/);
  } finally { await r.done(); }
});

test('manual brightness in auto mode gets overridden unless switched to manual first', async () => {
  const r = await rig({ model: 'vx600', autoMode: 'auto', autoBrightnessRaw: 0x40 }, { model: 'vx600', allowUnverified: true });
  try {
    const overridden = await r.ctl.setBrightness(80);
    assert.strictEqual(overridden.confirmed, false, 'auto mode wins, read-back does not match');
    const ok = await r.ctl.setBrightness(80, { switchToManual: true });
    assert.strictEqual(ok.confirmed, true);
    assert.strictEqual(ok.switched_to_manual, true);
    assert.strictEqual(r.sim.state().auto_mode, false);
  } finally { await r.done(); }
});

test('snapshot + diff finds a setting changed in NovaLCT', async () => {
  const r = await rig({ model: 'vx1000' }, { model: 'vx1000' });
  try {
    const before = await r.ctl.snapshot();
    assert.ok(before.regions.hw_brightness_block.hex.length === 0x360 * 2);
    assert.strictEqual(before.model, 'vx1000');
    // Someone sets start X = 1920, Y = 64 in NovaLCT, and changes a curve point.
    r.sim.setController(0x02000028, [0x80, 0x07, 0x40, 0x00]);
    r.sim.setController(REG.AUTO_BLOCK + 5, [0x05]);
    const after = await r.ctl.snapshot();
    const changes = diffSnapshots(before, after);
    const xy = changes.find((c) => c.address === '0x02000028');
    assert.ok(xy, JSON.stringify(changes));
    assert.deepStrictEqual(xy.as_uint16le, [0, 1920]);
    assert.ok(changes.some((c) => c.region === 'hw_brightness_block'));
    assert.strictEqual(diffSnapshots(after, after).length, 0);
  } finally { await r.done(); }
});

test('snapshot records unreadable areas instead of failing', async () => {
  const r = await rig({ model: 'vx600', rejectRegisters: [0x13010000] }, { model: 'vx600' });
  try {
    const snap = await r.ctl.snapshot();
    // The unanswered piece is retried in smaller pieces; only the bytes that never answered are marked unread.
    const vs = snap.regions.vx_screen;
    assert.ok(vs.error || (vs.mask && vs.mask.startsWith('0'.repeat(0x20)) && vs.mask.includes('1')), JSON.stringify(vs).slice(0, 200));
    assert.ok(snap.regions.sender_base.hex);
  } finally { await r.done(); }
});

test('no light sensor: status says so, auto is refused, auto-without-sensor is flagged', async () => {
  const r = await rig({ model: 'vx600', sensorPresent: false, autoMode: 'auto' }, { model: 'vx600', allowUnverified: true });
  try {
    const s = await r.ctl.getStatus();
    assert.strictEqual(s.sensor_present, false);
    assert.strictEqual(s.sensor_lux, null);
    assert.deepStrictEqual(s.warnings, ['auto_without_sensor']);
    await r.ctl.setBrightnessMode('manual');
    await assert.rejects(() => r.ctl.setBrightnessMode('auto'), /No light sensor/);
    assert.strictEqual(r.sim.state().auto_mode, false);
  } finally { await r.done(); }
});

test('sensor present: reported as present with its reading', async () => {
  const r = await rig({ model: 'vx600', sensorLux: 0, autoMode: 'auto' }, { model: 'vx600' });
  try {
    const s = await r.ctl.getStatus();
    assert.strictEqual(s.sensor_present, true, 'a dark night (0 lux) still counts as a sensor');
    assert.strictEqual(s.sensor_lux, 0);
  } finally { await r.done(); }
});

test('diff ignores bytes that could not be read in either snapshot', () => {
  const { diffSnapshots } = require('../lib/controller');
  const a = { regions: { r: { target: 'controller', address: 0x100, hex: '00112233', mask: '1101' } } };
  const b = { regions: { r: { target: 'controller', address: 0x100, hex: '0011ff44' } } };
  const changes = diffSnapshots(a, b);
  assert.strictEqual(changes.length, 1);
  assert.strictEqual(changes[0].address, '0x00000103');
});

test('layer window: writes X, Y, width, height as 32-bit numbers and reads them back', async () => {
  const r = await rig({ model: 'vx600' }, { model: 'vx600', allowUnverified: true });
  try {
    const res = await r.ctl.setLayerWindow(2, { x: 50, y: 40, width: 1500, height: 900 });
    assert.strictEqual(res.confirmed, true);
    const layers = await r.ctl.getLayers();
    assert.deepStrictEqual({ x: layers[1].x, y: layers[1].y, width: layers[1].width, height: layers[1].height }, { x: 50, y: 40, width: 1500, height: 900 });
    await r.ctl.setLayerEnabled(2, true);
    assert.strictEqual((await r.ctl.getLayers())[1].enabled, true);
    await assert.rejects(() => r.ctl.setLayerEnabled(1, false), /main layer/);
  } finally { await r.done(); }
});

test('layer window is refused until verified', async () => {
  const r = await rig({ model: 'vx600' }, { model: 'vx600' });
  try {
    await assert.rejects(() => r.ctl.setLayerWindow(1, { x: 0, y: 0, width: 1920, height: 1080 }), /not been verified/);
  } finally { await r.done(); }
});

test('status includes the layers on a VX600', async () => {
  const r = await rig({ model: 'vx600' }, { model: 'vx600' });
  try {
    const s = await r.ctl.getStatus();
    assert.ok(Array.isArray(s.layers) && s.layers.length === 3, JSON.stringify(s.layers));
  } finally { await r.done(); }
});
