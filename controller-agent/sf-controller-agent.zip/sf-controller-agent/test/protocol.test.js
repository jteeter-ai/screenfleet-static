'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { buildRequest, parseFrame, checksum, Code, Target, REQ_HEADER, RES_HEADER, buildResponse } = require('../lib/protocol');
const { REG } = require('../lib/registers');

const hex = (s) => Buffer.from(s.replace(/[^0-9a-f]/gi, ''), 'hex');

// Known-good frames copied from the Bitfocus Companion module (used in the field on VX600/VX1000).
test('brightness 50% matches the Companion VX1000 frame byte-for-byte', () => {
  const f = buildRequest({ serial: 0, target: Target.ALL_RECEIVERS, code: Code.WRITE, register: REG.BRIGHTNESS, data: [0x7f] });
  assert.deepStrictEqual(f, hex('55 aa 00 00 fe ff 01 ff ff ff 01 00 01 00 00 02 01 00 7f d4 5a'));
});

test('brightness 0% and 100% match Companion', () => {
  const z = buildRequest({ serial: 0, target: Target.ALL_RECEIVERS, code: Code.WRITE, register: REG.BRIGHTNESS, data: [0x00] });
  assert.deepStrictEqual(z, hex('55 aa 00 00 fe ff 01 ff ff ff 01 00 01 00 00 02 01 00 00 55 5a'));
  const f = buildRequest({ serial: 0, target: Target.ALL_RECEIVERS, code: Code.WRITE, register: REG.BRIGHTNESS, data: [0xff] });
  // Companion's static 100% entry lists checksum "5a 5b", which is a typo in its table:
  // its sendMessage() recomputes the checksum before sending, producing "54 5b" as here.
  assert.deepStrictEqual(f, hex('55 aa 00 00 fe ff 01 ff ff ff 01 00 01 00 00 02 01 00 ff 54 5b'));
});

test('VX1000 preset 3 recall matches Companion', () => {
  const f = buildRequest({ serial: 0, target: Target.CONTROLLER, code: Code.WRITE, register: REG.PRESET_RECALL, data: [0x02] });
  assert.deepStrictEqual(f, hex('55 aa 00 00 fe 00 00 00 00 00 01 00 00 01 51 13 01 00 02 bc 56'));
});

test('VX1000 black output mode matches Companion', () => {
  const f = buildRequest({ serial: 0, target: Target.CONTROLLER, code: Code.WRITE, register: REG.OUTPUT_MODE, data: [0x05, 0x00] });
  assert.deepStrictEqual(f, hex('55 aa 00 00 fe 00 00 00 00 00 01 00 04 00 00 13 02 00 05 00 72 56'));
});

test('VX layer 1 input HDMI 2 matches Companion', () => {
  const f = buildRequest({ serial: 0, target: Target.CONTROLLER, code: Code.WRITE, register: REG.LAYER_SOURCE[0], data: [0x01, 0, 0] });
  assert.deepStrictEqual(f, hex('55 aa 00 00 fe 00 00 00 00 00 01 00 12 00 02 13 03 00 01 00 00 7f 56'));
});

test('model-id read request matches Companion connect handshake', () => {
  const f = buildRequest({ serial: 0, target: Target.CONTROLLER, code: Code.READ, register: REG.MODEL_ID, length: 2 });
  const body = hex('55 aa 00 00 fe 00 00 00 00 00 00 00 02 00 00 00 02 00');
  assert.deepStrictEqual(f, Buffer.concat([body, checksum(body)]));
});

test('parseFrame handles split chunks, garbage and bad checksums', () => {
  const req = { serial: 9, source: 0xfe, destination: 0, deviceType: 0, port: 0, board: 0, code: Code.READ, register: REG.MODEL_ID };
  const resp = buildResponse({ request: req, data: [0x0e, 0x62] });
  const bad = Buffer.from(resp); bad[bad.length - 1] ^= 0xff;
  const stream = Buffer.concat([hex('00 13 37'), bad, resp]);
  let got = null; let buf = Buffer.alloc(0);
  for (const b of stream) { // feed one byte at a time
    buf = Buffer.concat([buf, Buffer.from([b])]);
    const { frame, rest } = parseFrame(buf, RES_HEADER);
    buf = rest;
    if (frame) got = frame;
  }
  assert.ok(got, 'frame parsed');
  assert.strictEqual(got.serial, 9);
  assert.deepStrictEqual([...got.data], [0x0e, 0x62]);
});

test('parseFrame decodes a write request with data', () => {
  const f = buildRequest({ serial: 4, target: Target.ALL_RECEIVERS, code: Code.WRITE, register: REG.BRIGHTNESS, data: [0x10] });
  const { frame } = parseFrame(f, REQ_HEADER);
  assert.strictEqual(frame.register, REG.BRIGHTNESS);
  assert.deepStrictEqual([...frame.data], [0x10]);
});
