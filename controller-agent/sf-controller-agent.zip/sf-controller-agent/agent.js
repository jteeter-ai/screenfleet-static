'use strict';
/**
 * ScreenFleet Controller Agent.
 *
 * Runs on the truck's PC. Every few seconds it checks in with ScreenFleet,
 * picks up any queued controller commands for THIS asset, runs them against
 * the NovaStar controller (over the LAN or USB), and reports back what the
 * controller actually did. Nothing on the truck has to accept inbound
 * connections: the agent only makes outbound HTTPS calls.
 *
 *   node agent.js --config sf-controller-agent.json
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { TcpTransport, SerialTransport } = require('./lib/transports');
const { NovaStarClient } = require('./lib/client');
const { Controller } = require('./lib/controller');
const { CloudClient } = require('./lib/cloud');

const VERSION = require('./package.json').version;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class Agent {
  /**
   * @param {object} deps
   * @param {object} deps.config          parsed config file
   * @param {object} deps.cloud           { sync(body) }
   * @param {function} [deps.makeTransport] (connection) => transport
   * @param {function} [deps.log]
   */
  constructor({ config, cloud, makeTransport = defaultTransport, log = console.log }) {
    this.config = config;
    this.cloud = cloud;
    this.makeTransport = makeTransport;
    this.log = log;
    this.controller = null;
    this.client = null;
    this.connectionKey = null;
    this.connectionError = null;
    this.pendingAcks = [];
    this.seen = new Set(); // command ids already executed (never run twice)
    this.lastStatus = null;
    this.lastStatusAt = 0;
    this.remote = {};
    this.stopped = false;
  }

  /** Connection settings: local config overrides what ScreenFleet has on file. */
  connection() {
    const r = this.remote.controller || {};
    const c = this.config.controller || {};
    return {
      type: c.connection_type || r.connection_type || 'tcp',
      host: c.host || r.host,
      port: Number(c.port || r.port || 5200),
      serial_path: c.serial_path || r.serial_path,
      baud_rate: Number(c.baud_rate || r.baud_rate || 115200),
      model: c.model || r.model,
      allow_unverified: Boolean(c.allow_unverified ?? r.allow_unverified),
      display_mode_strategy: c.display_mode_strategy || r.display_mode_strategy || undefined,
    };
  }

  describeConnection(conn = this.connection()) {
    return conn.type === 'usb' ? `USB ${conn.serial_path || '(no port set)'}` : `LAN ${conn.host || '(no IP set)'}:${conn.port}`;
  }

  async ensureController() {
    const conn = this.connection();
    const key = JSON.stringify(conn);
    if (this.controller && this.connectionKey === key) return this.controller;
    if (this.client) { await this.client.close().catch(() => {}); }
    this.controller = null;
    this.client = null;
    this.connectionKey = key;
    if (conn.type === 'usb' ? !conn.serial_path : !conn.host) {
      throw new Error(`Controller connection not configured (${this.describeConnection(conn)})`);
    }
    const transport = this.makeTransport(conn);
    this.client = new NovaStarClient(transport, { timeoutMs: this.config.command_timeout_ms || 2500 });
    this.controller = new Controller(this.client, {
      model: conn.model, allowUnverified: conn.allow_unverified, displayModeStrategy: conn.display_mode_strategy,
    });
    return this.controller;
  }

  async readStatus() {
    try {
      const ctl = await this.ensureController();
      const status = await ctl.getStatus();
      this.connectionError = status.reachable ? null : (status.errors.model || 'Controller not reachable');
      this.lastStatus = status;
      if (!status.reachable) { await this.client.close().catch(() => {}); this.controller = null; this.connectionKey = null; }
    } catch (e) {
      this.connectionError = e.message;
      this.lastStatus = null;
      // Force a fresh connection next time.
      if (this.client) await this.client.close().catch(() => {});
      this.controller = null;
      this.connectionKey = null;
    }
    this.lastStatusAt = Date.now();
    return this.lastStatus;
  }

  async runCommand(cmd) {
    const started = new Date().toISOString();
    if (cmd.expires_at && Date.parse(cmd.expires_at) < Date.now()) {
      return { command_id: cmd.id, ok: false, expired: true, error: 'Command expired before it reached the controller', started_at: started, completed_at: new Date().toISOString() };
    }
    try {
      const ctl = await this.ensureController();
      const result = await ctl.run(cmd.command_type, cmd.params || {});
      this.log(`✔ ${cmd.command_type} ${JSON.stringify(cmd.params || {})}`);
      return { command_id: cmd.id, ok: true, result, started_at: started, completed_at: new Date().toISOString() };
    } catch (e) {
      this.log(`✖ ${cmd.command_type} failed: ${e.message}`);
      if (e.timeout || /closed|ECONN|EHOSTUNREACH|ETIMEDOUT/.test(e.message)) { this.controller = null; this.connectionKey = null; }
      return { command_id: cmd.id, ok: false, error: e.message, started_at: started, completed_at: new Date().toISOString() };
    }
  }

  /** One check-in with ScreenFleet. Returns ms to wait before the next one. */
  async cycle() {
    const statusEvery = this.remote.status_interval_ms || 60000;
    if (!this.lastStatusAt || Date.now() - this.lastStatusAt > statusEvery) await this.readStatus();

    const acks = this.pendingAcks.splice(0);
    let resp;
    try {
      resp = await this.cloud.sync({
        hostname: os.hostname(),
        connection: { ...this.connection(), description: this.describeConnection(), error: this.connectionError },
        status: this.lastStatus,
        acks,
      });
    } catch (e) {
      this.pendingAcks.unshift(...acks); // keep results until ScreenFleet has them
      if (e.fatal) throw e;
      this.log(`ScreenFleet unreachable: ${e.message}`);
      return Math.min((this.remote.next_poll_ms || 10000) * 2, 60000);
    }
    this.remote = resp;

    const commands = (resp.commands || []).filter((c) => !this.seen.has(c.id));
    if (commands.length) {
      for (const cmd of commands) {
        this.seen.add(cmd.id);
        this.pendingAcks.push(await this.runCommand(cmd));
      }
      if (this.seen.size > 500) this.seen = new Set([...this.seen].slice(-200));
      await this.readStatus(); // report the controller's real state right after changing it
      return 0; // report results immediately
    }
    return resp.next_poll_ms || 10000;
  }

  async run() {
    this.log(`ScreenFleet Controller Agent ${VERSION} starting`);
    while (!this.stopped) {
      let wait;
      try {
        wait = await this.cycle();
      } catch (e) {
        if (e.fatal) {
          this.log(`ScreenFleet refused this agent key: ${e.message}. Generate a new key on the Asset's Controller panel.`);
          wait = 5 * 60000;
        } else {
          this.log(`Unexpected error: ${e.stack || e.message}`);
          wait = 15000;
        }
      }
      if (wait > 0) await sleep(wait);
    }
  }

  async stop() {
    this.stopped = true;
    if (this.client) await this.client.close().catch(() => {});
  }
}

function defaultTransport(conn) {
  if (conn.type === 'usb') return new SerialTransport({ path: conn.serial_path, baudRate: conn.baud_rate });
  return new TcpTransport({ host: conn.host, port: conn.port });
}

/**
 * Console logger, or a file logger that keeps the last ~5 MB (current file + one .old)
 * so a PC left running for months never fills its disk.
 */
function makeLogger(file, maxBytes = 2.5 * 1024 * 1024) {
  const stamp = () => new Date().toISOString().replace('T', ' ').slice(0, 19);
  if (!file) return (...m) => console.log(stamp(), ...m);
  const p = path.resolve(file);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  return (...m) => {
    const line = `${stamp()} ${m.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')}\n`;
    try {
      if (fs.existsSync(p) && fs.statSync(p).size > maxBytes) {
        fs.renameSync(p, p + '.old');
      }
      fs.appendFileSync(p, line);
    } catch (_) {
      process.stdout.write(line);
    }
  };
}

function loadConfig(file) {
  const p = path.resolve(file);
  if (!fs.existsSync(p)) throw new Error(`Config file not found: ${p}`);
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

if (require.main === module) {
  const args = process.argv.slice(2);
  const i = args.indexOf('--config');
  const file = i >= 0 ? args[i + 1] : path.join(__dirname, 'sf-controller-agent.json');
  const j = args.indexOf('--log');
  const logFile = j >= 0 ? args[j + 1] : null;
  const log = makeLogger(logFile);
  let config;
  try {
    config = loadConfig(file);
  } catch (e) {
    log(`Cannot start: ${e.message}`);
    process.exit(2);
  }
  const cloud = new CloudClient({ cloudUrl: config.cloud_url, agentKey: config.agent_key, agentVersion: VERSION });
  const agent = new Agent({ config, cloud, log });
  process.on('SIGINT', async () => { await agent.stop(); process.exit(0); });
  process.on('SIGTERM', async () => { await agent.stop(); process.exit(0); });
  agent.run();
}

module.exports = { Agent, loadConfig, makeLogger, VERSION };
