#!/usr/bin/env node
'use strict';
/**
 * sf-nova: talk to a NovaStar controller directly from the truck PC.
 * Used for bench testing before (and independently of) ScreenFleet.
 *
 *   node cli.js discover
 *   node cli.js status     --host 192.168.0.10
 *   node cli.js status     --usb COM3
 *   node cli.js probe      --host 192.168.0.10         (safe round-trip test)
 *   node cli.js brightness 40   --host ...
 *   node cli.js mode black|freeze|normal --host ...
 *   node cli.js preset 2   --host ...
 *   node cli.js input 1 hdmi2 --host ...
 *   node cli.js layers --host ...                  (read every layer's on/off, source, X, Y, width, height)
 *   node cli.js layer 1 0 0 1920 1080 --host ... --unverified   (move/resize layer 1: X Y width height)
 *   node cli.js layeron 2 / layeroff 2 --host ... --unverified
 *   node cli.js pattern red|off --host ...
 *   node cli.js automode auto|manual --host ...  (needs --unverified until tested)
 *   node cli.js lux --host ...                  (light sensor reading + current mode)
 *   node cli.js snapshot before.json --host ... (read-only capture of settings areas)
 *   node cli.js diff before.json after.json     (what changed between two snapshots)
 *
 * Options: --model vx600|vx1000|vx400  --port 5200  --baud 115200
 *          --strategy controller|receiver  --unverified  --debug  --json
 */
const { TcpTransport, SerialTransport, listSerialPorts, discoverNetworkControllers } = require('./lib/transports');
const { NovaStarClient } = require('./lib/client');
const { Controller, diffSnapshots } = require('./lib/controller');
const fs = require('fs');

const argv = process.argv.slice(2);
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a.startsWith('--')) {
    const k = a.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) flags[k] = true; else { flags[k] = next; i++; }
  } else pos.push(a);
}
const [cmd, ...rest] = pos;
const out = (x) => console.log(flags.json ? JSON.stringify(x, null, 2) : pretty(x));

function pretty(x) {
  if (typeof x !== 'object' || x === null) return String(x);
  return Object.entries(x).map(([k, v]) => `  ${k.padEnd(24)} ${typeof v === 'object' ? JSON.stringify(v) : v}`).join('\n');
}

function makeController() {
  let transport;
  if (flags.usb) transport = new SerialTransport({ path: flags.usb, baudRate: Number(flags.baud || 115200) });
  else if (flags.host) transport = new TcpTransport({ host: flags.host, port: Number(flags.port || 5200) });
  else throw new Error('Say where the controller is: --host <ip>  or  --usb <COM port>');
  const client = new NovaStarClient(transport, {
    timeoutMs: Number(flags.timeout || 2500),
    log: flags.debug ? (...m) => console.log('   ', ...m) : () => {},
  });
  const ctl = new Controller(client, {
    model: flags.model, allowUnverified: !!flags.unverified, displayModeStrategy: flags.strategy,
  });
  return { client, ctl, where: transport.describe() };
}

async function main() {
  if (!cmd || cmd === 'help') {
    console.log(require('fs').readFileSync(__filename, 'utf8').split('*/')[0].replace(/^[\s\S]*?\/\*\*/, '').replace(/^ \* ?/gm, ''));
    return;
  }
  if (cmd === 'discover') {
    console.log('Looking for controllers on the local network (UDP 3800)...');
    const ips = await discoverNetworkControllers();
    console.log(ips.length ? ips.map((ip) => `  found: ${ip}`).join('\n') : '  none answered (the PC and controller must be on the same subnet)');
    try {
      const ports = await listSerialPorts();
      console.log('\nSerial/USB ports on this PC:');
      console.log(ports.length ? ports.map((p) => `  ${p.path.padEnd(8)} ${p.manufacturer} ${p.vendorId}:${p.productId}`).join('\n') : '  none');
    } catch (e) {
      console.log(`\n(USB listing skipped: ${e.message})`);
    }
    return;
  }

  if (cmd === 'diff') {
    const [a, b] = rest;
    if (!a || !b) throw new Error('Usage: node cli.js diff before.json after.json');
    const changes = diffSnapshots(JSON.parse(fs.readFileSync(a, 'utf8')), JSON.parse(fs.readFileSync(b, 'utf8')));
    if (flags.json) { console.log(JSON.stringify(changes, null, 2)); return; }
    if (!changes.length) { console.log('No differences.'); return; }
    console.log(`${changes.length} change(s):`);
    for (const c of changes) {
      const u16 = c.as_uint16le ? `   (as number: ${c.as_uint16le[0]} -> ${c.as_uint16le[1]})` : '';
      console.log(`  ${c.address}  [${c.region}]  ${c.before} -> ${c.after}${u16}`);
    }
    return;
  }

  const { client, ctl, where } = makeController();
  try {
    if (!flags.json) console.log(`Controller at ${where}`);
    switch (cmd) {
      case 'status': out(await ctl.getStatus()); break;
      case 'probe': await probe(ctl); break;
      case 'brightness': out(await ctl.setBrightness(Number(rest[0]))); break;
      case 'mode': out(await ctl.setDisplayMode(rest[0])); break;
      case 'preset': out(await ctl.recallPreset(Number(rest[0]))); break;
      case 'input': out(await ctl.setInput(Number(rest[0]), rest[1])); break;
      case 'layers': console.log(JSON.stringify(await ctl.getLayers(), null, 1)); break;
      case 'layer': { // node cli.js layer 1 50 0 1500 1080 --unverified
        const [l, x, y, w, h] = rest.map(Number);
        out(await ctl.setLayerWindow(l, { x, y, width: w, height: h }));
        break;
      }
      case 'layeron': out(await ctl.setLayerEnabled(Number(rest[0]), true)); break;
      case 'layeroff': out(await ctl.setLayerEnabled(Number(rest[0]), false)); break;
      case 'pattern': out(await ctl.setTestPattern(rest[0])); break;
      case 'automode': out(await ctl.setBrightnessMode(rest[0])); break;
      case 'lux': {
        const s = await ctl.getStatus();
        out({ sensor_present: s.sensor_present, brightness_mode: s.brightness_mode, sensor_lux: s.sensor_lux, warnings: s.warnings || [], brightness_percent: s.brightness_percent,
          errors: Object.fromEntries(Object.entries(s.errors).filter(([k]) => ['brightness_mode', 'sensor_lux'].includes(k))) });
        break;
      }
      case 'snapshot': {
        const file = rest[0] || `snapshot-${Date.now()}.json`;
        const snap = await ctl.snapshot();
        snap.where = where;
        fs.writeFileSync(file, JSON.stringify(snap, null, 2));
        const failed = Object.entries(snap.regions).filter(([, r]) => r.error).map(([k]) => k);
        console.log(`Saved ${file} (${snap.model || 'unknown model'}). ${failed.length ? 'Could not read: ' + failed.join(', ') : 'All areas read.'}`);
        break;
      }
      default: throw new Error(`Unknown command "${cmd}". Run: node cli.js help`);
    }
  } finally {
    await client.close();
  }
}

/** Non-destructive check: read everything, then re-write the current brightness and confirm. */
async function probe(ctl) {
  const s = await ctl.getStatus();
  out(s);
  if (!s.reachable) throw new Error('Controller did not answer; check IP / cable / that NovaLCT is not holding the connection');
  if (typeof s.brightness_percent === 'number') {
    const r = await ctl.setBrightness(s.brightness_percent);
    console.log(`\nBrightness write test (re-applied ${s.brightness_percent}%): ${r.confirmed ? 'CONFIRMED by read-back' : 'written, but read-back did not match'}`);
  }
  console.log(`\nDetected model: ${s.model_detected || 'not recognised (id ' + s.model_id_hex + ')'}  firmware: ${s.firmware || '?'}`);
}

main().catch((e) => { console.error(`Error: ${e.message}`); process.exit(1); });
