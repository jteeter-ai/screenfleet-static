' ScreenFleet Native Partner App — autorun.brs
' Asset: XT1145 Spare
' Generated: 2026-05-12T03:40:53.648Z
' Resolution: 1920x1080
'
' BOOT FLOW:
'   1. Create brightsign-dumps/ (required by BrightSign partner specs)
'   2. Load config.json for API origin
'   3. Check roRegistry for screen token
'   4. If no token: launch sf-setup.html (provisioning mode)
'   5. If token found: download manifest + media via roAssetFetcher, then launch index.html
'
' HDMI INPUT (XT series only):
'   Activated via SF_HDMI_ZONES message from player.js bridge.
'   roVideoPlayer.PlayFile(roVideoInput) is the only correct API path.
'   ifVideoInput methods do NOT apply to HDMI input per BrightSign docs.

Dim g_hdmiPlayer As Object
Dim g_hdmiInput As Object
Dim g_token As String
Dim g_apiOrigin As String
Dim g_screenId As String

' ── Utility: Read config.json from SD card ───────────────────────────────
Function ReadConfig() As Object
    Print "[SF] Reading config.json..."
    fs = CreateObject("roReadFile", "sd:/config.json")
    If fs = Invalid Then
        Print "[SF] ERROR: config.json not found on sd:/"
        Return Invalid
    End If
    raw = fs.ReadLine()
    cfg = ParseJson(raw)
    If cfg = Invalid Then
        Print "[SF] ERROR: config.json parse failed"
        Return Invalid
    End If
    Print "[SF] config.json loaded. apiOrigin=" + cfg.apiOrigin
    Return cfg
End Function

' ── Utility: Read roRegistry for screen token ────────────────────────────
Function ReadToken() As String
    reg = CreateObject("roRegistry")
    section = CreateObject("roRegistrySection", "ScreenFleet")
    tok = section.Read("screen_token")
    If tok = Invalid Then Return ""
    Return tok
End Function

' ── Utility: Write screen token to roRegistry ────────────────────────────
Sub WriteToken(tok As String)
    reg = CreateObject("roRegistry")
    section = CreateObject("roRegistrySection", "ScreenFleet")
    section.Write("screen_token", tok)
    section.Flush()
    Print "[SF] Token written to roRegistry."
End Sub

' ── Asset download via roAssetFetcher ────────────────────────────────────
Sub DownloadManifest(manifest As Object)
    Print "[SF] DownloadManifest: " + Str(manifest.Count()) + " items"
    pool = CreateObject("roAssetPool", "sd:/pool")
    fetcher = CreateObject("roAssetFetcher", pool)
    fetcher.SetUserAndPassword("", "")
    For Each item In manifest
        Print "[SF] Queuing: " + item.name + " <- " + item.url
        fetcher.Add(item.url, item.name)
    End For
    fetcher.Start()
    ' Wait for all downloads to complete
    msgPort = CreateObject("roMessagePort")
    fetcher.SetPort(msgPort)
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roAssetFetcherEvent" Then
            evt = msg.GetData()
            If evt.reason = "complete" Then
                Print "[SF] roAssetFetcher: all downloads complete."
                Exit While
            Else If evt.reason = "error" Then
                Print "[SF] roAssetFetcher ERROR: " + evt.errorString
                Exit While
            End If
        End If
    End While
End Sub

' ── HDMI helpers (XT series only) ────────────────────────────────────────
Function SetupHdmiInput(zoneData As Object) As Boolean
    Print "[SF-HDMI] SetupHdmiInput: zone.id=" + zoneData.id
    vi = CreateObject("roVideoInput")
    If vi = Invalid Then
        Print "[SF-HDMI] FAIL: roVideoInput=Invalid. Not XT series?"
        Return False
    End If
    vp = CreateObject("roVideoPlayer")
    If vp = Invalid Then
        Print "[SF-HDMI] FAIL: roVideoPlayer=Invalid."
        Return False
    End If
    pcmOutputs = CreateObject("roArray", 2, False)
    compOutputs = CreateObject("roArray", 2, False)
    audioMode = zoneData.audioMode
    If audioMode = Invalid Or audioMode = "" Then audioMode = "aux"
    If audioMode = "hdmi" Then
        pcmOutputs.Push({AudioOutput: "HDMI"})
        compOutputs.Push({AudioOutput: "HDMI"})
    Else If audioMode = "both" Then
        pcmOutputs.Push({AudioOutput: "AnalogAudio"})
        pcmOutputs.Push({AudioOutput: "HDMI"})
        compOutputs.Push({AudioOutput: "HDMI"})
    Else
        pcmOutputs.Push({AudioOutput: "AnalogAudio"})
    End If
    vp.SetPcmAudioOutputs(pcmOutputs)
    If compOutputs.Count() > 0 Then vp.SetCompressedAudioOutputs(compOutputs)
    rect = CreateObject("roRectangle", zoneData.x, zoneData.y, zoneData.width, zoneData.height)
    vp.SetRectangle(rect)
    vp.SetVideoZOrder(zoneData.z_index)
    vp.PlayFile(vi)
    g_hdmiPlayer = vp
    g_hdmiInput = vi
    Print "[SF-HDMI] HDMI In active."
    Return True
End Function

Function HandleHdmiZones(zones As Object) As Void
    If zones.Count() = 0 Then Return
    If zones.Count() > 1 Then
        Print "[SF-HDMI] WARNING: multiple HDMI zones — only first activated (one physical port)."
    End If
    SetupHdmiInput(zones[0])
End Function

' ── Main ─────────────────────────────────────────────────────────────────
Sub Main()
    Print "[SF] ScreenFleet Native Partner App starting."
    Print "[SF] Asset: XT1145 Spare  Res: 1920x1080"

    ' Step 1: Create brightsign-dumps/ (required by BrightSign partner specs)
    dumpDir = CreateObject("roCreateFile", "sd:/brightsign-dumps/.keep")
    Print "[SF] brightsign-dumps/ created (partner spec requirement)."

    ' Step 2: Load config.json
    cfg = ReadConfig()
    If cfg = Invalid Then
        Print "[SF] FATAL: Cannot read config.json. Halting."
        Return
    End If
    g_apiOrigin = cfg.apiOrigin

    ' Step 3: Check roRegistry for screen token
    g_token = ReadToken()
    Print "[SF] roRegistry token: '" + g_token + "'"

    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, 1920, 1080)

    If g_token = "" Then
        ' Step 4: No token — launch provisioning page
        Print "[SF] No token found. Launching sf-setup.html (provisioning mode)."
        config = { url: "file:///sf-setup.html" }
        h = CreateObject("roHtmlWidget", r, config)
        h.EnableJavaScript(True)
        h.SetPort(msgPort)
        h.Show()
        ' Wait for SF_TOKEN_CONFIRMED message from sf-setup.html
        While True
            msg = Wait(0, msgPort)
            If Type(msg) = "roHtmlWidgetEvent" Then
                payload = msg.GetData()
                If Type(payload) = "roAssociativeArray" Then
                    If payload.reason = "message" And Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_TOKEN_CONFIRMED" Then
                            g_token = payload.message.token
                            g_screenId = payload.message.screen_id
                            WriteToken(g_token)
                            Print "[SF] Token registered. screenId=" + g_screenId
                            Exit While
                        End If
                    End If
                End If
            End If
        End While
        ' Reboot into normal playback mode
        Print "[SF] Rebooting to apply provisioning..."
        rebootObj = CreateObject("roSystemLog")
        rebootObj.Reboot()
        Return
    End If

    ' Step 5: Token found — fetch manifest + download media, then launch index.html
    Print "[SF] Token found. Fetching native manifest from " + g_apiOrigin
    ' (Manifest download is handled by player.js via fetch + roAssetFetcher bridge)
    ' Launch playback — use fallback if manifest unavailable on first boot
    manifestResult = Invalid
    manifestUrl = g_apiOrigin + "/functions/screenVersionCheck"
    http = CreateObject("roUrlTransfer")
    http.SetUrl(manifestUrl)
    http.AddHeader("Content-Type", "application/json")
    screenIdStored = CreateObject("roRegistrySection", "ScreenFleet").Read("screen_id")
    If screenIdStored = Invalid Then screenIdStored = ""
    manifestResult = ParseJson(http.AsyncGetToString())
    If manifestResult = Invalid Or manifestResult.status = "error" Or manifestResult.content_version = Invalid Then
        Print "[SF] No content version available — launching sf-fallback.html"
        config = { url: "file:///sf-fallback.html" }
    Else
        config = { url: "file:///index.html" }
    End If
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    Print "[SF] roHtmlWidget shown. Entering message loop."
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "load-error" Then
                    Print "[SF] HTML load error — retrying in 5s"
                    Sleep(5000)
                    h.SetUrl("file:///index.html")
                Else If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            HandleHdmiZones(payload.message.zones)
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
