
// ScreenFleet V2 BrightSign Player
// MODE A: Native ScreenFleet generated package (autorun.brs owns BrightScript runtime).
// If this HTML is loaded as a BrightAuthor HTML feed instead, that is Mode B.
// HDMI native activation only works in Mode A.
window.__SF_NATIVE_PACKAGE__ = true;
window.__SF_ASSET_ID__       = '69c206e32a609433ec805b6d';
window.__SF_GENERATED_AT__   = '2026-05-12T03:26:34.429Z';
console.log('[Player] ScreenFleet NATIVE PACKAGE (Mode A). assetId=69c206e32a609433ec805b6d');
console.log('[Player] Mode A: autorun.brs owns BrightScript runtime. HDMI activation via roVideoPlayer.PlayFile available.');
console.log('[Player] IMPORTANT: BrightAuthor HTML feed mode (Mode B) does NOT prove Mode A HDMI works.');

let CFG = null;
let currentPayload = null;
let knownVersion = null;
let screenId = null; // resolved from payload after registration
let zoneTimers = {};
const PAYLOAD_KEY = 'sf_v2_payload';
const VERSION_KEY = 'sf_v2_version';

// ── Boot ──────────────────────────────────────────────────────────────────────
async function boot() {
  // Register service worker for cache-first media
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js', { scope: './' });
      await navigator.serviceWorker.ready;
    } catch (e) { console.warn('[Player] SW registration failed', e); }
  }

  // Load config.json
  const cfgRes = await fetch('./config.json');
  CFG = await cfgRes.json();

  // screenId is not in config.json (native_partner_app package).
  // It is resolved from localStorage (set during provisioning) or from the first payload.
  screenId = localStorage.getItem('sf_screen_id') || null;

  // Register service worker for cache-first image delivery
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js', { scope: './' });
      await navigator.serviceWorker.ready;
    } catch (e) { console.warn('[Player] SW registration failed', e); }
  }

  // Try persisted payload first (offline boot)
  const stored = localStorage.getItem(PAYLOAD_KEY);
  if (stored) {
    try {
      currentPayload = JSON.parse(stored);
      knownVersion = currentPayload.content_version;
      if (!screenId && currentPayload.screen_id) {
        screenId = currentPayload.screen_id;
        localStorage.setItem('sf_screen_id', screenId);
      }
      renderPayload(currentPayload);
    } catch (_) {}
  }

  if (!screenId) {
    console.warn('[Player] No screenId yet — waiting for provisioning token from sf-setup.html or registry.');
    return;
  }

  // Fetch fresh payload
  await refreshPayload();

  // Start version poll
  setInterval(pollVersion, CFG.pollIntervalMs || 60000);
}

// ── API helpers ───────────────────────────────────────────────────────────────
async function invokeFunction(fnName, params) {
  const origin = CFG.apiOrigin;
  // BrightSign: use direct fetch to the Base44 function endpoint
  const url = `${origin}/functions/${fnName}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return res.json();
}

// ── Version poll ─────────────────────────────────────────────────────────────
async function pollVersion() {
  if (!screenId) return;
  try {
    const data = await invokeFunction(CFG.versionCheckFn, { screenId });
    if (data.content_version && data.content_version !== knownVersion) {
      console.log('[Player] Version changed, refreshing payload');
      await refreshPayload();
    }
  } catch (e) { console.warn('[Player] Version check failed (offline?)', e.message); }
}

// ── Payload fetch + atomic swap ───────────────────────────────────────────────
async function refreshPayload() {
  if (!screenId) return;
  try {
    const data = await invokeFunction(CFG.payloadFn, { screenId, native_mode: true });
    if (!data || data.status === 'error') return;
    // Persist screenId if returned by payload
    if (data.screen_id && !screenId) {
      screenId = data.screen_id;
      localStorage.setItem('sf_screen_id', screenId);
    }

    // Preload media via service worker before swapping
    await preloadManifest(data.media_manifest || []);

    // Atomic swap: persist then render
    localStorage.setItem(PAYLOAD_KEY, JSON.stringify(data));
    localStorage.setItem(VERSION_KEY, data.content_version);
    knownVersion = data.content_version;
    currentPayload = data;
    renderPayload(data);
  } catch (e) { console.warn('[Player] Payload fetch failed (offline?)', e.message); }
}

// ── Preload media via SW ──────────────────────────────────────────────────────
function preloadManifest(manifest) {
  return new Promise(resolve => {
    if (!navigator.serviceWorker.controller) { resolve(); return; }
    const oldChecksums = (currentPayload?.media_manifest || []).map(m => m.checksum);
    // Only send items not already cached (diff by checksum)
    const newItems = manifest.filter(m => !oldChecksums.includes(m.checksum));
    if (!newItems.length) { resolve(); return; }

    const onMsg = (e) => {
      if (e.data?.type === 'PRELOAD_DONE') {
        navigator.serviceWorker.removeEventListener('message', onMsg);
        resolve();
      }
    };
    navigator.serviceWorker.addEventListener('message', onMsg);
    navigator.serviceWorker.controller.postMessage({
      type: 'PRELOAD_MANIFEST',
      items: newItems,
      oldChecksums,
    });
    // Timeout safety
    setTimeout(resolve, 30000);
  });
}

// ── HDMI Zone helpers ─────────────────────────────────────────────────────────
//
// collectHdmiZones: extracts valid hdmi_input zones from a payload.
// BrightSign XT has ONE physical HDMI In port — only first zone is hardware-active.
// Matches content_source_type === 'hdmi_input' as stored by publishAsset.
//
function collectHdmiZones(zones) {
  console.log('[Player-HDMI] collectHdmiZones: scanning ' + zones.length + ' zones for content_source_type===hdmi_input');
  var hdmi = zones.filter(function(z) {
    console.log('[Player-HDMI]   zone ' + z.id + ' content_source_type=' + z.content_source_type);
    if (z.content_source_type !== 'hdmi_input') return false;
    if (!z.width || !z.height) {
      console.warn('[Player-HDMI] Skipping HDMI zone with missing dimensions:', z.id);
      return false;
    }
    return true;
  });
  console.log('[Player-HDMI] collectHdmiZones: found ' + hdmi.length + ' HDMI zone(s).');
  if (hdmi.length > 1) {
    console.warn('[Player-HDMI] WARNING: ' + hdmi.length + ' HDMI zones in payload. BrightSign XT has ONE physical HDMI In port.');
    console.warn('[Player-HDMI] Only first zone (' + hdmi[0].id + ') will be hardware-active.');
  }
  return hdmi;
}

// buildHdmiBridgeMessage: builds the SF_HDMI_ZONES payload sent via BSMessagePort.
// Per-zone fields:
//   id, x, y, width, height, z_index, fit — geometry/layout
//   audioMode — normalized string: 'aux' | 'hdmi' | 'both'
//               Sourced from canvas_creative_data.audioOutput (set by publishAsset).
//               BrightScript SetupHdmiInput() maps this to output arrays.
function buildHdmiBridgeMessage(hdmiZones) {
  var zones = hdmiZones.map(function(z) {
    var hdmiMeta = z.canvas_creative_data || {};
    var audioMode = hdmiMeta.audioOutput || 'aux'; // 'aux' | 'hdmi' | 'both'
    console.log('[Player-HDMI] buildHdmiBridgeMessage zone=' + z.id + ' audioMode=' + audioMode + ' (from canvas_creative_data.audioOutput=' + hdmiMeta.audioOutput + ')');
    return {
      id:        z.id,
      x:         z.x || 0,
      y:         z.y || 0,
      width:     z.width,
      height:    z.height,
      z_index:   z.z_index || 1,
      fit:       hdmiMeta.fit || 'stretch',
      audioMode: audioMode,
    };
  });
  return { type: 'SF_HDMI_ZONES', zones: zones };
}

// ── Runtime Mode Detection ───────────────────────────────────────────────────
// MODE A: ScreenFleet native generated package (autorun.brs owns the runtime)
//   - postBSMessage() is available (injected by BrightSign firmware into roHtmlWidget)
//   - HDMI activation is possible via roVideoPlayer.PlayFile(roVideoInput)
// MODE B: HTML feed loaded inside BrightAuthor / third-party BRS presentation
//   - postBSMessage() may or may not be available depending on BrightAuthor config
//   - HDMI activation is NOT owned by ScreenFleet — BrightAuthor owns the BRS runtime
//   - DO NOT treat Mode B as proof that Mode A (native package) works
//
// Detection: window.__SF_NATIVE_PACKAGE__ is set to true only in generated player.js.
// If running inside BrightAuthor HTML feed, this flag will be absent.
function detectRuntimeMode() {
  var isNativePackage = !!window.__SF_NATIVE_PACKAGE__;
  var hasPostBSMessage = typeof postBSMessage === 'function';
  var hasBSMessagePort = typeof BSMessagePort !== 'undefined';
  console.log('[Player-MODE] ══ Runtime Mode Detection ══');
  console.log('[Player-MODE] window.__SF_NATIVE_PACKAGE__ = ' + isNativePackage);
  console.log('[Player-MODE] typeof postBSMessage         = ' + typeof postBSMessage);
  console.log('[Player-MODE] typeof BSMessagePort         = ' + typeof BSMessagePort);
  if (!isNativePackage) {
    console.warn('[Player-MODE] WARNING: __SF_NATIVE_PACKAGE__ flag NOT set.');
    console.warn('[Player-MODE] This may be an HTML feed loaded inside BrightAuthor, not a native ScreenFleet package.');
    console.warn('[Player-MODE] Native HDMI activation (roVideoPlayer.PlayFile) is only possible in Mode A (native package).');
    console.warn('[Player-MODE] BrightAuthor HDMI widget working does NOT prove ScreenFleet native HDMI works.');
  } else {
    console.log('[Player-MODE] Mode A confirmed: ScreenFleet native generated package.');
    console.log('[Player-MODE] autorun.brs owns the BrightScript runtime. HDMI activation available.');
  }
  return { isNativePackage, hasPostBSMessage };
}

// signalBrightScriptHdmiZones: sends SF_HDMI_ZONES to BrightScript.
// ONLY runs in Mode A (native ScreenFleet package).
// In Mode B (hosted HTML inside BrightAuthor), ScreenFleet does not own the BrightScript
// runtime — HDMI activation via roVideoPlayer.PlayFile is not available from this context.
function signalBrightScriptHdmiZones(msg) {
  console.log('[Player-HDMI] signalBrightScriptHdmiZones called. zones=' + msg.zones.length);

  var mode = detectRuntimeMode();

  // Gate: hosted HTML mode cannot activate native HDMI. Skip bridge entirely.
  if (!mode.isNativePackage) {
    console.warn('[Player-HDMI] MODE B (hosted HTML): skipping SF_HDMI_ZONES bridge.');
    console.warn('[Player-HDMI] ScreenFleet is loaded as an HTML URL inside BrightAuthor. It does not own the BrightScript runtime.');
    console.warn('[Player-HDMI] Native HDMI activation requires Mode A: deploy the native ScreenFleet package (autorun.brs).');
    return;
  }

  console.log('[Player-HDMI] Mode A confirmed. Sending SF_HDMI_ZONES bridge payload: ' + JSON.stringify(msg));
  var sent = false;

  // PATH 1: postBSMessage() — documented BrightSign global (BS OS 7+)
  if (typeof postBSMessage === 'function') {
    try {
      postBSMessage(msg);
      console.log('[Player-HDMI] PATH1 OK: postBSMessage(msg) called.');
      sent = true;
    } catch(e) {
      console.error('[Player-HDMI] PATH1 FAIL: postBSMessage threw: ' + (e && e.message ? e.message : String(e)));
    }
  } else {
    console.warn('[Player-HDMI] PATH1 SKIP: postBSMessage not defined.');
  }

  // PATH 2: window.postMessage() — secondary path
  if (!sent) {
    try {
      window.postMessage(msg, '*');
      console.log('[Player-HDMI] PATH2 OK: window.postMessage(msg) called.');
      sent = true;
    } catch(e) {
      console.error('[Player-HDMI] PATH2 FAIL: ' + (e && e.message ? e.message : String(e)));
    }
  }

  if (!sent) {
    console.error('[Player-HDMI] ALL PATHS FAILED. Confirm this is BrightSign XT running native ScreenFleet package.');
  }
}

// ── Renderer ──────────────────────────────────────────────────────────────────
function logZoneManifest(zones) {
  // ARCHITECTURE: Both HTML canvas and BrightScript bridge use this same zones array.
  // There is ONE screenPayload call, ONE zone list. No separate manifests.
  console.log('[Player-MANIFEST] ══════════════════════════════════════════');
  console.log('[Player-MANIFEST] ZONE MANIFEST — source: screenPayload({ screenId: ' + CFG.screenId + ' })');
  console.log('[Player-MANIFEST] Total zones in payload: ' + zones.length);
  var hdmiCount = 0;
  var htmlCount = 0;
  zones.forEach(function(z, i) {
    var isHdmi = z.content_source_type === 'hdmi_input';
    if (isHdmi) hdmiCount++; else htmlCount++;
    console.log('[Player-MANIFEST] Zone[' + i + '] id=' + z.id +
      ' name=' + (z.name || '(unnamed)') +
      ' x=' + (z.x || 0) + ' y=' + (z.y || 0) +
      ' w=' + z.width + ' h=' + z.height +
      ' z_index=' + (z.z_index || 1) +
      ' type=' + z.content_source_type);
    if (isHdmi) {
      var meta = z.canvas_creative_data || {};
      console.log('[Player-MANIFEST]   ^ HDMI zone — audioOutput=' + (meta.audioOutput || 'aux') +
        ' fit=' + (meta.fit || 'stretch') +
        ' canvas_creative_data present=' + !!z.canvas_creative_data);
    }
  });
  console.log('[Player-MANIFEST] HTML/media zones: ' + htmlCount + ' | HDMI zones: ' + hdmiCount);
  console.log('[Player-MANIFEST] HTML canvas renders ALL ' + zones.length + ' zones from this list.');
  console.log('[Player-MANIFEST] BrightScript bridge receives HDMI subset (' + hdmiCount + ') from this SAME list.');
  if (hdmiCount === 0) {
    console.warn('[Player-MANIFEST] WARNING: 0 HDMI zones in payload. If HDMI was expected:');
    console.warn('[Player-MANIFEST]   1. Check publishAsset created a RuntimeZone with content_source_type=hdmi_input');
    console.warn('[Player-MANIFEST]   2. Check that RuntimeZone.published_screen_id = ' + CFG.screenId);
    console.warn('[Player-MANIFEST]   3. The native package CANNOT activate HDMI if screenPayload returns 0 HDMI zones.');
    console.warn('[Player-MANIFEST]   4. BrightAuthor HDMI working does NOT fix this — they are Mode B (HTML feed), not Mode A.');
  }
  console.log('[Player-MANIFEST] ══════════════════════════════════════════');
}

function renderPayload(payload) {
  var canvas = document.getElementById('canvas');
  if (!canvas) return;

  // Clear existing timers
  Object.values(zoneTimers).forEach(function(t) { clearTimeout(t); });
  zoneTimers = {};

  canvas.innerHTML = '';
  canvas.style.width = payload.screen_width + 'px';
  canvas.style.height = payload.screen_height + 'px';

  var zones = payload.zones || [];

  // Log full zone manifest — proves HTML canvas and BrightScript bridge use same source
  logZoneManifest(zones);

  zones.forEach(function(zone) { renderZone(canvas, zone); });

  // Signal BrightScript about HDMI zones after HTML zones are rendered.
  // Delay 1.5s to ensure roHtmlWidget JS environment is fully ready to bridge.
  // Then retry once after 5s in case the first message was dropped during boot.
  var hdmiZones = collectHdmiZones(zones);
  if (hdmiZones.length > 0) {
    var msg = buildHdmiBridgeMessage(hdmiZones);
    console.log('[Player-HDMI] Scheduling SF_HDMI_ZONES send. count=' + hdmiZones.length);
    // First attempt: 1.5s after render
    setTimeout(function() {
      console.log('[Player-HDMI] Attempt 1: sending SF_HDMI_ZONES...');
      signalBrightScriptHdmiZones(msg);
    }, 1500);
    // Retry: 8s after render (in case first was dropped during widget init)
    setTimeout(function() {
      console.log('[Player-HDMI] Attempt 2 (retry): sending SF_HDMI_ZONES...');
      signalBrightScriptHdmiZones(msg);
    }, 8000);
  }
}

function renderZone(canvas, zone) {
  if (zone.content_source_type === 'hdmi_input') {
    var hdmiEl = document.createElement('div');
    hdmiEl.id = 'zone-' + zone.id;
    hdmiEl.setAttribute('data-hdmi-zone', 'true');

    var isNative = !!window.__SF_NATIVE_PACKAGE__;

    // ── Mode A (native ScreenFleet package): transparent placeholder.
    // BrightScript owns the GPU video plane. roVideoPlayer renders below this div.
    // ── Mode B (hosted HTML inside BrightAuthor): show unsupported-state label.
    // ScreenFleet does not own the BrightScript runtime in this mode.
    // Native HDMI activation (roVideoPlayer.PlayFile) is not available.
    if (isNative) {
      hdmiEl.style.cssText = [
        'position:absolute',
        'left:' + (zone.x || 0) + 'px',
        'top:' + (zone.y || 0) + 'px',
        'width:' + zone.width + 'px',
        'height:' + zone.height + 'px',
        'z-index:' + (zone.z_index || 1),
        'background:transparent',
        'overflow:hidden',
        'pointer-events:none',
      ].join(';');
      console.log('[Player-HDMI] Mode A (native): transparent placeholder for HDMI zone ' + zone.id);
    } else {
      // Hosted HTML mode — HDMI cannot be activated. Show explicit unsupported message.
      hdmiEl.style.cssText = [
        'position:absolute',
        'left:' + (zone.x || 0) + 'px',
        'top:' + (zone.y || 0) + 'px',
        'width:' + zone.width + 'px',
        'height:' + zone.height + 'px',
        'z-index:' + (zone.z_index || 1),
        'background:#1a0a00',
        'border:2px dashed #7c3a00',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'overflow:hidden',
        'pointer-events:none',
        'box-sizing:border-box',
      ].join(';');
      hdmiEl.innerHTML = [
        '<div style="color:#f97316;font:bold 13px monospace;text-align:center;padding:0 12px;">HDMI Input</div>',
        '<div style="color:#9a5220;font:11px monospace;text-align:center;margin-top:6px;padding:0 12px;line-height:1.4;">',
          'Requires native ScreenFleet<br>player deployment.<br>',
          '<span style="color:#6b3a14;">Hosted HTML mode does not<br>support native HDMI control.</span>',
        '</div>',
      ].join('');
      console.warn('[Player-HDMI] Mode B (hosted HTML): HDMI zone ' + zone.id + ' cannot activate native hardware. Showing unsupported-state label.');
      console.warn('[Player-HDMI] To use HDMI input, deploy the native ScreenFleet package (Mode A) instead of loading this URL inside BrightAuthor.');
    }

    canvas.appendChild(hdmiEl);
    return;
  }

  var el = document.createElement('div');
  el.id = 'zone-' + zone.id;
  el.style.cssText = [
    'position:absolute',
    'left:' + (zone.x || 0) + 'px',
    'top:' + (zone.y || 0) + 'px',
    'width:' + zone.width + 'px',
    'height:' + zone.height + 'px',
    'z-index:' + (zone.z_index || 1),
    'background:' + (zone.background_color || '#000'),
    'overflow:hidden',
  ].join(';');
  canvas.appendChild(el);

  var items = zone.playback_track ? zone.playback_track.items || [] : [];
  if (!items.length) return;
  playTrack(el, zone, items, 0);
}

function playTrack(el, zone, items, index) {
  var item = items[index % items.length];
  if (!item) return;

  el.innerHTML = '';
  var fitCss = fitModeToCss(item.fit_mode || zone.fit_mode);
  var volume = zone.volume != null ? zone.volume : 100;

  if (item.file_type === 'video') {
    // Videos: use sd:// local pool path if available (downloaded by roAssetFetcher)
    var videoSrc = item.local_name ? 'sd:/media/' + item.local_name : item.file_url;
    var v = document.createElement('video');
    v.src = videoSrc;
    v.autoplay = true;
    v.playsInline = true;
    v.muted = volume === 0;
    v.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:' + fitCss;
    v.onended = function() { playTrack(el, zone, items, index + 1); };
    v.onerror = function() {
      if (item.local_name && v.src !== item.file_url) {
        console.warn('[Player] sd:// video failed, falling back to CDN:', item.file_url);
        v.src = item.file_url;
      } else {
        playTrack(el, zone, items, index + 1);
      }
    };
    el.appendChild(v);
  } else {
    // Images: SW cache handles CDN URLs; sd:// path not needed for images
    var img = document.createElement('img');
    img.src = item.file_url;
    img.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:' + fitCss;
    el.appendChild(img);
    var dur = (item.duration != null ? item.duration : 8) * 1000;
    var loop = !zone.playback_track || zone.playback_track.loop !== false;
    var nextIndex = index + 1;
    if (loop || nextIndex < items.length) {
      zoneTimers[zone.id] = setTimeout(function() { playTrack(el, zone, items, nextIndex); }, dur);
    }
  }
}

function fitModeToCss(fitMode) {
  switch (fitMode) {
    case 'fit': return 'contain';
    case 'stretch': return 'fill';
    case 'center': return 'none';
    default: return 'cover';
  }
}

// Boot on load
window.addEventListener('load', boot);
