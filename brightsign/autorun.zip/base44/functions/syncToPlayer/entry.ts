/**
 * syncToPlayer — CMS → Player App Content Sync
 *
 * Pushes minimal playback data for a screen to the ScreenFleet Player app's
 * syncScreenData endpoint. No user/org/admin data is exposed.
 *
 * Called by:
 *   - Entity automations (Screen, PublishedScreen, Playlist, Schedule changes)
 *   - Manual resync trigger from CMS admin UI
 *
 * Requires:
 *   - AppConfig.player_app_origin  (Player app URL)
 *   - PLAYER_SYNC_SECRET           (shared secret, must match Player app)
 *
 * Does NOT block CMS operations — caller should fire-and-forget.
 * Returns { ok, screen_id, error } for logging.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const MAX_RETRIES = 6; // Increased to handle rate limits
const RETRY_DELAY_MS = 1000; // Base delay, scales exponentially for rate limits

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function fetchWithRetry(url, options, retries = MAX_RETRIES) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, options);
      if (res.ok) return { ok: true, status: res.status, body: await res.json().catch(() => ({})) };
      const body = await res.json().catch(() => ({}));
      
      // Rate limit: always retry, with backoff
      if (res.status === 429 || (res.status === 500 && body.detail?.includes('Rate limit'))) {
        const backoffMs = Math.min(RETRY_DELAY_MS * Math.pow(2, attempt - 1), 30000);
        console.warn(`[syncToPlayer] Attempt ${attempt}/${retries} rate limited (HTTP ${res.status}). Backoff: ${backoffMs}ms`);
        if (attempt < retries) await sleep(backoffMs);
        continue;
      }
      
      // Other errors: log and fail
      console.warn(`[syncToPlayer] Attempt ${attempt}/${retries} failed: HTTP ${res.status}`, body);
      if (attempt < retries) await sleep(RETRY_DELAY_MS * attempt);
    } catch (err) {
      console.warn(`[syncToPlayer] Attempt ${attempt}/${retries} network error:`, err.message);
      if (attempt < retries) await sleep(RETRY_DELAY_MS * attempt);
    }
  }
  return { ok: false, error: `Failed after ${retries} attempts` };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { screenId } = body;
    if (!screenId) return Response.json({ error: 'screenId is required' }, { status: 400 });

    // Auth: accept either an authenticated CMS user OR a valid sync secret
    // (syncToPlayerTrigger invokes this via asServiceRole — no user session)
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');
    const headerSecret = req.headers.get('x-sync-secret');
    const isServiceInvocation = !headerSecret; // asServiceRole invocations carry no header
    const user = await base44.auth.me().catch(() => null);
    if (!user && headerSecret && headerSecret !== syncSecret) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    // asServiceRole invocations (no user, no header) are trusted — they originate from CMS automation only
    console.log(`[syncToPlayer] AUTH screen=${screenId} user=${user?.email || 'none'} headerSecret=${!!headerSecret} isServiceRole=${!user && !headerSecret}`);

    // ── Load AppConfig ────────────────────────────────────────────────────────
    const configs = await base44.asServiceRole.entities.AppConfig.list().catch(() => []);
    const appConfig = configs[0];
    const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '');

    if (!playerOrigin) {
      const msg = 'player_app_origin not configured in AppConfig — cannot sync to Player app.';
      console.warn('[syncToPlayer]', msg);
      return Response.json({ ok: false, screen_id: screenId, error: msg });
    }

    if (!syncSecret) {
      const msg = 'PLAYER_SYNC_SECRET not set — cannot authenticate sync request.';
      console.warn('[syncToPlayer]', msg);
      return Response.json({ ok: false, screen_id: screenId, error: msg });
    }

    // ── Load Screen ───────────────────────────────────────────────────────────
    console.log(`[syncToPlayer] CONFIG playerOrigin=${playerOrigin || 'MISSING'} secretSet=${!!syncSecret}`);
    const screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
    if (!screens.length) {
      return Response.json({ ok: false, screen_id: screenId, error: 'Screen not found' }, { status: 404 });
    }
    const screen = screens[0];

    // ── Load PublishedScreen (most recent) ────────────────────────────────────
    const published = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screenId });
    const publishedScreen = published.sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0] || null;

    // ── Load RuntimeZones ─────────────────────────────────────────────────────
    let runtimeZones = [];
    if (publishedScreen) {
      runtimeZones = await base44.asServiceRole.entities.RuntimeZone.filter({
        published_screen_id: publishedScreen.id,
      });
    }

    // ── Load Asset ────────────────────────────────────────────────────────────
    let asset = null;
    if (screen.asset_id) {
      const assets = await base44.asServiceRole.entities.Asset.filter({ id: screen.asset_id });
      if (assets[0]) {
        // Only expose playback-relevant fields — no org/user/admin data
        const a = assets[0];
        asset = {
          id: a.id,
          name: a.name,
          asset_type: a.asset_type,
          player_type: a.player_type,
          player_model: a.player_model,
          thumbnail_url: a.thumbnail_url,
        };
      }
    }

    // ── Load Schedules ────────────────────────────────────────────────────────
    const scheduleIds = publishedScreen?.schedule_ids || [];
    let schedules = [];
    if (scheduleIds.length) {
      // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
      // Schedule.truck_id is a V1 field. In V2, Schedule should be linked via asset_id directly.
      // screen.truck_id is also a V1 field on Screen. Both should be removed once V2 scheduling is in place.
      const allSchedules = await base44.asServiceRole.entities.Schedule.filter({ truck_id: screen.truck_id || screen.asset_id });
      schedules = allSchedules
        .filter(s => scheduleIds.includes(s.id))
        .map(s => ({
          id: s.id,
          name: s.name,
          content_type: s.content_type,
          playlist_id: s.playlist_id,
          start_time: s.start_time,
          end_time: s.end_time,
          days_of_week: s.days_of_week,
          play_all_day: s.play_all_day,
          priority: s.priority,
          is_active: s.is_active,
        }));
    }

    // ── Build media manifest (deduplicated file URLs) ─────────────────────────
    const urlSet = new Set();
    for (const rz of runtimeZones) {
      for (const item of rz.playback_track?.items || []) {
        if (item.file_url) urlSet.add(item.file_url);
      }
    }

    // ── Build minimal playback payload (NO user/org/admin data) ──────────────
    const totalItems = runtimeZones.reduce((sum, rz) => sum + (rz.playback_track?.items?.length || 0), 0);
    console.log(`[syncToPlayer] DATA screen=${screenId} publishedScreen=${publishedScreen?.id || 'NONE'} runtimeZones=${runtimeZones.length} totalItems=${totalItems}`);
    if (runtimeZones.length > 0) {
      const sample = runtimeZones[0]?.playback_track?.items?.[0];
      console.log(`[syncToPlayer] ITEM_CONTRACT sample keys=${sample ? Object.keys(sample).join(',') : 'no items'}`);
      // Log zone geometry to confirm x/y/width/height are present in outbound payload
      console.log('[syncToPlayer] ZONE_GEOMETRY', JSON.stringify(runtimeZones.map(rz => ({
        name: rz.name,
        x: rz.x ?? 0,
        y: rz.y ?? 0,
        width: rz.width,
        height: rz.height,
        z_index: rz.z_index ?? 1,
      }))));
    }
    const contentVersionIso = publishedScreen?.content_version || new Date().toISOString();
    // Player app entity schema requires content_version to be a number (epoch ms)
    const contentVersion = new Date(contentVersionIso).getTime();
    
    // Resolve device_safe_mode: screen-level overrides org-level default
    const deviceSafeMode = screen.device_safe_mode ?? appConfig?.default_device_safe_mode ?? false;
    
    const payload = {
      public_token: screen.public_token,
      device_safe_mode: deviceSafeMode,
      // Normalized field names (primary)
      cms_screen_id: screenId,
      resolution_width: screen.width,
      resolution_height: screen.height,
      // Backward compatibility aliases
      screen_id: screenId,
      screen_width: screen.width,
      screen_height: screen.height,
      screen_name: screen.name,
      screen_position: screen.position,
      screen_mode: screen.screen_mode,
      asset,
      content_version: contentVersion,
      content_version_iso: contentVersionIso,
      published_at: publishedScreen?.published_at || null,
      zones: runtimeZones.sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1)).map(rz => ({
        id: rz.id,
        layout_zone_id: rz.layout_zone_id,
        name: rz.name,
        x: rz.x ?? 0,
        y: rz.y ?? 0,
        width: rz.width,
        height: rz.height,
        z_index: rz.z_index ?? 1,
        fit_mode: rz.fit_mode || 'contain',
        background_color: rz.background_color || '#000000',
        volume: rz.volume ?? 100,
        content_source_type: rz.content_source_type || 'empty',
        canvas_creative_data: rz.canvas_creative_data || null,
        playback_track: {
          loop: rz.playback_track?.loop ?? true,
          // Normalize items: send both CMS field names (file_url, file_type) AND
          // Player app field name aliases (url, type) so the Player renderer finds
          // the values regardless of which convention it uses.
          items: (rz.playback_track?.items || []).map(item => ({
            ...item,
            url: item.file_url || item.url || null,
            type: item.file_type || item.type || null,
          })),
        },
      })),
      schedules,
      media_urls: [...urlSet],
      synced_at: new Date().toISOString(),
    };

    // ── POST to Player app ────────────────────────────────────────────────────
    const syncUrl = `${playerOrigin}/functions/syncScreenData`;
    console.log(`[syncToPlayer] Syncing screen ${screenId} to ${syncUrl}`);

    const result = await fetchWithRetry(syncUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-sync-secret': syncSecret,
      },
      body: JSON.stringify({ action: 'upsert', screen_data: payload }),
    });

    if (result.ok) {
      console.log(`[syncToPlayer] ✅ Screen ${screenId} synced successfully (version: ${contentVersion})`);
      // Audit log (fire and forget — do not block sync response)
      base44.asServiceRole.entities.AuditLog.create({
        org_id: screen.org_id || null,
        actor_email: user?.email || 'system',
        action: 'content_published',
        target_type: 'asset',
        target_id: screen.asset_id || screenId,
        details: `Screen "${screen.name}" synced to player (version: ${contentVersion})`,
      }).catch(() => {});
      return Response.json({ ok: true, screen_id: screenId, content_version: contentVersion });
    } else {
      console.error(`[syncToPlayer] ❌ Sync failed for screen ${screenId}:`, result.error);
      return Response.json({ ok: false, screen_id: screenId, error: result.error });
    }

  } catch (error) {
    console.error('[syncToPlayer] Fatal error:', error.message);
    return Response.json({ ok: false, error: error.message }, { status: 500 });
  }
});