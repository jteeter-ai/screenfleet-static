/**
 * validateScreenIntegrity — Check integrity constraints for screens
 *
 * Rules:
 * 1. No two active screens with same public_token
 * 2. No two active screens for same asset (unless explicit multi-screen design)
 * 3. No AssetLayout pointing to non-existent screen
 * 4. No PublishedScreen pointing to non-existent screen
 * 5. All RuntimeZones have valid published_screen_id
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const violations = [];

    // ── Load all active screens ────────────────────────────────────────────────
    const allScreens = await base44.asServiceRole.entities.Screen.list();
    const activeScreens = allScreens.filter((s) => s.status !== 'archived');
    const screenIds = new Set(activeScreens.map((s) => s.id));
    const screensByToken = {};
    const screensByAsset = {};

    for (const screen of activeScreens) {
      // Check token duplicates
      if (screen.public_token) {
        if (screensByToken[screen.public_token]) {
          violations.push({
            type: 'duplicate_token',
            token: screen.public_token,
            screen_ids: [screensByToken[screen.public_token].id, screen.id],
            severity: 'critical',
          });
        } else {
          screensByToken[screen.public_token] = screen;
        }
      }

      // Check asset duplicates
      if (screen.asset_id) {
        if (!screensByAsset[screen.asset_id]) screensByAsset[screen.asset_id] = [];
        screensByAsset[screen.asset_id].push(screen);
      }
    }

    // Multi-screen per asset is flagged (not necessarily violation, but warning)
    for (const [assetId, screens] of Object.entries(screensByAsset)) {
      if (screens.length > 1) {
        violations.push({
          type: 'multiple_active_screens_per_asset',
          asset_id: assetId,
          screen_count: screens.length,
          screen_ids: screens.map((s) => s.id),
          severity: 'warning',
          note: 'Confirm this is intentional multi-screen design',
        });
      }
    }

    // ── Check AssetLayout integrity ────────────────────────────────────────────
    const allAssetLayouts = await base44.asServiceRole.entities.AssetLayout.list();
    for (const al of allAssetLayouts) {
      if (al.screen_id && !screenIds.has(al.screen_id)) {
        violations.push({
          type: 'orphaned_asset_layout',
          asset_layout_id: al.id,
          asset_id: al.asset_id,
          dead_screen_id: al.screen_id,
          severity: 'high',
        });
      }
    }

    // ── Check PublishedScreen integrity ────────────────────────────────────────
    const allPublished = await base44.asServiceRole.entities.PublishedScreen.list();
    for (const ps of allPublished) {
      if (ps.screen_id && !screenIds.has(ps.screen_id)) {
        violations.push({
          type: 'orphaned_published_screen',
          published_screen_id: ps.id,
          asset_id: ps.asset_id,
          dead_screen_id: ps.screen_id,
          severity: 'high',
        });
      }
    }

    // ── Check RuntimeZone integrity ────────────────────────────────────────────
    const allRuntimeZones = await base44.asServiceRole.entities.RuntimeZone.list();
    const publishedIds = new Set(allPublished.map((p) => p.id));
    for (const rz of allRuntimeZones) {
      if (rz.published_screen_id && !publishedIds.has(rz.published_screen_id)) {
        violations.push({
          type: 'orphaned_runtime_zone',
          runtime_zone_id: rz.id,
          dead_published_screen_id: rz.published_screen_id,
          severity: 'high',
        });
      }
    }

    const summary = {
      total_screens: activeScreens.length,
      total_violations: violations.length,
      critical: violations.filter((v) => v.severity === 'critical').length,
      high: violations.filter((v) => v.severity === 'high').length,
      warning: violations.filter((v) => v.severity === 'warning').length,
    };

    console.log(
      `[validateScreenIntegrity] Summary: ${summary.total_violations} violations found`
    );

    return Response.json({
      ok: true,
      summary,
      violations,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[validateScreenIntegrity] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});