import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

const DEFAULTS = {
  public_app_origin: 'https://app.screenfleet.io',
  player_route: '/player',
  payload_function: 'screenPayload',
  version_function: 'screenVersionCheck',
  environment: 'production',
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const existing = await base44.asServiceRole.entities.AppConfig.list();

    if (existing.length > 0) {
      return Response.json({
        message: 'AppConfig already exists',
        config: existing[0],
        seeded: false,
      });
    }

    const config = await base44.asServiceRole.entities.AppConfig.create(DEFAULTS);

    console.log('[seedAppConfig] AppConfig seeded with defaults:', DEFAULTS);

    return Response.json({
      message: 'AppConfig seeded successfully',
      config,
      seeded: true,
    });
  } catch (error) {
    console.error('[seedAppConfig] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});