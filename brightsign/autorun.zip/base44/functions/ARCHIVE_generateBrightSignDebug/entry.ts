// ARCHIVED: Contains unique logic — review before permanent deletion.
// Stages boot_test, runtime_shell, config_test, payload_test, canvas_test, and full_native are
// NOT covered by generateBrightSignCleanStages. The bridge/HDMI stages (bridge_js_only through
// hdmi_test) have been superseded by the cleaner generateBrightSignCleanStages implementation,
// but the full network-connected player.js with localStorage caching and version polling is unique.

/**
 * V2 BrightSign Staged Debug Package Generator
 * Creates 7 isolation stages to identify which component breaks the full package:
 * 
 * Stage 0: boot_test — Minimal working package (PROVEN WORKING)
 * Stage 1: runtime_shell — Add local player.js skeleton, no network
 * Stage 2: config_test — Add config.json loading, display metadata
 * Stage 3: payload_test — Add network fetch to screenPayload, show zone count
 * Stage 4: canvas_test — Add HTML canvas rendering of payload
 * Stage 5: hdmi_test — Add HDMI bridge and native activation
 * Stage 6: full_native — Add service worker + caching (complete package)
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';
import { ZipWriter, BlobWriter, TextReader } from 'npm:@zip.js/zip.js@2.7.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { assetId, stage = 'boot_test' } = body;

    // Validate stage
    const VALID_STAGES = ['boot_test', 'runtime_shell', 'config_test', 'payload_test', 'canvas_test', 'bridge_js_only', 'bridge_js_send', 'bridge_bs_receive', 'bridge_bs_ack', 'hdmi_object_creation', 'hdmi_test', 'full_native'];
    if (!VALID_STAGES.includes(stage)) {
      return Response.json({ 
        error: `Invalid stage. Must be one of: ${VALID_STAGES.join(', ')}`,
        received: { stage }
      }, { status: 400 });
    }

    if (!assetId) return Response.json({ error: 'assetId is required. Pass { assetId: "...", stage: "boot_test" }' }, { status: 400 });

    const assets = await base44.asServiceRole.entities.Asset.filter({ id: assetId });
    const asset = assets[0];
    if (!asset) return Response.json({ error: 'Asset not found' }, { status: 404 });

    let screens = await base44.asServiceRole.entities.Screen.filter({ asset_id: assetId });
    if (!screens.length) return Response.json({ error: 'No screens configured for this asset' }, { status: 400 });

    screens = screens.sort((a, b) => {
      const yDiff = (a.start_y || 0) - (b.start_y || 0);
      if (yDiff !== 0) return yDiff;
      const xDiff = (a.start_x || 0) - (b.start_x || 0);
      if (xDiff !== 0) return xDiff;
      return (a.created_date || '').localeCompare(b.created_date || '');
    });

    const primaryScreen = screens[0];
    const screenWidth = primaryScreen.width || 1920;
    const screenHeight = primaryScreen.height || 1080;

    const configs = await base44.asServiceRole.entities.AppConfig.list().catch(() => []);
    const appConfig = configs[0];
    const apiOrigin = appConfig?.public_app_origin || 'https://app.screenfleet.io';

    const stageIndex = VALID_STAGES.indexOf(stage);

    // ── config.json (Stage 2+) ────────────────────────────────────────────────
    const configJson = JSON.stringify({
      screenId: primaryScreen.id,
      screenName: primaryScreen.name,
      screenWidth,
      screenHeight,
      assetId,
      assetName: asset.name,
      apiOrigin,
      versionCheckFn: 'screenVersionCheck',
      payloadFn: 'screenPayload',
      pollIntervalMs: 60000,
      generatedAt: new Date().toISOString(),
      runtimeScope: 'screen',
      debugStage: stage,
      debugStageIndex: stageIndex,
    }, null, 2);

    // ── autorun.brs (Ultra-minimal bridge isolation) ──────────────────────────
    // Stage 5A-1 (bridge_js_only): NO BrightScript changes — identical to Stage 3
    // Stage 5A-2 (bridge_js_send): NO BrightScript changes — JS sends, BS ignores
    // Stage 5A-3 (bridge_bs_receive): BrightScript logs receipt ONLY, no reply
    // Stage 5A-4 (bridge_bs_ack): BrightScript sends minimal ACK back
    const bridgeMode = stage === 'bridge_js_only' ? 'none' :
                       stage === 'bridge_js_send' ? 'js_send_only' :
                       stage === 'bridge_bs_receive' ? 'bs_receive_only' :
                       stage === 'bridge_bs_ack' ? 'bs_ack' : 'disabled';
    const includeBridge = ['bridge_js_only', 'bridge_js_send', 'bridge_bs_receive', 'bridge_bs_ack'].includes(stage);
    
    const autorunBrs = `' ScreenFleet V2 — Debug Stage: ${stage} (index ${stageIndex})
' Asset: ${asset.name} | Screen: ${primaryScreen.name} | Res: ${screenWidth}x${screenHeight}
' Generated: ${new Date().toISOString()}
' Bridge Mode: ${bridgeMode.toUpperCase()}
' 
' STAGE 3 COMPARISON (WORKING):
' - No HDMI functions
' - No global variables
' - No PostMessage calls
' - Simple message loop: Wait → check type → ignore
' 
' STAGE 5A ADDITIONS (CRASH INVESTIGATION):
${stage === 'bridge_js_only' ? `- NONE — identical to Stage 3` : ''}
${stage === 'bridge_js_send' ? `- NONE — identical to Stage 3 (JS sends, BS ignores)` : ''}
${stage === 'bridge_bs_receive' ? `- Print log when message received (NO reply)` : ''}
${stage === 'bridge_bs_ack' ? `- Print log + PostMessage ACK back to HTML` : ''}

Sub Main()
    Print "[SF] ══ Stage ${stageIndex}: ${stage} ══"
    Print "[SF] Asset: ${asset.name} | Screen: ${primaryScreen.name}"
    Print "[SF] Bridge Mode: ${bridgeMode}"
    
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    Print "[SF] roHtmlWidget shown. Waiting for messages..."
    
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" And payload.reason = "message" Then
                If Type(payload.message) = "roAssociativeArray" Then
                    ' CRITICAL FIX: Extract msgType safely AFTER Type() check
                    msgType = payload.message.type
                    Print "[SF-MSG] Received message type: " + msgType
                    
${stage === 'bridge_js_only' || stage === 'bridge_js_send' ? `                    ' STAGE 5A-1/5A-2: No BrightScript handling — ignore message
                    Print "[SF-BRIDGE] Message ignored (JS-only mode)"` : ''}
${stage === 'bridge_bs_receive' ? `                    ' STAGE 5A-3: Log receipt only, NO reply
                    Print "[SF-BRIDGE] Message received (receive-only mode)"
                    Print "[SF-BRIDGE] Type: " + msgType
                    If payload.message.type = "SF_TEST" Or payload.message.type = "SF_HDMI_ZONES" Then
                        Print "[SF-BRIDGE] ✓ Message logged successfully"
                    End If` : ''}
${stage === 'bridge_bs_ack' ? `                    ' STAGE 5A-4: Log + minimal ACK
                    Print "[SF-BRIDGE] Message received (ACK mode)"
                    Print "[SF-BRIDGE] Type: " + msgType
                    
                    ' Minimal ACK - just a simple string, no complex objects
                    ackMsg = {
                        type: "SF_ACK",
                        received: msgType,
                        ts: StrI(CreateObject("roTime").AsSeconds())
                    }
                    
                    On Error Resume Next
                    h.PostMessage(ackMsg)
                    errVal = Err()
                    On Error Goto 0
                    
                    If errVal <> 0 Then
                        Print "[SF-BRIDGE] ✗ PostMessage failed with error " + StrI(errVal)
                    Else
                        Print "[SF-BRIDGE] ✓ ACK sent to HTML"
                    End If` : ''}
                End If
            End If
        End If
    End While
End Sub
`;

    // ── player.js — Staged build (CLEAN - no template interpolation) ─────────
    // Stage 5A-1 (bridge_js_only): TRUE Stage 3 clone - NO conditional code
    const playerJs = `
// ScreenFleet V2 — Debug Stage: ${stage} (index ${stageIndex})
// Stage 5A-1: bridge_js_only — TRUE Stage 3 clone (PROVEN WORKING)

window.__SF_DEBUG_STAGE__ = '${stage}';
window.__SF_DEBUG_STAGE_INDEX__ = ${stageIndex};
window.__SF_ASSET_ID__ = '${assetId}';
window.__SF_SCREEN_ID__ = '${primaryScreen.id}';
window.__SF_GENERATED_AT__ = '${new Date().toISOString()}';

console.log('[SF] Stage 5A-1: bridge_js_only (Stage 3 equivalent)');
console.log('[SF] Asset: ${asset.name} | Screen: ${primaryScreen.name}');

let CFG = null;
let currentPayload = null;
let knownVersion = null;
let zoneTimers = {};
const PAYLOAD_KEY = 'sf_v2_payload';
const VERSION_KEY = 'sf_v2_version';

async function boot() {
  const cfgRes = await fetch('./config.json');
  CFG = await cfgRes.json();

  const stored = localStorage.getItem(PAYLOAD_KEY);
  if (stored) {
    try {
      currentPayload = JSON.parse(stored);
      knownVersion = currentPayload.content_version;
      renderPayload(currentPayload);
    } catch (_) {}
  }

  await refreshPayload();
  setInterval(pollVersion, CFG.pollIntervalMs || 60000);
}

async function invokeFunction(fnName, params) {
  const origin = CFG.apiOrigin;
  const url = origin + '/functions/' + fnName;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return res.json();
}

async function pollVersion() {
  try {
    const data = await invokeFunction(CFG.versionCheckFn, { screenId: CFG.screenId });
    if (data.content_version && data.content_version !== knownVersion) {
      console.log('[Player] Version changed, refreshing payload');
      await refreshPayload();
    }
  } catch (e) { console.warn('[Player] Version check failed (offline?)', e.message); }
}

async function refreshPayload() {
  try {
    const data = await invokeFunction(CFG.payloadFn, { screenId: CFG.screenId });
    if (!data || data.status === 'error') return;

    localStorage.setItem(PAYLOAD_KEY, JSON.stringify(data));
    localStorage.setItem(VERSION_KEY, data.content_version);
    knownVersion = data.content_version;
    currentPayload = data;
    renderPayload(data);
  } catch (e) { console.warn('[Player] Payload fetch failed (offline?)', e.message); }
}

function renderPayload(payload) {
  var canvas = document.getElementById('canvas');
  if (!canvas) return;

  Object.values(zoneTimers).forEach(function(t) { clearTimeout(t); });
  zoneTimers = {};

  canvas.innerHTML = '';
  canvas.style.width = payload.screen_width + 'px';
  canvas.style.height = payload.screen_height + 'px';

  var zones = payload.zones || [];
  zones.forEach(function(zone) { renderZone(canvas, zone); });
}

function renderZone(canvas, zone) {
  if (zone.content_source_type === 'hdmi_input') {
    var hdmiEl = document.createElement('div');
    hdmiEl.style.cssText = 'position:absolute;left:' + (zone.x || 0) + 'px;top:' + (zone.y || 0) + 'px;width:' + zone.width + 'px;height:' + zone.height + 'px;z-index:' + (zone.z_index || 1) + ';background:transparent;';
    canvas.appendChild(hdmiEl);
    return;
  }

  var el = document.createElement('div');
  el.style.cssText = 'position:absolute;left:' + (zone.x || 0) + 'px;top:' + (zone.y || 0) + 'px;width:' + zone.width + 'px;height:' + zone.height + 'px;z-index:' + (zone.z_index || 1) + ';background:' + (zone.background_color || '#000') + ';';
  canvas.appendChild(el);

  var items = zone.playback_track ? zone.playback_track.items || [] : [];
  if (!items.length) return;
  playTrack(el, zone, items, 0);
}

function playTrack(el, zone, items, index) {
  var item = items[index % items.length];
  if (!item) return;

  el.innerHTML = '';
  var fitCss = item.fit_mode === 'fit' ? 'contain' : (item.fit_mode === 'stretch' ? 'fill' : (item.fit_mode === 'center' ? 'none' : 'cover'));
  var volume = zone.volume != null ? zone.volume : 100;

  if (item.file_type === 'video') {
    var v = document.createElement('video');
    v.src = item.file_url;
    v.autoplay = true;
    v.playsInline = true;
    v.muted = volume === 0;
    v.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:' + fitCss;
    v.onended = function() { playTrack(el, zone, items, index + 1); };
    v.onerror = function() { playTrack(el, zone, items, index + 1); };
    el.appendChild(v);
  } else {
    var img = document.createElement('img');
    img.src = item.file_url;
    img.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:' + fitCss;
    el.appendChild(img);
    var dur = (item.duration != null ? item.duration : 8) * 1000;
    var loop = !zone.playback_track || zone.playback_track.loop !== false;
    var nextIndex = index + 1;
    if (loop || nextIndex < items.length) {
      zoneTimers[zone.id] = setTimeout(function() { playTrack(el, zone, items, nextIndex); }, dur);
    }
  }
}

window.addEventListener('load', boot);
`;

    // ── index.html ────────────────────────────────────────────────────────────
    // For Stage 5A-1: Use EXACT Stage 3 index.html - NO debug panel
    const indexHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=${screenWidth}, height=${screenHeight}">
  <title>ScreenFleet - ${asset.name}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: ${screenWidth}px; height: ${screenHeight}px; overflow: hidden; background: transparent; }
    #canvas { position: absolute; top: 0; left: 0; background: transparent; }
    #status { position: fixed; bottom: 8px; right: 8px; color: #ffffff22; font: 10px monospace; z-index: 9999; pointer-events: none; }
  </style>
</head>
<body>
  <div id="canvas"></div>
  <div id="status">ScreenFleet V2 - Stage 5A-1</div>
  <script src="./player.js"></script>
</body>
</html>`;

    // ── sw.js (Stage 6 only) ─────────────────────────────────────────────────
    const swJs = `
// ScreenFleet V2 Service Worker — Stage 6 only
const CACHE_NAME = 'sf-v2-media';
self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(clients.claim()); });
self.addEventListener('fetch', event => {
  const url = event.request.url;
  if (!url.startsWith('http')) return;
  const ext = url.split('?')[0].split('.').pop().toLowerCase();
  const isMedia = ['jpg','jpeg','png','gif','webp','mp4','mov','webm'].includes(ext);
  if (!isMedia) return;
  event.respondWith(
    caches.open(CACHE_NAME).then(cache =>
      cache.match(event.request).then(cached => cached || fetch(event.request).then(response => {
        if (response.ok) cache.put(event.request, response.clone());
        return response;
      }))
    )
  );
});
`;

    // ── README.txt ────────────────────────────────────────────────────────────
    const readme = `ScreenFleet V2 — Debug Stage: ${stage.toUpperCase()} (Index ${stageIndex})
============================================================
Asset:      ${asset.name}
Screen:     ${primaryScreen.name} (${primaryScreen.id})
Resolution: ${screenWidth}x${screenHeight}
API Origin: ${apiOrigin}
Generated:  ${new Date().toUTCString()}
Bridge Mode: ${bridgeMode.toUpperCase()}

STAGE PURPOSE — ULTRA-MINIMAL BRIDGE ISOLATION
----------------------------------------------
${stage === 'bridge_js_only' ? '✓ Stage 5A-1 — Stage 3 + JS debug labels, NO postBSMessage, NO BrightScript changes' : ''}
${stage === 'bridge_js_send' ? '✓ Stage 5A-2 — JS sends postBSMessage, BrightScript ignores (no handler)' : ''}
${stage === 'bridge_bs_receive' ? '✓ Stage 5A-3 — BrightScript logs message receipt ONLY (no reply)' : ''}
${stage === 'bridge_bs_ack' ? '✓ Stage 5A-4 — BrightScript sends minimal ACK back to HTML' : ''}
${stageIndex === 0 ? '✓ PROVEN WORKING — Minimal native boot test (no player.js)' : ''}
${stageIndex === 3 ? '✓ PROVEN WORKING — Payload fetch, no bridge code' : ''}

STAGE 3 vs STAGE 5A COMPARISON (CRASH INVESTIGATION)
----------------------------------------------------
STAGE 3 (WORKING) autorun.brs:
  - No global variables
  - No helper functions
  - Simple message loop: Wait → check type → ignore
  - NO PostMessage calls
  - NO HDMI-specific code

STAGE 5A (CRASHING) autorun.brs ADDITIONS:
  ${stage === 'bridge_js_only' ? '- NONE — identical to Stage 3' : ''}
  ${stage === 'bridge_js_send' ? '- NONE — identical to Stage 3' : ''}
  ${stage === 'bridge_bs_receive' ? '- Print "[SF-BRIDGE] Message received" when message arrives' : ''}
  ${stage === 'bridge_bs_ack' ? '- Print log + h.PostMessage(ackMsg) call' : ''}

SUSPECTED CRASH POINTS:
  1. h.PostMessage() call (Stage 5A-4 only)
  2. Message type checking logic
  3. roHtmlWidgetEvent payload parsing

FILES INCLUDED
--------------
autorun.brs  — ${stage === 'bridge_js_only' || stage === 'bridge_js_send' ? 'Identical to Stage 3 (no changes)' : (stage === 'bridge_bs_receive' ? 'Add Print log only' : (stage === 'bridge_bs_ack' ? 'Add Print + PostMessage' : 'N/A'))}
index.html   — Stage 3 + debug panel
player.js    — ${stage === 'bridge_js_only' ? 'Stage 3 + static debug labels' : (stage === 'bridge_js_send' ? 'Stage 3 + postBSMessage call' : (stage === 'bridge_bs_receive' ? 'Stage 3 + postBSMessage' : (stage === 'bridge_bs_ack' ? 'Stage 3 + postBSMessage + ACK listener' : 'N/A')))}
config.json  — Screen metadata (Stage 2+)
README.txt   — This file

ON-SCREEN DEBUG MARKERS
-----------------------
All stages show:
  ✓ HTML loaded
  ✓ player.js loaded (Stage ${stageIndex})
  ✓ Config loaded: <screenName>
  ✓ Payload fetch SUCCEEDED
  ✓ Zone count: N
  ✓ HDMI zone count: N

Stage-specific markers:
${stage === 'bridge_js_only' ? `  ✓ Bridge test mode: JS_ONLY
  ✓ Stage 5A-1 ready — Stage 3 base + debug labels only` : ''}
${stage === 'bridge_js_send' ? `  ✓ Bridge test mode: JS_SEND_ONLY
  ⏳ JS send attempted...
  ✓ postBSMessage succeeded (or ✗ FAILED)` : ''}
${stage === 'bridge_bs_receive' ? `  ✓ Bridge test mode: BS_RECEIVE_ONLY
  ⏳ Sending test message...
  ✓ Message sent
  ℹ Check BrightScript logs for receipt` : ''}
${stage === 'bridge_bs_ack' ? `  ✓ Bridge test mode: BS_ACK
  ⏳ Sending test message...
  ✓ Message sent
  ⏳ Waiting for BrightScript ACK...
  ✓ BrightScript ACK received! (if successful)` : ''}

TESTING INSTRUCTIONS (SEQUENTIAL)
----------------------------------
STAGE 5A-1 (FIRST): Prove Stage 3 base is stable
1. Deploy Stage 5A-1 package
2. Verify: Screen shows Stage 3 behavior + debug labels
3. If crashes: Stage 5 labeling itself breaks something
4. Expected: NO crash, behaves like Stage 3

STAGE 5A-2 (SECOND): Test JS postBSMessage call
1. Deploy Stage 5A-2 package
2. Verify: "✓ postBSMessage succeeded" or "✗ FAILED"
3. BrightScript ignores message (no handler)
4. If crashes: postBSMessage call itself is the problem

STAGE 5A-3 (THIRD): Test BrightScript message receipt
1. Deploy Stage 5A-3 package
2. Verify: Message sent from JS
3. Check BrightScript logs for "[SF-BRIDGE] Message received"
4. If crashes: BrightScript message parsing is the problem

STAGE 5A-4 (FOURTH): Test BrightScript PostMessage reply
1. ONLY after 5A-3 is stable
2. Deploy Stage 5A-4 package
3. Verify: "✓ BrightScript ACK received!"
4. If crashes: h.PostMessage() is the crash point

NEXT STAGE TO TEST
------------------
→ Start with Stage 5A-1 (bridge_js_only)
→ If stable: proceed to 5A-2
→ If 5A-2 crashes: postBSMessage is the problem
→ If 5A-3 crashes: BrightScript message handling is the problem
→ If 5A-4 crashes: h.PostMessage() is the problem

CRITICAL: Each stage adds ONE line of code.
NO MORE LARGE CHANGES — isolate the exact crash line.
`;

    // ── Build ZIP ─────────────────────────────────────────────────────────────
    const zipBlobWriter = new BlobWriter('application/zip');
    const zipWriter = new ZipWriter(zipBlobWriter);

    await zipWriter.add('autorun.brs', new TextReader(autorunBrs));
    await zipWriter.add('index.html', new TextReader(indexHtml));
    if (stageIndex >= 1) await zipWriter.add('player.js', new TextReader(playerJs));
    if (stageIndex >= 2) await zipWriter.add('config.json', new TextReader(configJson));
    if (stageIndex >= 6) await zipWriter.add('sw.js', new TextReader(swJs));
    await zipWriter.add('README.txt', new TextReader(readme));

    await zipWriter.close();
    const zipBlob = await zipBlobWriter.getData();

    const arrayBuffer = await zipBlob.arrayBuffer();
    const uint8 = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < uint8.length; i++) binary += String.fromCharCode(uint8[i]);
    const base64 = btoa(binary);
    const filename = `brightsign-v2-debug-${stage}-${asset.name.toLowerCase().replace(/\s+/g, '-')}.zip`;

    return Response.json({ base64, filename, stage, stageIndex });

  } catch (error) {
    console.error('generateBrightSignDebug error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});