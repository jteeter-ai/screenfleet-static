/**
 * diagnoseZoneGeometry
 * Inspects the full data chain for a given screen to diagnose multi-zone geometry bugs.
 * POST { screenId }
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { screenId } = await req.json();
    if (!screenId) return Response.json({ error: 'screenId required' }, { status: 400 });

    // 1. Screen
    const screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
    const screen = screens[0];
    if (!screen) return Response.json({ error: `Screen not found: ${screenId}` }, { status: 404 });

    // 2. AssetLayout → LayoutTemplate for this screen
    const assetLayouts = await base44.asServiceRole.entities.AssetLayout.filter({ screen_id: screenId });
    const assetLayout = assetLayouts[0] || null;
    const layoutTemplateId = assetLayout?.layout_template_id || null;

    // 3. LayoutZone records (source of truth for geometry in publish pipeline)
    const layoutZones = layoutTemplateId
      ? await base44.asServiceRole.entities.LayoutZone.filter({ layout_template_id: layoutTemplateId })
      : [];

    // 4. LayoutTemplate metadata
    const layoutTemplates = layoutTemplateId
      ? await base44.asServiceRole.entities.LayoutTemplate.filter({ id: layoutTemplateId })
      : [];
    const template = layoutTemplates[0] || null;

    // 5. PublishedScreen (most recent)
    const published = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screenId });
    const ps = published.sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0] || null;

    // 6. RuntimeZones
    const runtimeZones = ps
      ? await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: ps.id })
      : [];

    // --- Geometry analysis ---
    const allRtZerosX = runtimeZones.length > 1 && runtimeZones.every(z => (z.x ?? 0) === 0);
    const allLzZerosX = layoutZones.length > 1 && layoutZones.every(z => (z.x ?? 0) === 0);

    let geometry_diagnosis;
    if (runtimeZones.length === 0) {
      geometry_diagnosis = 'NO RUNTIME ZONES — screen has not been published yet or publish failed';
    } else if (allLzZerosX) {
      geometry_diagnosis = 'BUG IN LAYOUT ZONES — all LayoutZone records have x=0. The layout template zones were never given correct x positions. Fix: go to Layout Templates and set correct x positions for each zone.';
    } else if (allRtZerosX) {
      geometry_diagnosis = 'BUG IN PUBLISH PIPELINE — LayoutZones have correct x values but RuntimeZones all have x=0. The x field is not being written during publish. Republish to fix.';
    } else {
      geometry_diagnosis = 'Geometry looks correct — x values are varied across zones. Bug may be in Player rendering or syncToPlayer payload.';
    }

    return Response.json({
      screen: {
        id: screen.id,
        name: screen.name,
        width: screen.width,
        height: screen.height,
        asset_id: screen.asset_id,
      },
      assetLayout: assetLayout
        ? { id: assetLayout.id, layout_template_id: assetLayout.layout_template_id }
        : null,
      layoutTemplate: template
        ? { id: template.id, name: template.name, canvas_width: template.canvas_width, canvas_height: template.canvas_height }
        : null,
      layoutZones: layoutZones.map(z => ({
        id: z.id,
        name: z.name,
        x: z.x,
        y: z.y,
        width: z.width,
        height: z.height,
        z_index: z.z_index,
        default_source_type: z.default_source_type,
      })),
      publishedScreen: ps
        ? { id: ps.id, published_at: ps.published_at, content_version: ps.content_version, zone_count: ps.zone_count }
        : null,
      runtimeZones: runtimeZones.map(z => ({
        id: z.id,
        name: z.name,
        x: z.x,
        y: z.y,
        width: z.width,
        height: z.height,
        z_index: z.z_index,
        fit_mode: z.fit_mode,
        content_source_type: z.content_source_type,
        item_count: z.playback_track?.items?.length ?? 0,
        first_item: z.playback_track?.items?.[0]
          ? { type: z.playback_track.items[0].file_type || z.playback_track.items[0].content_type, url: (z.playback_track.items[0].file_url || '').substring(0, 80) }
          : null,
      })),
      geometry_diagnosis,
    });
  } catch (err) {
    return Response.json({ error: err?.message }, { status: 500 });
  }
});