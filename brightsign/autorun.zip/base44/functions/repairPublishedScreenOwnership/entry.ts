/**
 * Repair function: backfill missing or incorrect org_id on PublishedScreen records.
 * Admin only. Uses service role.
 * 
 * POST (no body required)
 * Returns: { repaired, skipped, mismatched, failed, total }
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const all = await base44.asServiceRole.entities.PublishedScreen.list();
    let repaired = 0, skipped = 0, mismatched = 0, failed = 0;
    const repairs = [];

    for (const ps of all) {
      try {
        // Resolve authoritative org via Screen → Asset
        const screens = await base44.asServiceRole.entities.Screen.filter({ id: ps.screen_id });
        const screen = screens[0];
        if (!screen) { failed++; continue; }

        const assetId = screen.asset_id || ps.asset_id;
        if (!assetId) { failed++; continue; }

        const assets = await base44.asServiceRole.entities.Asset.filter({ id: assetId });
        const asset = assets[0];
        if (!asset?.org_id) { failed++; continue; }

        const correctOrgId = asset.org_id;

        if (ps.org_id === correctOrgId) {
          skipped++;
          continue;
        }

        if (ps.org_id && ps.org_id !== correctOrgId) {
          mismatched++;
          console.warn('[repairPublishedScreenOwnership] MISMATCH', { id: ps.id, had: ps.org_id, correct: correctOrgId });
        }

        await base44.asServiceRole.entities.PublishedScreen.update(ps.id, { org_id: correctOrgId });
        console.log('[repairPublishedScreenOwnership] REPAIRED', { id: ps.id, org_id: correctOrgId });
        repaired++;
        repairs.push({ id: ps.id, old_org_id: ps.org_id || null, new_org_id: correctOrgId });
      } catch (e) {
        console.error('[repairPublishedScreenOwnership] FAILED', ps.id, e.message);
        failed++;
      }
    }

    console.log('[repairPublishedScreenOwnership] DONE', { total: all.length, repaired, skipped, mismatched, failed });

    return Response.json({ ok: true, total: all.length, repaired, skipped, mismatched, failed, repairs });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});