/**
 * regenerateScreenToken — Admin action to regenerate Player URL
 *
 * Creates a new public_token, updates Player with new token,
 * deactivates old token, logs action.
 *
 * Use case: Device is stuck on old URL or token needs refresh.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { screen_id } = await req.json();
    if (!screen_id) {
      return Response.json({ error: 'screen_id required' }, { status: 400 });
    }

    // ── Load screen ───────────────────────────────────────────────────────────
    const screens = await base44.entities.Screen.filter({ id: screen_id });
    const screen = screens[0];
    if (!screen) {
      return Response.json({ error: 'Screen not found' }, { status: 404 });
    }

    // Verify org membership for non-platform-admins
    if (user.role !== 'admin' && screen.org_id) {
      const memberships = await base44.asServiceRole.entities.OrgMember.filter({ user_email: user.email, org_id: screen.org_id });
      const member = memberships[0];
      if (!member || !['owner', 'admin', 'manager', 'ops_manager'].includes(member.org_role)) {
        return Response.json({ error: 'Forbidden: insufficient org permissions' }, { status: 403 });
      }
    }

    if (screen.status === 'archived') {
      return Response.json(
        { error: 'Cannot regenerate token for archived screen' },
        { status: 400 }
      );
    }

    const oldToken = screen.public_token;

    // ── Generate new token (UUID) ──────────────────────────────────────────────
    const newToken = crypto.randomUUID();

    // ── Deactivate old token on Player ─────────────────────────────────────────
    const config = (await base44.entities.AppConfig.list())[0];
    const playerOrigin = config?.player_app_origin?.replace(/\/$/, '');
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');

    let oldTokenDeactivated = false;
    if (playerOrigin && syncSecret && oldToken) {
      const deactRes = await fetch(`${playerOrigin}/functions/syncScreenData`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-sync-secret': syncSecret,
        },
        body: JSON.stringify({
          action: 'deactivate',
          public_token: oldToken,
          cms_screen_id: screen_id,
        }),
      }).catch((err) => {
        console.warn(
          `[regenerateScreenToken] Old token deactivate failed: ${err.message}`
        );
        return null;
      });

      oldTokenDeactivated = deactRes?.ok === true;
    }

    // ── Update Screen with new token ───────────────────────────────────────────
    await base44.entities.Screen.update(screen_id, {
      public_token: newToken,
      token_regenerated_at: new Date().toISOString(),
    });

    // ── Sync new token to Player ───────────────────────────────────────────────
    // Player will create a new PlayerScreen row for the new token
    // and mark the old token inactive.

    // ── Create audit log ───────────────────────────────────────────────────────
    const auditEntry = {
      action: 'regenerate_screen_token',
      user_email: user.email,
      screen_id,
      screen_name: screen.name,
      org_id: screen.org_id,
      old_token: oldToken,
      new_token: newToken,
      old_token_deactivated: oldTokenDeactivated,
      timestamp: new Date().toISOString(),
    };

    console.log('[regenerateScreenToken] Audit:', JSON.stringify(auditEntry));

    return Response.json({
      ok: true,
      screen_id,
      screen_name: screen.name,
      old_token: oldToken,
      new_token: newToken,
      old_token_deactivated: oldTokenDeactivated,
      player_url: config?.player_app_origin
        ? `${config.player_app_origin.replace(/\/$/, '')}/player/${newToken}`
        : 'N/A (player origin not configured)',
    });
  } catch (error) {
    console.error('[regenerateScreenToken] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});