/**
 * debugPlayerRecord — Read the exact stored Player-side record for a screen token.
 * Calls the Player app's own API to return what it actually has stored after sync.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { publicToken, screenId } = body;

    const configs = await base44.asServiceRole.entities.AppConfig.list();
    const appConfig = configs[0];
    const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '');
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');

    if (!playerOrigin) return Response.json({ error: 'player_app_origin not configured' }, { status: 400 });
    if (!syncSecret) return Response.json({ error: 'PLAYER_SYNC_SECRET not set' }, { status: 400 });

    // Resolve token from screenId if not provided directly
    let token = publicToken;
    let screenId2 = screenId;
    if (!token && screenId2) {
      const screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId2 });
      token = screens[0]?.public_token;
    }
    if (token && !screenId2) {
      const screens = await base44.asServiceRole.entities.Screen.filter({ public_token: token });
      screenId2 = screens[0]?.id;
    }
    if (!token) return Response.json({ error: 'publicToken or screenId required' }, { status: 400 });

    console.log(`[debugPlayerRecord] token=${token} screenId2=${screenId2}`);

    // Probe multiple Player endpoints in parallel to find where stored record lives
    const probeEndpoints = [
      { name: 'getScreenByToken', body: { public_token: token } },
      { name: 'getScreenByToken', body: { token } },
      { name: 'syncScreenData', body: { action: 'get', public_token: token } },
      { name: 'syncScreenData', body: { action: 'read', public_token: token } },
      { name: 'getScreen', body: { public_token: token } },
      { name: 'getScreenData', body: { public_token: token } },
      { name: 'screenPayload', body: { public_token: token } },
      { name: 'screenPayload', body: { screenId: screenId2 } },
    ];

    const probeResults = await Promise.all(probeEndpoints.map(async (ep) => {
      const url = `${playerOrigin}/functions/${ep.name}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
        body: JSON.stringify(ep.body),
      }).catch(e => ({ status: -1, json: async () => ({ network_error: e.message }) }));
      const body = await res.json().catch(() => null);
      return { endpoint: ep.name, request_body: ep.body, status: res.status, response: body };
    }));

    // Find first successful probe
    const successful = probeResults.find(r => r.status === 200);
    const readRes = { status: successful?.status || 0 };
    const readBody = successful?.response || null;
    console.log(`[debugPlayerRecord] probe results:`, probeResults.map(r => `${r.endpoint}(${JSON.stringify(r.request_body)})=${r.status}`).join(', '));

    if (!readRes.ok || !readBody) {
      // Fallback: try syncScreenData with action: 'get'
      console.log('[debugPlayerRecord] Trying syncScreenData action=get fallback');
      const fallbackRes = await fetch(`${playerOrigin}/functions/syncScreenData`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-sync-secret': syncSecret,
        },
        body: JSON.stringify({ action: 'get', public_token: token }),
      });
      const fallbackBody = await fallbackRes.json().catch(() => null);
      console.log(`[debugPlayerRecord] syncScreenData(get) status=${fallbackRes.status}`, JSON.stringify(fallbackBody).slice(0, 500));

      return Response.json({
        token,
        getScreenByToken_status: readRes.status,
        getScreenByToken_body: readBody,
        syncScreenData_get_status: fallbackRes.status,
        syncScreenData_get_body: fallbackBody,
      });
    }

    // Drill into zones and extract first item per zone
    const zones = readBody?.zones || readBody?.screen_data?.zones || [];
    const zoneItemSummary = zones.map((z, i) => {
      const firstItem = z?.playback_track?.items?.[0] || null;
      return {
        zone_index: i,
        zone_name: z?.name,
        item_count: z?.playback_track?.items?.length || 0,
        first_item: firstItem,
        first_item_keys: firstItem ? Object.keys(firstItem) : [],
        // Specifically check the fields that matter
        has_file_url: !!firstItem?.file_url,
        has_file_type: !!firstItem?.file_type,
        has_url: !!firstItem?.url,
        has_type: !!firstItem?.type,
        file_url_value: firstItem?.file_url || null,
        url_value: firstItem?.url || null,
        type_value: firstItem?.type || null,
        file_type_value: firstItem?.file_type || null,
      };
    });

    return Response.json({
      token,
      player_origin: playerOrigin,
      raw_response_keys: readBody ? Object.keys(readBody) : [],
      zone_count: zones.length,
      zone_item_summary: zoneItemSummary,
      // Full raw response for deep inspection
      raw_player_record: readBody,
    });

  } catch (error) {
    console.error('[debugPlayerRecord] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});