import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token } = await req.json();

    if (!token) {
      return Response.json({ error: 'Token is required' }, { status: 400 });
    }

    // Look up token
    const tokens = await base44.asServiceRole.entities.AppToken.filter({ token });
    if (!tokens || tokens.length === 0) {
      return Response.json({ error: 'Invalid token', code: 'INVALID_TOKEN' }, { status: 404 });
    }

    const appToken = tokens[0];

    // Check already used
    if (appToken.used_at) {
      return Response.json({ error: 'This setup link has already been used.', code: 'TOKEN_USED' }, { status: 410 });
    }

    // Check expiry
    if (new Date(appToken.expires_at) < new Date()) {
      return Response.json({ error: 'This setup link has expired. Please contact your administrator for a new invitation.', code: 'TOKEN_EXPIRED' }, { status: 410 });
    }

    // Mark token as used
    await base44.asServiceRole.entities.AppToken.update(appToken.id, {
      used_at: new Date().toISOString(),
    });

    console.log('[redeemSetupToken] Success for:', appToken.user_email);
    return Response.json({
      success: true,
      user_email: appToken.user_email,
      org_name: appToken.org_name,
      org_id: appToken.org_id,
    });
  } catch (error) {
    console.error('redeemSetupToken error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});