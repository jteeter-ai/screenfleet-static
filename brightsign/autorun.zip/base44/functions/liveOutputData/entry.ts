import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * liveOutputData — V2 screen preview data for Live Output Dashboard thumbnails.
 *
 * V2 DATA MODEL: Screen → PublishedScreen → RuntimeZone.playback_track
 * Returns screen metadata + zones with first-frame preview URL for each zone.
 *
 * FIXED: Previously queried the V1 Zone entity (zone_scope="runtime") which
 * is obsolete in V2. All zone data now lives in RuntimeZone.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { screenId } = body;

    if (!screenId) {
      return Response.json({ error: 'screenId required' }, { status: 400 });
    }

    // Fetch screen
    const screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
    const screen = screens[0];
    if (!screen) {
      return Response.json({ error: 'Screen not found' }, { status: 404 });
    }

    // Fetch latest PublishedScreen
    const publishedList = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screenId });
    if (!publishedList.length) {
      return Response.json({ screen: { id: screen.id, name: screen.name, width: screen.width, height: screen.height, status: screen.status }, zones: [] });
    }

    const published = publishedList.sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0];

    // Fetch RuntimeZones for this published screen
    const runtimeZones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: published.id });
    const sortedZones = runtimeZones.sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1));

    // Build enriched zone list — extract first playable item for preview thumbnail
    const zones = sortedZones.map(rz => {
      const items = rz.playback_track?.items || [];
      const firstItem = items[0] || null;

      return {
        id: rz.id,
        name: rz.name,
        x: rz.x ?? 0,
        y: rz.y ?? 0,
        width: rz.width,
        height: rz.height,
        z_index: rz.z_index ?? 1,
        content_type: rz.content_source_type || 'empty',
        background_color: rz.background_color || '#000000',
        is_visible: true,
        // Preview fields (first frame)
        media_url: firstItem?.file_url || null,
        media_file_type: firstItem?.file_type || null,
        // Pass full playback track so RuntimeCanvas can render it
        playback_track: rz.playback_track || { loop: true, items: [] },
        content_source_type: rz.content_source_type || 'empty',
        canvas_creative_data: rz.canvas_creative_data || null,
        fit_mode: rz.fit_mode || 'fill',
        volume: rz.volume ?? 100,
      };
    });

    return Response.json({
      screen: {
        id: screen.id,
        name: screen.name,
        // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
        // Screen.truck_id is a V1 field. Remove once all consumers use asset_id only.
        truck_id: screen.truck_id,
        asset_id: screen.asset_id,
        width: screen.width,
        height: screen.height,
        status: screen.status,
      },
      zones,
      published_at: published.published_at,
      content_version: published.content_version,
    });
  } catch (error) {
    console.error('liveOutputData error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});