/**
 * archiveScreen — Soft delete a screen with transactional cleanup
 *
 * Flow:
 * 1. Validate screen exists and is active
 * 2. Delete all AssetLayout records
 * 3. Delete all PublishedScreen records
 * 4. Change Screen.status to "archived"
 * 5. Call Player API to deactivate token
 * 6. Log audit entry
 * 7. Return cleanup summary
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { screen_id } = await req.json();
    if (!screen_id) {
      return Response.json({ error: 'screen_id required' }, { status: 400 });
    }

    // ── Load screen ───────────────────────────────────────────────────────────
    const screens = await base44.entities.Screen.filter({ id: screen_id });
    const screen = screens[0];
    if (!screen) {
      return Response.json({ error: 'Screen not found' }, { status: 404 });
    }
    if (screen.status === 'archived') {
      return Response.json({ error: 'Screen already archived' }, { status: 400 });
    }

    const org_id = screen.org_id;

    // ── Find and delete AssetLayout records ────────────────────────────────────
    const assetLayouts = await base44.entities.AssetLayout.filter({ screen_id });
    const deletedAssetLayouts = [];
    for (const al of assetLayouts) {
      await base44.entities.AssetLayout.delete(al.id);
      deletedAssetLayouts.push({
        id: al.id,
        asset_id: al.asset_id,
        layout_template_id: al.layout_template_id,
      });
    }

    // ── Find and delete PublishedScreen records ────────────────────────────────
    const published = await base44.entities.PublishedScreen.filter({ screen_id });
    const deletedPublished = [];
    for (const ps of published) {
      await base44.entities.PublishedScreen.delete(ps.id);
      deletedPublished.push({
        id: ps.id,
        asset_id: ps.asset_id,
        content_version: ps.content_version,
        published_at: ps.published_at,
      });
    }

    // ── Update screen status to archived ───────────────────────────────────────
    await base44.entities.Screen.update(screen_id, { status: 'archived' });

    // ── Call Player API to deactivate token ────────────────────────────────────
    const config = (await base44.entities.AppConfig.list())[0];
    const playerOrigin = config?.player_app_origin?.replace(/\/$/, '');
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');

    let playerDeactivateResult = null;
    if (playerOrigin && syncSecret && screen.public_token) {
      const playerRes = await fetch(`${playerOrigin}/functions/syncScreenData`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-sync-secret': syncSecret,
        },
        body: JSON.stringify({
          action: 'deactivate',
          public_token: screen.public_token,
          cms_screen_id: screen_id,
        }),
      }).catch((err) => {
        console.warn(`[archiveScreen] Player deactivate failed: ${err.message}`);
        return null;
      });

      if (playerRes?.ok) {
        playerDeactivateResult = await playerRes.json();
      } else {
        console.warn(
          `[archiveScreen] Player deactivate returned ${playerRes?.status}`
        );
      }
    }

    // ── Create audit log ───────────────────────────────────────────────────────
    const auditEntry = {
      action: 'archive_screen',
      user_email: user.email,
      screen_id,
      screen_name: screen.name,
      org_id,
      public_token: screen.public_token,
      deleted_asset_layouts: deletedAssetLayouts.length,
      deleted_published_screens: deletedPublished.length,
      player_deactivate_status: playerDeactivateResult ? 'success' : 'failed_or_skipped',
      timestamp: new Date().toISOString(),
    };

    console.log('[archiveScreen] Audit:', JSON.stringify(auditEntry));

    return Response.json({
      ok: true,
      screen_id,
      screen_name: screen.name,
      status: 'archived',
      summary: {
        deleted_asset_layouts: deletedAssetLayouts.length,
        deleted_published_screens: deletedPublished.length,
        player_token_deactivated: playerDeactivateResult ? true : false,
      },
      deleted_asset_layouts: deletedAssetLayouts,
      deleted_published_screens: deletedPublished,
      player_result: playerDeactivateResult,
    });
  } catch (error) {
    console.error('[archiveScreen] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});