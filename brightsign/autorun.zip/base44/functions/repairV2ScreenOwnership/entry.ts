/**
 * repairV2ScreenOwnership — admin-only repair function
 *
 * For each Screen:
 * - If asset_id is missing but truck_id matches a V2 Asset id, backfill asset_id
 * - If org_id is missing and asset has org_id, backfill org_id
 * - If asset_id exists but points to a different org than screen.org_id, report mismatch
 *
 * POST (no body required, processes all screens)
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const allScreens = await base44.asServiceRole.entities.Screen.list();
    console.log('[repairV2ScreenOwnership] total screens', allScreens.length);

    let repaired_asset_links = 0;
    let repaired_org_links = 0;
    let mismatched = 0;
    let skipped = 0;
    const details = [];

    // Build asset lookup cache
    const assetCache = {};
    const getAsset = async (id) => {
      if (!id) return null;
      if (assetCache[id] !== undefined) return assetCache[id];
      const records = await base44.asServiceRole.entities.Asset.filter({ id });
      assetCache[id] = records[0] || null;
      return assetCache[id];
    };

    for (const screen of allScreens) {
      const updates = {};
      let action = 'skipped';

      const effectiveAssetId = screen.asset_id || screen.truck_id || null;
      if (!effectiveAssetId) {
        details.push({ screen_id: screen.id, name: screen.name, action: 'skipped', reason: 'no asset_id or truck_id' });
        skipped++;
        continue;
      }

      const asset = await getAsset(effectiveAssetId);
      if (!asset) {
        details.push({ screen_id: screen.id, name: screen.name, action: 'skipped', reason: `asset ${effectiveAssetId} not found` });
        skipped++;
        continue;
      }

      // Check cross-org mismatch
      if (screen.asset_id && screen.org_id && asset.org_id && screen.org_id !== asset.org_id) {
        mismatched++;
        details.push({ screen_id: screen.id, name: screen.name, action: 'mismatch', screen_org_id: screen.org_id, asset_org_id: asset.org_id });
        console.warn('[repairV2ScreenOwnership] MISMATCH', { screen_id: screen.id, screen_org_id: screen.org_id, asset_org_id: asset.org_id });
        continue;
      }

      // Backfill asset_id from truck_id
      if (!screen.asset_id && screen.truck_id) {
        updates.asset_id = screen.truck_id;
        action = 'repaired_asset_link';
        repaired_asset_links++;
      }

      // Backfill org_id from asset
      if (!screen.org_id && asset.org_id) {
        updates.org_id = asset.org_id;
        if (action === 'repaired_asset_link') action = 'repaired_both';
        else action = 'repaired_org_link';
        repaired_org_links++;
      }

      if (Object.keys(updates).length > 0) {
        await base44.asServiceRole.entities.Screen.update(screen.id, updates);
        console.log('[repairV2ScreenOwnership] repaired', { screen_id: screen.id, updates });
        details.push({ screen_id: screen.id, name: screen.name, action, updates });
      } else {
        skipped++;
        details.push({ screen_id: screen.id, name: screen.name, action: 'skipped', reason: 'already correct' });
      }
    }

    const result = {
      ok: true,
      total: allScreens.length,
      repaired_asset_links,
      repaired_org_links,
      mismatched,
      skipped,
      details,
    };

    console.log('[repairV2ScreenOwnership] DONE', { total: allScreens.length, repaired_asset_links, repaired_org_links, mismatched, skipped });
    return Response.json(result);
  } catch (error) {
    console.error('[repairV2ScreenOwnership] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});