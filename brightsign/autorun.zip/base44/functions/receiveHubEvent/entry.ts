import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-hub-secret',
};

const HUB_PLAN_MAP = {
  hub_starter:    { plan_slug: 'starter',  modules: ['module_assets', 'module_playlists', 'module_scheduling'] },
  hub_pro:        { plan_slug: 'growth',   modules: ['module_assets', 'module_playlists', 'module_scheduling', 'module_studio', 'module_media_library'] },
  hub_enterprise: { plan_slug: 'total360', modules: ['module_assets', 'module_playlists', 'module_scheduling', 'module_studio', 'module_media_library', 'module_ooh_operator', 'module_ooh_reporting'] },
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS_HEADERS });

  const hubSecret = req.headers.get('x-hub-secret');
  if (!hubSecret || hubSecret !== Deno.env.get('HUB_SECRET')) {
    return Response.json({ error: 'Unauthorized' }, { status: 401, headers: CORS_HEADERS });
  }

  const base44 = createClientFromRequest(req);
  const { event_id, event_type, org_id, payload } = await req.json();
  console.log('[ScreenFleet] Hub event received:', event_type, org_id);

  // Idempotency check
  if (event_id) {
    const existing = await base44.asServiceRole.entities.HubEventLog.filter({ event_id });
    if (existing.length > 0) {
      console.log('[receiveHubEvent] duplicate event_id, skipping:', event_id);
      return Response.json({ processed: true, skipped: true, event_id }, { status: 200, headers: CORS_HEADERS });
    }
  }

  try {
    switch (event_type) {

      // Client subscribed to a plan that includes ScreenFleet
      case 'screenfleet.access.granted': {
        const { hub_plan_tier, users = [], legion_os_org_id } = payload;
        const mapping = HUB_PLAN_MAP[hub_plan_tier] || HUB_PLAN_MAP['hub_starter'];

        // Find the ScreenFleet org
        let orgs = await base44.asServiceRole.entities.Organization.filter({ id: org_id });
        if (orgs.length === 0) {
          console.warn('[receiveHubEvent] org not found for screenfleet.access.granted:', org_id);
          break;
        }
        const org = orgs[0];

        // Update org plan from hub
        await base44.asServiceRole.entities.Organization.update(org.id, {
          plan_source: 'legion_hub',
          legion_hub_plan_tier: hub_plan_tier,
          legion_os_org_id: legion_os_org_id || null,
          plan_slug: mapping.plan_slug,
          plan_modules_resolved: mapping.modules,
          subscription_status: 'active',
          last_hub_sync_at: new Date().toISOString(),
        });

        // Provision each user — since LegionOS and ScreenFleet share Base44 auth,
        // users who already have a Base44 account from LegionOS just need an OrgMember
        // record created. They log in with the same credentials they use for LegionOS.
        for (const u of users) {
          const existing = await base44.asServiceRole.entities.OrgMember.filter({
            org_id: org.id, user_email: u.email,
          });
          if (existing.length === 0) {
            await base44.asServiceRole.entities.OrgMember.create({
              org_id: org.id,
              user_email: u.email,
              org_role: u.role || 'admin',
              status: 'invited',
              invited_at: new Date().toISOString(),
            });
            try { await base44.users.inviteUser(u.email, 'user'); } catch {}
          } else if (existing[0].status === 'suspended') {
            await base44.asServiceRole.entities.OrgMember.update(existing[0].id, { status: 'active' });
          }
        }
        console.log(`[receiveHubEvent] access granted org=${org.id} tier=${hub_plan_tier} users=${users.length}`);
        break;
      }

      // Client upgraded or downgraded their plan
      case 'screenfleet.plan.changed': {
        const { hub_plan_tier } = payload;
        const mapping = HUB_PLAN_MAP[hub_plan_tier] || HUB_PLAN_MAP['hub_starter'];
        await base44.asServiceRole.entities.Organization.update(org_id, {
          legion_hub_plan_tier: hub_plan_tier,
          plan_slug: mapping.plan_slug,
          plan_modules_resolved: mapping.modules,
          last_hub_sync_at: new Date().toISOString(),
        });
        console.log(`[receiveHubEvent] plan changed org=${org_id} new_tier=${hub_plan_tier}`);
        break;
      }

      // Client cancelled or their Hub subscription lapsed
      case 'screenfleet.access.revoked': {
        await base44.asServiceRole.entities.Organization.update(org_id, {
          subscription_status: 'canceled',
          plan_modules_resolved: [],
          last_hub_sync_at: new Date().toISOString(),
        });
        // Suspend all members so they can't log in
        const members = await base44.asServiceRole.entities.OrgMember.filter({ org_id });
        await Promise.all(members.map(m =>
          base44.asServiceRole.entities.OrgMember.update(m.id, { status: 'suspended' })
        ));
        console.log(`[receiveHubEvent] access revoked org=${org_id}`);
        break;
      }

      // A specific user was added to the org from LegionOS
      case 'screenfleet.user.added': {
        const { email, role } = payload;
        const existing = await base44.asServiceRole.entities.OrgMember.filter({ org_id, user_email: email });
        if (existing.length === 0) {
          await base44.asServiceRole.entities.OrgMember.create({
            org_id, user_email: email, org_role: role || 'operator',
            status: 'invited', invited_at: new Date().toISOString(),
          });
          try { await base44.users.inviteUser(email, 'user'); } catch {}
        }
        break;
      }

      // A specific user was removed from the org in LegionOS
      case 'screenfleet.user.removed': {
        const { email } = payload;
        const members = await base44.asServiceRole.entities.OrgMember.filter({ org_id, user_email: email });
        if (members.length > 0) {
          await base44.asServiceRole.entities.OrgMember.update(members[0].id, { status: 'suspended' });
        }
        break;
      }

      default:
        console.log('[receiveHubEvent] unhandled event type:', event_type, payload);
    }

    // Record processed event for idempotency
    if (event_id) {
      await base44.asServiceRole.entities.HubEventLog.create({
        event_id,
        event_type,
        org_id: org_id || null,
        processed_at: new Date().toISOString(),
      });
    }

    return Response.json(
      { processed: true, app: 'screenfleet', event_id, event_type },
      { status: 200, headers: CORS_HEADERS }
    );
  } catch (err) {
    console.error('[receiveHubEvent] error:', err?.message);
    return Response.json({ error: err?.message }, { status: 500, headers: CORS_HEADERS });
  }
});