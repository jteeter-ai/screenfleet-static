/**
 * repairOrphanedScreenData — CMS integrity cleanup
 *
 * Finds and removes:
 * 1. AssetLayout records pointing to deleted/non-existent Screens
 * 2. PublishedScreen records pointing to deleted/non-existent Screens
 * 3. Orphaned Player-side rows for tokens that no longer have a CMS Screen
 *
 * Also reports duplicate live Screen records per asset (2+ Screens for same asset, all non-deleted).
 *
 * Call with { dryRun: true } to preview without deleting.
 * Call with { dryRun: false } to execute cleanup.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun !== false; // default safe: dryRun=true

    const configs = await base44.asServiceRole.entities.AppConfig.list();
    const appConfig = configs[0];
    const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '');
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');

    // ── Load all live Screens (only existing, non-deleted records come back) ──
    const allScreens = await base44.asServiceRole.entities.Screen.list();
    const liveScreenIds = new Set(allScreens.map(s => s.id));
    const liveTokens = new Set(allScreens.map(s => s.public_token).filter(Boolean));
    const screensByAsset = {};
    for (const s of allScreens) {
      if (!s.asset_id) continue;
      if (!screensByAsset[s.asset_id]) screensByAsset[s.asset_id] = [];
      screensByAsset[s.asset_id].push(s);
    }
    console.log(`[repairOrphanedScreenData] Live screens: ${liveScreenIds.size}`);

    // ── Find duplicate live screens per asset ─────────────────────────────────
    const duplicateAssets = [];
    for (const [assetId, screens] of Object.entries(screensByAsset)) {
      if (screens.length > 1) {
        duplicateAssets.push({
          asset_id: assetId,
          screen_count: screens.length,
          screens: screens.map(s => ({
            id: s.id,
            name: s.name,
            public_token: s.public_token,
            created_date: s.created_date,
            updated_date: s.updated_date,
          })),
          recommendation: 'Manually determine which screen token the device is configured to use, then delete the other(s).',
        });
      }
    }

    // ── Orphaned AssetLayout records ──────────────────────────────────────────
    const allAssetLayouts = await base44.asServiceRole.entities.AssetLayout.list();
    const orphanedAssetLayouts = allAssetLayouts.filter(al => al.screen_id && !liveScreenIds.has(al.screen_id));
    console.log(`[repairOrphanedScreenData] Orphaned AssetLayouts: ${orphanedAssetLayouts.length}`);

    // ── Orphaned PublishedScreen records ──────────────────────────────────────
    const allPublished = await base44.asServiceRole.entities.PublishedScreen.list();
    const orphanedPublished = allPublished.filter(ps => ps.screen_id && !liveScreenIds.has(ps.screen_id));
    console.log(`[repairOrphanedScreenData] Orphaned PublishedScreens: ${orphanedPublished.length}`);

    // ── Find Player-side ghost rows (token exists in Player but not CMS) ──────
    // We probe a known list of ghost tokens identified in prior forensics
    // plus any token NOT in liveTokens that we can verify from Player
    const knownGhostTokens = ['5b20b263-5389-4a12-807f-ae5568a46ce0'];
    const playerGhostResults = [];

    if (playerOrigin && syncSecret) {
      for (const ghostToken of knownGhostTokens) {
        const isStillGhost = !liveTokens.has(ghostToken);
        if (!isStillGhost) {
          playerGhostResults.push({ token: ghostToken, status: 'now_has_live_cms_screen_skip' });
          continue;
        }
        // Verify it actually exists on Player side
        const probe = await fetch(`${playerOrigin}/functions/getScreenByToken`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
          body: JSON.stringify({ token: ghostToken }),
        }).catch(() => null);
        const probeBody = probe ? await probe.json().catch(() => null) : null;
        const existsOnPlayer = probe?.status === 200 && probeBody?.zones !== undefined;

        if (existsOnPlayer && !dryRun) {
          // Send delete action to Player (requires Player to support action:'delete')
          const delRes = await fetch(`${playerOrigin}/functions/syncScreenData`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
            body: JSON.stringify({ action: 'delete', public_token: ghostToken }),
          }).catch(() => null);
          const delBody = delRes ? await delRes.json().catch(() => null) : null;
          playerGhostResults.push({
            token: ghostToken,
            exists_on_player: true,
            delete_attempted: true,
            delete_status: delRes?.status,
            delete_response: delBody,
          });
        } else {
          playerGhostResults.push({
            token: ghostToken,
            exists_on_player: existsOnPlayer,
            player_zones: probeBody?.zones?.length ?? null,
            delete_attempted: false,
            dry_run: dryRun,
          });
        }
      }
    }

    // ── Execute CMS cleanup (if not dry run) ─────────────────────────────────
    const deletedAssetLayouts = [];
    const deletedPublishedScreens = [];

    if (!dryRun) {
      for (const al of orphanedAssetLayouts) {
        await base44.asServiceRole.entities.AssetLayout.delete(al.id);
        deletedAssetLayouts.push(al.id);
        console.log(`[repairOrphanedScreenData] Deleted orphaned AssetLayout ${al.id} → screen ${al.screen_id}`);
      }
      for (const ps of orphanedPublished) {
        await base44.asServiceRole.entities.PublishedScreen.delete(ps.id);
        deletedPublishedScreens.push(ps.id);
        console.log(`[repairOrphanedScreenData] Deleted orphaned PublishedScreen ${ps.id} → screen ${ps.screen_id}`);
      }
    }

    return Response.json({
      dry_run: dryRun,
      summary: {
        live_screens: liveScreenIds.size,
        orphaned_asset_layouts: orphanedAssetLayouts.length,
        orphaned_published_screens: orphanedPublished.length,
        duplicate_screen_assets: duplicateAssets.length,
        player_ghost_tokens_checked: knownGhostTokens.length,
      },
      duplicate_live_screens_per_asset: duplicateAssets,
      orphaned_asset_layouts: orphanedAssetLayouts.map(al => ({
        id: al.id,
        asset_id: al.asset_id,
        dead_screen_id: al.screen_id,
        layout_template_id: al.layout_template_id,
        created_date: al.created_date,
      })),
      orphaned_published_screens: orphanedPublished.map(ps => ({
        id: ps.id,
        asset_id: ps.asset_id,
        dead_screen_id: ps.screen_id,
        content_version: ps.content_version,
        published_at: ps.published_at,
      })),
      player_ghost_rows: playerGhostResults,
      // Only populated if dryRun=false
      deleted_asset_layout_ids: deletedAssetLayouts,
      deleted_published_screen_ids: deletedPublishedScreens,
    });

  } catch (error) {
    console.error('[repairOrphanedScreenData] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});