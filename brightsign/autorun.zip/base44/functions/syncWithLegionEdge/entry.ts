import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { orgId } = await req.json();
    const legionEdgeKey = Deno.env.get('LEGIONEDGE_API_KEY');

    if (!legionEdgeKey) {
      return Response.json({ error: 'LegionEdge integration not configured' }, { status: 500 });
    }

    // Fetch org data
    const orgs = await base44.asServiceRole.entities.Organization.filter({ id: orgId });
    if (orgs.length === 0) {
      return Response.json({ error: 'Organization not found' }, { status: 404 });
    }

    const org = orgs[0];

    // Sync to LegionEdge
    const response = await fetch('https://legionedge.legionledtrucks.com/api/organizations/sync', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${legionEdgeKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        orgId: org.id,
        orgName: org.name,
        subscriptionStatus: org.subscription_status,
        planSlug: org.plan_slug,
        features: org.features_enabled
      })
    });

    if (!response.ok) {
      throw new Error(`LegionEdge sync failed: ${response.statusText}`);
    }

    const result = await response.json();
    return Response.json({ success: true, result });
  } catch (error) {
    console.error('Sync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});