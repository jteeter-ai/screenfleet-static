import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { userEmail, orgId, orgName, userRole = "user", type = "org_owner_setup", appUrl: clientAppUrl } = await req.json();
    console.log('[generateSetupToken] Called for:', userEmail, 'org:', orgName, 'appUrl:', clientAppUrl);

    if (!userEmail || !orgName) {
      return Response.json({ error: 'Missing required fields: userEmail, orgName' }, { status: 400 });
    }

    // Generate a secure random token
    const tokenBytes = new Uint8Array(32);
    crypto.getRandomValues(tokenBytes);
    const token = Array.from(tokenBytes).map(b => b.toString(16).padStart(2, '0')).join('');

    // Set expiry to 48 hours from now
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString();

    // Store token in AppToken entity
    await base44.asServiceRole.entities.AppToken.create({
      token,
      user_email: userEmail,
      org_id: orgId || null,
      org_name: orgName,
      user_role: userRole,
      type,
      expires_at: expiresAt,
      used_at: null,
    });

    // CRITICAL: always use the frontend origin passed from the caller.
    if (!clientAppUrl) {
      console.error('[generateSetupToken] MISSING appUrl! Caller must pass window.location.origin as appUrl.');
      return Response.json({ error: 'appUrl is required' }, { status: 400 });
    }
    const setupUrl = `${clientAppUrl}/SetPassword?token=${token}`;
    console.log('[generateSetupToken] Final email link:', setupUrl);

    // Build branded email
    const isOwner = type === 'org_owner_setup';
    const subject = isOwner
      ? `Welcome to ScreenFleet — Set up your account for ${orgName}`
      : `You've been invited to ${orgName} on ScreenFleet`;

    const emailBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; background: #f8fafc; margin: 0; padding: 0; }
    .wrapper { max-width: 580px; margin: 40px auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
    .header { background: #1e293b; padding: 32px 40px; text-align: center; }
    .header h1 { color: #ffffff; margin: 0; font-size: 22px; font-weight: 700; letter-spacing: -0.3px; }
    .header p { color: #94a3b8; margin: 4px 0 0; font-size: 13px; }
    .body { padding: 36px 40px; }
    .body p { color: #475569; font-size: 15px; line-height: 1.6; margin: 0 0 16px; }
    .body strong { color: #1e293b; }
    .cta-wrap { text-align: center; margin: 32px 0; }
    .cta { display: inline-block; padding: 14px 32px; background: #2563eb; color: #ffffff !important; text-decoration: none; border-radius: 8px; font-size: 15px; font-weight: 600; letter-spacing: -0.1px; }
    .link-note { background: #f1f5f9; border-radius: 8px; padding: 12px 16px; margin-top: 20px; }
    .link-note p { color: #64748b; font-size: 12px; margin: 0; word-break: break-all; }
    .footer { border-top: 1px solid #f1f5f9; padding: 20px 40px; text-align: center; }
    .footer p { color: #94a3b8; font-size: 12px; margin: 0; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="header">
      <h1>ScreenFleet</h1>
      <p>LED Truck Management Platform</p>
    </div>
    <div class="body">
      <p>Hello,</p>
      ${isOwner
        ? `<p>Your organization <strong>${orgName}</strong> has been created on ScreenFleet. As the account owner, you have full access to manage assets, team members, scheduling, and billing.</p>`
        : `<p>You've been invited to join <strong>${orgName}</strong> on ScreenFleet as a team member.</p>`
      }
      <p>Click the button below to set up your password and activate your account. This link expires in <strong>48 hours</strong>.</p>
      <div class="cta-wrap">
        <a href="${setupUrl}" class="cta">Set Up My Account &rarr;</a>
      </div>
      <div class="link-note">
        <p>If the button doesn't work, copy and paste this link into your browser:<br><strong>${setupUrl}</strong></p>
      </div>
      <p style="margin-top: 24px; font-size: 13px; color: #94a3b8;">If you didn't expect this email, you can safely ignore it. This link will expire in 48 hours.</p>
    </div>
    <div class="footer">
      <p>ScreenFleet &middot; LED Truck Management Platform</p>
    </div>
  </div>
</body>
</html>`;

    let emailStatus = 'sent';
    let emailError = null;
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: userEmail,
        subject,
        body: emailBody,
        from_name: 'ScreenFleet',
      });
      console.log('[generateSetupToken] Branded email sent to:', userEmail);
    } catch (emailErr) {
      emailError = emailErr.message;
      emailStatus = 'failed';
      console.error('[generateSetupToken] Branded email failed for:', userEmail, ':', emailErr.message);
    }

    return Response.json({
      success: true,
      token,
      setupUrl,
      user_email: userEmail,
      emailStatus,
      emailError,
    });
  } catch (error) {
    console.error('generateSetupToken error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});