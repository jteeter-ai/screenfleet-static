import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * Republish a truck asset to regenerate RuntimeZone records with corrected fit_mode defaults
 * POST { asset_id }
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { asset_id } = await req.json();
    if (!asset_id) return Response.json({ error: 'asset_id required' }, { status: 400 });

    console.log('[republishTruckAsset] Starting republish for asset:', asset_id);

    // Get asset
    const assets = await base44.entities.Asset.filter({ id: asset_id });
    const asset = assets[0];
    if (!asset) return Response.json({ error: `Asset not found: ${asset_id}` }, { status: 404 });

    // Validate org access
    if (user.role !== 'admin') {
      const memberships = await base44.entities.OrgMember.filter({ user_email: user.email, org_id: asset.org_id });
      if (!memberships.length) {
        return Response.json({ error: `Forbidden: access denied to org ${asset.org_id}` }, { status: 403 });
      }
    }

    // Call publishAsset via SDK
    let publishData;
    try {
      publishData = await base44.asServiceRole.functions.invoke('publishAsset', { asset_id });
      console.log('[republishTruckAsset] Publish succeeded:', publishData);
    } catch (pubErr) {
      console.error('[republishTruckAsset] Publish failed:', pubErr.message);
      return Response.json({ error: `Publish failed: ${pubErr.message}` }, { status: 500 });
    }

    // Verify the new RuntimeZone fit_modes
    const publishedScreens = await base44.entities.PublishedScreen.filter({ asset_id });
    const verification = [];
    for (const ps of publishedScreens) {
      const runtimeZones = await base44.entities.RuntimeZone.filter({ published_screen_id: ps.id });
      verification.push({
        published_screen_id: ps.id,
        zones: runtimeZones.map(rz => ({ id: rz.id, name: rz.name, fit_mode: rz.fit_mode })),
      });
    }

    return Response.json({
      status: 'ok',
      asset_id,
      asset_name: asset.name,
      publish_result: publishData,
      verification,
    });
  } catch (error) {
    console.error('[republishTruckAsset] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});