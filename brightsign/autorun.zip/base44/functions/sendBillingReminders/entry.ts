import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get all organizations
    const allOrgs = await base44.asServiceRole.entities.Organization.list();

    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);

    const orgsToRemind = allOrgs.filter((org) => {
      const expiryDate = org.trial_ends_at ? new Date(org.trial_ends_at) : org.plan_expires_at ? new Date(org.plan_expires_at) : null;

      if (!expiryDate) return false;

      // Check if expiry is within 30 days
      const daysUntilExpiry = Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
      return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
    });

    // Send reminders for each organization
    const results = [];
    for (const org of orgsToRemind) {
      try {
        const result = await base44.asServiceRole.functions.invoke('sendBillingReminder', { orgId: org.id });
        results.push({ orgId: org.id, success: true, email: result.data.sentTo });
      } catch (error) {
        results.push({ orgId: org.id, success: false, error: error.message });
      }
    }

    return Response.json({
      success: true,
      remindersSent: results.filter(r => r.success).length,
      totalChecked: allOrgs.length,
      results,
    });
  } catch (error) {
    console.error('Error in billing reminder batch:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});