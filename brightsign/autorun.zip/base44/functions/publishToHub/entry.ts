/**
 * publishToHub — internal helper to send events from ScreenFleet to the Hub app.
 *
 * Can be called as a standalone function or imported inline by other functions.
 * Since Deno functions cannot share imports, call this via:
 *   base44.functions.invoke('publishToHub', { event_type, org_id, payload })
 *
 * Never throws — logs success or failure only.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

export async function publishToHub({ event_type, org_id, payload }) {
  const hubUrl = Deno.env.get('HUB_PUBLISH_URL');
  const hubSecret = Deno.env.get('HUB_SECRET');

  if (!hubUrl) {
    console.warn('[publishToHub] HUB_PUBLISH_URL not set — skipping publish');
    return;
  }

  try {
    const res = await fetch(hubUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source_app: 'screenfleet',
        event_type,
        org_id,
        payload,
        secret: hubSecret,
      }),
    });
    if (res.ok) {
      console.log('[publishToHub] ✅ Event published:', event_type, org_id);
    } else {
      console.warn('[publishToHub] ⚠️ Hub returned non-OK status:', res.status, event_type);
    }
  } catch (err) {
    console.error('[publishToHub] ❌ Failed to publish event:', event_type, err.message);
  }
}

// Also expose as a standalone callable function endpoint
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: { 'Access-Control-Allow-Origin': '*' } });
  }

  const { event_type, org_id, payload } = await req.json();
  await publishToHub({ event_type, org_id, payload });
  return Response.json({ ok: true }, { status: 200 });
});