/**
 * retryScreenSync — Aggressive retry for a single failing screen with large backoff
 * POST { screen_id, max_retries: 10, initial_delay: 5000 }
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const screenId = body.screen_id;
    const maxRetries = body.max_retries || 10;
    const initialDelay = body.initial_delay || 5000;

    if (!screenId) {
      return Response.json({ error: 'screen_id required' }, { status: 400 });
    }

    const appConfig = (await base44.asServiceRole.entities.AppConfig.list())[0];
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');
    const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '');

    if (!playerOrigin || !syncSecret) {
      return Response.json({ error: 'Missing config' }, { status: 400 });
    }

    // Load screen data
    const screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
    if (!screens.length) return Response.json({ error: 'Screen not found' }, { status: 404 });
    const screen = screens[0];

    const publishedList = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screenId });
    if (!publishedList.length) return Response.json({ error: 'No PublishedScreen' }, { status: 404 });
    const published = publishedList[0];

    const zones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: published.id });

    // Build payload
    const contentVersionIso = published.content_version || new Date().toISOString();
    const contentVersion = new Date(contentVersionIso).getTime();
    const deviceSafeMode = screen.device_safe_mode ?? appConfig?.default_device_safe_mode ?? false;

    const syncPayload = {
      public_token: screen.public_token,
      device_safe_mode: deviceSafeMode,
      cms_screen_id: screenId,
      resolution_width: screen.width,
      resolution_height: screen.height,
      screen_id: screenId,
      screen_width: screen.width,
      screen_height: screen.height,
      screen_name: screen.name,
      screen_position: screen.position,
      screen_mode: screen.screen_mode,
      content_version: contentVersion,
      content_version_iso: contentVersionIso,
      published_at: published.published_at,
      zones: zones.sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1)).map(z => ({
        id: z.id,
        layout_zone_id: z.layout_zone_id,
        name: z.name,
        x: z.x ?? 0,
        y: z.y ?? 0,
        width: z.width,
        height: z.height,
        z_index: z.z_index ?? 1,
        fit_mode: z.fit_mode || 'contain',
        background_color: z.background_color || '#000000',
        volume: z.volume ?? 100,
        content_source_type: z.content_source_type || 'empty',
        canvas_creative_data: z.canvas_creative_data || null,
        playback_track: {
          loop: z.playback_track?.loop ?? true,
          items: (z.playback_track?.items || []).map(item => ({
            ...item,
            url: item.file_url || item.url || null,
            type: item.file_type || item.type || null,
          })),
        },
      })),
      synced_at: new Date().toISOString(),
    };

    const syncUrl = `${playerOrigin}/functions/syncScreenData`;
    const attempts = [];

    for (let i = 1; i <= maxRetries; i++) {
      const backoffMs = Math.min(initialDelay * Math.pow(1.5, i - 1), 60000);
      
      try {
        const res = await fetch(syncUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-sync-secret': syncSecret,
          },
          body: JSON.stringify({ action: 'upsert', screen_data: syncPayload }),
        });

        const resBody = await res.json();
        attempts.push({
          attempt: i,
          status: res.status,
          ok: res.ok,
          body: resBody,
          waited_before_ms: i > 1 ? backoffMs : 0,
        });

        if (res.ok) {
          console.log(`✅ Screen ${screen.name} synced on attempt ${i}`);
          return Response.json({
            success: true,
            screen_name: screen.name,
            attempt: i,
            result: resBody,
            total_attempts: attempts.length,
          });
        }

        // Rate limit: wait more
        if (res.status === 429 || (res.status === 500 && resBody.detail?.includes('Rate limit'))) {
          console.log(`[${i}/${maxRetries}] Rate limited. Waiting ${backoffMs}ms...`);
          if (i < maxRetries) {
            await new Promise(r => setTimeout(r, backoffMs));
          }
          continue;
        }

        // Other error: fail immediately
        return Response.json({
          success: false,
          screen_name: screen.name,
          attempt: i,
          error: resBody.error || res.statusText,
          attempts,
        });
      } catch (err) {
        attempts.push({
          attempt: i,
          error: err.message,
          waited_before_ms: i > 1 ? backoffMs : 0,
        });

        if (i < maxRetries) {
          await new Promise(r => setTimeout(r, backoffMs));
        }
      }
    }

    return Response.json({
      success: false,
      screen_name: screen.name,
      error: `Failed after ${maxRetries} attempts`,
      attempts,
    });
  } catch (error) {
    console.error('[retryScreenSync]', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});