import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const PLATFORM_ROLES = ['admin', 'platform_owner', 'platform_admin'];
const ORG_ADMIN_ROLES = ['owner', 'admin'];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orgId, memberEmail, orgName, userRole = 'user' } = await req.json();

    if (!orgId || !memberEmail || !orgName) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // SECURITY: Only platform admins or org admins can invite users
    const isPlatformAdmin = PLATFORM_ROLES.includes(user.role);
    if (!isPlatformAdmin) {
      const actorMembers = await base44.entities.OrgMember.filter({
        org_id: orgId,
        user_email: user.email,
      });
      const actorMember = actorMembers[0];
      if (!actorMember || !ORG_ADMIN_ROLES.includes(actorMember.org_role)) {
        return Response.json({ error: 'Forbidden: insufficient permission to invite users' }, { status: 403 });
      }
    }

    // Invite the user to the platform — sends a reliable platform-managed email
    try {
      await base44.users.inviteUser(memberEmail, userRole);
    } catch (inviteErr) {
      console.warn('inviteUser warning (user may already exist):', inviteErr.message);
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('sendOrgMemberInvite error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});