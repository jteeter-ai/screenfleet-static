import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { userEmail } = await req.json();

    if (!userEmail) {
      return Response.json({ error: 'Missing user email' }, { status: 400 });
    }

    // Generate reset link
    const resetUrl = `${new URL(req.url).origin}/auth/reset-password?email=${encodeURIComponent(userEmail)}`;

    // Send password reset email
    await base44.integrations.Core.SendEmail({
      to: userEmail,
      subject: 'Reset your ScreenFleet password',
      body: `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .button { display: inline-block; padding: 12px 24px; background: #2563eb; color: white; text-decoration: none; border-radius: 6px; }
    .footer { color: #999; font-size: 12px; margin-top: 30px; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Password Reset</h2>
    <p>Click the button below to reset your password:</p>
    <p><a href="${resetUrl}" class="button">Reset Password</a></p>
    <p style="margin-top: 20px; font-size: 12px; color: #999;">This link expires in 24 hours. If you didn't request this, you can safely ignore it.</p>
    <div class="footer">
      <p>ScreenFleet • LED Truck Management Platform</p>
    </div>
  </div>
</body>
</html>
      `,
    });

    return Response.json({ success: true, message: 'Password reset email sent' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});