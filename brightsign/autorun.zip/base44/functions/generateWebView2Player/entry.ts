/**
 * generateWebView2Player — Windows PC Player Launcher Generator
 *
 * CLASSIFICATION: PLAYER-DELIVERY ONLY
 * This function generates Windows .bat/.ps1/.vbs launcher scripts that point
 * physical Windows PC devices at the ScreenFleet Player app.
 *
 * MIGRATION NOTE:
 *   This function must be migrated to the ScreenFleet Player app once it exists.
 *   All generated scripts must point to the Player app origin, never the CMS.
 *   Input: playerUrl — MUST come from AppConfig.player_app_origin via the frontend.
 *   The CMS should never be used as a device playback endpoint.
 *
 * TODO (Player app migration):
 *   - Move this generator into the Player app backend
 *   - Scripts should launch: ${PLAYER_APP_ORIGIN}/player?screenId=XXX
 *   - Remove from CMS once Player app is live
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { truckId, playerUrl } = await req.json();

    if (!truckId || !playerUrl) {
      return Response.json({ error: 'Missing truckId or playerUrl. playerUrl must be AppConfig.player_app_origin — never the CMS origin.' }, { status: 400 });
    }

    // Generate a batch file that launches Edge in app mode
    const batchFile = `@echo off
REM ScreenFleet Player - Windows Edition
REM This script launches the ScreenFleet player in fullscreen mode

setlocal enabledelayedexpansion

REM Get all connected monitors
for /f "tokens=2 delims=:=" %%A in ('wmic logicaldisk get name ^| find ":"') do set "SystemDrive=%%A"

REM Try to find Microsoft Edge
set "EdgePath="
if exist "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe" (
    set "EdgePath=C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe"
) else if exist "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe" (
    set "EdgePath=C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
)

if "!EdgePath!"=="" (
    echo Microsoft Edge is not installed. Please install Microsoft Edge to run ScreenFleet Player.
    echo Download from: https://www.microsoft.com/en-us/edge
    pause
    exit /b 1
)

REM Launch Edge in app mode (fullscreen, no chrome)
REM Points to ScreenFleet Player app /player route.
REM NOTE: Append ?screenId=XXX to target a specific screen.
start "" "!EdgePath!" --app="${playerUrl}/player" --fullscreen

exit /b 0
`;

    // Generate a VBScript for better monitor selection UI
    const vbscript = `' ScreenFleet Player Launcher
' This script detects monitors and launches the player

Dim objWMIService, colItems, objItem, monitorCount
Dim strURL, objShell

strURL = "${playerUrl}/player"
monitorCount = 0

Set objWMIService = GetObject("winmgmts:")
Set colItems = objWMIService.ExecQuery("Select * from Win32_DesktopMonitor")

For Each objItem in colItems
    monitorCount = monitorCount + 1
Next

Set objShell = CreateObject("WScript.Shell")

' Launch Edge in app mode
If monitorCount > 1 Then
    MsgBox "ScreenFleet Player will launch on your primary display.", 0, "ScreenFleet"
End If

objShell.Run """C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe"" --app=""" & strURL & """ --fullscreen", 1, False
`;

    // Generate PowerShell launcher script (best option)
    const powershellScript = `# ScreenFleet Player Launcher
# Detects monitors and launches the player

param(
    [string]$Url = "${playerUrl}/player",
    [int]$Monitor = 0
)

# Find Microsoft Edge
$EdgePaths = @(
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
)

$EdgePath = $null
foreach ($path in $EdgePaths) {
    if (Test-Path $path) {
        $EdgePath = $path
        break
    }
}

if (-not $EdgePath) {
    Write-Host "ERROR: Microsoft Edge is not installed."
    Write-Host "Please install Microsoft Edge: https://www.microsoft.com/en-us/edge"
    Read-Host "Press Enter to exit"
    exit 1
}

# Get monitor information
$monitors = Get-WmiObject -Class Win32_DesktopMonitor
$monitorCount = @($monitors).Count

if ($monitorCount -gt 1) {
    Write-Host "Detected $monitorCount monitors"
    Write-Host "ScreenFleet will launch on your primary display"
}

# Launch Edge in app mode (fullscreen, no UI)
& "$EdgePath" --app="$Url" --fullscreen --disable-background-networking --disable-client-side-phishing-detection --disable-component-extensions-with-background-pages --disable-extensions --disable-sync

exit 0
`;

    // Create download package
    const downloadContent = {
      filename: 'screenfleet-player.bat',
      content: batchFile,
      files: {
        'run-player.bat': batchFile,
        'run-player.ps1': powershellScript,
        'run-player.vbs': vbscript
      }
    };

    // Return batch file content as JSON for download
    return Response.json({
      success: true,
      filename: 'run-screenfleet-player.bat',
      content: batchFile
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});