/**
 * V2 screenVersionCheck
 *
 * CLASSIFICATION: PLAYER-DELIVERY ONLY
 * This is a pure device polling endpoint. It has no CMS admin purpose.
 *
 * MIGRATION TARGET — must move to the ScreenFleet Player app.
 * When the Player app is deployed:
 *   - Move this function to the Player app backend
 *   - Devices poll the Player app for version changes, not the CMS
 *   - Player app fetches PublishedScreen data from CMS API internally
 *   - Remove this function from the CMS
 *
 * Public, no auth required (devices poll this without user sessions).
 * 
 * POST { screenId }
 * 
 * Returns the current content_version for a screen so players
 * can poll cheaply without fetching the full payload.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers });
  }

  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const screenId = body.screenId || body.screen_id;

    if (!screenId) {
      return Response.json({ error: 'screenId required' }, { status: 400, headers });
    }
    console.log(`[screenVersionCheck] ENTRY screenId=${screenId}`);

    // Resolve public_token to internal screen id (same pattern as screenPayload)
    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(screenId);
    let internalScreenId = screenId;
    if (isUUID) {
      const screens = await base44.asServiceRole.entities.Screen.filter({ public_token: screenId });
      if (!screens.length) {
        return Response.json({ error: 'Screen not found', status: 'not_found' }, { status: 404, headers });
      }
      internalScreenId = screens[0].id;
    }

    // Look up the most recent PublishedScreen using internal DB id
    const published = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: internalScreenId });

    if (!published.length) {
      console.log(`[screenVersionCheck] RESULT screenId=${screenId} status=no_published_state`);
      return Response.json({
        screen_id: screenId,
        content_version: null,
        has_update: false,
        expires_hint: 30,
        status: 'no_published_state',
      }, { status: 200, headers });
    }

    // Most recently published wins
    const latest = published.sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0];

    console.log(`[screenVersionCheck] RESULT screenId=${screenId} content_version=${latest.content_version} is_stale=${latest.is_stale}`);
    return Response.json({
      screen_id: screenId,
      content_version: latest.content_version,
      has_update: latest.is_stale, // true = content changed since last sync, player should re-fetch
      published_at: latest.published_at,
      expires_hint: 30, // seconds — player should re-poll this often
      status: 'ok',
    }, { status: 200, headers });

  } catch (error) {
    return Response.json({ error: error.message, status: 'error' }, { status: 500, headers });
  }
});