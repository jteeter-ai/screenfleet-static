import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * FIX: Update LayoutZone fit_mode_default from 'fill' to 'contain' and republish
 * POST { asset_id }
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { asset_id } = await req.json();
    if (!asset_id) return Response.json({ error: 'asset_id required' }, { status: 400 });

    // Get asset (use service role for admin operations)
    const assets = await base44.asServiceRole.entities.Asset.filter({ id: asset_id });
    const asset = assets[0];
    if (!asset) return Response.json({ error: `Asset not found: ${asset_id}` }, { status: 404 });

    // Get screens for this asset
    const screens = await base44.asServiceRole.entities.Screen.filter({ asset_id });
    if (!screens.length) return Response.json({ error: `No screens found for asset ${asset_id}` }, { status: 400 });

    // Get AssetLayouts to find the LayoutTemplate
    const assetLayouts = await base44.asServiceRole.entities.AssetLayout.filter({ asset_id });
    if (!assetLayouts.length) return Response.json({ error: `No AssetLayouts found for asset ${asset_id}` }, { status: 400 });

    const layoutTemplateId = assetLayouts[0]?.layout_template_id;
    if (!layoutTemplateId) return Response.json({ error: 'No layout template assigned' }, { status: 400 });

    console.log('[fixTruckLayoutFitMode] Fixing asset:', {
      asset_id,
      asset_name: asset.name,
      layout_template_id: layoutTemplateId,
      screen_count: screens.length,
    });

    // Get all LayoutZones for this template
    const layoutZones = await base44.asServiceRole.entities.LayoutZone.filter({ layout_template_id: layoutTemplateId });
    console.log('[fixTruckLayoutFitMode] Found LayoutZones:', {
      template_id: layoutTemplateId,
      zone_count: layoutZones.length,
      zones: layoutZones.map(lz => ({ id: lz.id, name: lz.name, current_fit_mode: lz.fit_mode_default })),
    });

    // Update ALL zones to ensure fit_mode_default = 'contain' (fix defaults)
    const updated = [];
    for (const lz of layoutZones) {
      const oldFitMode = lz.fit_mode_default || 'default/unset';
      if (oldFitMode !== 'contain') {
        await base44.asServiceRole.entities.LayoutZone.update(lz.id, { fit_mode_default: 'contain' });
        updated.push({ id: lz.id, name: lz.name, old_fit_mode: oldFitMode, new_fit_mode: 'contain' });
        console.log(`[fixTruckLayoutFitMode] Updated zone ${lz.id} "${lz.name}": ${oldFitMode} -> contain`);
      }
    }

    // Re-publish the asset (requires invoking publishAsset function)
    console.log('[fixTruckLayoutFitMode] Triggering re-publish...');
    let publishRes = null;
    try {
      publishRes = await base44.asServiceRole.functions.invoke('publishAsset', { asset_id });
    } catch (pubErr) {
      console.warn('[fixTruckLayoutFitMode] Publish invoke failed, will verify separately:', pubErr.message);
    }

    // Verify the new RuntimeZone fit_modes
    const publishedScreens = await base44.asServiceRole.entities.PublishedScreen.filter({ asset_id });
    const verification = [];
    for (const ps of publishedScreens) {
      const runtimeZones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: ps.id });
      verification.push({
        published_screen_id: ps.id,
        screen_name: runtimeZones[0]?.screen_id ? `Screen ${runtimeZones[0].screen_id}` : 'Unknown',
        zones: runtimeZones.map(rz => ({ id: rz.id, name: rz.name, fit_mode: rz.fit_mode })),
      });
    }

    return Response.json({
      status: 'ok',
      message: 'LayoutZones updated. Call publishAsset separately to regenerate RuntimeZones.',
      asset_id,
      asset_name: asset.name,
      layout_template_id: layoutTemplateId,
      layout_zones_updated: updated,
      verification,
    });
  } catch (error) {
    console.error('[fixTruckLayoutFitMode] ERROR:', error.message, error.stack);
    return Response.json({ error: error.message }, { status: 500 });
  }
});