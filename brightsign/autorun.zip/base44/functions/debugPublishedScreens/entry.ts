/**
 * Debug: inspect PublishedScreen records.
 * POST { org_id?, asset_id?, screen_id? }
 * Uses service role. Auth required.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { org_id, asset_id, screen_id } = await req.json().catch(() => ({}));

    const all = await base44.asServiceRole.entities.PublishedScreen.list();

    const pick = (ps) => ({
      id: ps.id,
      org_id: ps.org_id,
      asset_id: ps.asset_id,
      screen_id: ps.screen_id,
      published_at: ps.published_at,
      content_version: ps.content_version,
    });

    const orgFiltered = org_id ? all.filter(p => p.org_id === org_id) : [];
    const assetFiltered = asset_id ? all.filter(p => p.asset_id === asset_id) : [];
    const screenFiltered = screen_id ? all.filter(p => p.screen_id === screen_id) : [];

    console.log('[DEBUG PUBLISHED SCREENS]', {
      total: all.length,
      org_filtered: orgFiltered.length,
      asset_filtered: assetFiltered.length,
      screen_filtered: screenFiltered.length,
      org_id, asset_id, screen_id,
    });

    return Response.json({
      total: all.length,
      org_filtered: orgFiltered.length,
      asset_filtered: assetFiltered.length,
      screen_filtered: screenFiltered.length,
      records: all.map(pick),
      org_records: orgFiltered.map(pick),
      asset_records: assetFiltered.map(pick),
      screen_records: screenFiltered.map(pick),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});