import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const PLATFORM_ROLES = ['admin', 'platform_owner', 'platform_admin'];
const ORG_ADMIN_ROLES = ['owner', 'admin'];
const VALID_ORG_ROLES = ['owner', 'admin', 'manager', 'ops_manager', 'content_manager', 'scheduler', 'screen_operator', 'analyst', 'operator', 'viewer'];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { userEmail, orgId, orgName, orgRole = 'operator', appUrl } = await req.json();

    if (!userEmail || !orgId || !orgName || !appUrl) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Validate orgRole is a valid org role (not platform role)
    if (!VALID_ORG_ROLES.includes(orgRole)) {
      return Response.json({ error: 'Invalid org role' }, { status: 400 });
    }

    // SECURITY: Only platform admins or org admins can create users
    const isPlatformAdmin = PLATFORM_ROLES.includes(user.role);
    let isOrgAdmin = false;

    if (!isPlatformAdmin) {
      const actorMembers = await base44.entities.OrgMember.filter({
        org_id: orgId,
        user_email: user.email,
      });
      const actorMember = actorMembers[0];
      if (!actorMember || !ORG_ADMIN_ROLES.includes(actorMember.org_role)) {
        return Response.json({ error: 'Forbidden: insufficient permission to invite users' }, { status: 403 });
      }
      isOrgAdmin = true;
    }

    // SECURITY: Org admins cannot assign owner role unless they are owners
    if (isOrgAdmin && !isPlatformAdmin && orgRole === 'owner') {
      const actorMembers = await base44.entities.OrgMember.filter({
        org_id: orgId,
        user_email: user.email,
      });
      const actorMember = actorMembers[0];
      if (actorMember.org_role !== 'owner') {
        return Response.json({ error: 'Forbidden: only owners can assign owner role' }, { status: 403 });
      }
    }

    // Verify target org exists
    const orgs = await base44.asServiceRole.entities.Organization.filter({ id: orgId });
    if (!orgs[0]) {
      return Response.json({ error: 'Organization not found' }, { status: 404 });
    }

    // Create OrgMember as active immediately (no "invited" limbo)
    const member = await base44.asServiceRole.entities.OrgMember.create({
      org_id: orgId,
      user_email: userEmail,
      org_role: orgRole,
      status: 'active',
      joined_at: new Date().toISOString(),
    });

    // Send branded setup email via generateSetupToken
    const tokenRes = await base44.asServiceRole.functions.invoke('generateSetupToken', {
      userEmail,
      orgId,
      orgName,
      userRole: 'user',
      type: 'member_invite',
      appUrl,
    });

    return Response.json({
      success: true,
      user_email: userEmail,
      member_id: member.id,
      setupUrl: tokenRes.setupUrl,
      emailStatus: tokenRes.emailStatus,
      emailError: tokenRes.emailError,
    });
  } catch (error) {
    console.error('[createOrgUser] error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});