/**
 * debugPublishedZones — Admin-only diagnostic
 *
 * POST { screenId }
 *
 * Returns the FULL chain for a published screen:
 *   A. Layout Template → LayoutZones
 *   B. PublishedScreen record
 *   C. RuntimeZone records (what publishAsset created)
 *   D. screenPayload-equivalent zone output
 *   E. collectHdmiZones result
 *
 * Use this to find exactly which stage is dropping a zone.
 * Compare A (layout) vs C (runtime) vs D (payload) counts.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const body = await req.json();
    const screenId = body.screenId || body.screen_id;
    if (!screenId) return Response.json({ error: 'screenId required' }, { status: 400 });

    const report = { screenId, stages: {}, verdict: null };

    // ── A. Screen + AssetLayout → LayoutTemplate → LayoutZones ───────────────
    let screens;
    try {
      screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
    } catch (e) {
      return Response.json({ error: `Screen lookup failed: ${e.message}. Is the screenId valid?`, screenId }, { status: 400 });
    }
    if (!screens.length) return Response.json({ error: `Screen not found: ${screenId}` }, { status: 404 });
    const screen = screens[0];

    report.screen = {
      id: screen.id,
      name: screen.name,
      asset_id: screen.asset_id,
      width: screen.width,
      height: screen.height,
    };

    // AssetLayout → LayoutTemplate
    let layoutZones = [];
    let layoutTemplate = null;
    let assetLayout = null;

    if (screen.asset_id) {
      const assetLayouts = await base44.asServiceRole.entities.AssetLayout.filter({
        asset_id: screen.asset_id,
        screen_id: screenId,
      });
      assetLayout = assetLayouts[0] || null;

      if (assetLayout?.layout_template_id) {
        const templates = await base44.asServiceRole.entities.LayoutTemplate.filter({ id: assetLayout.layout_template_id });
        layoutTemplate = templates[0] || null;
        layoutZones = await base44.asServiceRole.entities.LayoutZone.filter({ layout_template_id: assetLayout.layout_template_id });
      }
    }

    report.stages.A_layout = {
      asset_layout_id: assetLayout?.id || null,
      layout_template_id: assetLayout?.layout_template_id || null,
      layout_template_name: layoutTemplate?.name || null,
      layout_zone_count: layoutZones.length,
      layout_zones: layoutZones.map(lz => ({
        id: lz.id,
        name: lz.name,
        x: lz.x ?? 0,
        y: lz.y ?? 0,
        width: lz.width,
        height: lz.height,
        z_index: lz.z_index ?? 1,
        default_source_type: lz.default_source_type || null,
        hdmi_audio_output: lz.hdmi_audio_output || null,
        is_hdmi: lz.default_source_type === 'hdmi',
      })),
      hdmi_zone_count: layoutZones.filter(lz => lz.default_source_type === 'hdmi').length,
      WARNING: layoutZones.filter(lz => lz.default_source_type === 'hdmi').length === 0
        ? 'NO HDMI LayoutZones found. Either default_source_type is not set to "hdmi" on the zone, or the wrong layout template is assigned.'
        : null,
    };

    // ── B. PublishedScreen record ─────────────────────────────────────────────
    const publishedList = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screenId });
    const publishedScreen = publishedList.sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0] || null;

    report.stages.B_published_screen = publishedScreen ? {
      id: publishedScreen.id,
      screen_id: publishedScreen.screen_id,
      asset_id: publishedScreen.asset_id,
      layout_template_id: publishedScreen.layout_template_id,
      content_version: publishedScreen.content_version,
      published_at: publishedScreen.published_at,
      zone_count_at_publish: publishedScreen.zone_count,
      is_stale: publishedScreen.is_stale,
    } : { error: 'NO PublishedScreen found for this screenId. Publish the asset first.' };

    // ── C. RuntimeZone records ────────────────────────────────────────────────
    let runtimeZones = [];
    if (publishedScreen) {
      runtimeZones = await base44.asServiceRole.entities.RuntimeZone.filter({
        published_screen_id: publishedScreen.id,
      });
    }

    report.stages.C_runtime_zones = {
      published_screen_id: publishedScreen?.id || null,
      runtime_zone_count: runtimeZones.length,
      runtime_zones: runtimeZones.map(rz => ({
        id: rz.id,
        layout_zone_id: rz.layout_zone_id,
        name: rz.name,
        x: rz.x ?? 0,
        y: rz.y ?? 0,
        width: rz.width,
        height: rz.height,
        z_index: rz.z_index ?? 1,
        content_source_type: rz.content_source_type,
        is_hdmi: rz.content_source_type === 'hdmi_input',
        has_playback_track: !!(rz.playback_track?.items?.length),
        playback_track_item_count: rz.playback_track?.items?.length ?? 0,
        has_canvas_creative_data: !!rz.canvas_creative_data,
        canvas_creative_data: rz.canvas_creative_data || null,
        is_duplicate_of: rz.is_duplicate_of || null,
      })),
      hdmi_runtime_zone_count: runtimeZones.filter(rz => rz.content_source_type === 'hdmi_input').length,
    };

    // ── D. screenPayload-equivalent output ────────────────────────────────────
    const payloadZones = runtimeZones
      .sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1))
      .map(rz => ({
        id: rz.id,
        layout_zone_id: rz.layout_zone_id,
        name: rz.name,
        x: rz.x ?? 0,
        y: rz.y ?? 0,
        width: rz.width,
        height: rz.height,
        z_index: rz.z_index ?? 1,
        content_source_type: rz.content_source_type || 'empty',
        canvas_creative_data: rz.canvas_creative_data || null,
        playback_track: rz.playback_track || { loop: true, items: [] },
      }));

    report.stages.D_screen_payload = {
      zone_count: payloadZones.length,
      zones: payloadZones.map(z => ({
        id: z.id,
        name: z.name,
        x: z.x, y: z.y, width: z.width, height: z.height,
        z_index: z.z_index,
        content_source_type: z.content_source_type,
        has_canvas_creative_data: !!z.canvas_creative_data,
      })),
      hdmi_zone_count: payloadZones.filter(z => z.content_source_type === 'hdmi_input').length,
    };

    // ── E. collectHdmiZones result ────────────────────────────────────────────
    const hdmiZones = payloadZones.filter(z =>
      z.content_source_type === 'hdmi_input' && z.width && z.height
    );

    report.stages.E_collect_hdmi_zones = {
      hdmi_zones_found: hdmiZones.length,
      hdmi_zones: hdmiZones.map(z => ({
        id: z.id,
        name: z.name,
        x: z.x, y: z.y, width: z.width, height: z.height,
        z_index: z.z_index,
        audioMode: z.canvas_creative_data?.audioOutput || 'aux',
        fit: z.canvas_creative_data?.fit || 'stretch',
      })),
    };

    // ── Verdict ───────────────────────────────────────────────────────────────
    const layoutZoneCount = layoutZones.length;
    const runtimeZoneCount = runtimeZones.length;
    const payloadZoneCount = payloadZones.length;
    const hdmiInLayout = layoutZones.filter(lz => lz.default_source_type === 'hdmi').length;
    const hdmiInRuntime = runtimeZones.filter(rz => rz.content_source_type === 'hdmi_input').length;
    const hdmiInPayload = payloadZones.filter(z => z.content_source_type === 'hdmi_input').length;

    const problems = [];

    if (!publishedScreen) {
      problems.push('STAGE B: No PublishedScreen found. Asset has not been published for this screen.');
    }
    if (layoutZoneCount === 0) {
      problems.push('STAGE A: Layout template has 0 zones. Check AssetLayout assignment and LayoutZone records.');
    }
    if (runtimeZoneCount < layoutZoneCount) {
      problems.push(`STAGE A→C: Layout has ${layoutZoneCount} zones but only ${runtimeZoneCount} RuntimeZones were created. BUG IN publishAsset. Re-publish after fixing.`);
    }
    if (hdmiInLayout === 0) {
      problems.push('STAGE A: No LayoutZone has default_source_type="hdmi". HDMI zone must be configured in Layout Template editor before publishing.');
    }
    if (hdmiInLayout > 0 && hdmiInRuntime === 0) {
      problems.push(`STAGE A→C: Layout has ${hdmiInLayout} HDMI zone(s) but 0 HDMI RuntimeZones. BUG: resolveZoneTrack did not detect default_source_type="hdmi". Check LayoutZone.default_source_type value exactly.`);
    }
    if (hdmiInRuntime > 0 && hdmiInPayload === 0) {
      problems.push('STAGE C→D: RuntimeZone has HDMI zone but screenPayload returned 0. BUG IN screenPayload filter.');
    }
    if (hdmiInPayload > 0 && hdmiZones.length === 0) {
      problems.push('STAGE D→E: screenPayload has HDMI zone but collectHdmiZones found 0. Check width/height are non-zero.');
    }

    if (problems.length === 0) {
      report.verdict = `OK: ${layoutZoneCount} layout zones → ${runtimeZoneCount} runtime zones → ${payloadZoneCount} payload zones. HDMI: ${hdmiInLayout} in layout → ${hdmiInRuntime} in runtime → ${hdmiInPayload} in payload → ${hdmiZones.length} in collectHdmiZones. Pipeline is correct.`;
    } else {
      report.verdict = `PROBLEMS FOUND (${problems.length}): ` + problems.join(' | ');
    }

    report.summary = {
      layout_zone_count: layoutZoneCount,
      runtime_zone_count: runtimeZoneCount,
      payload_zone_count: payloadZoneCount,
      hdmi_in_layout: hdmiInLayout,
      hdmi_in_runtime: hdmiInRuntime,
      hdmi_in_payload: hdmiInPayload,
      hdmi_in_collect_result: hdmiZones.length,
      drop_stage: runtimeZoneCount < layoutZoneCount ? 'publishAsset (A→C)' :
                  hdmiInRuntime === 0 && hdmiInLayout > 0 ? 'resolveZoneTrack (A→C, HDMI detection)' :
                  hdmiInPayload === 0 && hdmiInRuntime > 0 ? 'screenPayload (C→D)' :
                  hdmiZones.length === 0 && hdmiInPayload > 0 ? 'collectHdmiZones (D→E)' :
                  'none detected',
    };

    return Response.json(report);

  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
});