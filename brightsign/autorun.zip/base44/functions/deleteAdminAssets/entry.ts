/**
 * deleteAdminAssets
 * Safely removes all V1 legacy "Admin Assets" (Truck records with no org_id).
 * Cleans all dependent records first: Zones → PublishedScreens → Screens → Layouts → Schedules → Truck
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();

  if (user?.role !== 'admin') {
    return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
  }

  const { dryRun = true } = await req.json().catch(() => ({}));

  // 1. Find all Truck records with no org_id (global/admin-scope V1 assets)
  const allTrucks = await base44.asServiceRole.entities.Truck.list();
  const adminTrucks = allTrucks.filter(t => !t.org_id);

  if (adminTrucks.length === 0) {
    return Response.json({ success: true, message: 'No admin-scope V1 Truck records found. Nothing to delete.', deleted: {} });
  }

  const truckIds = adminTrucks.map(t => t.id);

  // 2. Find dependent Screens (V1: truck_id set, no asset_id)
  const allScreens = await base44.asServiceRole.entities.Screen.list();
  const adminScreens = allScreens.filter(s => truckIds.includes(s.truck_id));
  const adminScreenIds = adminScreens.map(s => s.id);

  // 3. Find Zones tied to those screens
  const allZones = await base44.asServiceRole.entities.Zone.list();
  const adminZones = allZones.filter(z => adminScreenIds.includes(z.screen_id));

  // 4. Find Layouts tied to those trucks
  const allLayouts = await base44.asServiceRole.entities.Layout.list();
  const adminLayouts = allLayouts.filter(l => truckIds.includes(l.truck_id));

  // 5. Find Schedules tied to those trucks
  const allSchedules = await base44.asServiceRole.entities.Schedule.list();
  const adminSchedules = allSchedules.filter(s => truckIds.includes(s.truck_id));

  // 6. Find PublishedScreens for those screens
  const allPublished = await base44.asServiceRole.entities.PublishedScreen.list();
  const adminPublished = allPublished.filter(p => adminScreenIds.includes(p.screen_id));

  // 7. Find RuntimeZones for those screens
  const allRuntimeZones = await base44.asServiceRole.entities.RuntimeZone.list();
  const adminRuntimeZones = allRuntimeZones.filter(rz => adminScreenIds.includes(rz.screen_id));

  const summary = {
    trucks: adminTrucks.map(t => ({ id: t.id, name: t.name })),
    screens: adminScreens.length,
    zones: adminZones.length,
    layouts: adminLayouts.length,
    schedules: adminSchedules.length,
    publishedScreens: adminPublished.length,
    runtimeZones: adminRuntimeZones.length,
  };

  if (dryRun) {
    return Response.json({ dryRun: true, willDelete: summary });
  }

  // --- EXECUTE DELETION (deepest deps first) ---
  const errors = [];

  const safeDelete = async (entity, ids, label) => {
    const results = await Promise.allSettled(ids.map(id => base44.asServiceRole.entities[entity].delete(id)));
    const failed = results.filter(r => r.status === 'rejected');
    if (failed.length) errors.push(`${label}: ${failed.length} failed`);
    return results.filter(r => r.status === 'fulfilled').length;
  };

  const deleted = {};

  deleted.runtimeZones = await safeDelete('RuntimeZone', adminRuntimeZones.map(rz => rz.id), 'RuntimeZone');
  deleted.publishedScreens = await safeDelete('PublishedScreen', adminPublished.map(p => p.id), 'PublishedScreen');
  deleted.zones = await safeDelete('Zone', adminZones.map(z => z.id), 'Zone');
  deleted.schedules = await safeDelete('Schedule', adminSchedules.map(s => s.id), 'Schedule');
  deleted.layouts = await safeDelete('Layout', adminLayouts.map(l => l.id), 'Layout');
  deleted.screens = await safeDelete('Screen', adminScreens.map(s => s.id), 'Screen');
  deleted.trucks = await safeDelete('Truck', truckIds, 'Truck');

  return Response.json({
    success: errors.length === 0,
    deleted,
    errors: errors.length ? errors : undefined,
    message: errors.length
      ? `Completed with ${errors.length} error(s)`
      : `Successfully deleted ${deleted.trucks} admin truck(s) and all dependencies`,
  });
});