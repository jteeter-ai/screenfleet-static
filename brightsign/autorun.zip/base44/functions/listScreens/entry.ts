import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { org_id } = await req.json();
    if (!org_id) return Response.json({ error: 'org_id required' }, { status: 400 });

    // Verify caller is a member of this org (or platform admin)
    if (user.role !== 'admin') {
      const members = await base44.asServiceRole.entities.OrgMember.filter({
        user_email: user.email,
        org_id,
      });
      if (!members.length) return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const screens = await base44.asServiceRole.entities.Screen.filter({ org_id });
    return Response.json(screens);
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
});