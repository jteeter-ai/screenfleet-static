/**
 * debugBrightSignHdmiConfig
 * POST { published_screen_id: "..." }
 *
 * Returns the exact HDMI zone payload, JS bridge message, and BrightScript
 * setup snippet that would be generated for a given published screen.
 * Use this to inspect HDMI config before hardware deployment.
 *
 * Admin only.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden: admin only' }, { status: 403 });

    const { published_screen_id } = await req.json();
    if (!published_screen_id) return Response.json({ error: 'published_screen_id required' }, { status: 400 });

    // ── Fetch published screen and its runtime zones ─────────────────────────
    const [psArr, allRuntimeZones] = await Promise.all([
      base44.asServiceRole.entities.PublishedScreen.filter({ id: published_screen_id }),
      base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id }),
    ]);

    const ps = psArr[0];
    if (!ps) return Response.json({ error: `PublishedScreen not found: ${published_screen_id}` }, { status: 404 });

    const screenArr = await base44.asServiceRole.entities.Screen.filter({ id: ps.screen_id });
    const screen = screenArr[0] || {};

    // ── Identify HDMI zones ───────────────────────────────────────────────────
    const hdmiZones = allRuntimeZones.filter(z => z.content_source_type === 'hdmi_input');
    const mediaZones = allRuntimeZones.filter(z => z.content_source_type !== 'hdmi_input');

    // ── Build exact JS bridge message (mirrors player.js buildHdmiBridgeMessage) ─
    // Bridge uses audioMode string ('aux'|'hdmi'|'both') — BrightScript maps to output arrays.
    const bridgeZones = hdmiZones.map(z => {
      const meta = z.canvas_creative_data || {};
      const audioMode = meta.audioOutput || 'aux';
      return {
        id:        z.id,
        x:         z.x || 0,
        y:         z.y || 0,
        width:     z.width,
        height:    z.height,
        z_index:   z.z_index || 1,
        fit:       meta.fit || 'stretch',
        audioMode, // 'aux' | 'hdmi' | 'both'
      };
    });

    const jsBridgeMessage = hdmiZones.length > 0
      ? { type: 'SF_HDMI_ZONES', zones: bridgeZones }
      : null;

    // ── Build BrightScript snippet for the primary HDMI zone ─────────────────
    // This is the exact code that autorun.brs would execute for this screen.
    let brightscriptSnippet = null;
    let warnings = [];

    if (hdmiZones.length > 0) {
      const primaryZone = bridgeZones[0];

      if (hdmiZones.length > 1) {
        warnings.push(
          `${hdmiZones.length} HDMI zones found. BrightSign XT has ONE physical HDMI In port.`,
          `Only zone id=${primaryZone.id} will be hardware-active.`,
        );
      }

      if (!primaryZone.width || !primaryZone.height) {
        warnings.push(`HDMI zone id=${primaryZone.id} has missing width/height — BrightScript setup would fail.`);
      }

      // Derive what BrightScript SetupHdmiInput() will do for this audioMode
      const pcmOutputs = primaryZone.audioMode === 'hdmi' ? ['HDMI']
        : primaryZone.audioMode === 'both' ? ['AnalogAudio', 'HDMI']
        : ['AnalogAudio'];
      const compOutputs = pcmOutputs.filter(o => o === 'HDMI' || o === 'SPDIF');

      const pcmEntries = pcmOutputs.map(o => `{AudioOutput: "${o}"}`).join(', ');
      const compEntries = compOutputs.length > 0
        ? compOutputs.map(o => `{AudioOutput: "${o}"}`).join(', ')
        : null;

      brightscriptSnippet = [
        `' --- SetupHdmiInput for zone: ${primaryZone.id} ---`,
        `' audioMode (from ScreenFleet UI): "${primaryZone.audioMode}"`,
        `' → PCM outputs:        [${pcmOutputs.join(', ')}]`,
        `' → Compressed outputs: [${compOutputs.join(', ') || 'none — AnalogAudio does not support compressed passthrough'}]`,
        ``,
        `vi = CreateObject("roVideoInput")`,
        `If vi = Invalid Then`,
        `    Print "[SF-HDMI] FAIL: roVideoInput not available — requires BrightSign XT series"`,
        `    Return False`,
        `End If`,
        ``,
        `vp = CreateObject("roVideoPlayer")`,
        `If vp = Invalid Then`,
        `    Print "[SF-HDMI] FAIL: roVideoPlayer creation failed"`,
        `    Return False`,
        `End If`,
        ``,
        `vp.SetPcmAudioOutputs([${pcmEntries}])`,
        compEntries
          ? `vp.SetCompressedAudioOutputs([${compEntries}])`
          : `' SetCompressedAudioOutputs skipped — no HDMI/SPDIF output selected`,
        ``,
        `rect = CreateObject("roRectangle", ${primaryZone.x}, ${primaryZone.y}, ${primaryZone.width}, ${primaryZone.height})`,
        `vp.SetRectangle(rect)`,
        `vp.SetVideoZOrder(${primaryZone.z_index})`,
        `vp.PlayFile(vi)`,
        `g_hdmiPlayer = vp`,
        `g_hdmiInput = vi`,
      ].join('\n');
    }

    // ── Assemble report ───────────────────────────────────────────────────────
    return Response.json({
      published_screen_id,
      screen_id: ps.screen_id,
      screen_name: screen.name || 'unknown',
      player_type: screen.player_type || 'unknown',
      player_model: screen.player_model || 'unknown',
      content_version: ps.content_version,

      summary: {
        total_runtime_zones: allRuntimeZones.length,
        hdmi_zone_count: hdmiZones.length,
        media_zone_count: mediaZones.length,
        multi_hdmi_warning: hdmiZones.length > 1,
      },

      // Full RuntimeZone records for each HDMI zone
      hdmi_runtime_zones: hdmiZones.map(z => ({
        id: z.id,
        name: z.name,
        content_source_type: z.content_source_type,
        x: z.x,
        y: z.y,
        width: z.width,
        height: z.height,
        z_index: z.z_index,
        canvas_creative_data: z.canvas_creative_data,
      })),

      // The exact message that player.js sends to autorun.brs via JS bridge
      js_bridge_message: jsBridgeMessage,

      // The exact BrightScript that autorun.brs executes for these zones
      brightscript_snippet: brightscriptSnippet,

      // Audio routing notes
      audio_routing: hdmiZones.length > 0 ? {
        audioMode: bridgeZones[0]?.audioMode || 'aux',
        pcm_outputs: bridgeZones[0]?.audioMode === 'hdmi' ? ['HDMI']
          : bridgeZones[0]?.audioMode === 'both' ? ['AnalogAudio', 'HDMI']
          : ['AnalogAudio'],
        compressed_outputs: bridgeZones[0]?.audioMode === 'aux' ? [] : ['HDMI'],
        routing_method: 'SetPcmAudioOutputs on roVideoPlayer (not device-global, not via roAudioOutput)',
        compressed_note: 'AnalogAudio does NOT support compressed (AC3/DTS) passthrough. Compressed only routed to HDMI/SPDIF.',
        bridge_transport: 'BSMessagePort — JS: new BSMessagePort().postMessage(obj); BrightScript: payload.reason="message", payload.message=roAssociativeArray',
        ui_to_brs_map: {
          aux:  { pcm: ['AnalogAudio'], compressed: [] },
          hdmi: { pcm: ['HDMI'], compressed: ['HDMI'] },
          both: { pcm: ['AnalogAudio', 'HDMI'], compressed: ['HDMI'] },
        },
      } : null,

      warnings,
    });

  } catch (error) {
    console.error('[debugBrightSignHdmiConfig] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});