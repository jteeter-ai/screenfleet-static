import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Use asServiceRole so entity permission restrictions don't block the user
    // from reading their own membership records
    const members = await base44.asServiceRole.entities.OrgMember.filter({
      user_email: user.email,
    });

    // Also load their org details
    const orgIds = [...new Set(members.map(m => m.org_id).filter(Boolean))];
    let orgs = [];
    if (orgIds.length > 0) {
      const results = await Promise.all(
        orgIds.map(id => base44.asServiceRole.entities.Organization.filter({ id }))
      );
      orgs = results.flat();
    }

    return Response.json({ members, orgs });
  } catch (err) {
    console.error('[getMyMembership] error:', err?.message);
    return Response.json({ error: err?.message }, { status: 500 });
  }
});