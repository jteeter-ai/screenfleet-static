/**
 * apiScreenPayload — V1 Legacy Player Content Delivery Endpoint
 *
 * CLASSIFICATION: PLAYER-DELIVERY ONLY (V1 LEGACY)
 * This is a legacy V1 endpoint that resolves Zone entity records (zone_scope="runtime")
 * for older hardware players and V1 BrightSign deployments.
 *
 * STATUS: DEPRECATED — V2 uses screenPayload.js instead (RuntimeZone-based).
 * Keep alive only for any active V1 deployments. Do not add new features.
 *
 * MIGRATION TARGET — must be removed from the CMS once all devices are on V2.
 * When the Player app is deployed:
 *   - V2 devices use Player app's screenPayload equivalent
 *   - V1 devices can be migrated at that time
 *   - Remove this function from the CMS
 *
 * Public, no auth required (devices poll this without user sessions).
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

/**
 * PUBLIC REST API ENDPOINT FOR BRIGHTSIGN PLAYBACK (V1 LEGACY — SEE ABOVE)
 * 
 * Accessible via: GET /_functions/apiScreenPayload?screenId=XXX
 * 
 * Returns fully resolved runtime payload for hardware players:
 * - Screen configuration (resolution, dimensions, status)
 * - Runtime zones (zone_scope="runtime" only)
 * - Expanded playlist/rotation data for offline playback
 * - Content version for cache invalidation
 * 
 * CRITICAL: This endpoint MUST work outside Base44 editor environment
 * Used by BrightSign, TVs, and external browser displays
 */
Deno.serve(async (req) => {
  // Enable CORS for cross-origin requests from hardware players
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers });
  }

  try {
    // Support both GET (external browsers/BrightSign) and POST (internal invocations)
    let screenId;
    
    if (req.method === 'GET') {
      const url = new URL(req.url);
      screenId = url.searchParams.get('screenId');
    } else if (req.method === 'POST') {
      const body = await req.json();
      screenId = body.screenId;
    }

    if (!screenId) {
      console.error('[apiScreenPayload] Missing screenId parameter');
      return Response.json({ error: 'screenId parameter required (use ?screenId=XXX for GET or {"screenId":"XXX"} for POST)' }, { status: 400, headers });
    }

    console.log(`[apiScreenPayload] ✅ Request received for screenId=${screenId}`);

    let base44;
    try {
      base44 = createClientFromRequest(req);
      console.log('[apiScreenPayload] ✅ Base44 client initialized');
    } catch (e) {
      console.error('[apiScreenPayload] ❌ Failed to create Base44 client:', e.message);
      return Response.json({ 
        error: 'Failed to initialize app context', 
        detail: e.message 
      }, { status: 500, headers });
    }
    
    // Fetch screen metadata using service role (bypasses auth for hardware players)
    let screens;
    try {
      screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
      console.log(`[apiScreenPayload] ✅ Screen query returned ${screens.length} results`);
    } catch (e) {
      console.error('[apiScreenPayload] ❌ Failed to fetch screen:', e.message);
      return Response.json({ 
        error: 'Failed to fetch screen data', 
        detail: e.message 
      }, { status: 500, headers });
    }
    
    const screen = screens[0];
    
    if (!screen) {
      console.error(`[apiScreenPayload] ❌ Screen not found: ${screenId}`);
      return Response.json({ error: 'Screen not found', screenId }, { status: 404, headers });
    }

    console.log(`[apiScreenPayload] ✅ Screen found: ${screen.name} (${screen.width}x${screen.height})`);

    // Fetch ONLY runtime zones (zone_scope="runtime")
    // CRITICAL: Never return template zones to the player
    let zones;
    try {
      zones = await base44.asServiceRole.entities.Zone.filter({ 
        screen_id: screenId,
        zone_scope: "runtime"
      });
      console.log(`[apiScreenPayload] ✅ Loaded ${zones.length} runtime zones for screen ${screen.name}`);
    } catch (e) {
      console.error('[apiScreenPayload] ⚠️ Failed to fetch zones:', e.message);
      zones = []; // Graceful fallback: return screen with no zones
    }

    // Collect unique playlist and rotation IDs from zones
    const playlistIds = [...new Set(zones.filter(z => z.playlist_id).map(z => z.playlist_id))];
    const rotationIds = [...new Set(zones.filter(z => z.rotation_id).map(z => z.rotation_id))];

    console.log(`[apiScreenPayload] 📦 Expanding content: ${playlistIds.length} playlists, ${rotationIds.length} rotations`);

    // Fetch expanded playlist data (for BrightSign compatibility)
    const playlists = {};
    for (const playlistId of playlistIds) {
      try {
        const [playlist] = await base44.asServiceRole.entities.Playlist.filter({ id: playlistId });
        const spots = await base44.asServiceRole.entities.PlaylistSpot.filter({ playlist_id: playlistId });
        const spotIds = spots.map(s => s.id);
        const creativesArrays = await Promise.all(spotIds.map(id => 
          base44.asServiceRole.entities.PlaylistCreative.filter({ spot_id: id })
        ));
        const creatives = creativesArrays.flat();
        
        playlists[playlistId] = {
          ...playlist,
          spots: spots.sort((a, b) => (a.spot_number || 0) - (b.spot_number || 0)),
          creatives: creatives.sort((a, b) => {
            const spotA = spots.find(s => s.id === a.spot_id);
            const spotB = spots.find(s => s.id === b.spot_id);
            const spotDiff = (spotA?.spot_number || 0) - (spotB?.spot_number || 0);
            return spotDiff !== 0 ? spotDiff : (a.order || 0) - (b.order || 0);
          })
        };
        console.log(`  ✅ Playlist ${playlist.name}: ${spots.length} spots, ${creatives.length} creatives`);
      } catch (e) {
        console.error(`[apiScreenPayload] ⚠️ Failed to fetch playlist ${playlistId}:`, e.message);
      }
    }

    // Fetch expanded rotation data
    const rotations = {};
    for (const rotationId of rotationIds) {
      try {
        const [rotation] = await base44.asServiceRole.entities.Rotation.filter({ id: rotationId });
        const spots = await base44.asServiceRole.entities.Spot.filter({ rotation_id: rotationId });
        const spotIds = spots.map(s => s.id);
        const creativesArrays = await Promise.all(spotIds.map(id => 
          base44.asServiceRole.entities.Creative.filter({ spot_id: id })
        ));
        const creatives = creativesArrays.flat();
        
        rotations[rotationId] = {
          ...rotation,
          spots: spots.sort((a, b) => (a.spot_number || 0) - (b.spot_number || 0)),
          creatives: creatives
        };
        console.log(`  ✅ Rotation ${rotation.name}: ${spots.length} spots, ${creatives.length} creatives`);
      } catch (e) {
        console.error(`[apiScreenPayload] ⚠️ Failed to fetch rotation ${rotationId}:`, e.message);
      }
    }

    // Build resolved payload for player runtime
    const payload = {
      screen: {
        id: screen.id,
        name: screen.name,
        truck_id: screen.truck_id,
        width: screen.width,
        height: screen.height,
        status: screen.status,
        content_version: screen.content_version || screen.last_published_at || screen.updated_date,
      },
      zones: zones.map(z => ({
        id: z.id,
        template_zone_id: z.template_zone_id,
        name: z.name,
        x: z.x || 0,
        y: z.y || 0,
        width: z.width,
        height: z.height,
        z_index: z.z_index || 1,
        content_type: z.content_type || 'empty',
        playlist_id: z.playlist_id,
        rotation_id: z.rotation_id,
        media_url: z.media_url,
        media_file_type: z.media_file_type,
        html_url: z.html_url,
        volume: z.volume ?? 100,
        fit_mode: z.fit_mode || 'fill',
        background_color: z.background_color || '#000000',
        is_visible: z.is_visible !== false,
      })),
      playlists, // Expanded playlist data with spots and creatives
      rotations, // Expanded rotation data with spots and creatives
      version: screen.content_version || screen.last_published_at || screen.updated_date,
      fetched_at: new Date().toISOString(),
    };

    console.log(`[apiScreenPayload] 🎉 SUCCESS: Returning payload with ${zones.length} zones, ${Object.keys(playlists).length} playlists, ${Object.keys(rotations).length} rotations, version ${payload.version}`);
    return Response.json(payload, { headers });
  } catch (error) {
    console.error('[apiScreenPayload] ❌ FATAL ERROR:', error.message, error.stack);
    return Response.json({ 
      error: 'Internal server error', 
      detail: error.message,
      stack: error.stack 
    }, { status: 500, headers });
  }
});