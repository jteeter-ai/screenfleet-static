import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const MODULE_KEYS = {
  ASSETS:              'module_assets',
  LAYOUTS:             'module_layouts',
  MEDIA_LIBRARY:       'module_media_library',
  PLAYLISTS:           'module_playlists',
  ROUTE_PRESENTATIONS: 'module_route_presentations',
  SEQUENCES:           'module_sequences',
  SCHEDULING:          'module_scheduling',
  LIVE_OUTPUT:         'module_live_output',
  SCREEN_CONTROLS:     'module_screen_controls',
  STUDIO:              'module_studio',
  ANALYTICS:           'module_analytics',
  TEAM_MANAGEMENT:     'module_team_management',
  PLAYER_MONITORING:   'module_player_monitoring',
  BILLING:             'module_billing',
  PLATFORM_ADMIN:      'module_platform_admin',
};

const PLAN_MODULE_DEFAULTS = {
  starter: [
    MODULE_KEYS.ASSETS,
    MODULE_KEYS.LAYOUTS,
    MODULE_KEYS.MEDIA_LIBRARY,
    MODULE_KEYS.PLAYLISTS,
    MODULE_KEYS.SCHEDULING,
    MODULE_KEYS.LIVE_OUTPUT,
    MODULE_KEYS.SCREEN_CONTROLS,
    MODULE_KEYS.PLAYER_MONITORING,
    MODULE_KEYS.TEAM_MANAGEMENT,
  ],
  growth: [
    MODULE_KEYS.ASSETS,
    MODULE_KEYS.LAYOUTS,
    MODULE_KEYS.MEDIA_LIBRARY,
    MODULE_KEYS.PLAYLISTS,
    MODULE_KEYS.ROUTE_PRESENTATIONS,
    MODULE_KEYS.SEQUENCES,
    MODULE_KEYS.SCHEDULING,
    MODULE_KEYS.LIVE_OUTPUT,
    MODULE_KEYS.SCREEN_CONTROLS,
    MODULE_KEYS.PLAYER_MONITORING,
    MODULE_KEYS.ANALYTICS,
    MODULE_KEYS.TEAM_MANAGEMENT,
  ],
  total360: [
    MODULE_KEYS.ASSETS,
    MODULE_KEYS.LAYOUTS,
    MODULE_KEYS.MEDIA_LIBRARY,
    MODULE_KEYS.PLAYLISTS,
    MODULE_KEYS.ROUTE_PRESENTATIONS,
    MODULE_KEYS.SEQUENCES,
    MODULE_KEYS.SCHEDULING,
    MODULE_KEYS.LIVE_OUTPUT,
    MODULE_KEYS.SCREEN_CONTROLS,
    MODULE_KEYS.STUDIO,
    MODULE_KEYS.ANALYTICS,
    MODULE_KEYS.TEAM_MANAGEMENT,
    MODULE_KEYS.PLAYER_MONITORING,
    MODULE_KEYS.BILLING,
  ],
};

function validatePlans(plans) {
  const seedingPlans = [];
  const warnings = [];

  // Feature key → MODULE_KEY mapping for seeding from legacy features array
  const FEATURE_TO_MODULE = {
    'basic_scheduling': MODULE_KEYS.SCHEDULING,
    'playlists': MODULE_KEYS.PLAYLISTS,
    'rotations': MODULE_KEYS.ROUTE_PRESENTATIONS,
    'route_presentations': MODULE_KEYS.ROUTE_PRESENTATIONS,
    'total360_rotation': MODULE_KEYS.ROUTE_PRESENTATIONS,
    'sequences': MODULE_KEYS.SEQUENCES,
    'multi_zone': MODULE_KEYS.LAYOUTS,
    'multi_zone_layouts': MODULE_KEYS.LAYOUTS,
    'analytics': MODULE_KEYS.ANALYTICS,
    'live_output': MODULE_KEYS.LIVE_OUTPUT,
    'screen_controls': MODULE_KEYS.SCREEN_CONTROLS,
    'media_library': MODULE_KEYS.MEDIA_LIBRARY,
    'studio': MODULE_KEYS.STUDIO,
    'team_management': MODULE_KEYS.TEAM_MANAGEMENT,
    'player_monitoring': MODULE_KEYS.PLAYER_MONITORING,
    'billing_access': MODULE_KEYS.BILLING,
  };

  plans.forEach((plan) => {
    if (plan.modules_included === undefined || plan.modules_included === null) {
      let seeded = [];

      // Try 1: slug-based defaults
      if (plan.slug && PLAN_MODULE_DEFAULTS[plan.slug]) {
        seeded = [...PLAN_MODULE_DEFAULTS[plan.slug]];
      }
      // Try 2: feature_flags mapping
      else if (plan.feature_flags) {
        if (plan.feature_flags.playlists)          seeded.push(MODULE_KEYS.PLAYLISTS);
        if (plan.feature_flags.route_presentations) seeded.push(MODULE_KEYS.ROUTE_PRESENTATIONS);
        if (plan.feature_flags.sequences)           seeded.push(MODULE_KEYS.SEQUENCES);
      }
      // Try 3: features array mapping (fallback)
      if (seeded.length === 0 && Array.isArray(plan.features)) {
        const seen = new Set();
        plan.features.forEach(f => {
          const moduleKey = FEATURE_TO_MODULE[f];
          if (moduleKey && !seen.has(moduleKey)) {
            seeded.push(moduleKey);
            seen.add(moduleKey);
          }
        });
      }

      // Always include baseline modules
      const baseline = [
        MODULE_KEYS.ASSETS, MODULE_KEYS.LAYOUTS, MODULE_KEYS.MEDIA_LIBRARY,
        MODULE_KEYS.PLAYLISTS, MODULE_KEYS.SCHEDULING, MODULE_KEYS.LIVE_OUTPUT,
        MODULE_KEYS.SCREEN_CONTROLS, MODULE_KEYS.PLAYER_MONITORING,
      ];
      const final = [...new Set([...seeded, ...baseline])];

      if (final.length > 0) {
        seedingPlans.push({ id: plan.id, slug: plan.slug, name: plan.name, modules_included: final });
      } else {
        warnings.push(`Plan "${plan.name}" (${plan.slug}) has no modules_included and could not be auto-seeded.`);
      }
    } else if (Array.isArray(plan.modules_included) && plan.modules_included.length === 0) {
      warnings.push(`Plan "${plan.name}" (${plan.slug}) has modules_included=[] (zero modules).`);
    }
  });

  return { seedingPlans, warnings };
}

/**
 * validateAndMigratePlans
 * Phase 5B safety check. Detects plans with missing modules_included.
 * Params: { dryRun: boolean, autoSeed: boolean }
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { dryRun = true, autoSeed = true } = await req.json();
    const plans = await base44.asServiceRole.entities.Plan.list();
    const { seedingPlans, warnings } = validatePlans(plans);

    if (!dryRun && autoSeed && seedingPlans.length > 0) {
      for (const plan of seedingPlans) {
        await base44.asServiceRole.entities.Plan.update(plan.id, {
          modules_included: plan.modules_included,
        });
      }
    }

    return Response.json({
      dryRun,
      seedingPlans: seedingPlans.map(p => ({
        slug: p.slug,
        name: p.name,
        modules_count: p.modules_included.length,
      })),
      warnings,
      total_plans: plans.length,
      seeded_count: seedingPlans.length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});