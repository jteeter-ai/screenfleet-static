import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { content_type, playlist_id, route_presentation_id } = await req.json();
    if (!content_type) {
      return Response.json({ error: 'Missing content_type' }, { status: 400 });
    }

    if (content_type === 'playlist') {
      if (!playlist_id) return Response.json({ error: 'Missing playlist_id for playlist content' }, { status: 400 });
      const playlist = await base44.entities.Playlist.get(playlist_id);
      if (!playlist) return Response.json({ error: 'Playlist not found' }, { status: 404 });
      return Response.json({ valid: true, layout_template_id: playlist.layout_template_id });
    }

    if (content_type === 'route_presentation') {
      if (!route_presentation_id) return Response.json({ error: 'Missing route_presentation_id for route_presentation content' }, { status: 400 });
      const presentation = await base44.entities.RoutePresentation.get(route_presentation_id);
      if (!presentation) return Response.json({ error: 'RoutePresentation not found' }, { status: 404 });
      return Response.json({ valid: true, layout_template_id: presentation.layout_template_id });
    }

    return Response.json({ error: 'Invalid content_type' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});