/**
 * Build Sequence Playback Track
 * 
 * Resolves a sequence into a flattened playback list.
 * Each sequence item is resolved independently.
 * 
 * Input: sequence_id
 * Output: { items: [{ id, order, type, content: {...} }] }
 */

import { createClientFromRequest } from "npm:@base44/sdk@0.8.21";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    
    const { sequence_id } = await req.json();
    
    if (!sequence_id) {
      return Response.json(
        { error: "sequence_id is required" },
        { status: 400 }
      );
    }
    
    // Fetch the sequence
    const sequences = await base44.entities.Sequence.filter({
      id: sequence_id,
    });
    
    if (sequences.length === 0) {
      return Response.json(
        { error: "Sequence not found" },
        { status: 404 }
      );
    }
    
    const sequence = sequences[0];
    
    // Fetch all items for this sequence, ordered by order field
    const rawItems = await base44.entities.SequenceItem.filter({
      sequence_id,
    });
    
    const orderedItems = [...rawItems].sort((a, b) => a.order - b.order);
    
    if (orderedItems.length === 0) {
      return Response.json({
        sequence_id,
        items: [],
        message: "Sequence has no items",
      });
    }
    
    // Resolve each item independently
    const resolvedItems = [];
    
    for (const item of orderedItems) {
      let content = null;
      
      if (item.type === "playlist" && item.playlist_id) {
        // Fetch playlist (item is a black box — return as-is)
        const playlists = await base44.entities.Playlist.filter({
          id: item.playlist_id,
        });
        if (playlists.length > 0) {
          content = playlists[0];
        }
      } else if (item.type === "presentation" && item.presentation_id) {
        // Fetch route presentation (item is a black box — return as-is)
        const presentations = await base44.entities.RoutePresentation.filter({
          id: item.presentation_id,
        });
        if (presentations.length > 0) {
          content = presentations[0];
        }
      }
      
      resolvedItems.push({
        id: item.id,
        order: item.order,
        type: item.type,
        content: content || null,
        reference_id:
          item.type === "playlist" ? item.playlist_id : item.presentation_id,
      });
    }
    
    console.log(
      `[buildSequenceTrack] Sequence ${sequence_id}: ${resolvedItems.length} items`
    );
    
    return Response.json({
      sequence_id,
      sequence_name: sequence.name,
      items: resolvedItems,
    });
  } catch (error) {
    console.error("[buildSequenceTrack] Error:", error.message);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});