import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { orgId, ownerEmail, orgName, appUrl } = await req.json();

    if (!orgId || !ownerEmail || !orgName) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Generate a secure token and send branded setup email
    // CRITICAL: pass appUrl so the email link points to the frontend, not the Deno backend
    const result = await base44.asServiceRole.functions.invoke('generateSetupToken', {
      userEmail: ownerEmail,
      orgId,
      orgName,
      userRole: 'user',
      type: 'org_owner_setup',
      appUrl: appUrl || null,
    });

    return Response.json({ success: true, setupUrl: result?.setupUrl });
  } catch (error) {
    console.error('Error sending org owner invite:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});