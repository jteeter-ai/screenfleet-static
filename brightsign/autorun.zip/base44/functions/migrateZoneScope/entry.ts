import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

/**
 * CRITICAL DATA MIGRATION: Add zone_scope discriminator to all existing zones
 * 
 * This fixes the root cause bug where template zones get deleted during publish.
 * 
 * Migration rules:
 * - If zone has layout_id → zone_scope = "template"
 * - If zone has template_zone_id OR (screen_id AND no layout_id) → zone_scope = "runtime"
 * 
 * After this migration, zone_scope is REQUIRED for all zones.
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Fetch ALL zones
    const allZones = await base44.asServiceRole.entities.Zone.list('-created_date', 9999);
    console.log(`[Migration] Found ${allZones.length} total zones to migrate`);

    let templateCount = 0;
    let runtimeCount = 0;
    let alreadyMigratedCount = 0;
    const errors = [];

    for (const zone of allZones) {
      // Skip if already has zone_scope
      if (zone.zone_scope) {
        alreadyMigratedCount++;
        continue;
      }

      let newScope = null;

      // Rule 1: Has layout_id → template zone
      if (zone.layout_id) {
        newScope = 'template';
        templateCount++;
      }
      // Rule 2: Has template_zone_id OR (has screen_id AND no layout_id) → runtime zone
      else if (zone.template_zone_id || (zone.screen_id && !zone.layout_id)) {
        newScope = 'runtime';
        runtimeCount++;
      }
      else {
        // Ambiguous case - log for manual review
        console.warn(`[Migration] Ambiguous zone ${zone.id}:`, {
          layout_id: zone.layout_id,
          screen_id: zone.screen_id,
          template_zone_id: zone.template_zone_id,
          name: zone.name
        });
        // Default to template if it has a name and geometry (safer default)
        newScope = 'template';
        templateCount++;
        errors.push({
          zone_id: zone.id,
          reason: 'Ambiguous - defaulted to template',
          details: { layout_id: zone.layout_id, screen_id: zone.screen_id }
        });
      }

      // Update the zone
      try {
        await base44.asServiceRole.entities.Zone.update(zone.id, { zone_scope: newScope });
        console.log(`[Migration] Updated zone ${zone.id} → zone_scope="${newScope}"`);
      } catch (err) {
        console.error(`[Migration] Failed to update zone ${zone.id}:`, err.message);
        errors.push({
          zone_id: zone.id,
          reason: 'Update failed',
          error: err.message
        });
      }
    }

    return Response.json({
      success: true,
      message: 'Zone scope migration complete',
      summary: {
        total_zones: allZones.length,
        already_migrated: alreadyMigratedCount,
        migrated_to_template: templateCount,
        migrated_to_runtime: runtimeCount,
        errors: errors.length
      },
      errors: errors.length > 0 ? errors : undefined
    });

  } catch (error) {
    console.error('[Migration] Fatal error:', error);
    return Response.json({ 
      success: false, 
      error: error.message,
      stack: error.stack 
    }, { status: 500 });
  }
});