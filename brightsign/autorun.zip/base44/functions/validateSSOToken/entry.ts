import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token } = await req.json();

    if (!token) {
      return Response.json({ valid: false, error: 'Token is required' }, { status: 400 });
    }

    const tokens = await base44.asServiceRole.entities.AppToken.filter({ token, type: 'sso' });
    if (!tokens.length) {
      return Response.json({ valid: false, code: 'INVALID_TOKEN', error: 'Invalid or unrecognized SSO token.' });
    }

    const appToken = tokens[0];

    if (appToken.used_at) {
      return Response.json({ valid: false, code: 'TOKEN_USED', error: 'This SSO link has already been used.' });
    }

    if (new Date(appToken.expires_at) < new Date()) {
      return Response.json({ valid: false, code: 'TOKEN_EXPIRED', error: 'This SSO link has expired. Please request a new one.' });
    }

    // Mark token as used
    await base44.asServiceRole.entities.AppToken.update(appToken.id, {
      used_at: new Date().toISOString(),
    });

    console.log(`[validateSSOToken] SSO token redeemed for ${appToken.user_email} org=${appToken.org_id}`);
    return Response.json({
      valid: true,
      user_email: appToken.user_email,
      org_id: appToken.org_id,
      org_name: appToken.org_name,
    });
  } catch (err) {
    console.error('[validateSSOToken] error:', err?.message);
    return Response.json({ error: err?.message }, { status: 500 });
  }
});