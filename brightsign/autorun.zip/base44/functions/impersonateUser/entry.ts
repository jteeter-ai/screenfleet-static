import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * impersonateUser — Platform admin tool to view an org as a specific member.
 *
 * FIXED: Previously used `new URL(req.url).origin` which returned the Deno function
 * host (spry-weasel-13-....deno.dev) instead of the CMS app origin. The browser
 * would then navigate to the raw function host URL, which requires Base44-App-Id
 * headers that a plain browser tab never sends.
 *
 * FIX: The frontend now passes `appOrigin` (window.location.origin) and we use
 * that to build a URL pointing to /ImpersonateView inside the CMS app itself.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // SECURITY: Platform admin only
    const PLATFORM_ROLES = ['platform_owner', 'platform_admin', 'platform_support', 'admin'];
    if (!user || !PLATFORM_ROLES.includes(user.role)) {
      return Response.json({ error: 'Forbidden: platform admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { memberId, appOrigin } = body;

    if (!memberId) {
      return Response.json({ error: 'Missing memberId' }, { status: 400 });
    }

    // Fetch the org member
    const members = await base44.asServiceRole.entities.OrgMember.filter({ id: memberId });
    const member = members[0];
    if (!member) {
      return Response.json({ error: 'Member not found' }, { status: 404 });
    }

    // Fetch the org for the name
    const orgs = await base44.asServiceRole.entities.Organization.filter({ id: member.org_id });
    const org = orgs[0];

    // Build URL pointing to the CMS app's /ImpersonateView route (NOT the Deno host).
    // appOrigin is passed by the frontend as window.location.origin, e.g. https://app.screenfleet.io
    // Fall back to a sensible default if not provided (should always be provided by frontend).
    const origin = appOrigin || 'https://app.screenfleet.io';
    const params = new URLSearchParams({
      email: member.user_email,
      orgId: member.org_id,
      orgName: org?.name || member.org_id,
    });
    const impersonationUrl = `${origin}/ImpersonateView?${params.toString()}`;

    // Audit log
    base44.asServiceRole.entities.AuditLog.create({
      org_id: member.org_id,
      actor_email: user.email,
      action: 'admin_impersonation',
      target_type: 'org_member',
      target_id: member.id,
      details: `Platform admin "${user.email}" viewed org "${org?.name || member.org_id}" as "${member.user_email}"`,
    }).catch(() => {});

    return Response.json({
      success: true,
      impersonationUrl,
      email: member.user_email,
      orgId: member.org_id,
      orgName: org?.name,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});