import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import Stripe from 'npm:stripe@17.0.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

// Map plan slugs to Stripe price IDs (you'll set these in Stripe dashboard)
const PLAN_PRICES = {
  starter: Deno.env.get('STRIPE_PRICE_STARTER'),
  growth: Deno.env.get('STRIPE_PRICE_GROWTH'),
  total360: Deno.env.get('STRIPE_PRICE_TOTAL360'),
};

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orgId, planSlug, successUrl, cancelUrl } = await req.json();

    if (!orgId || !planSlug) {
      return Response.json({ error: 'Missing orgId or planSlug' }, { status: 400 });
    }

    const org = await base44.asServiceRole.entities.Organization.filter({ id: orgId });
    if (org.length === 0) {
      return Response.json({ error: 'Organization not found' }, { status: 404 });
    }

    const organization = org[0];
    const priceId = PLAN_PRICES[planSlug];

    if (!priceId) {
      return Response.json({ error: 'Invalid plan' }, { status: 400 });
    }

    // Get or create Stripe customer
    let customerId = organization.stripe_customer_id;

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: organization.billing_email || organization.owner_email,
        metadata: { orgId, orgName: organization.name }
      });
      customerId = customer.id;
      
      // Update org with Stripe customer ID
      await base44.asServiceRole.entities.Organization.update(orgId, {
        stripe_customer_id: customerId
      });
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        }
      ],
      mode: 'subscription',
      success_url: successUrl || `${new URL(req.url).origin}/billing?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancelUrl || `${new URL(req.url).origin}/billing`,
    });

    return Response.json({ checkoutUrl: session.url, sessionId: session.id });
  } catch (error) {
    console.error('Checkout error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});