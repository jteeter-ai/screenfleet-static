/**
 * reportHeartbeat
 * Called by player devices on a regular interval (e.g. every 60s).
 * Upserts a PlayerHeartbeat record for the given screen_id.
 * Public endpoint — no user auth required (players are unattended).
 * Validates authenticity via screenId presence + optional secret.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  const { screen_id, content_version, player_version } = await req.json().catch(() => ({}));

  if (!screen_id) {
    return Response.json({ error: 'screen_id is required' }, { status: 400 });
  }

  // Look up screen to get asset_id and org_id (use service role — no user auth)
  const screens = await base44.asServiceRole.entities.Screen.filter({ id: screen_id });
  const screen = screens[0];
  if (!screen) {
    return Response.json({ error: 'Screen not found' }, { status: 404 });
  }

  const now = new Date().toISOString();

  // Upsert: find existing heartbeat for this screen or create new
  const existing = await base44.asServiceRole.entities.PlayerHeartbeat.filter({ screen_id });
  const heartbeatData = {
    screen_id,
    asset_id: screen.asset_id || null,
    org_id: screen.org_id || null,
    last_seen_at: now,
    ...(content_version ? { content_version } : {}),
    ...(player_version ? { player_version } : {}),
  };

  if (existing.length > 0) {
    await base44.asServiceRole.entities.PlayerHeartbeat.update(existing[0].id, heartbeatData);
  } else {
    await base44.asServiceRole.entities.PlayerHeartbeat.create(heartbeatData);
  }

  return Response.json({ ok: true, last_seen_at: now });
});