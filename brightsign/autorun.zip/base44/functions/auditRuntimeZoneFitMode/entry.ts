import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * AUDIT: Comprehensive RuntimeZone fit_mode analysis across all orgs/assets
 * POST {} - no parameters required
 * 
 * Returns:
 * - Total RuntimeZone count
 * - Count with fit_mode = "fill"
 * - Detailed breakdown by org, asset, screen, zone
 * - Classification: intentional vs legacy/stale fill
 * - Ad-display zone identification
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Only platform admins can run this audit
    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: platform admin required' }, { status: 403 });
    }

    console.log('[auditRuntimeZoneFitMode] Starting comprehensive audit...');

    // Fetch all data in parallel
    const [runtimeZones, assets, orgs, screens, publishedScreens, layoutZones] = await Promise.all([
      base44.asServiceRole.entities.RuntimeZone.list('', 10000),
      base44.asServiceRole.entities.Asset.list('', 10000),
      base44.asServiceRole.entities.Organization.list('', 10000),
      base44.asServiceRole.entities.Screen.list('', 10000),
      base44.asServiceRole.entities.PublishedScreen.list('', 10000),
      base44.asServiceRole.entities.LayoutZone.list('', 10000),
    ]);

    console.log('[auditRuntimeZoneFitMode] Fetched data:', {
      runtimeZones: runtimeZones.length,
      assets: assets.length,
      orgs: orgs.length,
      screens: screens.length,
      publishedScreens: publishedScreens.length,
      layoutZones: layoutZones.length,
    });

    // Build lookup maps
    const assetMap = new Map(assets.map(a => [a.id, a]));
    const orgMap = new Map(orgs.map(o => [o.id, o]));
    const screenMap = new Map(screens.map(s => [s.id, s]));
    const psMap = new Map(publishedScreens.map(ps => [ps.id, ps]));
    const layoutZoneMap = new Map(layoutZones.map(lz => [lz.id, lz]));

    // Helpers
    const isAdDisplayZone = (zone, layoutZone) => {
      // Ad-display zones typically:
      // 1. Have names like "spot", "ad", "creative", "rotation", "presentation"
      // 2. Are assigned Route Presentations or Playlists (not HDMI/canvas)
      // 3. Are not the primary/hero zone
      const namePatterns = ['spot', 'ad', 'creative', 'rotation', 'presentation', 'display'];
      const zoneName = (zone.name || '').toLowerCase();
      const hasAdName = namePatterns.some(p => zoneName.includes(p));
      const isPlaylistOrPresentation = ['playlist', 'presentation', 'route_presentation'].includes(zone.content_source_type);
      const isNotHdmiOrCanvas = !['hdmi_input', 'canvas_creative'].includes(zone.content_source_type);
      return hasAdName || (isPlaylistOrPresentation && isNotHdmiOrCanvas);
    };

    const isLikelyLegacy = (zone, layoutZone, screen) => {
      // Legacy indicators:
      // 1. Screen has updated_date much newer than zone's created_date (zone predates screen update)
      // 2. fit_mode doesn't match LayoutZone default (divergence suggests legacy persist)
      // 3. Small/medium zones (not hero/main display)
      // 4. Multiple zones with same fit_mode = fill (uniform legacy value)
      if (!layoutZone || !screen) return false;
      
      const zoneCreatedMs = new Date(zone.created_date || 0).getTime();
      const screenUpdatedMs = new Date(screen.updated_date || 0).getTime();
      const timeDiff = screenUpdatedMs - zoneCreatedMs;
      
      const hasOldTimestamp = timeDiff > 7 * 24 * 60 * 60 * 1000; // >7 days
      const fitMismatch = layoutZone.fit_mode_default !== 'fill' && zone.fit_mode === 'fill';
      const isSmallZone = (zone.width * zone.height) < (screen.width * screen.height * 0.5);
      
      return hasOldTimestamp || fitMismatch || isSmallZone;
    };

    // Group and analyze
    const byOrg = {};
    let totalFill = 0;

    for (const zone of runtimeZones) {
      if (zone.fit_mode === 'fill') totalFill++;

      const ps = psMap.get(zone.published_screen_id);
      if (!ps) continue;

      const asset = assetMap.get(ps.asset_id);
      const org = asset ? orgMap.get(asset.org_id) : null;
      const screen = screenMap.get(zone.screen_id);
      const layoutZone = layoutZoneMap.get(zone.layout_zone_id);

      const orgId = org?.id || 'UNKNOWN';
      const orgName = org?.name || 'Unknown Org';
      const assetId = asset?.id || 'UNKNOWN';
      const assetName = asset?.name || 'Unknown Asset';

      if (!byOrg[orgId]) {
        byOrg[orgId] = { name: orgName, assets: {} };
      }
      if (!byOrg[orgId].assets[assetId]) {
        byOrg[orgId].assets[assetId] = { name: assetName, zones: [] };
      }

      byOrg[orgId].assets[assetId].zones.push({
        id: zone.id,
        name: zone.name,
        fit_mode: zone.fit_mode,
        screen_id: zone.screen_id,
        screen_name: screen?.name || 'Unknown Screen',
        layout_zone_id: zone.layout_zone_id,
        content_source_type: zone.content_source_type,
        isAdDisplay: isAdDisplayZone(zone, layoutZone),
        isLikelyLegacy: zone.fit_mode === 'fill' ? isLikelyLegacy(zone, layoutZone, screen) : null,
        created_date: zone.created_date,
        width: zone.width,
        height: zone.height,
        published_screen_id: zone.published_screen_id,
      });
    }

    // Build summary by asset
    const byAsset = [];
    Object.entries(byOrg).forEach(([orgId, org]) => {
      Object.entries(org.assets).forEach(([assetId, asset]) => {
        const fillZones = asset.zones.filter(z => z.fit_mode === 'fill');
        const adDisplayZones = asset.zones.filter(z => z.isAdDisplay);
        const legacyFillZones = fillZones.filter(z => z.isLikelyLegacy);
        const intentionalFillZones = fillZones.filter(z => !z.isLikelyLegacy);

        byAsset.push({
          org_name: org.name,
          asset_name: asset.name,
          total_zones: asset.zones.length,
          fill_zones_count: fillZones.length,
          ad_display_zones_count: adDisplayZones.length,
          legacy_fill_zones: legacyFillZones.length,
          intentional_fill_zones: intentionalFillZones.length,
          zones: asset.zones,
        });
      });
    });

    // Sort by fill count descending
    byAsset.sort((a, b) => b.fill_zones_count - a.fill_zones_count);

    const report = {
      audit_date: new Date().toISOString(),
      summary: {
        total_runtime_zones: runtimeZones.length,
        total_with_fit_mode_fill: totalFill,
        fill_percentage: ((totalFill / runtimeZones.length) * 100).toFixed(2) + '%',
        organizations_count: Object.keys(byOrg).length,
        assets_with_fill: byAsset.filter(a => a.fill_zones_count > 0).length,
      },
      by_asset_detail: byAsset,
    };

    return Response.json(report);
  } catch (error) {
    console.error('[auditRuntimeZoneFitMode] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});