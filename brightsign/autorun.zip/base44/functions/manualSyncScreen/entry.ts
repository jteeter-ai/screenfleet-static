/**
 * manualSyncScreen — Trigger sync with retry, for admin testing
 * POST { screen_id }
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const screenId = body.screen_id;
    if (!screenId) {
      return Response.json({ error: 'screen_id required' }, { status: 400 });
    }

    // Verify org membership for non-platform-admins
    if (user.role !== 'admin') {
      const screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
      const screen = screens[0];
      if (screen?.org_id) {
        const memberships = await base44.asServiceRole.entities.OrgMember.filter({ user_email: user.email, org_id: screen.org_id });
        const member = memberships[0];
        if (!member || !['owner', 'admin', 'manager', 'ops_manager'].includes(member.org_role)) {
          return Response.json({ error: 'Forbidden: insufficient org permissions' }, { status: 403 });
        }
      }
    }

    // Invoke syncToPlayer via the SDK
    const result = await base44.functions.invoke('syncToPlayer', { screenId });
    
    return Response.json(result, { status: 200 });
  } catch (error) {
    console.error('[manualSyncScreen]', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});