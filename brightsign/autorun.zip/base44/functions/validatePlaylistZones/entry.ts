import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { playlist_id, layout_template_id: direct_layout_id, zone_assignments } = await req.json();
    
    if ((!playlist_id && !direct_layout_id) || !zone_assignments) {
      return Response.json({ error: 'Missing playlist_id or layout_template_id and zone_assignments' }, { status: 400 });
    }

    let resolvedLayoutTemplateId = direct_layout_id || null;

    if (!resolvedLayoutTemplateId && playlist_id) {
      const playlist = await base44.entities.Playlist.get(playlist_id);
      if (!playlist) return Response.json({ error: 'Playlist not found' }, { status: 404 });
      resolvedLayoutTemplateId = playlist.layout_template_id;
    }

    if (!resolvedLayoutTemplateId) {
      return Response.json({ valid: true, layout_template_id: null });
    }

    const layoutZones = await base44.entities.LayoutZone.filter({ 
      layout_template_id: resolvedLayoutTemplateId
    });
    const validZoneIds = new Set(layoutZones.map(z => z.id));

    // Validate all zone_assignments reference valid layout zones
     const invalidZones = Object.keys(zone_assignments).filter(zoneId => !validZoneIds.has(zoneId));
     if (invalidZones.length > 0) {
       return Response.json({ 
         error: 'Invalid zone IDs', 
         invalid_zones: invalidZones 
       }, { status: 400 });
     }

     // Validate all media_asset_ids exist (if present)
     // Note: zone_assignments may contain additional fields like volume, muted, detected_video_duration, manual_duration_override
     // These are allowed and passed through unchanged
     const assignmentsWithMedia = Object.values(zone_assignments).filter(a => a?.media_asset_id);
     if (assignmentsWithMedia.length > 0) {
       const mediaAssets = await Promise.all(
         assignmentsWithMedia.map(a => base44.entities.MediaAsset.get(a.media_asset_id))
       );
       const missingAssets = mediaAssets.filter(a => a === null);
       if (missingAssets.length > 0) {
         return Response.json({ error: 'Some media assets not found' }, { status: 400 });
       }
     }

    return Response.json({ valid: true, layout_template_id: resolvedLayoutTemplateId });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});