/**
 * diagnoseLiveOutputPipeline — full chain diagnostic
 * POST { org_id, asset_id? }
 *
 * Auth required. Inspects the full V2 publish graph and reports mismatches.
 * For debugging only — returns verbose JSON.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { org_id, asset_id } = await req.json().catch(() => ({}));
    if (!org_id) return Response.json({ error: 'org_id required' }, { status: 400 });

    const mismatches = [];
    const report = { org_id, asset_id: asset_id || null, user: user.email };

    // Membership check
    let membership_ok = user.role === 'admin';
    if (!membership_ok) {
      const memberships = await base44.entities.OrgMember.filter({ user_email: user.email, org_id });
      membership_ok = memberships.length > 0;
    }
    report.membership_ok = membership_ok;
    if (!membership_ok) mismatches.push(`User ${user.email} is NOT a member of org ${org_id}`);

    // Asset check
    let asset = null;
    if (asset_id) {
      const assetRecords = await base44.asServiceRole.entities.Asset.filter({ id: asset_id });
      asset = assetRecords[0] || null;
      report.asset_found = !!asset;
      report.asset_org_id = asset?.org_id || null;
      if (!asset) {
        mismatches.push(`Asset ${asset_id} not found`);
      } else if (!asset.org_id) {
        mismatches.push(`Asset ${asset_id} has no org_id — publish will fail`);
      } else if (asset.org_id !== org_id) {
        mismatches.push(`Asset ${asset_id} has org_id=${asset.org_id} but queried org_id=${org_id}`);
      }
    } else {
      report.asset_found = null;
      report.asset_org_id = null;
    }

    // Screens by asset_id
    const screensByAssetId = asset_id
      ? await base44.asServiceRole.entities.Screen.filter({ asset_id })
      : [];

    // Screens by truck_id (legacy) — check if any screens only have truck_id
    const screensByTruckId = asset_id
      ? await base44.asServiceRole.entities.Screen.filter({ truck_id: asset_id })
      : [];

    const screensByAssetIdSet = new Set(screensByAssetId.map(s => s.id));
    const legacyOnlyScreens = screensByTruckId.filter(s => !screensByAssetIdSet.has(s.id));

    report.screens = screensByAssetId.map(s => ({ id: s.id, name: s.name, asset_id: s.asset_id, truck_id: s.truck_id, org_id: s.org_id }));
    report.screens_via_truck_id_only = legacyOnlyScreens.map(s => ({ id: s.id, name: s.name, asset_id: s.asset_id, truck_id: s.truck_id, org_id: s.org_id }));

    if (screensByAssetId.length === 0 && asset_id) {
      mismatches.push(`No screens found with Screen.asset_id = "${asset_id}". Publish will return "no screens".`);
    }
    if (legacyOnlyScreens.length > 0) {
      mismatches.push(`${legacyOnlyScreens.length} screen(s) only have truck_id=${asset_id} but NOT asset_id. They won't be published until asset_id is backfilled.`);
    }

    for (const s of screensByAssetId) {
      if (s.org_id && s.org_id !== org_id) {
        mismatches.push(`Screen "${s.name}" (${s.id}) has org_id=${s.org_id}, expected ${org_id}`);
      }
      if (!s.org_id) {
        mismatches.push(`Screen "${s.name}" (${s.id}) has no org_id — may be invisible to org queries`);
      }
    }

    // AssetLayouts
    const assetLayouts = asset_id
      ? await base44.asServiceRole.entities.AssetLayout.filter({ asset_id })
      : [];
    report.asset_layouts = assetLayouts.map(al => ({ id: al.id, screen_id: al.screen_id, layout_template_id: al.layout_template_id }));

    for (const screen of screensByAssetId) {
      const layout = assetLayouts.find(al => al.screen_id === screen.id);
      if (!layout) {
        mismatches.push(`Screen "${screen.name}" (${screen.id}) has no AssetLayout — zones will be empty on publish`);
      }
    }

    // Schedules (truck_id = asset_id in V2 naming convention)
    const schedules = asset_id
      ? await base44.asServiceRole.entities.Schedule.filter({ truck_id: asset_id })
      : [];
    const activeSchedules = schedules.filter(s => s.is_active);
    report.schedules = schedules.map(s => ({ id: s.id, name: s.name, content_type: s.content_type, is_active: s.is_active, playlist_id: s.playlist_id, rotation_id: s.rotation_id, sequence_id: s.sequence_id }));

    if (asset_id && activeSchedules.length === 0) {
      mismatches.push(`No active schedules found for asset ${asset_id} (Schedule.truck_id = "${asset_id}"). Publish will produce zones with no content.`);
    }

    // PublishedScreens for org
    const publishedScreens = await base44.asServiceRole.entities.PublishedScreen.filter({ org_id });
    const assetPublishedScreens = asset_id ? publishedScreens.filter(ps => ps.asset_id === asset_id) : publishedScreens;
    report.published_screens = assetPublishedScreens.map(ps => ({ id: ps.id, screen_id: ps.screen_id, asset_id: ps.asset_id, org_id: ps.org_id, published_at: ps.published_at, content_version: ps.content_version }));

    // RuntimeZones for those published screens
    const runtimeZonesAll = await Promise.all(
      assetPublishedScreens.map(ps => base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: ps.id }))
    );
    const runtimeZones = runtimeZonesAll.flat();
    report.runtime_zones = runtimeZones.map(rz => ({ id: rz.id, published_screen_id: rz.published_screen_id, screen_id: rz.screen_id, layout_zone_id: rz.layout_zone_id, content_source_type: rz.content_source_type, playback_item_count: rz.playback_track?.items?.length ?? 0 }));

    for (const ps of assetPublishedScreens) {
      if (ps.org_id !== org_id) {
        mismatches.push(`PublishedScreen ${ps.id} has org_id=${ps.org_id}, expected ${org_id} — cross-org mismatch`);
      }
      const zones = runtimeZonesAll[assetPublishedScreens.indexOf(ps)] || [];
      if (zones.length === 0) {
        mismatches.push(`PublishedScreen ${ps.id} (screen=${ps.screen_id}) has NO RuntimeZones`);
      } else {
        const emptyZones = zones.filter(rz => !rz.playback_track?.items?.length);
        if (emptyZones.length > 0) {
          mismatches.push(`PublishedScreen ${ps.id} has ${emptyZones.length}/${zones.length} zone(s) with empty playback_track`);
        }
      }
    }

    report.counts = {
      screens: screensByAssetId.length,
      screens_legacy_only: legacyOnlyScreens.length,
      asset_layouts: assetLayouts.length,
      schedules_total: schedules.length,
      schedules_active: activeSchedules.length,
      published_screens: assetPublishedScreens.length,
      runtime_zones: runtimeZones.length,
    };
    report.mismatches = mismatches;

    console.log('[diagnoseLiveOutputPipeline]', JSON.stringify({ org_id, asset_id, counts: report.counts, mismatches }, null, 2));

    return Response.json(report);
  } catch (error) {
    console.error('[diagnoseLiveOutputPipeline] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});