/**
 * syncToPlayerTrigger — Entity Automation Handler
 *
 * Called by entity automations when Screen, PublishedScreen, Playlist,
 * Schedule, or Asset records change. Resolves the affected screen IDs
 * and fires syncToPlayer for each one. Fire-and-forget — never blocks CMS.
 *
 * Payload shape from entity automation:
 *   { event: { type, entity_name, entity_id }, data: { ...entity fields } }
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { event, data } = body;

    console.log(`[syncToPlayerTrigger] Triggered by ${event?.entity_name} ${event?.type} id=${event?.entity_id}`);
    console.log('[syncToPlayerTrigger] DIAG', JSON.stringify({ entity_name: event?.entity_name, entity_id: event?.entity_id, event_type: event?.type }));

    const entityName = event?.entity_name;
    const entityId = event?.entity_id;
    if (!entityId) {
      return Response.json({ ok: true, skipped: 'no entity_id' });
    }

    // Resolve screen IDs from the changed entity
    let screenIds = [];

    if (entityName === 'Screen') {
      screenIds = [entityId];
    } else if (entityName === 'PublishedScreen') {
      const screenId = data?.screen_id;
      if (screenId) screenIds = [screenId];
    } else if (entityName === 'Asset') {
      // Find all screens belonging to this asset
      const screens = await base44.asServiceRole.entities.Screen.filter({ asset_id: entityId });
      screenIds = screens.map(s => s.id);
    } else if (entityName === 'Playlist') {
      // Find PublishedScreens whose schedule_ids reference playlists linked to this playlist.
      // Simplest safe approach: find schedules using this playlist, then their screens.
      // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
      // Schedule entity and Schedule.truck_id are V1. V2 should resolve screens via PublishedScreen.schedule_ids and asset_id.
      const schedules = await base44.asServiceRole.entities.Schedule.filter({ playlist_id: entityId });
      // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
      // Schedule.truck_id and Screen.truck_id are V1 fields. V2 should use asset_id linkage only.
      const truckIds = [...new Set(schedules.map(s => s.truck_id).filter(Boolean))];
      for (const tid of truckIds) {
        const screens = await base44.asServiceRole.entities.Screen.filter({ truck_id: tid });
        screenIds.push(...screens.map(s => s.id));
      }
      screenIds = [...new Set(screenIds)];
    } else if (entityName === 'Schedule') {
      // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
      // The Schedule entity and Schedule.truck_id are V1. In V2, schedule changes should
      // be resolved via asset_id directly, without the Schedule entity as intermediary.
      const truckId = data?.truck_id;
      if (truckId) {
        // truck_id doubles as asset_id in V2 — resolve screens from both fields
        // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
        // Screen.truck_id is a V1 field. Only asset_id should be used in V2.
        const [byTruck, byAsset] = await Promise.all([
          base44.asServiceRole.entities.Screen.filter({ truck_id: truckId }),
          base44.asServiceRole.entities.Screen.filter({ asset_id: truckId }),
        ]);
        screenIds = [...new Set([...byTruck, ...byAsset].map(s => s.id))];
      }
    }

    if (!screenIds.length) {
      console.log(`[syncToPlayerTrigger] No screens resolved for ${entityName} ${entityId} — skipping.`);
      return Response.json({ ok: true, synced: 0 });
    }

    console.log(`[syncToPlayerTrigger] Resolved ${screenIds.length} screen(s) to sync:`, screenIds);

    // Fire syncToPlayer for each screen — do not await all, log errors independently
    const results = await Promise.allSettled(
      screenIds.map(screenId =>
        base44.asServiceRole.functions.invoke('syncToPlayer', { screenId })
          .then(r => {
            const d = r?.data;
            if (d?.ok) {
              console.log(`[syncToPlayerTrigger] ✅ screen ${screenId} synced`);
            } else {
              console.warn(`[syncToPlayerTrigger] ⚠️ screen ${screenId} sync returned not-ok:`, d?.error);
            }
            return d;
          })
          .catch(err => {
            console.error(`[syncToPlayerTrigger] ❌ screen ${screenId} sync error:`, err.message);
            return { ok: false, error: err.message };
          })
      )
    );

    const synced = results.filter(r => r.status === 'fulfilled' && r.value?.ok).length;
    const failed = results.length - synced;
    console.log(`[syncToPlayerTrigger] Done. synced=${synced} failed=${failed}`);

    return Response.json({ ok: true, synced, failed, screenIds });

  } catch (error) {
    console.error('[syncToPlayerTrigger] Fatal error:', error.message);
    // Return 200 so automation doesn't retry in a tight loop
    return Response.json({ ok: false, error: error.message });
  }
});