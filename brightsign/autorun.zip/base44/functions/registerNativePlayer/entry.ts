import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // No user auth required — this is called from a BrightSign device
    // before any user session exists. The token itself is the credential.

    const body = await req.json();
    const { public_token } = body;

    if (!public_token) {
      return Response.json(
        { error: 'public_token is required' },
        { status: 400 }
      );
    }

    // Step 1: Find the ScreenManifest matching this token
    const manifests = await base44.asServiceRole.entities.ScreenManifest.filter({
      public_token,
    });

    if (!manifests || manifests.length === 0) {
      return Response.json(
        { error: 'Screen token not found. Check your ScreenFleet CMS Assets page.' },
        { status: 404 }
      );
    }

    const manifest = manifests[0];
    const screenId = manifest._screen_id || manifest.screen_id;

    // Step 2: Find the Screen to get the asset_id
    const screens = await base44.asServiceRole.entities.Screen.filter({
      id: screenId,
    });

    if (!screens || screens.length === 0) {
      return Response.json(
        { error: 'Screen record not found for this token.' },
        { status: 404 }
      );
    }

    const screen = screens[0];
    const assetId = screen.asset_id;

    // Step 3: Update the Asset — mark as provisioned
    if (assetId) {
      await base44.asServiceRole.entities.Asset.update(assetId, {
        native_token_provisioned_at: new Date().toISOString(),
        player_deployment_mode: 'native_install',
      });
    }

    // Step 4: Return everything the player needs to boot
    return Response.json({
      success: true,
      screen_id: screenId,
      screen_name: manifest.screen_name || screen.name,
      asset_id: assetId,
      content_version: manifest.content_version,
      payload: manifest.manifest_payload,
      registered_at: new Date().toISOString(),
    });

  } catch (error) {
    console.error('[registerNativePlayer] Error:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});