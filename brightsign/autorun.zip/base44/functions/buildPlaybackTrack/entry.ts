import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

/**
 * buildPlaybackTrack: Flatten a RoutePresentation into a fully-resolved PlaybackTrack.
 * 
 * BEHAVIOR:
 * - Each RouteSpot with multiple creatives → creatives rotate EVENLY across rotations
 * - Single creative per spot → always plays
 * - 2+ creatives → cycle sequentially, repeat indefinitely
 * 
 * Example (3 creatives, Spot#1):
 * Rotation 1 → Creative[0]
 * Rotation 2 → Creative[1]
 * Rotation 3 → Creative[2]
 * Rotation 4 → Creative[0] (loop)
 * 
 * OUTPUT: items[] where each item = {rotationIndex, spotId, creativeId, dwell, zone_assignments}
 * Player receives a flat sequence to loop through — NO runtime decision logic needed.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { route_presentation_id, num_rotations = 10 } = await req.json();
    if (!route_presentation_id) {
      return Response.json({ error: 'route_presentation_id required' }, { status: 400 });
    }

    // Fetch route presentation
    const presentation = await base44.entities.RoutePresentation.filter({ id: route_presentation_id });
    if (!presentation || presentation.length === 0) {
      return Response.json({ error: 'RoutePresentation not found' }, { status: 404 });
    }
    const rp = presentation[0];

    // Fetch all spots for this presentation
    const spots = await base44.entities.RouteSpot.filter({ route_presentation_id: rp.id });
    const spotMap = {};
    spots.forEach(s => { spotMap[s.id] = s; });

    // Fetch all creatives for all spots
    const creatives = await base44.entities.RouteCreative.filter({
      route_spot_id: { $in: spots.map(s => s.id) }
    });
    
    // Group creatives by spot, sorted by order
    const creativesPerSpot = {};
    spots.forEach(s => {
      creativesPerSpot[s.id] = creatives
        .filter(c => c.route_spot_id === s.id)
        .sort((a, b) => (a.order || 0) - (b.order || 0));
    });

    // Tier slot limits — group by rotation_offset (stable advertiser slot key)
    const TIER_SLOT_LIMITS = { impact: 1, growth: 2, launch: 4 };

    const items = [];
    for (const spot of spots) {
      const spotCreatives = creativesPerSpot[spot.id] || [];
      if (spotCreatives.length === 0) continue;

      // Group by rotation_offset only
      const slotMap = {};
      for (const c of spotCreatives) {
        const slot = c.rotation_offset ?? 0;
        if (!slotMap[slot]) slotMap[slot] = [];
        slotMap[slot].push(c);
      }

      // Sort slots numerically and enforce tier limit
      const maxSlots = TIER_SLOT_LIMITS[spot.tier] ?? 1;
      const slots = Object.keys(slotMap).map(Number).sort((a, b) => a - b).slice(0, maxSlots);
      const numSlots = slots.length;
      if (numSlots === 0) continue;

      for (let rotIdx = 0; rotIdx < num_rotations; rotIdx++) {
        const slotKey = slots[rotIdx % numSlots];
        const slotCreatives = slotMap[slotKey];
        if (!slotCreatives?.length) continue;

        const depth = Math.floor(rotIdx / numSlots);
        const creative = slotCreatives[depth % slotCreatives.length];
        if (!creative) continue;

        const dwell = creative.dwell_time_override ?? spot.dwell_time ?? rp.default_dwell_time ?? 8;

        items.push({
          rotation_index: rotIdx,
          spot_id: spot.id,
          spot_number: spot.spot_number,
          creative_id: creative.id,
          advertiser_name: creative.advertiser_name || '',
          dwell_time: dwell,
          zone_assignments: creative.zone_assignments || {},
        });
      }
    }

    console.log(`PlaybackTrack built: ${items.length} items across ${num_rotations} rotations from ${spots.length} spots`);

    return Response.json({
      route_presentation_id: rp.id,
      num_rotations,
      num_spots: spots.length,
      items,
    });
  } catch (error) {
    console.error('buildPlaybackTrack error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});