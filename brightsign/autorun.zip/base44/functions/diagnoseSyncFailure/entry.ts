/**
 * diagnoseSyncFailure — Surgical sync debugging for specific screen IDs
 * 
 * Captures:
 * 1. Exact request payload sent to Player
 * 2. Exact response status + body from Player
 * 3. screenPayload function output (what gets serialized)
 * 4. AppConfig values
 * 5. Screen/PublishedScreen/RuntimeZone state
 * 
 * POST { screen_names: ["Poster 2095 B", "P1.9 Indoor Rental"] }
 * Returns diagnostic data for each screen
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

async function fetchScreenPayload(screenId) {
  try {
    const response = await fetch('http://localhost:8000/functions/screenPayload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ screenId }),
    });
    const data = await response.json();
    return { status: response.status, body: data };
  } catch (err) {
    return { error: err.message };
  }
}

async function buildAndLogSyncRequest(base44, screenId) {
  console.log(`\n═══════════════════════════════════════`);
  console.log(`DIAGNOSTIC: Screen ID ${screenId}`);
  console.log(`═══════════════════════════════════════`);

  // 1. Get Screen
  const screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
  const screen = screens[0];
  if (!screen) return { error: `Screen ${screenId} not found` };
  console.log(`[1] SCREEN LOADED:`);
  console.log(`  - name: ${screen.name}`);
  console.log(`  - public_token: ${screen.public_token}`);
  console.log(`  - asset_id: ${screen.asset_id}`);
  console.log(`  - width: ${screen.width}, height: ${screen.height}`);
  console.log(`  - device_safe_mode: ${screen.device_safe_mode}`);
  console.log(`  - status: ${screen.status}`);

  // 2. Get PublishedScreen
  const publishedList = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screenId });
  const published = publishedList[0];
  console.log(`\n[2] PUBLISHED SCREEN:`);
  if (!published) {
    console.log(`  ERROR: No PublishedScreen found!`);
    return { screen, error: 'No PublishedScreen' };
  }
  console.log(`  - id: ${published.id}`);
  console.log(`  - content_version: ${published.content_version} (type: ${typeof published.content_version})`);
  console.log(`  - published_at: ${published.published_at}`);
  console.log(`  - zone_count: ${published.zone_count}`);

  // 3. Get RuntimeZones
  const zones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: published.id });
  console.log(`\n[3] RUNTIME ZONES: ${zones.length} zones`);
  for (let i = 0; i < zones.length; i++) {
    const z = zones[i];
    const itemCount = z.playback_track?.items?.length || 0;
    console.log(`  Zone ${i}: "${z.name}" (${z.width}×${z.height} @ ${z.x},${z.y}) - ${itemCount} items`);
    if (itemCount > 0) {
      const item = z.playback_track.items[0];
      console.log(`    Item[0] keys: ${Object.keys(item).join(', ')}`);
      console.log(`    Item[0] file_url: ${item.file_url || 'MISSING'}`);
      console.log(`    Item[0] file_type: ${item.file_type || 'MISSING'}`);
    }
  }

  // 4. Get AppConfig
  const configs = await base44.asServiceRole.entities.AppConfig.list();
  const appConfig = configs[0];
  console.log(`\n[4] APP CONFIG:`);
  console.log(`  - player_app_origin: ${appConfig?.player_app_origin || 'MISSING'}`);
  console.log(`  - default_device_safe_mode: ${appConfig?.default_device_safe_mode}`);

  // 5. Build the exact payload that syncToPlayer would send
  const contentVersionIso = published.content_version || new Date().toISOString();
  const contentVersion = new Date(contentVersionIso).getTime();
  const deviceSafeMode = screen.device_safe_mode ?? appConfig?.default_device_safe_mode ?? false;

  const syncPayload = {
    public_token: screen.public_token,
    device_safe_mode: deviceSafeMode,
    cms_screen_id: screenId,
    resolution_width: screen.width,
    resolution_height: screen.height,
    screen_id: screenId,
    screen_width: screen.width,
    screen_height: screen.height,
    screen_name: screen.name,
    screen_position: screen.position,
    screen_mode: screen.screen_mode,
    content_version: contentVersion,
    content_version_iso: contentVersionIso,
    published_at: published.published_at,
    zones: zones.sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1)).map(z => ({
      id: z.id,
      layout_zone_id: z.layout_zone_id,
      name: z.name,
      x: z.x ?? 0,
      y: z.y ?? 0,
      width: z.width,
      height: z.height,
      z_index: z.z_index ?? 1,
      fit_mode: z.fit_mode || 'contain',
      background_color: z.background_color || '#000000',
      volume: z.volume ?? 100,
      content_source_type: z.content_source_type || 'empty',
      canvas_creative_data: z.canvas_creative_data || null,
      playback_track: {
        loop: z.playback_track?.loop ?? true,
        items: (z.playback_track?.items || []).map(item => ({
          ...item,
          url: item.file_url || item.url || null,
          type: item.file_type || item.type || null,
        })),
      },
    })),
    synced_at: new Date().toISOString(),
  };

  console.log(`\n[5] SYNC PAYLOAD TO PLAYER:`);
  console.log(`  - public_token: ${syncPayload.public_token}`);
  console.log(`  - content_version: ${syncPayload.content_version} (ISO: ${syncPayload.content_version_iso})`);
  console.log(`  - device_safe_mode: ${syncPayload.device_safe_mode}`);
  console.log(`  - zones count: ${syncPayload.zones.length}`);
  console.log(`  - payload size (JSON): ~${JSON.stringify(syncPayload).length} bytes`);

  // 6. Simulate the Player API call
  const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '');
  const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');
  const syncUrl = `${playerOrigin}/functions/syncScreenData`;

  console.log(`\n[6] PLAYER API CALL:`);
  console.log(`  - URL: ${syncUrl}`);
  console.log(`  - Method: POST`);
  console.log(`  - Secret set: ${!!syncSecret}`);

  if (!playerOrigin || !syncSecret) {
    console.log(`  ERROR: Missing playerOrigin or PLAYER_SYNC_SECRET`);
    return { screen, published, syncPayload, error: 'Missing config' };
  }

  // 7. Attempt the sync
  console.log(`\n[7] SENDING SYNC REQUEST...`);
  let playerResponse = null;
  try {
    const response = await fetch(syncUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-sync-secret': syncSecret,
      },
      body: JSON.stringify({ action: 'upsert', screen_data: syncPayload }),
    });
    playerResponse = {
      status: response.status,
      statusText: response.statusText,
      body: await response.json().catch(() => ({})),
    };
  } catch (err) {
    playerResponse = { error: err.message };
  }

  console.log(`\n[8] PLAYER RESPONSE:`);
  console.log(`  - Status: ${playerResponse.status || 'ERROR'}`);
  console.log(`  - Body:`, JSON.stringify(playerResponse.body || playerResponse.error, null, 2));

  return {
    screen,
    published,
    zones,
    appConfig,
    syncPayload,
    playerResponse,
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const body = await req.json();
    const screenNames = body.screen_names || [];

    // Find screen IDs by name
    const allScreens = await base44.asServiceRole.entities.Screen.list();
    const results = {};

    for (const name of screenNames) {
      const screen = allScreens.find(s => s.name === name);
      if (!screen) {
        results[name] = { error: `Screen "${name}" not found` };
        continue;
      }

      const diag = await buildAndLogSyncRequest(base44, screen.id);
      results[name] = diag;
    }

    return Response.json({ diagnostics: results }, { status: 200 });
  } catch (error) {
    console.error('[diagnoseSyncFailure] Fatal:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});