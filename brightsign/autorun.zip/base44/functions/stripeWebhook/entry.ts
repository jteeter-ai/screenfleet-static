import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import Stripe from 'npm:stripe@17.0.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const body = await req.text();
    const signature = req.headers.get('stripe-signature');

    // Construct Stripe event with signature verification
    const event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
    
    // Now authenticate with Base44 after signature validation
    const base44 = createClientFromRequest(req);

    // Handle subscription events
    if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.created') {
      const subscription = event.data.object;
      
      // Find org by Stripe customer ID
      const orgs = await base44.asServiceRole.entities.Organization.filter({ 
        stripe_customer_id: subscription.customer 
      });
      
      if (orgs.length > 0) {
        const org = orgs[0];
        const status = subscription.status === 'active' ? 'active' : 
                      subscription.status === 'past_due' ? 'past_due' : 
                      subscription.status === 'trialing' ? 'trialing' : 'unpaid';
        
        await base44.asServiceRole.entities.Organization.update(org.id, {
          stripe_subscription_id: subscription.id,
          subscription_status: status,
          plan_expires_at: new Date(subscription.current_period_end * 1000).toISOString()
        });
      }
    }

    if (event.type === 'customer.subscription.deleted') {
      const subscription = event.data.object;
      
      const orgs = await base44.asServiceRole.entities.Organization.filter({ 
        stripe_customer_id: subscription.customer 
      });
      
      if (orgs.length > 0) {
        await base44.asServiceRole.entities.Organization.update(orgs[0].id, {
          subscription_status: 'canceled',
          stripe_subscription_id: null
        });
      }
    }

    if (event.type === 'invoice.payment_failed') {
      const invoice = event.data.object;
      
      const orgs = await base44.asServiceRole.entities.Organization.filter({ 
        stripe_customer_id: invoice.customer 
      });
      
      if (orgs.length > 0) {
        await base44.asServiceRole.entities.Organization.update(orgs[0].id, {
          subscription_status: 'past_due'
        });
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 400 });
  }
});