import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const VALID_PLATFORM_ROLES = [
  'platform_owner',
  'platform_admin',
  'platform_developer',
  'platform_accounting',
];

const ADMIN_ONLY_ROLES = ['platform_owner'];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // SECURITY: Only platform_owner and platform_admin can manage platform users
    const isPlatformOwner = user.role === 'platform_owner';
    const isPlatformAdmin = user.role === 'platform_admin';

    if (!isPlatformOwner && !isPlatformAdmin) {
      return Response.json(
        { error: 'Forbidden: Only platform owners and admins can manage platform users' },
        { status: 403 }
      );
    }

    const { action, email, role, userId } = await req.json();

    // ── INVITE ──────────────────────────────────────────────────────────────
    if (action === 'invite') {
      if (!email || !role) {
        return Response.json(
          { error: 'Missing required fields: email, role' },
          { status: 400 }
        );
      }

      if (!VALID_PLATFORM_ROLES.includes(role)) {
        return Response.json(
          { error: `Invalid role: ${role}` },
          { status: 400 }
        );
      }

      // SECURITY: platform_admin cannot assign platform_owner
      if (!isPlatformOwner && ADMIN_ONLY_ROLES.includes(role)) {
        return Response.json(
          { error: 'Forbidden: Only platform owners can assign platform_owner role' },
          { status: 403 }
        );
      }

      try {
        await base44.users.inviteUser(email, 'admin');
        base44.asServiceRole.entities.AuditLog.create({
          org_id: null,
          actor_email: user.email,
          action: 'platform_user_modified',
          target_type: 'user',
          target_id: email,
          details: `Platform user invited: "${email}" as "${role}"`,
        }).catch(() => {});
        return Response.json({ success: true, message: `Invited ${email} as ${role}` });
      } catch (error) {
        return Response.json(
          { error: error.message || 'Failed to invite user' },
          { status: 500 }
        );
      }
    }

    // ── EDIT ─────────────────────────────────────────────────────────────────
    if (action === 'edit') {
      if (!userId || !role) {
        return Response.json(
          { error: 'Missing required fields: userId, role' },
          { status: 400 }
        );
      }

      if (!VALID_PLATFORM_ROLES.includes(role)) {
        return Response.json(
          { error: `Invalid role: ${role}` },
          { status: 400 }
        );
      }

      // SECURITY: platform_admin cannot promote to platform_owner
      if (!isPlatformOwner && role === 'platform_owner') {
        return Response.json(
          { error: 'Forbidden: Only platform owners can assign platform_owner role' },
          { status: 403 }
        );
      }

      // SECURITY: prevent removing last platform_owner
      if (role !== 'platform_owner') {
        const allUsers = await base44.asServiceRole.entities.User.list();
        const platformOwners = allUsers.filter((u) => u.role === 'platform_owner' && u.id !== userId);
        if (platformOwners.length === 0) {
          return Response.json(
            { error: 'Cannot remove the last platform owner' },
            { status: 403 }
          );
        }
      }

      try {
        await base44.asServiceRole.entities.User.update(userId, { role });
        base44.asServiceRole.entities.AuditLog.create({
          org_id: null,
          actor_email: user.email,
          action: 'platform_user_modified',
          target_type: 'user',
          target_id: userId,
          details: `Platform user role changed to "${role}" by "${user.email}"`,
        }).catch(() => {});
        return Response.json({ success: true, message: `Updated user role to ${role}` });
      } catch (error) {
        return Response.json(
          { error: error.message || 'Failed to update role' },
          { status: 500 }
        );
      }
    }

    // ── REMOVE ───────────────────────────────────────────────────────────────
    if (action === 'remove') {
      if (!userId) {
        return Response.json(
          { error: 'Missing required field: userId' },
          { status: 400 }
        );
      }

      // SECURITY: prevent removing the last platform_owner
      const targetUser = await base44.asServiceRole.entities.User.filter({ id: userId });
      if (targetUser.length > 0 && targetUser[0].role === 'platform_owner') {
        const allUsers = await base44.asServiceRole.entities.User.list();
        const platformOwners = allUsers.filter((u) => u.role === 'platform_owner');
        if (platformOwners.length === 1) {
          return Response.json(
            { error: 'Cannot remove the last platform owner' },
            { status: 403 }
          );
        }
      }

      try {
        // Remove platform role by resetting to 'user'
        await base44.asServiceRole.entities.User.update(userId, { role: 'user' });
        base44.asServiceRole.entities.AuditLog.create({
          org_id: null,
          actor_email: user.email,
          action: 'platform_user_modified',
          target_type: 'user',
          target_id: userId,
          details: `Platform user removed (role reset to "user") by "${user.email}"`,
        }).catch(() => {});
        return Response.json({ success: true, message: 'Platform user removed' });
      } catch (error) {
        return Response.json(
          { error: error.message || 'Failed to remove user' },
          { status: 500 }
        );
      }
    }

    return Response.json(
      { error: 'Invalid action' },
      { status: 400 }
    );
  } catch (error) {
    return Response.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
});