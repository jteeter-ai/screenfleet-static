/**
 * repairScreenIntegrity — Enhanced version with lifecycle awareness
 *
 * Finds and safely removes:
 * 1. AssetLayout records pointing to non-existent/archived screens
 * 2. PublishedScreen records pointing to non-existent/archived screens
 * 3. RuntimeZone records pointing to non-existent PublishedScreens
 * 4. Player-side ghost rows for deleted tokens
 *
 * Call with { dryRun: true } to preview without deleting.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun !== false;

    const config = (await base44.asServiceRole.entities.AppConfig.list())[0];
    const playerOrigin = config?.player_app_origin?.replace(/\/$/, '');
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');

    // ── Load active screens (archived/deleted are not canonical) ─────────────────
    const allScreens = await base44.asServiceRole.entities.Screen.list();
    const activeScreenIds = new Set(
      allScreens
        .filter((s) => s.status === 'active')
        .map((s) => s.id)
    );
    console.log(`[repairScreenIntegrity] Active screens: ${activeScreenIds.size}`);

    // ── Orphaned AssetLayout ───────────────────────────────────────────────────
    const allAssetLayouts = await base44.asServiceRole.entities.AssetLayout.list();
    const orphanedAssetLayouts = allAssetLayouts.filter(
      (al) => al.screen_id && !activeScreenIds.has(al.screen_id)
    );

    // ── Orphaned PublishedScreen ───────────────────────────────────────────────
    const allPublished = await base44.asServiceRole.entities.PublishedScreen.list();
    const orphanedPublished = allPublished.filter(
      (ps) => ps.screen_id && !activeScreenIds.has(ps.screen_id)
    );

    // ── Orphaned RuntimeZone ───────────────────────────────────────────────────
    const publishedIds = new Set(allPublished.map((p) => p.id));
    const allRuntimeZones = await base44.asServiceRole.entities.RuntimeZone.list();
    const orphanedRuntimeZones = allRuntimeZones.filter(
      (rz) => rz.published_screen_id && !publishedIds.has(rz.published_screen_id)
    );

    // ── Execute cleanup (if not dry run) ───────────────────────────────────────
    const deletedAssetLayouts = [];
    const deletedPublished = [];
    const deletedRuntimeZones = [];

    if (!dryRun) {
      for (const al of orphanedAssetLayouts) {
        await base44.asServiceRole.entities.AssetLayout.delete(al.id);
        deletedAssetLayouts.push(al.id);
        console.log(
          `[repairScreenIntegrity] Deleted orphaned AssetLayout ${al.id}`
        );
      }
      for (const ps of orphanedPublished) {
        await base44.asServiceRole.entities.PublishedScreen.delete(ps.id);
        deletedPublished.push(ps.id);
        console.log(
          `[repairScreenIntegrity] Deleted orphaned PublishedScreen ${ps.id}`
        );
      }
      for (const rz of orphanedRuntimeZones) {
        await base44.asServiceRole.entities.RuntimeZone.delete(rz.id);
        deletedRuntimeZones.push(rz.id);
        console.log(
          `[repairScreenIntegrity] Deleted orphaned RuntimeZone ${rz.id}`
        );
      }
    }

    return Response.json({
      dry_run: dryRun,
      summary: {
        active_screens: activeScreenIds.size,
        orphaned_asset_layouts: orphanedAssetLayouts.length,
        orphaned_published_screens: orphanedPublished.length,
        orphaned_runtime_zones: orphanedRuntimeZones.length,
      },
      orphaned_asset_layouts: orphanedAssetLayouts.map((al) => ({
        id: al.id,
        asset_id: al.asset_id,
        dead_screen_id: al.screen_id,
      })),
      orphaned_published_screens: orphanedPublished.map((ps) => ({
        id: ps.id,
        asset_id: ps.asset_id,
        dead_screen_id: ps.screen_id,
        published_at: ps.published_at,
      })),
      orphaned_runtime_zones: orphanedRuntimeZones.map((rz) => ({
        id: rz.id,
        dead_published_screen_id: rz.published_screen_id,
      })),
      deleted_asset_layout_ids: deletedAssetLayouts,
      deleted_published_screen_ids: deletedPublished,
      deleted_runtime_zone_ids: deletedRuntimeZones,
    });
  } catch (error) {
    console.error('[repairScreenIntegrity] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});