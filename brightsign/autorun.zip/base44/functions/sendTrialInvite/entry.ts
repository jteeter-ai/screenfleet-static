import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { email } = await req.json();

    if (!email) {
      return Response.json({ error: 'Email is required' }, { status: 400 });
    }

    const appUrl = new URL(req.url).origin;
    const trialSignupUrl = `${appUrl}/auth/signup?trial=true&email=${encodeURIComponent(email)}`;

    // Send trial invitation email
    const emailBody = `
<h2>Start Your Free 30-Day Trial!</h2>
<p>Hello,</p>
<p>You're invited to try ScreenFleet for free! Get full access to manage your advertising assets and content scheduling without any credit card required.</p>
<h3>What You Get:</h3>
<ul>
  <li>Full 30-day free trial access</li>
  <li>3 advertising assets (trucks/displays)</li>
  <li>3 team member accounts</li>
  <li>Complete scheduling and content management</li>
  <li>No credit card needed to start</li>
</ul>
<h3>Get Started:</h3>
<p><a href="${trialSignupUrl}" style="display: inline-block; padding: 10px 20px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px;">Start Free Trial</a></p>
<p style="margin-top: 20px; font-size: 12px; color: #666;">
  If the button doesn't work, copy and paste this link: ${trialSignupUrl}
</p>
<p>Questions? Reach out to our support team.</p>
<p>Best regards,<br>ScreenFleet Team</p>
    `;

    await base44.integrations.Core.SendEmail({
      to: email,
      subject: 'Start Your Free 30-Day ScreenFleet Trial',
      body: emailBody,
      from_name: 'ScreenFleet'
    });

    return Response.json({ success: true, signupUrl: trialSignupUrl });
  } catch (error) {
    console.error('Error sending trial invite:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});