import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

/**
 * Centralized screen payload resolution for player runtime
 * Returns fully resolved screen data including zones, content, version
 * Used by hardware players (BrightSign, kiosks) and browser previews
 * Implements intentional caching strategy and offline fallback support
 */
Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const { screenId } = body;

    if (!screenId) {
      return Response.json({ error: 'screenId required' }, { status: 400 });
    }

    let base44;
    try {
      base44 = createClientFromRequest(req);
    } catch (e) {
      console.error('Failed to create client from request:', e.message);
      return Response.json({ error: 'Failed to initialize app context', detail: e.message }, { status: 500 });
    }
    
    // Use service role to bypass auth for hardware players
    let screens;
    try {
      screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
    } catch (e) {
      console.error('Failed to fetch screen:', e.message);
      return Response.json({ error: 'Failed to fetch screen data', detail: e.message }, { status: 500 });
    }
    
    const screen = screens[0];
    
    if (!screen) {
      return Response.json({ error: 'Screen not found', screenId }, { status: 404 });
    }

    // Step 3: Fetch ONLY runtime zones (zone_scope="runtime") for this screen
    // CRITICAL: Never return template zones to the player
    let zones;
    try {
      zones = await base44.asServiceRole.entities.Zone.filter({ 
        screen_id: screenId,
        zone_scope: "runtime"
      });
    } catch (e) {
      console.error('Failed to fetch zones:', e.message);
      zones = []; // Graceful fallback: return screen with no zones
    }

    // Build resolved payload
    const payload = {
      screen: {
        id: screen.id,
        name: screen.name,
        truck_id: screen.truck_id,
        width: screen.width,
        height: screen.height,
        status: screen.status,
        content_version: screen.content_version || screen.last_published_at || screen.updated_date,
      },
      zones: zones.map(z => ({
        id: z.id,
        template_zone_id: z.template_zone_id,
        name: z.name,
        x: z.x || 0,
        y: z.y || 0,
        width: z.width,
        height: z.height,
        z_index: z.z_index || 1,
        content_type: z.content_type || 'empty',
        playlist_id: z.playlist_id,
        rotation_id: z.rotation_id,
        media_url: z.media_url,
        media_file_type: z.media_file_type,
        html_url: z.html_url,
        volume: z.volume ?? 100,
        fit_mode: z.fit_mode || 'fill',
        background_color: z.background_color || '#000000',
        is_visible: z.is_visible !== false,
      })),
      version: screen.content_version || screen.last_published_at || screen.updated_date,
      fetched_at: new Date().toISOString(),
    };

    return Response.json(payload);
  } catch (error) {
    console.error('getScreenPayload error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});