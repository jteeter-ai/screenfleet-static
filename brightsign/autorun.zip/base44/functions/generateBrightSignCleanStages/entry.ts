/**
 * V2 BrightSign Clean Stage Generator
 * DEBUG ONLY — NOT FOR OPERATOR USE — XT1145 HDMI TESTING
 *
 * This function generates STAGED DEBUG packages for HDMI input isolation testing.
 * It is NOT the production deployment generator.
 * For operator-facing production packages, use generateBrightSignFiles instead.
 * These two generators must remain strictly separated:
 *   - generateBrightSignCleanStages → XT1145 debug testing / admin only
 *   - generateBrightSignFiles        → production operators
 *
 * Access is restricted in the UI to:
 *   - asset.name === "XT1145 Spare"  (test hardware)
 *   - user.role === "admin"          (platform admin override)
 *
 * STAGE GROUPS (in order of testing progression):
 *   GROUP A — JS Bridge validation (stages: clone_label_only, bridge_probe,
 *             window_postmessage_send, window_postmessage_receive, window_postmessage_ack)
 *   GROUP B — HDMI parse/object creation (stages: hdmi_parse_only, hdmi_objects_only,
 *             hdmi_videoinput_only, hdmi_videoplayer_only)
 *   GROUP C — HDMI playback pipeline (stages: hdmi_playfile_only,
 *             hdmi_playfile_with_rect, hdmi_final_binding_test, hdmi_setport_test)
 *   GROUP D — Future/blocked (stages: bs_receive_log, bs_ack, hdmi_objects, hdmi_full)
 *
 * NOTE ON FILE SPLITTING: Deno backend functions are deployed independently.
 * Local imports between function files are NOT supported (Module not found error).
 * All stage logic must remain in this single file. Organize by STAGE GROUPS above.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';
import { ZipWriter, BlobWriter, TextReader } from 'npm:@zip.js/zip.js@2.7.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { assetId, stage = 'stage3_clone_label_only' } = body;

    const VALID_STAGES = [
      'stage3_clone_label_only',
      'stage3_js_send_only',
      'stage3_bridge_probe',
      'stage3_window_postmessage_send',
      'stage3_window_postmessage_receive',
      'stage3_window_postmessage_ack',
      'stage3_hdmi_parse_only',
      'stage3_hdmi_objects_only',
      'stage3_hdmi_videoinput_only',
      'stage3_hdmi_videoplayer_only',
      'stage3_hdmi_playfile_only',
      'stage3_hdmi_playfile_with_rect',
      'stage3_hdmi_final_binding_test',
      'stage3_hdmi_setport_test',
      'stage3_bs_receive_log',
      'stage3_bs_ack',
      'stage3_hdmi_objects',
      'stage3_hdmi_full',
    ];

    if (!VALID_STAGES.includes(stage)) {
      return Response.json({
        error: `Invalid stage key: "${stage}". Must be one of: ${VALID_STAGES.join(', ')}`,
        received_stage: stage,
        valid_stages: VALID_STAGES,
      }, { status: 400 });
    }

    if (!assetId) {
      return Response.json({ error: 'Missing required field: assetId' }, { status: 400 });
    }

    const assets = await base44.asServiceRole.entities.Asset.filter({ id: assetId });
    const asset = assets[0];
    if (!asset) return Response.json({ error: `Asset not found: ${assetId}` }, { status: 404 });

    let screens = await base44.asServiceRole.entities.Screen.filter({ asset_id: assetId });
    if (!screens.length) return Response.json({ error: 'No screens configured for this asset' }, { status: 400 });

    screens = screens.sort((a, b) => {
      const yDiff = (a.start_y || 0) - (b.start_y || 0);
      if (yDiff !== 0) return yDiff;
      const xDiff = (a.start_x || 0) - (b.start_x || 0);
      if (xDiff !== 0) return xDiff;
      return (a.created_date || '').localeCompare(b.created_date || '');
    });

    const primaryScreen = screens[0];
    const screenWidth = primaryScreen.width || 1920;
    const screenHeight = primaryScreen.height || 1080;

    const configs = await base44.asServiceRole.entities.AppConfig.list().catch(() => []);
    const appConfig = configs[0];
    const apiOrigin = appConfig?.public_app_origin || 'https://app.screenfleet.io';

    const stageIndex = VALID_STAGES.indexOf(stage);

    const configJson = JSON.stringify({
      screenId: primaryScreen.id,
      screenName: primaryScreen.name,
      screenWidth,
      screenHeight,
      assetId,
      assetName: asset.name,
      apiOrigin,
      versionCheckFn: 'screenVersionCheck',
      payloadFn: 'screenPayload',
      pollIntervalMs: 60000,
      generatedAt: new Date().toISOString(),
      debugStage: stage,
      debugStageIndex: stageIndex,
    }, null, 2);

    // ── autorun.brs templates ─────────────────────────────────────────────────

    // Stage: stage3_hdmi_setport_test
    // ADDITION vs stage3_hdmi_final_binding_test: videoPlayer.SetPort(msgPort)
    // Documented BrightScript: roVideoPlayer requires SetPort before playback
    // so its internal state machine can drive the display pipeline.
    //
    // FULL SEQUENCE UNDER TEST:
    //   1. CreateObject("roVideoInput")
    //   2. videoInput.SetHDMIInput(0)
    //   3. CreateObject("roVideoPlayer")
    //   4. videoPlayer.SetPort(msgPort)   <-- ADDITION
    //   5. videoPlayer.SetRectangle(rect)
    //   6. videoPlayer.SetVideoZOrder(1)
    //   7. videoPlayer.PlayFile(videoInput)
    const autorunHdmiSetPortTest = `' ScreenFleet V2 — Stage: stage3_hdmi_setport_test
' ADDITION vs stage3_hdmi_final_binding_test: videoPlayer.SetPort(msgPort) before PlayFile
' BrightScript API: roVideoPlayer requires SetPort so its state machine drives display pipeline.
'
' FULL SEQUENCE:
'   1. CreateObject(roVideoInput)
'   2. videoInput.SetHDMIInput(0)
'   3. CreateObject(roVideoPlayer)
'   4. videoPlayer.SetPort(msgPort)   <-- NEW
'   5. videoPlayer.SetRectangle(rect)
'   6. videoPlayer.SetVideoZOrder(1)
'   7. videoPlayer.PlayFile(videoInput)

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_setport_test ══"
    Print "[SF] ADDITION: videoPlayer.SetPort(msgPort) before PlayFile"
    Print "[SF] Full sequence: SetHDMIInput + SetPort + SetRect + ZOrder + PlayFile"

    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    Print "[SF] roHtmlWidget shown. Waiting for SF_HDMI_ZONES..."

    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            Print "[SF-HDMI] ✓ SF_HDMI_ZONES received — executing full sequence..."
                            videoInput = CreateObject("roVideoInput")
                            If videoInput = Invalid Then
                                Print "[SF-HDMI] ✗ roVideoInput FAILED — aborting"
                            Else
                                Print "[SF-HDMI] ✓ Step 1: roVideoInput created"
                                bindResult = videoInput.SetHDMIInput(0)
                                Print "[SF-HDMI] ✓ Step 2: SetHDMIInput(0) = " + Str(bindResult)
                                videoPlayer = CreateObject("roVideoPlayer")
                                If videoPlayer = Invalid Then
                                    Print "[SF-HDMI] ✗ roVideoPlayer FAILED — aborting"
                                Else
                                    Print "[SF-HDMI] ✓ Step 3: roVideoPlayer created"
                                    videoPlayer.SetPort(msgPort)
                                    Print "[SF-HDMI] ✓ Step 4: videoPlayer.SetPort(msgPort) done"
                                    videoRect = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
                                    videoPlayer.SetRectangle(videoRect)
                                    Print "[SF-HDMI] ✓ Step 5: SetRectangle done"
                                    videoPlayer.SetVideoZOrder(1)
                                    Print "[SF-HDMI] ✓ Step 6: SetVideoZOrder(1) done"
                                    Print "[SF-HDMI] Starting 10s countdown..."
                                    For i = 10 To 1 Step -1
                                        Print "[SF-HDMI] Playback start in " + Str(i) + "..."
                                        Sleep(1000)
                                    Next i
                                    Print "[SF-HDMI] Step 7: PlayFile(videoInput)"
                                    result = videoPlayer.PlayFile(videoInput)
                                    Print "[SF-HDMI] PlayFile returned: " + Str(result)
                                    Sleep(3000)
                                    Print "[SF-HDMI] ✓ Still alive 3s after PlayFile"
                                    Sleep(7000)
                                    Print "[SF-HDMI] ✓ Still alive 10s after PlayFile"
                                    Sleep(10000)
                                    Print "[SF-HDMI] ✓ Still alive 20s after PlayFile"
                                    Print "[SF-HDMI] Sequence complete. Entering idle loop."
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunHdmiFinalBindingTest = `' ScreenFleet V2 — Stage: stage3_hdmi_final_binding_test
' SINGLE ADDITION vs stage3_hdmi_playfile_with_rect:
'   videoInput.SetHDMIInput(0)  <- binds roVideoInput to physical HDMI In port 0

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_final_binding_test ══"
    Print "[SF] SINGLE TEST: videoInput.SetHDMIInput(0) before SetRectangle+PlayFile"

    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    Print "[SF] roHtmlWidget shown. Waiting for SF_HDMI_ZONES..."

    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            Print "[SF-HDMI] ✓ SF_HDMI_ZONES received — creating objects..."
                            videoInput = CreateObject("roVideoInput")
                            If videoInput = Invalid Then
                                Print "[SF-HDMI] ✗ roVideoInput FAILED — aborting"
                            Else
                                Print "[SF-HDMI] ✓ roVideoInput created"
                                videoPlayer = CreateObject("roVideoPlayer")
                                If videoPlayer = Invalid Then
                                    Print "[SF-HDMI] ✗ roVideoPlayer FAILED — aborting"
                                Else
                                    Print "[SF-HDMI] ✓ roVideoPlayer created"
                                    Print "[SF-HDMI] >>> Calling videoInput.SetHDMIInput(0)"
                                    bindResult = videoInput.SetHDMIInput(0)
                                    Print "[SF-HDMI] SetHDMIInput(0) returned: " + Str(bindResult)
                                    videoRect = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
                                    videoPlayer.SetRectangle(videoRect)
                                    videoPlayer.SetVideoZOrder(1)
                                    For i = 10 To 1 Step -1
                                        Print "[SF-HDMI] Playback start in " + Str(i) + "..."
                                        Sleep(1000)
                                    Next i
                                    Print "[SF-HDMI] >>> Calling PlayFile(roVideoInput)..."
                                    result = videoPlayer.PlayFile(videoInput)
                                    Print "[SF-HDMI] PlayFile returned: " + Str(result)
                                    Sleep(3000)
                                    Print "[SF-HDMI] ✓ Still alive 3s after PlayFile"
                                    Sleep(7000)
                                    Print "[SF-HDMI] ✓ Still alive 10s after PlayFile"
                                    Sleep(10000)
                                    Print "[SF-HDMI] ✓ Still alive 20s after PlayFile"
                                    Print "[SF-HDMI] Instrumentation complete. Entering idle loop."
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunHdmiPlayfileWithRect = `' ScreenFleet V2 — Stage: stage3_hdmi_playfile_with_rect

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_playfile_with_rect ══"

    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()

    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            videoInput = CreateObject("roVideoInput")
                            If videoInput <> Invalid Then
                                videoPlayer = CreateObject("roVideoPlayer")
                                If videoPlayer <> Invalid Then
                                    videoRect = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
                                    videoPlayer.SetRectangle(videoRect)
                                    videoPlayer.SetVideoZOrder(1)
                                    For i = 10 To 1 Step -1
                                        Print "[SF-HDMI] Playback start in " + Str(i) + "..."
                                        Sleep(1000)
                                    Next i
                                    result = videoPlayer.PlayFile(videoInput)
                                    Print "[SF-HDMI] PlayFile returned: " + Str(result)
                                    Sleep(3000)
                                    Print "[SF-HDMI] ✓ Still alive 3s after PlayFile"
                                    Sleep(7000)
                                    Print "[SF-HDMI] ✓ Still alive 10s after PlayFile"
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunHdmiPlayfileOnly = `' ScreenFleet V2 — Stage: stage3_hdmi_playfile_only

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_playfile_only ══"

    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()

    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            videoInput = CreateObject("roVideoInput")
                            If videoInput <> Invalid Then
                                videoPlayer = CreateObject("roVideoPlayer")
                                If videoPlayer <> Invalid Then
                                    For i = 10 To 1 Step -1
                                        Sleep(1000)
                                    Next i
                                    result = videoPlayer.PlayFile(videoInput)
                                    Print "[SF-HDMI] PlayFile returned: " + Str(result)
                                    Sleep(3000)
                                    Print "[SF-HDMI] ✓ Still alive 3s after PlayFile"
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunHdmiVideoInputOnly = `' ScreenFleet V2 — Stage: stage3_hdmi_videoinput_only

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_videoinput_only ══"
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            videoInput = CreateObject("roVideoInput")
                            If videoInput = Invalid Then
                                Print "[SF-HDMI] ✗ roVideoInput FAILED"
                            Else
                                Print "[SF-HDMI] ✓ roVideoInput created — no roVideoPlayer"
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunHdmiVideoPlayerOnly = `' ScreenFleet V2 — Stage: stage3_hdmi_videoplayer_only

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_videoplayer_only ══"
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            videoPlayer = CreateObject("roVideoPlayer")
                            If videoPlayer = Invalid Then
                                Print "[SF-HDMI] ✗ roVideoPlayer FAILED"
                            Else
                                Print "[SF-HDMI] ✓ roVideoPlayer created — no roVideoInput"
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunHdmiObjectsOnly = `' ScreenFleet V2 — Stage: stage3_hdmi_objects_only

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_objects_only ══"
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            videoInput = CreateObject("roVideoInput")
                            If videoInput <> Invalid Then Print "[SF-HDMI] ✓ roVideoInput created"
                            videoPlayer = CreateObject("roVideoPlayer")
                            If videoPlayer <> Invalid Then Print "[SF-HDMI] ✓ roVideoPlayer created — NO playback"
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunHdmiParseOnly = `' ScreenFleet V2 — Stage: stage3_hdmi_parse_only

Sub Main()
    Print "[SF] ══ Stage: stage3_hdmi_parse_only ══"
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            Print "[SF-HDMI] ✓ SF_HDMI_ZONES received — parse only"
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunWindowPostMessageReceive = `' ScreenFleet V2 — Stage: stage3_window_postmessage_receive

Sub Main()
    Print "[SF] ══ Stage: stage3_window_postmessage_receive ══"
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_TEST" Then
                            Print "[SF-BRIDGE] ✓ SF_TEST received — RECEIVE-ONLY, no ACK"
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunWindowPostMessageAck = `' ScreenFleet V2 — Stage: stage3_window_postmessage_ack

Sub Main()
    Print "[SF] ══ Stage: stage3_window_postmessage_ack ══"
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_TEST" Then
                            Print "[SF-BRIDGE] ✓ SF_TEST received — sending SF_ACK"
                            h.PostMessage({ type: "SF_ACK", received: "SF_TEST" })
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunGeneric = `' ScreenFleet V2 — Clean Stage: ${stage} (index ${stageIndex})

Sub Main()
    Print "[SF] ══ Clean Stage ${stageIndex}: ${stage} ══"
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" And payload.reason = "message" Then
                If Type(payload.message) = "roAssociativeArray" Then
                    Print "[SF-MSG] Received: " + payload.message.type
                End If
            End If
        End If
    End While
End Sub
`;

    const autorunBrs = stage === 'stage3_hdmi_setport_test' ? autorunHdmiSetPortTest
      : stage === 'stage3_hdmi_final_binding_test' ? autorunHdmiFinalBindingTest
      : stage === 'stage3_hdmi_playfile_with_rect' ? autorunHdmiPlayfileWithRect
      : stage === 'stage3_hdmi_playfile_only' ? autorunHdmiPlayfileOnly
      : stage === 'stage3_hdmi_videoinput_only' ? autorunHdmiVideoInputOnly
      : stage === 'stage3_hdmi_videoplayer_only' ? autorunHdmiVideoPlayerOnly
      : stage === 'stage3_hdmi_objects_only' ? autorunHdmiObjectsOnly
      : stage === 'stage3_hdmi_parse_only' ? autorunHdmiParseOnly
      : stage === 'stage3_window_postmessage_ack' ? autorunWindowPostMessageAck
      : stage === 'stage3_window_postmessage_receive' ? autorunWindowPostMessageReceive
      : autorunGeneric;

    // ── player.js helpers ─────────────────────────────────────────────────────

    // Shared player.js builder for all HDMI countdown stages
    function makeHdmiCountdownPlayerJs(stageKey, borderColor, bgColor, stageLabel, extraStatusLines) {
      return `// ScreenFleet V2 — Stage: ${stageKey}
window.__SF_CLEAN_STAGE__ = '${stageKey}';
console.log('[SF] ${stageKey}: script parsed at ' + new Date().toISOString());
var SCREEN_W = ${screenWidth};
var SCREEN_H = ${screenHeight};
var heartbeatCount = 0;
setInterval(function() {
  heartbeatCount++;
  var el = document.getElementById('sf-heartbeat');
  if (el) { el.textContent = 'HTML alive: ' + heartbeatCount; el.style.color = (heartbeatCount % 2 === 0) ? '#ffff00' : '#ff8800'; }
  console.log('[SF-HEARTBEAT] tick ' + heartbeatCount);
}, 1000);
function appendStatus(msg, color) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  line.style.cssText = 'font:bold 22px monospace;margin:4px 0;color:' + (color || '#00ff00') + ';';
  line.textContent = msg; el.appendChild(line); console.log('[SF-STATUS] ' + msg);
}
function setCountdown(text, color) {
  var el = document.getElementById('sf-countdown');
  if (el) { el.textContent = text; el.style.color = color || '#ffff44'; }
}
window.onerror = function(msg, url, line) { appendStatus('\\u2717 JS ERROR: ' + msg, '#ff4444'); return false; };
var CFG = null;
window.addEventListener('load', function() { appendStatus('\\u2713 load event fired'); boot(); });
async function boot() {
  try {
    var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
    SCREEN_W = CFG.screenWidth || SCREEN_W; SCREEN_H = CFG.screenHeight || SCREEN_H;
    appendStatus('\\u2713 Config loaded: ' + CFG.screenName);
  } catch (e) { appendStatus('\\u2717 Config fetch failed: ' + e.message, '#ff4444'); }
  ${extraStatusLines}
  try {
    window.postMessage({ type: 'SF_HDMI_ZONES', stage: '${stageKey}', zones: [{ id: 'hdmi_zone_0', x: 0, y: 0, width: SCREEN_W, height: SCREEN_H, z_index: 1, audio_output: 'aux' }] }, '*');
    appendStatus('\\u2713 SF_HDMI_ZONES sent');
    setCountdown('Waiting for HDMI objects...');
  } catch (e) { appendStatus('\\u2717 postMessage failed: ' + e.message, '#ff4444'); }
  var objDoneAt = 2000; var playfileAt = 12000;
  setTimeout(function() { appendStatus('\\u2713 Objects created (approx)'); }, objDoneAt);
  for (var i = 10; i >= 0; i--) {
    (function(n, delay) {
      setTimeout(function() {
        if (n > 0) setCountdown('Playback start in ' + n + '...');
        else setCountdown('>>> PlayFile(roVideoInput) called <<<', '#ff4400');
      }, delay);
    })(i, objDoneAt + (10 - i) * 1000);
  }
  setTimeout(function() { appendStatus('\\u23f1 Execution continues after PlayFile (JS alive)', '#00ffff'); }, playfileAt + 500);
  setTimeout(function() { appendStatus('\\u23f1 Still alive 3s after PlayFile', '#00ffff'); setCountdown('Still alive 3s after PlayFile', '#00ff88'); }, playfileAt + 3000);
  setTimeout(function() { appendStatus('\\u23f1 Still alive 10s after PlayFile', '#00ffff'); setCountdown('Still alive 10s after PlayFile', '#00ff88'); }, playfileAt + 10000);
  setTimeout(function() { appendStatus('\\u23f1 Still alive 20s after PlayFile \\u2014 sustained', '#00ffff'); }, playfileAt + 20000);
}
`;
    }

    const hdmiSetPortTestPlayerJs = makeHdmiCountdownPlayerJs(
      'stage3_hdmi_setport_test',
      '#4488ff', '#000511',
      'HDMI SetPort Test',
      `appendStatus('\\u2713 STAGE: stage3_hdmi_setport_test');
  appendStatus('\\u2713 NEW: videoPlayer.SetPort(msgPort) before PlayFile');
  appendStatus('  Sequence: SetHDMIInput(0) + SetPort + SetRect + ZOrder + PlayFile');`
    );

    const hdmiFinalBindingTestPlayerJs = makeHdmiCountdownPlayerJs(
      'stage3_hdmi_final_binding_test',
      '#cc44ff', '#08000a',
      'HDMI Final Binding Test',
      `appendStatus('\\u2713 STAGE: stage3_hdmi_final_binding_test');
  appendStatus('\\u2713 NEW: videoInput.SetHDMIInput(0) called in BS before PlayFile');`
    );

    const hdmiPlayfileWithRectPlayerJs = makeHdmiCountdownPlayerJs(
      'stage3_hdmi_playfile_with_rect',
      '#00ff44', '#000a00',
      'HDMI PlayFile+Rect Test',
      `appendStatus('\\u2713 STAGE: stage3_hdmi_playfile_with_rect');
  appendStatus('\\u2713 SetRectangle + SetVideoZOrder(1) before PlayFile');`
    );

    const hdmiPlayfileOnlyPlayerJs = makeHdmiCountdownPlayerJs(
      'stage3_hdmi_playfile_only',
      '#ff4400', '#0a0000',
      'HDMI PlayFile Test',
      `appendStatus('\\u2713 STAGE: stage3_hdmi_playfile_only');`
    );

    const bridgeProbePlayerJs = `// ScreenFleet V2 — Stage: stage3_bridge_probe
console.log('[SF-PROBE] stage3_bridge_probe starting');
function addProbe(label, value, highlight) {
  var list = document.getElementById('probe-list'); if (!list) return;
  var row = document.createElement('div');
  row.style.cssText = 'margin:4px 0;font:bold 20px monospace;padding:4px 8px;background:rgba(0,0,0,0.5);';
  row.style.color = highlight === 'good' ? '#00ff00' : highlight === 'bad' ? '#ff4444' : '#ffffff';
  row.textContent = label + ': ' + value; list.appendChild(row);
}
function runProbe() {
  addProbe('typeof BSMessagePort', typeof BSMessagePort, typeof BSMessagePort !== 'undefined' ? 'good' : 'bad');
  addProbe('typeof window.postMessage', typeof window.postMessage, typeof window.postMessage === 'function' ? 'good' : 'bad');
  addProbe('navigator.userAgent', navigator.userAgent || '(empty)', 'good');
  var done = document.getElementById('probe-done');
  if (done) done.textContent = '--- PROBE COMPLETE ---';
}
window.addEventListener('load', function() { setTimeout(runProbe, 300); });
`;

    const hdmiVideoInputOnlyPlayerJs = `// ScreenFleet V2 — Stage: stage3_hdmi_videoinput_only
window.__SF_CLEAN_STAGE__ = 'stage3_hdmi_videoinput_only';
var SCREEN_W = ${screenWidth}; var SCREEN_H = ${screenHeight};
var heartbeatCount = 0;
function appendStatus(message, isError) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  line.style.cssText = 'font:bold 22px monospace;margin:4px 0;color:' + (isError ? '#ff4444' : '#00ff00') + ';';
  line.textContent = (isError ? '\u2717 ' : '\u2713 ') + message;
  el.appendChild(line);
}
setInterval(function() {
  heartbeatCount++;
  var el = document.getElementById('sf-heartbeat');
  if (el) { el.textContent = 'HTML alive: ' + heartbeatCount; el.style.color = (heartbeatCount % 2 === 0) ? '#00ffff' : '#0088ff'; }
}, 1000);
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
var CFG = null;
async function boot() {
  appendStatus('player.js loaded');
  var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
  SCREEN_W = CFG.screenWidth || SCREEN_W; SCREEN_H = CFG.screenHeight || SCREEN_H;
  window.postMessage({ type: 'SF_HDMI_ZONES', stage: 'stage3_hdmi_videoinput_only', zones: [{ id: 'hdmi_zone_0', x: 0, y: 0, width: SCREEN_W, height: SCREEN_H, z_index: 1, audio_output: 'aux' }] }, '*');
  appendStatus('SF_HDMI_ZONES sent');
}
window.addEventListener('load', boot);
`;

    const hdmiVideoPlayerOnlyPlayerJs = `// ScreenFleet V2 — Stage: stage3_hdmi_videoplayer_only
window.__SF_CLEAN_STAGE__ = 'stage3_hdmi_videoplayer_only';
var SCREEN_W = ${screenWidth}; var SCREEN_H = ${screenHeight};
var heartbeatCount = 0;
function appendStatus(message, isError) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  line.style.cssText = 'font:bold 22px monospace;margin:4px 0;color:' + (isError ? '#ff4444' : '#00ff00') + ';';
  line.textContent = (isError ? '\u2717 ' : '\u2713 ') + message;
  el.appendChild(line);
}
setInterval(function() {
  heartbeatCount++;
  var el = document.getElementById('sf-heartbeat');
  if (el) { el.textContent = 'HTML alive: ' + heartbeatCount; el.style.color = (heartbeatCount % 2 === 0) ? '#ff00ff' : '#aa00ff'; }
}, 1000);
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
var CFG = null;
async function boot() {
  appendStatus('player.js loaded');
  var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
  SCREEN_W = CFG.screenWidth || SCREEN_W; SCREEN_H = CFG.screenHeight || SCREEN_H;
  window.postMessage({ type: 'SF_HDMI_ZONES', stage: 'stage3_hdmi_videoplayer_only', zones: [{ id: 'hdmi_zone_0', x: 0, y: 0, width: SCREEN_W, height: SCREEN_H, z_index: 1, audio_output: 'aux' }] }, '*');
  appendStatus('SF_HDMI_ZONES sent');
}
window.addEventListener('load', boot);
`;

    const hdmiObjectsOnlyPlayerJs = `// ScreenFleet V2 — Stage: stage3_hdmi_objects_only
window.__SF_CLEAN_STAGE__ = 'stage3_hdmi_objects_only';
var SCREEN_W = ${screenWidth}; var SCREEN_H = ${screenHeight};
var heartbeatCount = 0;
setInterval(function() {
  heartbeatCount++;
  var el = document.getElementById('sf-heartbeat');
  if (el) { el.textContent = 'HTML alive: ' + heartbeatCount; el.style.color = (heartbeatCount % 2 === 0) ? '#ffff00' : '#ff8800'; }
}, 1000);
function appendStatus(message, isError) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  line.style.cssText = 'font:bold 22px monospace;margin:4px 0;color:' + (isError ? '#ff4444' : '#00ff00') + ';';
  line.textContent = (isError ? '\u2717 ' : '\u2713 ') + message;
  el.appendChild(line);
}
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
var CFG = null;
window.addEventListener('load', function() { boot(); });
async function boot() {
  try {
    var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
    SCREEN_W = CFG.screenWidth || SCREEN_W; SCREEN_H = CFG.screenHeight || SCREEN_H;
    appendStatus('Config loaded: ' + CFG.screenName);
  } catch (e) { appendStatus('Config fetch failed: ' + e.message, true); }
  var sw = SCREEN_W; var sh = SCREEN_H;
  window.postMessage({ type: 'SF_HDMI_ZONES', stage: 'stage3_hdmi_objects_only', zones: [{ id: 'hdmi_zone_0', x: 0, y: 0, width: sw, height: sh, z_index: 1, audio_output: 'aux' }], screen_width: sw, screen_height: sh, ts: new Date().toISOString() }, '*');
  appendStatus('SF_HDMI_ZONES sent');
}
`;

    const hdmiParseOnlyPlayerJs = `// ScreenFleet V2 — Stage: stage3_hdmi_parse_only
window.__SF_CLEAN_STAGE__ = 'stage3_hdmi_parse_only';
var SCREEN_W = ${screenWidth}; var SCREEN_H = ${screenHeight};
function appendStatus(message, isError) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  line.style.cssText = 'font:bold 20px monospace;margin:3px 0;color:' + (isError ? '#ff4444' : '#00ff00') + ';';
  line.textContent = (isError ? '\u2717 ' : '\u2713 ') + message;
  el.appendChild(line);
}
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
var CFG = null;
async function boot() {
  appendStatus('player.js loaded');
  var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
  SCREEN_W = CFG.screenWidth || SCREEN_W; SCREEN_H = CFG.screenHeight || SCREEN_H;
  var sw = SCREEN_W; var sh = SCREEN_H;
  window.postMessage({ type: 'SF_HDMI_ZONES', stage: 'stage3_hdmi_parse_only', zones: [{ id: 'hdmi_zone_0', x: 0, y: 0, width: sw, height: sh, z_index: 1, audio_output: 'aux' }], screen_width: sw, screen_height: sh, ts: new Date().toISOString() }, '*');
  appendStatus('SF_HDMI_ZONES sent');
}
window.addEventListener('load', boot);
`;

    const windowPostMessageAckPlayerJs = `// ScreenFleet V2 — Stage: stage3_window_postmessage_ack
window.__SF_CLEAN_STAGE__ = 'stage3_window_postmessage_ack';
var ackReceived = false; var ackTimeoutId = null;
function appendStatus(message, isError, isHighlight) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  var color = isError ? '#ff4444' : isHighlight ? '#ffff00' : '#00ff00';
  line.style.cssText = 'font:bold 20px monospace;margin:3px 0;color:' + color + ';';
  line.textContent = (isError ? '\u2717 ' : '\u2713 ') + message;
  el.appendChild(line);
}
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
window.addEventListener('message', function(evt) {
  if (evt.data && evt.data.type === 'SF_ACK') {
    ackReceived = true;
    if (ackTimeoutId) clearTimeout(ackTimeoutId);
    appendStatus('\u2605 BRIGHTSCRIPT ACK RECEIVED \u2605', false, true);
  }
});
var CFG = null;
async function boot() {
  appendStatus('player.js loaded');
  var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
  appendStatus('Config loaded: ' + CFG.screenName);
  window.postMessage({ type: 'SF_TEST', stage: 'stage3_window_postmessage_ack', ts: new Date().toISOString() }, '*');
  appendStatus('window.postMessage sent \u2014 waiting for BS SF_ACK...');
  ackTimeoutId = setTimeout(function() {
    if (!ackReceived) appendStatus('No ACK received (8s timeout)', true);
  }, 8000);
}
window.addEventListener('load', boot);
`;

    const windowPostMessageReceivePlayerJs = `// ScreenFleet V2 — Stage: stage3_window_postmessage_receive
window.__SF_CLEAN_STAGE__ = 'stage3_window_postmessage_receive';
function appendStatus(message, isError) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  line.style.cssText = 'font:bold 20px monospace;margin:3px 0;color:' + (isError ? '#ff4444' : '#00ff00') + ';';
  line.textContent = (isError ? '\u2717 ' : '\u2713 ') + message;
  el.appendChild(line);
}
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
var CFG = null;
async function boot() {
  appendStatus('player.js loaded');
  var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
  appendStatus('Config loaded: ' + CFG.screenName);
  window.postMessage({ type: 'SF_TEST', stage: 'stage3_window_postmessage_receive', ts: new Date().toISOString() }, '*');
  appendStatus('window.postMessage SF_TEST sent \u2014 waiting for BS to receive...');
}
window.addEventListener('load', boot);
`;

    const windowPostMessagePlayerJs = `// ScreenFleet V2 — Stage: stage3_window_postmessage_send
window.__SF_CLEAN_STAGE__ = 'stage3_window_postmessage_send';
function appendStatus(message, isError) {
  var el = document.getElementById('sf-js-status'); if (!el) return;
  var line = document.createElement('div');
  line.style.cssText = 'font:bold 20px monospace;margin:3px 0;color:' + (isError ? '#ff4444' : '#00ff00') + ';';
  line.textContent = (isError ? '\u2717 ' : '\u2713 ') + message;
  el.appendChild(line);
}
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
var CFG = null;
async function boot() {
  appendStatus('player.js loaded');
  var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
  appendStatus('Config loaded: ' + CFG.screenName);
  window.postMessage({ type: 'SF_TEST', stage: 'stage3_window_postmessage_send', ts: new Date().toISOString() }, '*');
  appendStatus('window.postMessage success \u2014 waiting for BrightScript receive...');
}
window.addEventListener('load', boot);
`;

    const playerJs = `// ScreenFleet V2 — Clean Stage: ${stage}
window.__SF_CLEAN_STAGE__ = '${stage}';
function appendStatus(message, isError) {
  var statusEl = document.getElementById('sf-js-status');
  if (!statusEl) { statusEl = document.createElement('div'); statusEl.id = 'sf-js-status'; var fb = document.getElementById('sf-fallback'); if (fb) fb.appendChild(statusEl); }
  statusEl.innerHTML += (isError ? '<div style="color:#f00">\u2717 ' : '<div style="color:#0f0">\u2713 ') + message + '</div>';
}
window.onerror = function(msg) { appendStatus('JS ERROR: ' + msg, true); return false; };
var CFG = null;
async function boot() {
  try {
    appendStatus('Loading config.json...');
    var cfgRes = await fetch('./config.json'); CFG = await cfgRes.json();
    appendStatus('Config loaded: ' + CFG.screenName);
    appendStatus('Boot complete');
  } catch (e) { appendStatus('BOOT ERROR: ' + e.message, true); }
}
window.addEventListener('load', boot);
`;

    // ── index.html builder ────────────────────────────────────────────────────

    function makeHdmiIndexHtml(stageKey, borderColor, bgColor, titleEmoji, titleText, extraMeta) {
      return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>ScreenFleet - ${titleText}</title>
<style>* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:${screenWidth}px; height:${screenHeight}px; overflow:hidden; background:${bgColor}; }
#sf-debug { position:fixed; top:20px; left:20px; width:calc(${screenWidth}px - 40px); background:rgba(0,0,0,0.93); border:4px solid ${borderColor}; padding:24px; z-index:99999; }
#sf-debug .title { font:bold 32px monospace; color:${borderColor}; margin-bottom:8px; }
#sf-debug .subtitle { font:bold 18px monospace; color:#ffff00; margin-bottom:4px; }
#sf-debug .meta { font:14px monospace; color:#aaa; margin-bottom:12px; }
#sf-heartbeat { font:bold 28px monospace; color:#ffff00; margin-bottom:10px; padding:6px 12px; border:2px solid #ffff00; display:inline-block; }
#sf-countdown { font:bold 30px monospace; color:#ffff44; margin:10px 0; padding:8px 12px; border:2px solid #ffff44; display:inline-block; }
#sf-js-status { margin-top:10px; }</style></head>
<body><div id="sf-debug">
  <div class="title">${titleEmoji} ${titleText}</div>
  <div class="subtitle">STAGE: ${stageKey}</div>
  ${extraMeta}
  <div class="meta">Asset: ${asset.name} | Screen: ${primaryScreen.name} (${screenWidth}x${screenHeight})</div>
  <div id="sf-heartbeat">HTML alive: 0</div>
  <div id="sf-countdown">Waiting for HDMI objects...</div>
  <div id="sf-js-status"></div>
</div><script src="./player.js"></script></body></html>`;
    }

    const hdmiSetPortTestIndexHtml = makeHdmiIndexHtml(
      'stage3_hdmi_setport_test', '#4488ff', '#000511',
      '\ud83d\udfe6', 'HDMI SetPort Test',
      '<div class="meta">ADDITION: videoPlayer.SetPort(msgPort) before PlayFile</div>'
    );

    const hdmiFinalBindingTestIndexHtml = makeHdmiIndexHtml(
      'stage3_hdmi_final_binding_test', '#cc44ff', '#08000a',
      '\ud83d\udfe3', 'HDMI Final Binding Test',
      '<div class="meta">SINGLE TEST: videoInput.SetHDMIInput(0) before PlayFile</div>'
    );

    const hdmiPlayfileWithRectIndexHtml = makeHdmiIndexHtml(
      'stage3_hdmi_playfile_with_rect', '#00ff44', '#000a00',
      '\ud83d\udfe2', 'HDMI PlayFile+Rect Test',
      ''
    );

    const hdmiPlayfileOnlyIndexHtml = makeHdmiIndexHtml(
      'stage3_hdmi_playfile_only', '#ff4400', '#0a0000',
      '\ud83d\udd34', 'HDMI PlayFile Test',
      ''
    );

    const hdmiVideoInputOnlyIndexHtml = makeHdmiIndexHtml(
      'stage3_hdmi_videoinput_only', '#00ffff', '#001111',
      '\ud83d\udd35', 'roVideoInput-Only Split Test',
      ''
    );

    const hdmiVideoPlayerOnlyIndexHtml = makeHdmiIndexHtml(
      'stage3_hdmi_videoplayer_only', '#ff00ff', '#110011',
      '\ud83d\udfe3', 'roVideoPlayer-Only Split Test',
      ''
    );

    const hdmiObjectsOnlyIndexHtml = makeHdmiIndexHtml(
      'stage3_hdmi_objects_only', '#ff8800', '#111',
      '\ud83d\udd36', 'HDMI Object Creation Test',
      ''
    );

    const standardIndexHtml = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>ScreenFleet - ${asset.name}</title>
<style>* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:${screenWidth}px; height:${screenHeight}px; overflow:hidden; background:#000; }
#sf-fallback { position:absolute; top:20px; left:20px; color:#fff; font:bold 20px monospace; z-index:10000; background:rgba(0,0,0,0.85); padding:20px; border:3px solid #00ff00; max-width:80%; line-height:1.6; }
#canvas { position:absolute; top:0; left:0; background:transparent; z-index:1; }</style></head>
<body>
  <div id="sf-fallback">
    <div style="font-size:28px;color:#00ff00;margin-bottom:10px">ScreenFleet Clean Debug Boot</div>
    <div style="color:#0f0">\u2713 HTML loaded \u2014 stage ${stageIndex}: ${stage}</div>
    <div style="color:#0f0">\u2713 Asset: ${asset.name} | Screen: ${primaryScreen.name}</div>
    <div id="sf-js-status"></div>
  </div>
  <div id="canvas"></div>
  <script src="./player.js"></script>
</body></html>`;

    // ── Dispatch ───────────────────────────────────────────────────────────────
    const indexHtml = stage === 'stage3_hdmi_setport_test' ? hdmiSetPortTestIndexHtml
      : stage === 'stage3_hdmi_final_binding_test' ? hdmiFinalBindingTestIndexHtml
      : stage === 'stage3_hdmi_playfile_with_rect' ? hdmiPlayfileWithRectIndexHtml
      : stage === 'stage3_hdmi_playfile_only' ? hdmiPlayfileOnlyIndexHtml
      : stage === 'stage3_hdmi_videoinput_only' ? hdmiVideoInputOnlyIndexHtml
      : stage === 'stage3_hdmi_videoplayer_only' ? hdmiVideoPlayerOnlyIndexHtml
      : stage === 'stage3_hdmi_objects_only' ? hdmiObjectsOnlyIndexHtml
      : standardIndexHtml;

    const finalPlayerJs = stage === 'stage3_hdmi_setport_test' ? hdmiSetPortTestPlayerJs
      : stage === 'stage3_hdmi_final_binding_test' ? hdmiFinalBindingTestPlayerJs
      : stage === 'stage3_hdmi_playfile_with_rect' ? hdmiPlayfileWithRectPlayerJs
      : stage === 'stage3_hdmi_playfile_only' ? hdmiPlayfileOnlyPlayerJs
      : stage === 'stage3_hdmi_videoinput_only' ? hdmiVideoInputOnlyPlayerJs
      : stage === 'stage3_hdmi_videoplayer_only' ? hdmiVideoPlayerOnlyPlayerJs
      : stage === 'stage3_hdmi_objects_only' ? hdmiObjectsOnlyPlayerJs
      : stage === 'stage3_hdmi_parse_only' ? hdmiParseOnlyPlayerJs
      : stage === 'stage3_window_postmessage_ack' ? windowPostMessageAckPlayerJs
      : stage === 'stage3_window_postmessage_receive' ? windowPostMessageReceivePlayerJs
      : stage === 'stage3_window_postmessage_send' ? windowPostMessagePlayerJs
      : stage === 'stage3_bridge_probe' ? bridgeProbePlayerJs
      : playerJs;

    // ── Build ZIP ─────────────────────────────────────────────────────────────
    const zipBlobWriter = new BlobWriter('application/zip');
    const zipWriter = new ZipWriter(zipBlobWriter);

    await zipWriter.add('autorun.brs', new TextReader(autorunBrs));
    await zipWriter.add('index.html', new TextReader(indexHtml));
    await zipWriter.add('player.js', new TextReader(finalPlayerJs));
    await zipWriter.add('config.json', new TextReader(configJson));
    await zipWriter.add('README.txt', new TextReader(`ScreenFleet V2 — Stage: ${stage} (index ${stageIndex})
Asset: ${asset.name} | Screen: ${primaryScreen.name} | Res: ${screenWidth}x${screenHeight}
Generated: ${new Date().toUTCString()}
Stage key: ${stage}
Valid stages: ${VALID_STAGES.join(', ')}
`));

    await zipWriter.close();
    const zipBlob = await zipBlobWriter.getData();

    const arrayBuffer = await zipBlob.arrayBuffer();
    const uint8 = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < uint8.length; i++) binary += String.fromCharCode(uint8[i]);
    const base64 = btoa(binary);
    const filename = `brightsign-v2-CLEAN-${stage}-${asset.name.toLowerCase().replace(/\s+/g, '-')}.zip`;

    // ── Artifact validation ───────────────────────────────────────────────────
    // Before returning, confirm the package is complete and stage key is correct.
    // This catches corruption from accidental empty-string templates or dispatch misses.
    const validationErrors = [];
    if (!autorunBrs || autorunBrs.trim().length < 50) validationErrors.push('autorun.brs is missing or too short');
    if (!indexHtml || indexHtml.trim().length < 50) validationErrors.push('index.html is missing or too short');
    if (!finalPlayerJs || finalPlayerJs.trim().length < 50) validationErrors.push('player.js is missing or too short');
    if (!configJson || configJson.trim().length < 10) validationErrors.push('config.json is missing or empty');
    if (base64.length < 100) validationErrors.push('Generated zip is suspiciously small — package may be corrupted');
    // Confirm stage key is echoed in autorun.brs (catches dispatch table misses)
    if (!autorunBrs.includes(stage)) validationErrors.push(`autorun.brs does not reference stage key "${stage}" — dispatch table may have a bug`);
    if (validationErrors.length > 0) {
      console.error('[generateBrightSignCleanStages] ARTIFACT VALIDATION FAILED:', validationErrors);
      return Response.json({
        error: 'Package artifact validation failed. Do not deploy this package.',
        stage,
        validation_errors: validationErrors,
      }, { status: 500 });
    }

    return Response.json({ base64, filename, stage, stageIndex });

  } catch (error) {
    console.error('generateBrightSignCleanStages error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});