import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  // Verify caller is Legion Hub/LegionOS using shared secret
  const hubSecret = req.headers.get('x-hub-secret');
  if (!hubSecret || hubSecret !== Deno.env.get('HUB_SECRET')) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const base44 = createClientFromRequest(req);
  const { user_email, org_id } = await req.json();

  if (!user_email || !org_id) {
    return Response.json({ error: 'Missing user_email or org_id' }, { status: 400 });
  }

  // Verify this user is actually a member of this org
  const members = await base44.asServiceRole.entities.OrgMember.filter({
    org_id, user_email,
  });
  if (members.length === 0) {
    return Response.json({ error: 'User is not a member of this org' }, { status: 403 });
  }

  // Generate a short-lived session token (10 minutes)
  const token = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  // Store token in AppToken entity for validation at /SSOLogin
  await base44.asServiceRole.entities.AppToken.create({
    token,
    user_email,
    org_id,
    type: 'sso',
    expires_at: expiresAt,
    used_at: null,
  });

  // Return the deep-link URL that LegionOS will redirect the user to
  const appOrigin = Deno.env.get('SCREENFLEET_APP_ORIGIN') || 'https://app.screenfleet.io';
  const login_url = `${appOrigin}/SSOLogin?token=${token}`;

  console.log(`[generateLegionOSToken] SSO token created for ${user_email} org=${org_id}`);
  return Response.json({ ok: true, login_url, expires_at: expiresAt });
});