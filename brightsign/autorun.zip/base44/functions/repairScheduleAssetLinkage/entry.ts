/**
 * repairScheduleAssetLinkage — admin-only diagnostic + repair
 *
 * Inspects Schedule.truck_id to determine if it points to a V2 Asset.
 * In V2 the convention is Schedule.truck_id = Asset.id (not a Truck entity id).
 * Reports schedules that don't map to a real asset.
 * Does NOT silently mutate — reports findings and only writes if asset found.
 *
 * POST (no body required)
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
    // The Schedule entity is V1. This entire repair function operates on V1 Schedule.truck_id semantics.
    // Once V2 scheduling is implemented, this function should be replaced or removed.
    const allSchedules = await base44.asServiceRole.entities.Schedule.list();
    console.log('[repairScheduleAssetLinkage] total schedules', allSchedules.length);

    const assetCache = {};
    const getAsset = async (id) => {
      if (!id) return null;
      if (assetCache[id] !== undefined) return assetCache[id];
      const records = await base44.asServiceRole.entities.Asset.filter({ id });
      assetCache[id] = records[0] || null;
      return assetCache[id];
    };

    let valid = 0;
    let orphaned = 0;
    let no_truck_id = 0;
    const details = [];

    for (const schedule of allSchedules) {
      if (!schedule.truck_id) {
        no_truck_id++;
        details.push({ schedule_id: schedule.id, name: schedule.name, status: 'no_truck_id', truck_id: null });
        continue;
      }

      const asset = await getAsset(schedule.truck_id);
      if (!asset) {
        orphaned++;
        details.push({
          schedule_id: schedule.id,
          name: schedule.name,
          status: 'orphaned',
          truck_id: schedule.truck_id,
          note: 'truck_id does not resolve to any Asset record. This schedule is unreachable by publish.',
        });
        console.warn('[repairScheduleAssetLinkage] orphaned schedule', { id: schedule.id, truck_id: schedule.truck_id });
      } else {
        valid++;
        details.push({
          schedule_id: schedule.id,
          name: schedule.name,
          status: 'valid',
          truck_id: schedule.truck_id,
          asset_id: asset.id,
          asset_name: asset.name,
          asset_org_id: asset.org_id,
          content_type: schedule.content_type,
          is_active: schedule.is_active,
        });
      }
    }

    const result = {
      ok: true,
      total: allSchedules.length,
      valid,
      orphaned,
      no_truck_id,
      note: 'In V2, Schedule.truck_id is semantically an asset_id. Orphaned schedules reference non-existent assets.',
      details,
    };

    console.log('[repairScheduleAssetLinkage] DONE', { total: allSchedules.length, valid, orphaned, no_truck_id });
    return Response.json(result);
  } catch (error) {
    console.error('[repairScheduleAssetLinkage] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});