/**
 * V2 Publish Engine
 * POST { asset_id }
 *
 * V2 ONLY — uses PublishedScreen + RuntimeZone. No Zone entity. No Truck for rendering.
 * org_id is NEVER accepted from the client. Always resolved server-side from the asset.
 * Old record cleanup is scoped by both screen_id AND org_id to prevent cross-org deletions.
 * Full graph validation before any publish writes.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { asset_id } = await req.json();
    if (!asset_id) return Response.json({ error: 'asset_id required' }, { status: 400 });

    // Resolve org server-side — never from client input
    const assetRecords = await base44.asServiceRole.entities.Asset.filter({ id: asset_id });
    const asset = assetRecords[0];
    if (!asset) return Response.json({ error: `Asset not found: ${asset_id}` }, { status: 404 });
    if (!asset.org_id) return Response.json({ error: `Asset ${asset_id} has no org_id — cannot publish safely` }, { status: 400 });

    const resolvedOrgId = asset.org_id;

    // Validate user has access to this org (platform admins bypass; org members need a recognized role)
    if (user.role !== 'admin') {
      const memberships = await base44.asServiceRole.entities.OrgMember.filter({ user_email: user.email, org_id: resolvedOrgId });
      const member = memberships[0];
      if (!member || !['owner', 'admin', 'manager', 'ops_manager'].includes(member.org_role)) {
        return Response.json({ error: 'Forbidden: insufficient org permissions' }, { status: 403 });
      }
    }

    const now = new Date().toISOString();
    const results = [];
    const validationErrors = [];

    // --- FETCH FULL GRAPH ---
    // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
    // Schedule.truck_id is a V1 field repurposed to hold asset_id in V2.
    // A proper V2 Schedule entity should link directly via asset_id, not truck_id.
    const [screens, assetLayouts, schedules] = await Promise.all([
      base44.asServiceRole.entities.Screen.filter({ asset_id }),
      base44.asServiceRole.entities.AssetLayout.filter({ asset_id }),
      base44.asServiceRole.entities.Schedule.filter({ truck_id: asset_id, is_active: true }),
    ]);

    console.log('[PUBLISH FULL DEBUG]', {
      asset_id,
      resolvedOrgId,
      screens: screens.map(s => ({ id: s.id, name: s.name, asset_id: s.asset_id, truck_id: s.truck_id, org_id: s.org_id })),
      asset_layout_count: assetLayouts.length,
      schedule_count: schedules.length,
      schedule_ids: schedules.map(s => s.id),
      schedule_content_types: schedules.map(s => s.content_type),
    });

    if (!screens.length) {
      return Response.json({
        ok: false,
        error: `No screens found for asset ${asset_id} (filter: Screen.asset_id = "${asset_id}"). Check that screens are linked via asset_id, not only truck_id.`,
        results: [],
      }, { status: 400 });
    }

    // --- VALIDATE: screens belong to same org ---
    for (const screen of screens) {
      if (screen.org_id && screen.org_id !== resolvedOrgId) {
        validationErrors.push(`Screen "${screen.name}" (${screen.id}) has org_id=${screen.org_id} but asset org_id=${resolvedOrgId}`);
      }
    }

    // --- VALIDATE: content entities belong to same org ---
    const playlistIds = [...new Set(schedules.filter(s => s.content_type === 'playlist' && s.playlist_id).map(s => s.playlist_id))];
    const presentationIds = [...new Set(schedules.filter(s => s.content_type === 'rotation' && s.rotation_id).map(s => s.rotation_id))];
    const sequenceIds = [...new Set(schedules.filter(s => s.content_type === 'sequence' && s.sequence_id).map(s => s.sequence_id))];

    const [allPlaylists, allPresentations, allSequences] = await Promise.all([
      playlistIds.length ? Promise.all(playlistIds.map(id => base44.asServiceRole.entities.Playlist.filter({ id }))) : Promise.resolve([]),
      presentationIds.length ? Promise.all(presentationIds.map(id => base44.asServiceRole.entities.RoutePresentation.filter({ id }))) : Promise.resolve([]),
      sequenceIds.length ? Promise.all(sequenceIds.map(id => base44.asServiceRole.entities.Sequence.filter({ id }))) : Promise.resolve([]),
    ]);

    const playlistMap = Object.fromEntries(allPlaylists.flat().map(p => [p.id, p]));
    const presentationMap = Object.fromEntries(allPresentations.flat().map(p => [p.id, p]));
    const sequenceMap = Object.fromEntries(allSequences.flat().map(s => [s.id, s]));

    for (const id of playlistIds) {
      const pl = playlistMap[id];
      if (!pl) { validationErrors.push(`Playlist ${id} referenced by schedule not found`); continue; }
      if (pl.org_id && pl.org_id !== resolvedOrgId) validationErrors.push(`Playlist "${pl.name}" (${id}) belongs to org ${pl.org_id}, not ${resolvedOrgId}`);
    }
    for (const id of presentationIds) {
      const pr = presentationMap[id];
      if (!pr) { validationErrors.push(`RoutePresentation ${id} referenced by schedule not found`); continue; }
      if (pr.org_id && pr.org_id !== resolvedOrgId) validationErrors.push(`RoutePresentation "${pr.name}" (${id}) belongs to org ${pr.org_id}, not ${resolvedOrgId}`);
    }
    for (const id of sequenceIds) {
      const seq = sequenceMap[id];
      if (!seq) { validationErrors.push(`Sequence ${id} referenced by schedule not found`); continue; }
      if (seq.org_id && seq.org_id !== resolvedOrgId) validationErrors.push(`Sequence "${seq.name}" (${id}) belongs to org ${seq.org_id}, not ${resolvedOrgId}`);
    }

    if (validationErrors.length) {
      console.error('[publishAsset] VALIDATION FAILED', validationErrors);
      return Response.json({ ok: false, error: 'Publish validation failed', validation_errors: validationErrors }, { status: 400 });
    }

    // --- PER-SCREEN PUBLISH ---
    for (const screen of screens) {
      const assetLayout = assetLayouts.find(al => al.screen_id === screen.id);
      const layoutTemplateId = assetLayout?.layout_template_id || null;

      if (!layoutTemplateId) {
        console.warn('[publishAsset] No AssetLayout found for screen', { screen_id: screen.id, screen_name: screen.name });
      }

      const layoutZones = layoutTemplateId
        ? await base44.asServiceRole.entities.LayoutZone.filter({ layout_template_id: layoutTemplateId })
        : [];

      console.log('[publishAsset] screen layout', {
        screen_id: screen.id,
        screen_name: screen.name,
        layoutTemplateId,
        zone_count: layoutZones.length,
      });

      const compatiblePlaylists = schedules
        .filter(s => s.content_type === 'playlist' && s.playlist_id)
        .map(s => playlistMap[s.playlist_id])
        .filter(Boolean);

      const compatiblePresentations = schedules
        .filter(s => s.content_type === 'rotation' && s.rotation_id)
        .map(s => presentationMap[s.rotation_id])
        .filter(Boolean);

      const compatibleSequences = [];
      for (const seqId of sequenceIds) {
        const seq = sequenceMap[seqId];
        if (!seq) continue;
        if (!schedules.find(s => s.sequence_id === seqId)) continue;
        const items = await base44.asServiceRole.entities.SequenceItem.filter({ sequence_id: seqId });
        compatibleSequences.push({ seq, items: items.sort((a, b) => a.order - b.order) });
      }

      // Org-safe cleanup: scope by BOTH screen_id AND org_id
      try {
        const oldPublished = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screen.id, org_id: resolvedOrgId });
        for (const old of oldPublished) {
          try {
            const oldZones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: old.id });
            await Promise.all(oldZones.map(rz => base44.asServiceRole.entities.RuntimeZone.delete(rz.id)));
            await base44.asServiceRole.entities.PublishedScreen.delete(old.id);
          } catch (innerErr) {
            console.warn(`[publishAsset] cleanup: failed to delete old PublishedScreen ${old.id} — skipping:`, innerErr.message);
          }
        }
      } catch (outerErr) {
        console.warn(`[publishAsset] cleanup: failed to query old PublishedScreen records for screen ${screen.id} — skipping cleanup:`, outerErr.message);
      }

      const publishedScreen = await base44.asServiceRole.entities.PublishedScreen.create({
        org_id: resolvedOrgId,
        screen_id: screen.id,
        asset_id,
        layout_template_id: layoutTemplateId,
        content_version: now,
        published_at: now,
        last_published_at: now,
        published_by: user.email,
        is_stale: false,
        schedule_ids: schedules.map(s => s.id),
        zone_count: layoutZones.length,
      });

      console.log('[publishAsset] created PublishedScreen', {
        published_screen_id: publishedScreen.id,
        screen_id: screen.id,
        org_id: resolvedOrgId,
        layout_template_id: layoutTemplateId,
        zone_count: layoutZones.length,
      });

      const primaryZones = layoutZones.filter(lz => !lz.is_duplicate_of);
      const duplicateZones = layoutZones.filter(lz => !!lz.is_duplicate_of);
      const zoneTrackMap = {};

      for (const lz of primaryZones) {
        zoneTrackMap[lz.id] = await resolveZoneTrack(lz, { compatiblePlaylists, compatiblePresentations, compatibleSequences, base44 });
      }

      const runtimeZoneCreates = [];

      for (const lz of primaryZones) {
        const track = zoneTrackMap[lz.id];
        runtimeZoneCreates.push(base44.asServiceRole.entities.RuntimeZone.create({
          published_screen_id: publishedScreen.id,
          screen_id: screen.id,
          layout_zone_id: lz.id,
          name: lz.name,
          x: lz.x ?? 0,
          y: lz.y ?? 0,
          width: lz.width,
          height: lz.height,
          z_index: lz.z_index ?? 1,
          fit_mode: lz.fit_mode_default ?? 'contain',
          background_color: lz.background_color_default || '#000000',
          volume: lz.volume_default ?? 100,
          content_source_type: track.source_type,
          content_source_id: track.source_id,
          canvas_creative_data: track.canvas_creative_data || null,
          is_duplicate_of: null,
          playback_track: { loop: true, items: track.items },
        }));
      }

      for (const lz of duplicateZones) {
        const sourceTrack = zoneTrackMap[lz.is_duplicate_of] || { source_type: 'empty', source_id: null, items: [] };
        runtimeZoneCreates.push(base44.asServiceRole.entities.RuntimeZone.create({
          published_screen_id: publishedScreen.id,
          screen_id: screen.id,
          layout_zone_id: lz.id,
          name: lz.name,
          x: lz.x ?? 0,
          y: lz.y ?? 0,
          width: lz.width,
          height: lz.height,
          z_index: lz.z_index ?? 1,
          fit_mode: lz.fit_mode_default ?? 'contain',
          background_color: lz.background_color_default || '#000000',
          volume: lz.volume_default ?? 100,
          content_source_type: sourceTrack.source_type,
          content_source_id: sourceTrack.source_id,
          canvas_creative_data: sourceTrack.canvas_creative_data || null,
          is_duplicate_of: lz.is_duplicate_of,
          playback_track: { loop: true, items: sourceTrack.items },
        }));
      }

      const createdZones = await Promise.all(runtimeZoneCreates);
      console.log('[publishAsset] created RuntimeZones', {
        screen_id: screen.id,
        zone_count: createdZones.length,
        source_types: createdZones.map(rz => rz?.content_source_type),
        item_counts: zoneTrackMap ? Object.entries(zoneTrackMap).map(([id, t]) => ({ zone: id, items: t.items?.length })) : [],
      });

      results.push({
        screen_id: screen.id,
        screen_name: screen.name,
        published_screen_id: publishedScreen.id,
        org_id: resolvedOrgId,
        zone_count: layoutZones.length,
        runtime_zone_count: createdZones.length,
        content_types: {
          playlists: compatiblePlaylists.map(p => p.name),
          presentations: compatiblePresentations.map(p => p.name),
          sequences: compatibleSequences.map(s => s.seq.name),
        },
      });
    }

    // TODO: V1 LEGACY REFERENCE — needs V2 equivalent
    // Schedule entity is V1. published_at timestamp update should move to V2 scheduling model.
    await Promise.all(schedules.map(s => base44.asServiceRole.entities.Schedule.update(s.id, { published_at: now })));

    console.log('[publishAsset] SUCCESS', { asset_id, resolvedOrgId, screen_count: results.length });

    return Response.json({ ok: true, content_version: now, results });

  } catch (error) {
    console.error('[publishAsset] ERROR:', error.message, error.stack);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function resolveZoneTrack(layoutZone, { compatiblePlaylists, compatiblePresentations, compatibleSequences, base44 }) {
  console.log(`[resolveZoneTrack] zone="${layoutZone.name}" id=${layoutZone.id} default_source_type=${JSON.stringify(layoutZone.default_source_type)}`);

  // HDMI Input zones bypass normal content resolution entirely.
  // The player runtime (BrightSign XT) handles these as hardware input sources.
  // IMPORTANT: LayoutZone.default_source_type MUST equal the string "hdmi" exactly.
  // Check Layout Template editor to ensure the zone is set to source type "hdmi".
  if (layoutZone.default_source_type === 'hdmi') {
    // audioOutput stored as UI value: 'aux' | 'hdmi' | 'both' (default: 'aux')
    const audioOutput = layoutZone.hdmi_audio_output || 'aux';
    console.log(`[resolveZoneTrack] -> HDMI zone detected. audioOutput=${audioOutput}`);
    return {
      source_type: 'hdmi_input',
      source_id: null,
      items: [],
      canvas_creative_data: {
        type: 'hdmi_input',
        source: 'brightsign_hdmi_in',
        audioOutput,  // 'aux' | 'hdmi' | 'both'
        fit: layoutZone.fit_mode_default || 'stretch',
        hardwareRequirements: { platform: 'brightsign', series: ['XT'], models: ['XT1144', 'XT1145', 'XT244', 'XT245'] },
      },
    };
  }
  if (compatibleSequences.length > 0) {
    const { seq, items: seqItems } = compatibleSequences[0];
    const resolvedItems = await buildSequenceTrack(seq, seqItems, layoutZone.id, base44);
    if (resolvedItems.length > 0) {
      console.log(`[resolveZoneTrack] -> sequence: ${seq.id}, items=${resolvedItems.length}`);
      return { source_type: 'sequence', source_id: seq.id, items: resolvedItems };
    }
  }
  if (compatiblePresentations.length > 0) {
    const presentation = compatiblePresentations[0];
    const items = await buildPresentationTrack(presentation.id, layoutZone.id, base44);
    if (items.length > 0) {
      console.log(`[resolveZoneTrack] -> presentation: ${presentation.id}, items=${items.length}`);
      return { source_type: 'presentation', source_id: presentation.id, items };
    }
  }
  if (compatiblePlaylists.length > 0) {
    const playlist = compatiblePlaylists[0];
    const items = await buildPlaylistTrack(playlist.id, layoutZone.id, base44);
    if (items.length > 0) {
      console.log(`[resolveZoneTrack] -> playlist: ${playlist.id} "${playlist.name}", items=${items.length}`);
      return { source_type: 'playlist', source_id: playlist.id, items };
    }
  }
  console.log(`[resolveZoneTrack] -> empty (no content resolved for this zone)`);
  return { source_type: 'empty', source_id: null, items: [] };
}

function resolveZoneAssignment(zone_assignments, layoutZoneId) {
  if (!zone_assignments) return null;
  return zone_assignments[layoutZoneId] || Object.values(zone_assignments)[0] || null;
}

async function tryResolveCanvasCreative(assignment, base44) {
  if (!assignment || assignment.content_type !== 'canvas_creative' || !assignment.canvas_creative_id) return null;
  try {
    const creatives = await base44.asServiceRole.entities.CanvasCreative.filter({ id: assignment.canvas_creative_id });
    const cc = creatives[0] || null;
    if (!cc) {
      console.warn(`[tryResolveCanvasCreative] CanvasCreative id=${assignment.canvas_creative_id} not found in DB`);
    }
    return cc;
  } catch (err) {
    console.error(`[tryResolveCanvasCreative] ERROR fetching canvas_creative_id=${assignment.canvas_creative_id}:`, err.message);
    return null;
  }
}

async function buildPlaylistTrack(playlistId, layoutZoneId, base44) {
  const [playlist, playlistItems] = await Promise.all([
    base44.asServiceRole.entities.Playlist.filter({ id: playlistId }).then(r => r[0]),
    base44.asServiceRole.entities.PlaylistItem.filter({ playlist_id: playlistId }),
  ]);
  if (!playlist || !playlistItems.length) return [];
  const items = [];
  for (const pi of playlistItems.sort((a, b) => a.order - b.order)) {
    const za = resolveZoneAssignment(pi.zone_assignments, layoutZoneId);
    if (!za) {
      console.warn(`[buildPlaylistTrack] PlaylistItem ${pi.id} (order=${pi.order}) has no zone assignment for zone ${layoutZoneId} — skipping item`);
      continue;
    }

    // Canvas creative path
    if (za.content_type === 'canvas_creative') {
      const cc = await tryResolveCanvasCreative(za, base44);
      if (cc) {
        console.log(`[buildPlaylistTrack] PlaylistItem ${pi.id} -> canvas_creative id=${cc.id} name="${cc.name}" layers=${cc.layers_json?.length ?? 0}`);
        const isStudioTimed = cc.sync_mode && cc.sync_mode !== 'independent';
        const studioDuration = ((pi.duration === 0 || pi.duration == null) && isStudioTimed) ? null : (pi.duration || playlist.default_duration || 8);
        items.push({
          content_type: 'canvas_creative',
          canvas_creative_id: cc.id,
          canvas_creative: cc,
          duration: studioDuration,
          transition: pi.transition ?? playlist.default_transition ?? 'fade',
          source: 'playlist',
          playlist_item_id: pi.id,
        });
      } else {
        // Canvas creative referenced but not found — emit error item so it is visible, not silently black
        console.error(`[buildPlaylistTrack] PlaylistItem ${pi.id} references canvas_creative_id=${za.canvas_creative_id} but it could not be resolved. Emitting error placeholder.`);
        items.push({
          content_type: 'canvas_creative_error',
          canvas_creative_id: za.canvas_creative_id,
          canvas_creative: null,
          error: `Studio creative ${za.canvas_creative_id} not found`,
          duration: pi.duration ?? playlist.default_duration ?? 8,
          transition: pi.transition ?? playlist.default_transition ?? 'fade',
          source: 'playlist',
          playlist_item_id: pi.id,
        });
      }
      continue;
    }

    // Media file path
    if (!za.file_url) {
      console.warn(`[buildPlaylistTrack] PlaylistItem ${pi.id} zone assignment has no file_url and is not canvas_creative — skipping`);
      continue;
    }
    items.push({
      file_url: za.file_url,
      file_type: za.file_type || 'image',
      duration: pi.duration ?? playlist.default_duration ?? 8,
      transition: pi.transition ?? playlist.default_transition ?? 'fade',
      fit_mode: null,
      source: 'playlist',
      playlist_item_id: pi.id,
      volume: za.volume ?? 100,
      muted: za.muted ?? false,
    });
  }
  console.log(`[buildPlaylistTrack] playlist=${playlistId} zone=${layoutZoneId} -> ${items.length} items:`, items.map(i => ({ type: i.content_type || i.file_type, id: i.canvas_creative_id || i.file_url?.split('/').pop() })));
  return items;
}

const TIER_ADVERTISER_LIMITS = { impact: 1, growth: 2, launch: 4 };

async function buildPresentationTrack(presentationId, layoutZoneId, base44) {
  const [presentation, spots] = await Promise.all([
    base44.asServiceRole.entities.RoutePresentation.filter({ id: presentationId }).then(r => r[0]),
    base44.asServiceRole.entities.RouteSpot.filter({ route_presentation_id: presentationId }),
  ]);
  if (!presentation || !spots.length) return [];
  const sortedSpots = spots.sort((a, b) => a.spot_number - b.spot_number);
  const allCreatives = await Promise.all(sortedSpots.map(spot => base44.asServiceRole.entities.RouteCreative.filter({ route_spot_id: spot.id })));
  const MAX_ROTATIONS = 4;
  const items = [];
  for (let si = 0; si < sortedSpots.length; si++) {
    const spot = sortedSpots[si];
    const spotCreatives = (allCreatives[si] || []).sort((a, b) => a.order - b.order);
    if (!spotCreatives.length) continue;
    const slotMap = {};
    for (const c of spotCreatives) { const slot = c.rotation_offset ?? 0; if (!slotMap[slot]) slotMap[slot] = []; slotMap[slot].push(c); }
    const maxSlots = TIER_ADVERTISER_LIMITS[spot.tier] ?? 1;
    const slots = Object.keys(slotMap).map(Number).sort((a, b) => a - b).slice(0, maxSlots);
    if (!slots.length) continue;
    for (let rot = 0; rot < MAX_ROTATIONS; rot++) {
      const slotKey = slots[rot % slots.length];
      const slotCreatives = slotMap[slotKey];
      if (!slotCreatives?.length) continue;
      const creative = slotCreatives[Math.floor(rot / slots.length) % slotCreatives.length];
      if (!creative) continue;
      const za = resolveZoneAssignment(creative.zone_assignments, layoutZoneId);
      if (!za) continue;
      if (za.content_type === 'canvas_creative') {
        const cc = await tryResolveCanvasCreative(za, base44);
        if (cc) {
          items.push({ content_type: 'canvas_creative', canvas_creative_id: cc.id, canvas_creative: cc, duration: spot.dwell_time ?? presentation.default_dwell_time ?? 8, transition: 'fade', source: 'presentation', spot_number: spot.spot_number, advertiser_name: creative.advertiser_name, rotation: rot });
        } else {
          console.error(`[buildPresentationTrack] canvas_creative_id=${za.canvas_creative_id} not resolved for spot ${spot.spot_number} rot ${rot}`);
          items.push({ content_type: 'canvas_creative_error', canvas_creative_id: za.canvas_creative_id, canvas_creative: null, error: `Studio creative ${za.canvas_creative_id} not found`, duration: spot.dwell_time ?? presentation.default_dwell_time ?? 8, transition: 'fade', source: 'presentation', spot_number: spot.spot_number, advertiser_name: creative.advertiser_name, rotation: rot });
        }
        continue;
      }
      if (!za.file_url) { console.warn(`[buildPresentationTrack] zone assignment has no file_url for spot ${spot.spot_number} rot ${rot}`); continue; }
      items.push({ file_url: za.file_url, file_type: za.file_type || 'image', duration: spot.dwell_time ?? presentation.default_dwell_time ?? 8, transition: 'fade', fit_mode: null, source: 'presentation', spot_number: spot.spot_number, advertiser_name: creative.advertiser_name, rotation: rot });
    }
  }
  return items;
}

async function buildSequenceTrack(seq, seqItems, layoutZoneId, base44) {
  const items = [];
  for (const step of seqItems) {
    const stepType = step.type || step.content_type;
    if (stepType === 'playlist' && step.playlist_id) {
      const pi = await buildPlaylistTrack(step.playlist_id, layoutZoneId, base44);
      items.push(...pi.map(i => ({ ...i, sequence_step_order: step.order })));
    } else if ((stepType === 'presentation' || stepType === 'route_presentation') && (step.presentation_id || step.route_presentation_id)) {
      const pi = await buildPresentationTrack(step.presentation_id || step.route_presentation_id, layoutZoneId, base44);
      items.push(...pi.map(i => ({ ...i, sequence_step_order: step.order })));
    }
  }
  return items;
}