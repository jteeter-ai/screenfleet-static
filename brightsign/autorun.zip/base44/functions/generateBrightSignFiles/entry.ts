/**
 * V2 BrightSign Package Generator
 * PRODUCTION ONLY — DO NOT ADD DEBUG/STAGED LOGIC HERE
 *
 * This function generates the OPERATOR-FACING production SD card package.
 * For staged HDMI debug/test packages, use generateBrightSignCleanStages instead.
 * These two generators must remain strictly separated:
 *   - generateBrightSignFiles    → production operators
 *   - generateBrightSignCleanStages → XT1145 debug testing / admin only
 *
 * Generates a local-first SD card package that:
 *  - Caches V2 screenPayload + media to IndexedDB/CacheStorage
 *  - Plays from local cache with network fallback
 *  - Polls screenVersionCheck every 60s
 *  - Downloads only changed files (by checksum)
 *  - Performs atomic payload swap
 *  - Boots and plays with no network after first cache
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';
import { ZipWriter, BlobWriter, TextReader } from 'npm:@zip.js/zip.js@2.7.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();

    // ── Contract enforcement: only assetId is accepted ───────────────────────
    // FAIL LOUDLY if caller passes screenId or truckId — those are wrong.
    // The package generator is asset-scoped. It resolves primaryScreen internally.
    // Do NOT change this to accept screenId or truckId without updating the entire pipeline.
    if (body.screenId) {
      return Response.json({
        error: 'WRONG IDENTIFIER: received screenId but generateBrightSignFiles requires assetId. The caller must pass { assetId }, not { screenId }.',
        hint: 'Find the screen\'s asset_id from the Screen entity and pass that instead.',
        received: { screenId: body.screenId },
      }, { status: 400 });
    }
    if (body.truckId) {
      return Response.json({
        error: 'WRONG IDENTIFIER: received truckId but generateBrightSignFiles requires assetId. Pass { assetId } instead.',
        received: { truckId: body.truckId },
      }, { status: 400 });
    }
    const { assetId } = body;
    if (!assetId) return Response.json({ error: 'assetId is required. Pass { assetId: "..." } in the request body.' }, { status: 400 });

    const assets = await base44.asServiceRole.entities.Asset.filter({ id: assetId });
    const asset = assets[0];
    if (!asset) return Response.json({ error: 'Asset not found' }, { status: 404 });

    let screens = await base44.asServiceRole.entities.Screen.filter({ asset_id: assetId });
    if (!screens.length) return Response.json({ error: 'No screens configured for this asset' }, { status: 400 });

    // Deterministic sort: top→bottom, left→right
    screens = screens.sort((a, b) => {
      const yDiff = (a.start_y || 0) - (b.start_y || 0);
      if (yDiff !== 0) return yDiff;
      const xDiff = (a.start_x || 0) - (b.start_x || 0);
      if (xDiff !== 0) return xDiff;
      return (a.created_date || '').localeCompare(b.created_date || '');
    });

    const primaryScreen = screens[0];
    const screenWidth = primaryScreen.width || 1920;
    const screenHeight = primaryScreen.height || 1080;

    // Load AppConfig for canonical API origin.
    // NOTE: apiOrigin here is the CMS/API origin (public_app_origin), NOT the Player app origin.
    // The BrightSign player uses this to call screenPayload and screenVersionCheck backend functions,
    // which currently live on the CMS backend.
    //
    // MIGRATION NOTE (Player app):
    //   Once the ScreenFleet Player app is deployed:
    //   1. screenPayload and screenVersionCheck should move to the Player app backend.
    //   2. apiOrigin in config.json should switch to AppConfig.player_app_origin.
    //   3. The versionCheckFn and payloadFn names in config.json will become Player app route paths.
    //   4. This generator should be migrated to the Player app.
    //
    // CLASSIFICATION: PLAYER-DELIVERY ONLY
    //   This entire function generates device-facing SD card packages.
    //   It has no CMS management purpose. It must move to the Player app.
    const configs = await base44.asServiceRole.entities.AppConfig.list().catch(() => []);
    const appConfig = configs[0];
    // apiOrigin = CMS backend URL used by BrightSign to poll screenPayload/screenVersionCheck.
    // When Player app is live, replace with appConfig?.player_app_origin.
    const apiOrigin = appConfig?.public_app_origin || 'https://app.screenfleet.io';

    // ── config.json ──────────────────────────────────────────────────────────
    // ARCHITECTURE NOTE: This package is STRICTLY SCREEN-SCOPED.
    // assetId resolves → primaryScreen → screenId baked into config.
    // At runtime, player.js calls screenPayload({ screenId }) which returns ALL
    // RuntimeZones for that screen, including HDMI zones and HTML/media zones.
    // The HTML canvas AND the BrightScript HDMI bridge both consume that SAME
    // screenPayload response — there is ONE zone manifest, not two.
    // If only 1 zone appears in the payload, the issue is in publishAsset,
    // not in the player. Check that HDMI RuntimeZone was created with the
    // correct published_screen_id matching this screen.
    const configJson = JSON.stringify({
      assetId,
      assetName: asset.name,
      apiOrigin,
      versionCheckFn: 'screenVersionCheck',
      payloadFn: 'screenPayload',
      registerFn: 'registerNativePlayer',
      pollIntervalMs: 60000,
      generatedAt: new Date().toISOString(),
      packageType: 'native_partner_app',
    }, null, 2);

    // ── autozip.brs — BSN.cloud partner provisioning trigger ─────────────────
    const autozzipBrs = `' ScreenFleet autozip.brs
' This file triggers BrightSign OS to extract the autorun.zip on first boot.
' After extraction the player reboots and executes autorun.brs.
' DO NOT RENAME THIS FILE — BrightSign OS looks for autozip.brs inside the zip.
Sub Main()
End Sub
`;

    // ── autorun.brs ───────────────────────────────────────────────────────────
    const autorunBrs = `' ScreenFleet Native Partner App — autorun.brs
' Asset: ${asset.name}
' Generated: ${new Date().toISOString()}
' Resolution: ${screenWidth}x${screenHeight}
'
' BOOT FLOW:
'   1. Create brightsign-dumps/ (required by BrightSign partner specs)
'   2. Load config.json for API origin
'   3. Check roRegistry for screen token
'   4. If no token: launch sf-setup.html (provisioning mode)
'   5. If token found: download manifest + media via roAssetFetcher, then launch index.html
'
' HDMI INPUT (XT series only):
'   Activated via SF_HDMI_ZONES message from player.js bridge.
'   roVideoPlayer.PlayFile(roVideoInput) is the only correct API path.
'   ifVideoInput methods do NOT apply to HDMI input per BrightSign docs.

Dim g_hdmiPlayer As Object
Dim g_hdmiInput As Object
Dim g_token As String
Dim g_apiOrigin As String
Dim g_screenId As String

' ── Utility: Read config.json from SD card ───────────────────────────────
Function ReadConfig() As Object
    Print "[SF] Reading config.json..."
    fs = CreateObject("roReadFile", "sd:/config.json")
    If fs = Invalid Then
        Print "[SF] ERROR: config.json not found on sd:/"
        Return Invalid
    End If
    raw = fs.ReadLine()
    cfg = ParseJson(raw)
    If cfg = Invalid Then
        Print "[SF] ERROR: config.json parse failed"
        Return Invalid
    End If
    Print "[SF] config.json loaded. apiOrigin=" + cfg.apiOrigin
    Return cfg
End Function

' ── Utility: Read roRegistry for screen token ────────────────────────────
Function ReadToken() As String
    reg = CreateObject("roRegistry")
    section = CreateObject("roRegistrySection", "ScreenFleet")
    tok = section.Read("screen_token")
    If tok = Invalid Then Return ""
    Return tok
End Function

' ── Utility: Write screen token to roRegistry ────────────────────────────
Sub WriteToken(tok As String)
    reg = CreateObject("roRegistry")
    section = CreateObject("roRegistrySection", "ScreenFleet")
    section.Write("screen_token", tok)
    section.Flush()
    Print "[SF] Token written to roRegistry."
End Sub

' ── Asset download via roAssetFetcher ────────────────────────────────────
Sub DownloadManifest(manifest As Object)
    Print "[SF] DownloadManifest: " + Str(manifest.Count()) + " items"
    pool = CreateObject("roAssetPool", "sd:/pool")
    fetcher = CreateObject("roAssetFetcher", pool)
    fetcher.SetUserAndPassword("", "")
    For Each item In manifest
        Print "[SF] Queuing: " + item.name + " <- " + item.url
        fetcher.Add(item.url, item.name)
    End For
    fetcher.Start()
    ' Wait for all downloads to complete
    msgPort = CreateObject("roMessagePort")
    fetcher.SetPort(msgPort)
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roAssetFetcherEvent" Then
            evt = msg.GetData()
            If evt.reason = "complete" Then
                Print "[SF] roAssetFetcher: all downloads complete."
                Exit While
            Else If evt.reason = "error" Then
                Print "[SF] roAssetFetcher ERROR: " + evt.errorString
                Exit While
            End If
        End If
    End While
End Sub

' ── HDMI helpers (XT series only) ────────────────────────────────────────
Function SetupHdmiInput(zoneData As Object) As Boolean
    Print "[SF-HDMI] SetupHdmiInput: zone.id=" + zoneData.id
    vi = CreateObject("roVideoInput")
    If vi = Invalid Then
        Print "[SF-HDMI] FAIL: roVideoInput=Invalid. Not XT series?"
        Return False
    End If
    vp = CreateObject("roVideoPlayer")
    If vp = Invalid Then
        Print "[SF-HDMI] FAIL: roVideoPlayer=Invalid."
        Return False
    End If
    pcmOutputs = CreateObject("roArray", 2, False)
    compOutputs = CreateObject("roArray", 2, False)
    audioMode = zoneData.audioMode
    If audioMode = Invalid Or audioMode = "" Then audioMode = "aux"
    If audioMode = "hdmi" Then
        pcmOutputs.Push({AudioOutput: "HDMI"})
        compOutputs.Push({AudioOutput: "HDMI"})
    Else If audioMode = "both" Then
        pcmOutputs.Push({AudioOutput: "AnalogAudio"})
        pcmOutputs.Push({AudioOutput: "HDMI"})
        compOutputs.Push({AudioOutput: "HDMI"})
    Else
        pcmOutputs.Push({AudioOutput: "AnalogAudio"})
    End If
    vp.SetPcmAudioOutputs(pcmOutputs)
    If compOutputs.Count() > 0 Then vp.SetCompressedAudioOutputs(compOutputs)
    rect = CreateObject("roRectangle", zoneData.x, zoneData.y, zoneData.width, zoneData.height)
    vp.SetRectangle(rect)
    vp.SetVideoZOrder(zoneData.z_index)
    vp.PlayFile(vi)
    g_hdmiPlayer = vp
    g_hdmiInput = vi
    Print "[SF-HDMI] HDMI In active."
    Return True
End Function

Function HandleHdmiZones(zones As Object) As Void
    If zones.Count() = 0 Then Return
    If zones.Count() > 1 Then
        Print "[SF-HDMI] WARNING: multiple HDMI zones — only first activated (one physical port)."
    End If
    SetupHdmiInput(zones[0])
End Function

' ── Main ─────────────────────────────────────────────────────────────────
Sub Main()
    Print "[SF] ScreenFleet Native Partner App starting."
    Print "[SF] Asset: ${asset.name}  Res: ${screenWidth}x${screenHeight}"

    ' Step 1: Create brightsign-dumps/ (required by BrightSign partner specs)
    dumpDir = CreateObject("roCreateFile", "sd:/brightsign-dumps/.keep")
    Print "[SF] brightsign-dumps/ created (partner spec requirement)."

    ' Step 2: Load config.json
    cfg = ReadConfig()
    If cfg = Invalid Then
        Print "[SF] FATAL: Cannot read config.json. Halting."
        Return
    End If
    g_apiOrigin = cfg.apiOrigin

    ' Step 3: Check roRegistry for screen token
    g_token = ReadToken()
    Print "[SF] roRegistry token: '" + g_token + "'"

    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screenWidth}, ${screenHeight})

    If g_token = "" Then
        ' Step 4: No token — launch provisioning page
        Print "[SF] No token found. Launching sf-setup.html (provisioning mode)."
        config = { url: "file:///sf-setup.html" }
        h = CreateObject("roHtmlWidget", r, config)
        h.EnableJavaScript(True)
        h.SetPort(msgPort)
        h.Show()
        ' Wait for SF_TOKEN_CONFIRMED message from sf-setup.html
        While True
            msg = Wait(0, msgPort)
            If Type(msg) = "roHtmlWidgetEvent" Then
                payload = msg.GetData()
                If Type(payload) = "roAssociativeArray" Then
                    If payload.reason = "message" And Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_TOKEN_CONFIRMED" Then
                            g_token = payload.message.token
                            g_screenId = payload.message.screen_id
                            WriteToken(g_token)
                            Print "[SF] Token registered. screenId=" + g_screenId
                            Exit While
                        End If
                    End If
                End If
            End If
        End While
        ' Reboot into normal playback mode
        Print "[SF] Rebooting to apply provisioning..."
        rebootObj = CreateObject("roSystemLog")
        rebootObj.Reboot()
        Return
    End If

    ' Step 5: Token found — fetch manifest + download media, then launch index.html
    Print "[SF] Token found. Fetching native manifest from " + g_apiOrigin
    ' (Manifest download is handled by player.js via fetch + roAssetFetcher bridge)
    ' Launch playback
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    h.Show()
    Print "[SF] roHtmlWidget shown. Entering message loop."
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "load-error" Then
                    Print "[SF] HTML load error — retrying in 5s"
                    Sleep(5000)
                    h.SetUrl("file:///index.html")
                Else If payload.reason = "message" Then
                    If Type(payload.message) = "roAssociativeArray" Then
                        If payload.message.type = "SF_HDMI_ZONES" Then
                            HandleHdmiZones(payload.message.zones)
                        End If
                    End If
                End If
            End If
        End If
    End While
End Sub
`;

    // ── sw.js — Service Worker (cache-first for media) ────────────────────────
    const swJs = `
// ScreenFleet V2 Service Worker — cache-first media delivery
const CACHE_NAME = 'sf-v2-media';

self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(clients.claim()); });

self.addEventListener('fetch', event => {
  const url = event.request.url;
  // Only intercept media fetches (images/videos from remote hosts)
  if (!url.startsWith('http')) return;
  const ext = url.split('?')[0].split('.').pop().toLowerCase();
  const isMedia = ['jpg','jpeg','png','gif','webp'].includes(ext); // videos served from sd:// local pool, not SW
  if (!isMedia) return;

  event.respondWith(
    caches.open(CACHE_NAME).then(cache =>
      cache.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          if (response.ok) cache.put(event.request, response.clone());
          return response;
        });
      })
    )
  );
});

// Message: preload manifest
self.addEventListener('message', async event => {
  if (event.data?.type !== 'PRELOAD_MANIFEST') return;
  const { items, oldChecksums } = event.data;
  const cache = await caches.open(CACHE_NAME);

  // Download new/changed files
  for (const item of items) {
    const req = new Request(item.url);
    const existing = await cache.match(req);
    if (!existing) {
      try {
        const res = await fetch(req);
        if (res.ok) await cache.put(req, res);
      } catch (e) { console.warn('[SW] Failed to cache', item.url); }
    }
  }

  // Orphan cleanup: delete URLs no longer in manifest
  const activeUrls = new Set(items.map(i => i.url));
  const keys = await cache.keys();
  for (const key of keys) {
    if (!activeUrls.has(key.url)) await cache.delete(key);
  }

  event.source?.postMessage({ type: 'PRELOAD_DONE' });
});
`;

    // ── player.js — V2 local-first playback engine ────────────────────────────
    const playerJs = `
// ScreenFleet V2 BrightSign Player
// MODE A: Native ScreenFleet generated package (autorun.brs owns BrightScript runtime).
// If this HTML is loaded as a BrightAuthor HTML feed instead, that is Mode B.
// HDMI native activation only works in Mode A.
window.__SF_NATIVE_PACKAGE__ = true;
window.__SF_ASSET_ID__       = '${assetId}';
window.__SF_GENERATED_AT__   = '${new Date().toISOString()}';
console.log('[Player] ScreenFleet NATIVE PACKAGE (Mode A). assetId=${assetId}');
console.log('[Player] Mode A: autorun.brs owns BrightScript runtime. HDMI activation via roVideoPlayer.PlayFile available.');
console.log('[Player] IMPORTANT: BrightAuthor HTML feed mode (Mode B) does NOT prove Mode A HDMI works.');

let CFG = null;
let currentPayload = null;
let knownVersion = null;
let screenId = null; // resolved from payload after registration
let zoneTimers = {};
const PAYLOAD_KEY = 'sf_v2_payload';
const VERSION_KEY = 'sf_v2_version';

// ── Boot ──────────────────────────────────────────────────────────────────────
async function boot() {
  // Register service worker for cache-first media
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js', { scope: './' });
      await navigator.serviceWorker.ready;
    } catch (e) { console.warn('[Player] SW registration failed', e); }
  }

  // Load config.json
  const cfgRes = await fetch('./config.json');
  CFG = await cfgRes.json();

  // screenId is not in config.json (native_partner_app package).
  // It is resolved from localStorage (set during provisioning) or from the first payload.
  screenId = localStorage.getItem('sf_screen_id') || null;

  // Register service worker for cache-first image delivery
  if ('serviceWorker' in navigator) {
    try {
      await navigator.serviceWorker.register('./sw.js', { scope: './' });
      await navigator.serviceWorker.ready;
    } catch (e) { console.warn('[Player] SW registration failed', e); }
  }

  // Try persisted payload first (offline boot)
  const stored = localStorage.getItem(PAYLOAD_KEY);
  if (stored) {
    try {
      currentPayload = JSON.parse(stored);
      knownVersion = currentPayload.content_version;
      if (!screenId && currentPayload.screen_id) {
        screenId = currentPayload.screen_id;
        localStorage.setItem('sf_screen_id', screenId);
      }
      renderPayload(currentPayload);
    } catch (_) {}
  }

  if (!screenId) {
    console.warn('[Player] No screenId yet — waiting for provisioning token from sf-setup.html or registry.');
    return;
  }

  // Fetch fresh payload
  await refreshPayload();

  // Start version poll
  setInterval(pollVersion, CFG.pollIntervalMs || 60000);
}

// ── API helpers ───────────────────────────────────────────────────────────────
async function invokeFunction(fnName, params) {
  const origin = CFG.apiOrigin;
  // BrightSign: use direct fetch to the Base44 function endpoint
  const url = \`\${origin}/functions/\${fnName}\`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return res.json();
}

// ── Version poll ─────────────────────────────────────────────────────────────
async function pollVersion() {
  if (!screenId) return;
  try {
    const data = await invokeFunction(CFG.versionCheckFn, { screenId });
    if (data.content_version && data.content_version !== knownVersion) {
      console.log('[Player] Version changed, refreshing payload');
      await refreshPayload();
    }
  } catch (e) { console.warn('[Player] Version check failed (offline?)', e.message); }
}

// ── Payload fetch + atomic swap ───────────────────────────────────────────────
async function refreshPayload() {
  if (!screenId) return;
  try {
    const data = await invokeFunction(CFG.payloadFn, { screenId, native_mode: true });
    if (!data || data.status === 'error') return;
    // Persist screenId if returned by payload
    if (data.screen_id && !screenId) {
      screenId = data.screen_id;
      localStorage.setItem('sf_screen_id', screenId);
    }

    // Preload media via service worker before swapping
    await preloadManifest(data.media_manifest || []);

    // Atomic swap: persist then render
    localStorage.setItem(PAYLOAD_KEY, JSON.stringify(data));
    localStorage.setItem(VERSION_KEY, data.content_version);
    knownVersion = data.content_version;
    currentPayload = data;
    renderPayload(data);
  } catch (e) { console.warn('[Player] Payload fetch failed (offline?)', e.message); }
}

// ── Preload media via SW ──────────────────────────────────────────────────────
function preloadManifest(manifest) {
  return new Promise(resolve => {
    if (!navigator.serviceWorker.controller) { resolve(); return; }
    const oldChecksums = (currentPayload?.media_manifest || []).map(m => m.checksum);
    // Only send items not already cached (diff by checksum)
    const newItems = manifest.filter(m => !oldChecksums.includes(m.checksum));
    if (!newItems.length) { resolve(); return; }

    const onMsg = (e) => {
      if (e.data?.type === 'PRELOAD_DONE') {
        navigator.serviceWorker.removeEventListener('message', onMsg);
        resolve();
      }
    };
    navigator.serviceWorker.addEventListener('message', onMsg);
    navigator.serviceWorker.controller.postMessage({
      type: 'PRELOAD_MANIFEST',
      items: newItems,
      oldChecksums,
    });
    // Timeout safety
    setTimeout(resolve, 30000);
  });
}

// ── HDMI Zone helpers ─────────────────────────────────────────────────────────
//
// collectHdmiZones: extracts valid hdmi_input zones from a payload.
// BrightSign XT has ONE physical HDMI In port — only first zone is hardware-active.
// Matches content_source_type === 'hdmi_input' as stored by publishAsset.
//
function collectHdmiZones(zones) {
  console.log('[Player-HDMI] collectHdmiZones: scanning ' + zones.length + ' zones for content_source_type===hdmi_input');
  var hdmi = zones.filter(function(z) {
    console.log('[Player-HDMI]   zone ' + z.id + ' content_source_type=' + z.content_source_type);
    if (z.content_source_type !== 'hdmi_input') return false;
    if (!z.width || !z.height) {
      console.warn('[Player-HDMI] Skipping HDMI zone with missing dimensions:', z.id);
      return false;
    }
    return true;
  });
  console.log('[Player-HDMI] collectHdmiZones: found ' + hdmi.length + ' HDMI zone(s).');
  if (hdmi.length > 1) {
    console.warn('[Player-HDMI] WARNING: ' + hdmi.length + ' HDMI zones in payload. BrightSign XT has ONE physical HDMI In port.');
    console.warn('[Player-HDMI] Only first zone (' + hdmi[0].id + ') will be hardware-active.');
  }
  return hdmi;
}

// buildHdmiBridgeMessage: builds the SF_HDMI_ZONES payload sent via BSMessagePort.
// Per-zone fields:
//   id, x, y, width, height, z_index, fit — geometry/layout
//   audioMode — normalized string: 'aux' | 'hdmi' | 'both'
//               Sourced from canvas_creative_data.audioOutput (set by publishAsset).
//               BrightScript SetupHdmiInput() maps this to output arrays.
function buildHdmiBridgeMessage(hdmiZones) {
  var zones = hdmiZones.map(function(z) {
    var hdmiMeta = z.canvas_creative_data || {};
    var audioMode = hdmiMeta.audioOutput || 'aux'; // 'aux' | 'hdmi' | 'both'
    console.log('[Player-HDMI] buildHdmiBridgeMessage zone=' + z.id + ' audioMode=' + audioMode + ' (from canvas_creative_data.audioOutput=' + hdmiMeta.audioOutput + ')');
    return {
      id:        z.id,
      x:         z.x || 0,
      y:         z.y || 0,
      width:     z.width,
      height:    z.height,
      z_index:   z.z_index || 1,
      fit:       hdmiMeta.fit || 'stretch',
      audioMode: audioMode,
    };
  });
  return { type: 'SF_HDMI_ZONES', zones: zones };
}

// ── Runtime Mode Detection ───────────────────────────────────────────────────
// MODE A: ScreenFleet native generated package (autorun.brs owns the runtime)
//   - postBSMessage() is available (injected by BrightSign firmware into roHtmlWidget)
//   - HDMI activation is possible via roVideoPlayer.PlayFile(roVideoInput)
// MODE B: HTML feed loaded inside BrightAuthor / third-party BRS presentation
//   - postBSMessage() may or may not be available depending on BrightAuthor config
//   - HDMI activation is NOT owned by ScreenFleet — BrightAuthor owns the BRS runtime
//   - DO NOT treat Mode B as proof that Mode A (native package) works
//
// Detection: window.__SF_NATIVE_PACKAGE__ is set to true only in generated player.js.
// If running inside BrightAuthor HTML feed, this flag will be absent.
function detectRuntimeMode() {
  var isNativePackage = !!window.__SF_NATIVE_PACKAGE__;
  var hasPostBSMessage = typeof postBSMessage === 'function';
  var hasBSMessagePort = typeof BSMessagePort !== 'undefined';
  console.log('[Player-MODE] ══ Runtime Mode Detection ══');
  console.log('[Player-MODE] window.__SF_NATIVE_PACKAGE__ = ' + isNativePackage);
  console.log('[Player-MODE] typeof postBSMessage         = ' + typeof postBSMessage);
  console.log('[Player-MODE] typeof BSMessagePort         = ' + typeof BSMessagePort);
  if (!isNativePackage) {
    console.warn('[Player-MODE] WARNING: __SF_NATIVE_PACKAGE__ flag NOT set.');
    console.warn('[Player-MODE] This may be an HTML feed loaded inside BrightAuthor, not a native ScreenFleet package.');
    console.warn('[Player-MODE] Native HDMI activation (roVideoPlayer.PlayFile) is only possible in Mode A (native package).');
    console.warn('[Player-MODE] BrightAuthor HDMI widget working does NOT prove ScreenFleet native HDMI works.');
  } else {
    console.log('[Player-MODE] Mode A confirmed: ScreenFleet native generated package.');
    console.log('[Player-MODE] autorun.brs owns the BrightScript runtime. HDMI activation available.');
  }
  return { isNativePackage, hasPostBSMessage };
}

// signalBrightScriptHdmiZones: sends SF_HDMI_ZONES to BrightScript.
// ONLY runs in Mode A (native ScreenFleet package).
// In Mode B (hosted HTML inside BrightAuthor), ScreenFleet does not own the BrightScript
// runtime — HDMI activation via roVideoPlayer.PlayFile is not available from this context.
function signalBrightScriptHdmiZones(msg) {
  console.log('[Player-HDMI] signalBrightScriptHdmiZones called. zones=' + msg.zones.length);

  var mode = detectRuntimeMode();

  // Gate: hosted HTML mode cannot activate native HDMI. Skip bridge entirely.
  if (!mode.isNativePackage) {
    console.warn('[Player-HDMI] MODE B (hosted HTML): skipping SF_HDMI_ZONES bridge.');
    console.warn('[Player-HDMI] ScreenFleet is loaded as an HTML URL inside BrightAuthor. It does not own the BrightScript runtime.');
    console.warn('[Player-HDMI] Native HDMI activation requires Mode A: deploy the native ScreenFleet package (autorun.brs).');
    return;
  }

  console.log('[Player-HDMI] Mode A confirmed. Sending SF_HDMI_ZONES bridge payload: ' + JSON.stringify(msg));
  var sent = false;

  // PATH 1: postBSMessage() — documented BrightSign global (BS OS 7+)
  if (typeof postBSMessage === 'function') {
    try {
      postBSMessage(msg);
      console.log('[Player-HDMI] PATH1 OK: postBSMessage(msg) called.');
      sent = true;
    } catch(e) {
      console.error('[Player-HDMI] PATH1 FAIL: postBSMessage threw: ' + (e && e.message ? e.message : String(e)));
    }
  } else {
    console.warn('[Player-HDMI] PATH1 SKIP: postBSMessage not defined.');
  }

  // PATH 2: window.postMessage() — secondary path
  if (!sent) {
    try {
      window.postMessage(msg, '*');
      console.log('[Player-HDMI] PATH2 OK: window.postMessage(msg) called.');
      sent = true;
    } catch(e) {
      console.error('[Player-HDMI] PATH2 FAIL: ' + (e && e.message ? e.message : String(e)));
    }
  }

  if (!sent) {
    console.error('[Player-HDMI] ALL PATHS FAILED. Confirm this is BrightSign XT running native ScreenFleet package.');
  }
}

// ── Renderer ──────────────────────────────────────────────────────────────────
function logZoneManifest(zones) {
  // ARCHITECTURE: Both HTML canvas and BrightScript bridge use this same zones array.
  // There is ONE screenPayload call, ONE zone list. No separate manifests.
  console.log('[Player-MANIFEST] ══════════════════════════════════════════');
  console.log('[Player-MANIFEST] ZONE MANIFEST — source: screenPayload({ screenId: ' + CFG.screenId + ' })');
  console.log('[Player-MANIFEST] Total zones in payload: ' + zones.length);
  var hdmiCount = 0;
  var htmlCount = 0;
  zones.forEach(function(z, i) {
    var isHdmi = z.content_source_type === 'hdmi_input';
    if (isHdmi) hdmiCount++; else htmlCount++;
    console.log('[Player-MANIFEST] Zone[' + i + '] id=' + z.id +
      ' name=' + (z.name || '(unnamed)') +
      ' x=' + (z.x || 0) + ' y=' + (z.y || 0) +
      ' w=' + z.width + ' h=' + z.height +
      ' z_index=' + (z.z_index || 1) +
      ' type=' + z.content_source_type);
    if (isHdmi) {
      var meta = z.canvas_creative_data || {};
      console.log('[Player-MANIFEST]   ^ HDMI zone — audioOutput=' + (meta.audioOutput || 'aux') +
        ' fit=' + (meta.fit || 'stretch') +
        ' canvas_creative_data present=' + !!z.canvas_creative_data);
    }
  });
  console.log('[Player-MANIFEST] HTML/media zones: ' + htmlCount + ' | HDMI zones: ' + hdmiCount);
  console.log('[Player-MANIFEST] HTML canvas renders ALL ' + zones.length + ' zones from this list.');
  console.log('[Player-MANIFEST] BrightScript bridge receives HDMI subset (' + hdmiCount + ') from this SAME list.');
  if (hdmiCount === 0) {
    console.warn('[Player-MANIFEST] WARNING: 0 HDMI zones in payload. If HDMI was expected:');
    console.warn('[Player-MANIFEST]   1. Check publishAsset created a RuntimeZone with content_source_type=hdmi_input');
    console.warn('[Player-MANIFEST]   2. Check that RuntimeZone.published_screen_id = ' + CFG.screenId);
    console.warn('[Player-MANIFEST]   3. The native package CANNOT activate HDMI if screenPayload returns 0 HDMI zones.');
    console.warn('[Player-MANIFEST]   4. BrightAuthor HDMI working does NOT fix this — they are Mode B (HTML feed), not Mode A.');
  }
  console.log('[Player-MANIFEST] ══════════════════════════════════════════');
}

function renderPayload(payload) {
  var canvas = document.getElementById('canvas');
  if (!canvas) return;

  // Clear existing timers
  Object.values(zoneTimers).forEach(function(t) { clearTimeout(t); });
  zoneTimers = {};

  canvas.innerHTML = '';
  canvas.style.width = payload.screen_width + 'px';
  canvas.style.height = payload.screen_height + 'px';

  var zones = payload.zones || [];

  // Log full zone manifest — proves HTML canvas and BrightScript bridge use same source
  logZoneManifest(zones);

  zones.forEach(function(zone) { renderZone(canvas, zone); });

  // Signal BrightScript about HDMI zones after HTML zones are rendered.
  // Delay 1.5s to ensure roHtmlWidget JS environment is fully ready to bridge.
  // Then retry once after 5s in case the first message was dropped during boot.
  var hdmiZones = collectHdmiZones(zones);
  if (hdmiZones.length > 0) {
    var msg = buildHdmiBridgeMessage(hdmiZones);
    console.log('[Player-HDMI] Scheduling SF_HDMI_ZONES send. count=' + hdmiZones.length);
    // First attempt: 1.5s after render
    setTimeout(function() {
      console.log('[Player-HDMI] Attempt 1: sending SF_HDMI_ZONES...');
      signalBrightScriptHdmiZones(msg);
    }, 1500);
    // Retry: 8s after render (in case first was dropped during widget init)
    setTimeout(function() {
      console.log('[Player-HDMI] Attempt 2 (retry): sending SF_HDMI_ZONES...');
      signalBrightScriptHdmiZones(msg);
    }, 8000);
  }
}

function renderZone(canvas, zone) {
  if (zone.content_source_type === 'hdmi_input') {
    var hdmiEl = document.createElement('div');
    hdmiEl.id = 'zone-' + zone.id;
    hdmiEl.setAttribute('data-hdmi-zone', 'true');

    var isNative = !!window.__SF_NATIVE_PACKAGE__;

    // ── Mode A (native ScreenFleet package): transparent placeholder.
    // BrightScript owns the GPU video plane. roVideoPlayer renders below this div.
    // ── Mode B (hosted HTML inside BrightAuthor): show unsupported-state label.
    // ScreenFleet does not own the BrightScript runtime in this mode.
    // Native HDMI activation (roVideoPlayer.PlayFile) is not available.
    if (isNative) {
      hdmiEl.style.cssText = [
        'position:absolute',
        'left:' + (zone.x || 0) + 'px',
        'top:' + (zone.y || 0) + 'px',
        'width:' + zone.width + 'px',
        'height:' + zone.height + 'px',
        'z-index:' + (zone.z_index || 1),
        'background:transparent',
        'overflow:hidden',
        'pointer-events:none',
      ].join(';');
      console.log('[Player-HDMI] Mode A (native): transparent placeholder for HDMI zone ' + zone.id);
    } else {
      // Hosted HTML mode — HDMI cannot be activated. Show explicit unsupported message.
      hdmiEl.style.cssText = [
        'position:absolute',
        'left:' + (zone.x || 0) + 'px',
        'top:' + (zone.y || 0) + 'px',
        'width:' + zone.width + 'px',
        'height:' + zone.height + 'px',
        'z-index:' + (zone.z_index || 1),
        'background:#1a0a00',
        'border:2px dashed #7c3a00',
        'display:flex',
        'flex-direction:column',
        'align-items:center',
        'justify-content:center',
        'overflow:hidden',
        'pointer-events:none',
        'box-sizing:border-box',
      ].join(';');
      hdmiEl.innerHTML = [
        '<div style="color:#f97316;font:bold 13px monospace;text-align:center;padding:0 12px;">HDMI Input</div>',
        '<div style="color:#9a5220;font:11px monospace;text-align:center;margin-top:6px;padding:0 12px;line-height:1.4;">',
          'Requires native ScreenFleet<br>player deployment.<br>',
          '<span style="color:#6b3a14;">Hosted HTML mode does not<br>support native HDMI control.</span>',
        '</div>',
      ].join('');
      console.warn('[Player-HDMI] Mode B (hosted HTML): HDMI zone ' + zone.id + ' cannot activate native hardware. Showing unsupported-state label.');
      console.warn('[Player-HDMI] To use HDMI input, deploy the native ScreenFleet package (Mode A) instead of loading this URL inside BrightAuthor.');
    }

    canvas.appendChild(hdmiEl);
    return;
  }

  var el = document.createElement('div');
  el.id = 'zone-' + zone.id;
  el.style.cssText = [
    'position:absolute',
    'left:' + (zone.x || 0) + 'px',
    'top:' + (zone.y || 0) + 'px',
    'width:' + zone.width + 'px',
    'height:' + zone.height + 'px',
    'z-index:' + (zone.z_index || 1),
    'background:' + (zone.background_color || '#000'),
    'overflow:hidden',
  ].join(';');
  canvas.appendChild(el);

  var items = zone.playback_track ? zone.playback_track.items || [] : [];
  if (!items.length) return;
  playTrack(el, zone, items, 0);
}

function playTrack(el, zone, items, index) {
  var item = items[index % items.length];
  if (!item) return;

  el.innerHTML = '';
  var fitCss = fitModeToCss(item.fit_mode || zone.fit_mode);
  var volume = zone.volume != null ? zone.volume : 100;

  if (item.file_type === 'video') {
    // Videos: use sd:// local pool path if available (downloaded by roAssetFetcher)
    var videoSrc = item.local_name ? 'sd:/media/' + item.local_name : item.file_url;
    var v = document.createElement('video');
    v.src = videoSrc;
    v.autoplay = true;
    v.playsInline = true;
    v.muted = volume === 0;
    v.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:' + fitCss;
    v.onended = function() { playTrack(el, zone, items, index + 1); };
    v.onerror = function() {
      if (item.local_name && v.src !== item.file_url) {
        console.warn('[Player] sd:// video failed, falling back to CDN:', item.file_url);
        v.src = item.file_url;
      } else {
        playTrack(el, zone, items, index + 1);
      }
    };
    el.appendChild(v);
  } else {
    // Images: SW cache handles CDN URLs; sd:// path not needed for images
    var img = document.createElement('img');
    img.src = item.file_url;
    img.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:' + fitCss;
    el.appendChild(img);
    var dur = (item.duration != null ? item.duration : 8) * 1000;
    var loop = !zone.playback_track || zone.playback_track.loop !== false;
    var nextIndex = index + 1;
    if (loop || nextIndex < items.length) {
      zoneTimers[zone.id] = setTimeout(function() { playTrack(el, zone, items, nextIndex); }, dur);
    }
  }
}

function fitModeToCss(fitMode) {
  switch (fitMode) {
    case 'fit': return 'contain';
    case 'stretch': return 'fill';
    case 'center': return 'none';
    default: return 'cover';
  }
}

// Boot on load
window.addEventListener('load', boot);
`;

    // ── index.html ────────────────────────────────────────────────────────────
    const indexHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=${screenWidth}, height=${screenHeight}">
  <title>ScreenFleet - ${asset.name}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: ${screenWidth}px; height: ${screenHeight}px; overflow: hidden; background: transparent; }
    #canvas { position: absolute; top: 0; left: 0; background: transparent; }
    #status { position: fixed; bottom: 8px; right: 8px; color: #ffffff22; font: 10px monospace; z-index: 9999; pointer-events: none; }
  </style>
</head>
<body>
  <div id="canvas"></div>
  <div id="status">ScreenFleet V2</div>
  <script src="./player.js"></script>
</body>
</html>`;

    // ── sf-setup.html — first-boot provisioning page ─────────────────────────
    const sfSetupHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ScreenFleet Setup</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: ${screenWidth}px; height: ${screenHeight}px; background: #0a0a14; color: #fff; font-family: monospace; display: flex; align-items: center; justify-content: center; flex-direction: column; }
    h1 { font-size: 2em; color: #4f8ef7; margin-bottom: 0.5em; }
    p { color: #aaa; margin-bottom: 1.5em; font-size: 1.1em; }
    #status { color: #4f8ef7; font-size: 1em; margin-top: 1em; min-height: 2em; }
    #error  { color: #f74f4f; font-size: 0.9em; margin-top: 0.5em; min-height: 1.5em; }
  </style>
</head>
<body>
  <h1>ScreenFleet</h1>
  <p>Provisioning player — please wait...</p>
  <div id="status">Connecting to ScreenFleet...</div>
  <div id="error"></div>
  <script>
    (async function() {
      var statusEl = document.getElementById('status');
      var errorEl  = document.getElementById('error');

      function setStatus(msg) { statusEl.textContent = msg; console.log('[SF-Setup] ' + msg); }
      function setError(msg)  { errorEl.textContent  = msg; console.error('[SF-Setup] ' + msg); }

      var cfgRes, cfg;
      try {
        cfgRes = await fetch('./config.json');
        cfg    = await cfgRes.json();
        setStatus('Config loaded. API: ' + cfg.apiOrigin);
      } catch(e) {
        setError('Failed to load config.json: ' + e.message);
        return;
      }

      // Get device serial from BrightSign if available
      var deviceSerial = '';
      try {
        if (typeof BSDeviceInfo !== 'undefined') {
          deviceSerial = BSDeviceInfo.deviceUniqueId || '';
        }
      } catch(_) {}

      // The screen token is stored in the SD card file system by BSN.cloud provisioning.
      // Read it from the well-known path.
      var token = '';
      try {
        var tokenRes = await fetch('./sf-token.txt');
        if (tokenRes.ok) token = (await tokenRes.text()).trim();
      } catch(_) {}

      if (!token) {
        setError('No sf-token.txt found. Ensure BSN.cloud provisioning wrote the screen token to sf-token.txt on the SD card.');
        return;
      }

      setStatus('Token found. Registering with ScreenFleet...');

      var regRes, regData;
      try {
        var url = cfg.apiOrigin + '/functions/' + cfg.registerFn;
        regRes  = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ public_token: token, deviceSerial: deviceSerial }),
        });
        regData = await regRes.json();
      } catch(e) {
        setError('Registration request failed: ' + e.message);
        return;
      }

      if (!regData || regData.error) {
        setError('Registration failed: ' + (regData && regData.error ? regData.error : 'unknown error'));
        return;
      }

      setStatus('Registered! screenId=' + regData.screen_id + '. Notifying autorun...');

      // Send token + screen_id to autorun.brs via postBSMessage
      var msg = { type: 'SF_TOKEN_CONFIRMED', token: token, screen_id: regData.screen_id };
      if (typeof postBSMessage === 'function') {
        postBSMessage(msg);
      } else {
        window.postMessage(msg, '*');
      }

      setStatus('Provisioning complete. Rebooting...');
    })();
  </script>
</body>
</html>`;

    // ── README.txt ────────────────────────────────────────────────────────────
    const readme = `ScreenFleet V2 BrightSign Package
==================================
Asset:      ${asset.name}
Screen:     ${primaryScreen.name}
Resolution: ${screenWidth}x${screenHeight}
Player:     ${asset.player_model || 'BrightSign'}
API Origin: ${apiOrigin}
Generated:  ${new Date().toUTCString()}

SETUP
-----
1. Format SD card as FAT32 (16GB+ recommended)
2. Extract ALL files to the ROOT of the SD card
3. Insert SD card into BrightSign player and power on

FILES
-----
autozip.brs  - BSN.cloud extraction trigger (do not rename)
autorun.brs  - BrightSign boot script (do not rename)
sf-setup.html- First-boot provisioning page (launched when no token found)
index.html   - Player shell (launched after provisioning)
player.js    - V2 local-first playback engine
sw.js        - Service worker (cache-first image delivery)
config.json  - Asset configuration (assetId, API origin, no screenId)
README.txt   - This file

PLAYBACK BEHAVIOR
-----------------
- On first boot: fetches V2 screenPayload from ${apiOrigin}
- Downloads all media files to browser cache (via service worker)
- Subsequent boots: plays from cache immediately, checks for updates in background
- If network unavailable: plays cached payload indefinitely
- Version polling: every 60 seconds (checks content_version only)
- On version change: downloads only new/changed files (by checksum)

PAYLOAD API
-----------
Version check: POST ${apiOrigin}/functions/screenVersionCheck { screenId }
Full payload:  POST ${apiOrigin}/functions/screenPayload      { screenId }

RUNTIME ARCHITECTURE
---------------------
This package is STRICTLY SCREEN-SCOPED.
At runtime, player.js calls: screenPayload({ screenId: '${primaryScreen.id}' })
The HTML canvas and BrightScript HDMI bridge both use this SAME payload.
One zone manifest, not two. If HDMI is missing, check publishAsset RuntimeZones.
See [Player-MANIFEST] logs on device for full zone diagnostics.

DO NOT test HDMI via BrightAuthor HTML feed (Mode B). Only this package (Mode A) can
activate roVideoPlayer.PlayFile(roVideoInput).

SCREEN ID
---------
${primaryScreen.id}

ASSET ID
--------
${assetId}
`;

    // ── Build ZIP ─────────────────────────────────────────────────────────────
    const zipBlobWriter = new BlobWriter('application/zip');
    const zipWriter = new ZipWriter(zipBlobWriter);

    await zipWriter.add('autozip.brs', new TextReader(autozzipBrs));
    await zipWriter.add('autorun.brs', new TextReader(autorunBrs));
    await zipWriter.add('sf-setup.html', new TextReader(sfSetupHtml));
    await zipWriter.add('index.html', new TextReader(indexHtml));
    await zipWriter.add('player.js', new TextReader(playerJs));
    await zipWriter.add('sw.js', new TextReader(swJs));
    await zipWriter.add('config.json', new TextReader(configJson));
    await zipWriter.add('README.txt', new TextReader(readme));

    await zipWriter.close();
    const zipBlob = await zipBlobWriter.getData();

    const arrayBuffer = await zipBlob.arrayBuffer();
    const uint8 = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < uint8.length; i++) binary += String.fromCharCode(uint8[i]);
    const base64 = btoa(binary);
    const filename = `brightsign-v2-${asset.name.toLowerCase().replace(/\s+/g, '-')}-setup.zip`;

    return Response.json({ base64, filename });

  } catch (error) {
    console.error('generateBrightSignFiles error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});