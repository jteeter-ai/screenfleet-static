/**
 * diagnoseSyncFailureV2 — Get exact Player response for each failing screen
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const body = await req.json();
    const screenNames = body.screen_names || [];

    const allScreens = await base44.asServiceRole.entities.Screen.list();
    const results = {};

    for (const name of screenNames) {
      const screen = allScreens.find(s => s.name === name);
      if (!screen) {
        results[name] = { error: `Screen not found` };
        continue;
      }

      // Load PublishedScreen
      const publishedList = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: screen.id });
      const published = publishedList[0];
      if (!published) {
        results[name] = { screen_name: screen.name, error: 'No PublishedScreen' };
        continue;
      }

      // Load RuntimeZones
      const zones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: published.id });

      // Get AppConfig
      const configs = await base44.asServiceRole.entities.AppConfig.list();
      const appConfig = configs[0];

      // Build sync payload (exact replica of syncToPlayer)
      const contentVersionIso = published.content_version || new Date().toISOString();
      const contentVersion = new Date(contentVersionIso).getTime();
      const deviceSafeMode = screen.device_safe_mode ?? appConfig?.default_device_safe_mode ?? false;

      const syncPayload = {
        public_token: screen.public_token,
        device_safe_mode: deviceSafeMode,
        cms_screen_id: screen.id,
        resolution_width: screen.width,
        resolution_height: screen.height,
        screen_id: screen.id,
        screen_width: screen.width,
        screen_height: screen.height,
        screen_name: screen.name,
        screen_position: screen.position,
        screen_mode: screen.screen_mode,
        content_version: contentVersion,
        content_version_iso: contentVersionIso,
        published_at: published.published_at,
        zones: zones.sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1)).map(z => ({
          id: z.id,
          layout_zone_id: z.layout_zone_id,
          name: z.name,
          x: z.x ?? 0,
          y: z.y ?? 0,
          width: z.width,
          height: z.height,
          z_index: z.z_index ?? 1,
          fit_mode: z.fit_mode || 'contain',
          background_color: z.background_color || '#000000',
          volume: z.volume ?? 100,
          content_source_type: z.content_source_type || 'empty',
          canvas_creative_data: z.canvas_creative_data || null,
          playback_track: {
            loop: z.playback_track?.loop ?? true,
            items: (z.playback_track?.items || []).map(item => ({
              ...item,
              url: item.file_url || item.url || null,
              type: item.file_type || item.type || null,
            })),
          },
        })),
        synced_at: new Date().toISOString(),
      };

      // Sync to Player
      const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '');
      const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');
      const syncUrl = `${playerOrigin}/functions/syncScreenData`;

      let playerResponse = null;
      try {
        const res = await fetch(syncUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-sync-secret': syncSecret,
          },
          body: JSON.stringify({ action: 'upsert', screen_data: syncPayload }),
        });
        const resBody = await res.json();
        playerResponse = {
          status: res.status,
          statusText: res.statusText,
          ok: res.ok,
          body: resBody,
        };
      } catch (err) {
        playerResponse = { error: err.message };
      }

      results[name] = {
        screen_name: screen.name,
        screen_id: screen.id,
        public_token: screen.public_token,
        device_safe_mode: deviceSafeMode,
        width: screen.width,
        height: screen.height,
        zones_count: zones.length,
        content_version: contentVersion,
        content_version_iso: contentVersionIso,
        published_screen_id: published.id,
        payload_size_bytes: JSON.stringify(syncPayload).length,
        // Player response
        player_response: playerResponse,
      };
    }

    return Response.json(results, { status: 200 });
  } catch (error) {
    console.error('[diagnoseSyncFailureV2]', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});