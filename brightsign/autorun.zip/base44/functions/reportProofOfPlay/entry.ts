/**
 * reportProofOfPlay — CMS Proof of Play ingestion endpoint
 *
 * Called by the ScreenFleet Player app once per creative play instance.
 * Public endpoint (no user session on device), authenticated by PLAYER_SYNC_SECRET header.
 *
 * IDEMPOTENCY: Uses a deterministic event_key to prevent double-counting on Player retry.
 * event_key = stable concat of: screen_id + route_spot_id + route_creative_id + playback_started_at + content_version
 *
 * If a record with the same event_key already exists, the request is silently accepted (200 ok)
 * without creating a duplicate. This makes the endpoint safe for retry-on-failure.
 *
 * PLAYER DEPENDENCY CONTRACT (for isolated Player implementation):
 *
 * Endpoint: POST /functions/reportProofOfPlay
 * Header:   x-sync-secret: <PLAYER_SYNC_SECRET>
 * Body (JSON):
 *   {
 *     screen_id:              string (required),
 *     asset_id:               string | null,
 *     route_presentation_id:  string | null,
 *     route_spot_id:          string | null,
 *     route_creative_id:      string | null,
 *     playback_started_at:    ISO string (required),
 *     playback_completed_at:  ISO string | null,
 *     delivered_seconds:      number | null,
 *     status:                 "played" | "interrupted" | "skipped" | "failed" (required),
 *     content_version:        string | null,
 *     player_version:         string | null,
 *     gps_lat:                number | null,
 *     gps_lng:                number | null,
 *     gps_speed:              number | null,
 *     was_offline:            boolean (default false)
 *   }
 *
 * EMIT POLICY (Player-side):
 *   - Emit ONE event per creative play instance (not per frame)
 *   - Success path:     emit on completion (status="played")
 *   - Interrupted path: emit when interrupted/interrupted (status="interrupted", include delivered_seconds)
 *   - Skipped path:     emit when content is skipped early (status="skipped")
 *   - Failure path:     emit if playback fails to start or crashes (status="failed")
 *   - Do NOT emit for sub-frame events or heartbeats
 *
 * RETRY BEHAVIOR (Player-side):
 *   - Retry up to 3 times with exponential backoff (1s, 2s, 4s)
 *   - If offline: buffer events in localStorage, flush on reconnect
 *   - Set was_offline=true for buffered events
 *   - The CMS event_key deduplication guarantees retries are safe
 *
 * BATCHING (Player-side):
 *   - Preferred: send events individually on completion for real-time reporting
 *   - Offline buffer: flush in batches of up to 50 events on reconnect
 *   - For offline batches, call this endpoint once per event (not a batch endpoint)
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// Simple deterministic key from stable event fields
function buildEventKey(screenId, routeSpotId, routeCreativeId, playbackStartedAt, contentVersion) {
  const parts = [
    screenId || '',
    routeSpotId || '',
    routeCreativeId || '',
    playbackStartedAt || '',
    contentVersion || '',
  ];
  // Simple hash-like key — no crypto needed, collision probability is negligible for this use case
  return parts.join('|').replace(/[^a-zA-Z0-9|._-]/g, '_').substring(0, 200);
}

Deno.serve(async (req) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers });
  }

  try {
    const base44 = createClientFromRequest(req);

    // ── Auth: PLAYER_SYNC_SECRET (devices have no user session) ──────────────
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');
    const headerSecret = req.headers.get('x-sync-secret');

    if (!syncSecret || headerSecret !== syncSecret) {
      console.warn('[reportProofOfPlay] Unauthorized: bad or missing x-sync-secret');
      return Response.json({ error: 'Unauthorized' }, { status: 401, headers });
    }

    // ── Parse body ────────────────────────────────────────────────────────────
    const body = await req.json().catch(() => null);
    if (!body) {
      return Response.json({ error: 'Invalid JSON body' }, { status: 400, headers });
    }

    const {
      screen_id,
      asset_id,
      route_presentation_id,
      route_spot_id,
      route_creative_id,
      playback_started_at,
      playback_completed_at,
      delivered_seconds,
      status,
      content_version,
      player_version,
      gps_lat,
      gps_lng,
      gps_speed,
      was_offline,
    } = body;

    // ── Validate required fields ──────────────────────────────────────────────
    if (!screen_id) return Response.json({ error: 'screen_id is required' }, { status: 400, headers });
    if (!playback_started_at) return Response.json({ error: 'playback_started_at is required' }, { status: 400, headers });
    if (!['played', 'interrupted', 'skipped', 'failed'].includes(status)) {
      return Response.json({ error: 'status must be played|interrupted|skipped|failed' }, { status: 400, headers });
    }

    // ── Build dedupe key ──────────────────────────────────────────────────────
    const event_key = buildEventKey(
      screen_id,
      route_spot_id,
      route_creative_id,
      playback_started_at,
      content_version
    );

    // ── Idempotency check: reject duplicate keys ──────────────────────────────
    const existing = await base44.asServiceRole.entities.ProofOfPlayEvent.filter({ event_key });
    if (existing.length > 0) {
      console.log(`[reportProofOfPlay] Duplicate event_key=${event_key} — skipping, already recorded`);
      return Response.json({ ok: true, deduplicated: true, event_id: existing[0].id }, { status: 200, headers });
    }

    // ── CMS enrichment: resolve advertiser/campaign/org from RouteSpot ────────
    let advertiser_id = null;
    let campaign_id = null;
    let org_id = null;
    let resolved_asset_id = asset_id || null;

    // Resolve org_id and asset_id from Screen
    try {
      const screens = await base44.asServiceRole.entities.Screen.filter({ id: screen_id });
      const screen = screens[0];
      if (screen) {
        resolved_asset_id = resolved_asset_id || screen.asset_id || null;
        if (screen.asset_id) {
          const assets = await base44.asServiceRole.entities.Asset.filter({ id: screen.asset_id });
          if (assets[0]) org_id = assets[0].org_id || null;
        }
      }
    } catch (_) { /* non-fatal */ }

    // Resolve advertiser_id + campaign_id from RouteSpot
    if (route_spot_id) {
      try {
        const spots = await base44.asServiceRole.entities.RouteSpot.filter({ id: route_spot_id });
        const spot = spots[0];
        if (spot) {
          advertiser_id = spot.advertiser_id || null;
          campaign_id = spot.campaign_id || null;
        }
      } catch (_) { /* non-fatal */ }
    }

    // Resolve campaign_creative_id from RouteCreative
    let campaign_creative_id = null;
    let media_asset_id = null;
    if (route_creative_id) {
      try {
        const creatives = await base44.asServiceRole.entities.RouteCreative.filter({ id: route_creative_id });
        const creative = creatives[0];
        if (creative) {
          campaign_creative_id = creative.campaign_creative_id || null;
          // Attempt to extract first media_asset_id from zone_assignments
          const assignments = Object.values(creative.zone_assignments || {});
          const firstMedia = assignments.find(a => a.media_asset_id);
          if (firstMedia) media_asset_id = firstMedia.media_asset_id;
        }
      } catch (_) { /* non-fatal */ }
    }

    // ── Write ProofOfPlayEvent ─────────────────────────────────────────────────
    const eventRecord = await base44.asServiceRole.entities.ProofOfPlayEvent.create({
      event_key,
      org_id,
      asset_id: resolved_asset_id,
      screen_id,
      route_presentation_id: route_presentation_id || null,
      route_spot_id: route_spot_id || null,
      route_creative_id: route_creative_id || null,
      advertiser_id,
      campaign_id,
      campaign_creative_id,
      media_asset_id,
      content_version: content_version || null,
      player_version: player_version || null,
      playback_started_at,
      playback_completed_at: playback_completed_at || null,
      delivered_seconds: typeof delivered_seconds === 'number' ? delivered_seconds : null,
      status,
      gps_lat: typeof gps_lat === 'number' ? gps_lat : null,
      gps_lng: typeof gps_lng === 'number' ? gps_lng : null,
      gps_speed: typeof gps_speed === 'number' ? gps_speed : null,
      was_offline: was_offline === true,
    });

    console.log(`[reportProofOfPlay] ✅ Recorded event ${eventRecord.id} screen=${screen_id} status=${status} started=${playback_started_at}`);

    // ── Check if campaign is fully delivered and publish to Hub ──────────────
    if (campaign_id && status === 'played') {
      try {
        const campaign = (await base44.asServiceRole.entities.Campaign.filter({ id: campaign_id }))[0];
        if (campaign?.contracted_play_count) {
          const allPlays = await base44.asServiceRole.entities.ProofOfPlayEvent.filter({ campaign_id, status: 'played' });
          const totalPlays = allPlays.length;
          const totalDeliveredSeconds = allPlays.reduce((sum, e) => sum + (e.delivered_seconds || 0), 0);
          if (totalPlays >= campaign.contracted_play_count) {
            const hubUrl = Deno.env.get('HUB_PUBLISH_URL');
            const hubSecret = Deno.env.get('HUB_SECRET');
            if (hubUrl) {
              fetch(hubUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  source_app: 'screenfleet',
                  event_type: 'campaign.completed',
                  org_id,
                  payload: { campaign_id, advertiser_id, org_id, total_plays: totalPlays, delivered_seconds: totalDeliveredSeconds },
                  secret: hubSecret,
                }),
              }).then(r => console.log('[reportProofOfPlay] campaign.completed published to Hub, status:', r.status))
                .catch(e => console.warn('[reportProofOfPlay] Failed to publish campaign.completed to Hub:', e.message));
            }
          }
        }
      } catch (e) {
        console.warn('[reportProofOfPlay] Non-fatal: campaign completion check failed:', e.message);
      }
    }

    return Response.json({ ok: true, event_id: eventRecord.id }, { status: 201, headers });

  } catch (error) {
    console.error('[reportProofOfPlay] Error:', error.message);
    return Response.json({ ok: false, error: error.message }, { status: 500, headers });
  }
});