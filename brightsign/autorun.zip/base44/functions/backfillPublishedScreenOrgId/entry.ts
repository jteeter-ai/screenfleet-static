/**
 * One-time migration: backfill org_id on all PublishedScreen records
 * that are missing it. Traces: PublishedScreen → Screen → Asset → org_id
 * 
 * POST (no body required) — admin only
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const publishedScreens = await base44.asServiceRole.entities.PublishedScreen.list();
    let updated = 0;
    let skipped = 0;
    let failed = 0;

    for (const ps of publishedScreens) {
      if (ps.org_id) { skipped++; continue; }
      try {
        const screens = await base44.asServiceRole.entities.Screen.filter({ id: ps.screen_id });
        const screen = screens[0];
        if (!screen?.asset_id) { failed++; continue; }

        const assets = await base44.asServiceRole.entities.Asset.filter({ id: screen.asset_id });
        const asset = assets[0];
        if (!asset?.org_id) { failed++; continue; }

        await base44.asServiceRole.entities.PublishedScreen.update(ps.id, { org_id: asset.org_id });
        updated++;
      } catch (e) {
        console.error(`[backfill] Failed for PublishedScreen ${ps.id}:`, e.message);
        failed++;
      }
    }

    console.log('[backfill] Done:', { total: publishedScreens.length, updated, skipped, failed });
    return Response.json({ ok: true, total: publishedScreens.length, updated, skipped, failed });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});