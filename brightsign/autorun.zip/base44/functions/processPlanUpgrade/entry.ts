import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orgId, newPlanSlug, billingFrequency } = await req.json();

    if (!orgId || !newPlanSlug) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Get organization
    const orgs = await base44.entities.Organization.filter({ id: orgId });
    if (!orgs || orgs.length === 0) {
      return Response.json({ error: 'Organization not found' }, { status: 404 });
    }

    const org = orgs[0];

    // Get new plan
    const plans = await base44.asServiceRole.entities.Plan.filter({ slug: newPlanSlug });
    if (!plans || plans.length === 0) {
      return Response.json({ error: 'Plan not found' }, { status: 404 });
    }

    const newPlan = plans[0];
    const billingCycle = newPlan.billing_cycles?.find(bc => bc.frequency === (billingFrequency || 'monthly'));

    if (!billingCycle) {
      return Response.json({ error: 'Billing frequency not available for this plan' }, { status: 400 });
    }

    // Calculate pro-rated amount if upgrading mid-cycle
    let proRatedAmount = billingCycle.price;
    const now = new Date();
    const currentCycleEnd = org.plan_expires_at ? new Date(org.plan_expires_at) : null;

    if (currentCycleEnd && currentCycleEnd > now && org.plan_slug !== newPlanSlug) {
      const daysRemaining = Math.ceil((currentCycleEnd - now) / (1000 * 60 * 60 * 24));
      const daysInCycle = 30; // Use 30-day month for calculation
      proRatedAmount = (billingCycle.price / daysInCycle) * daysRemaining;
    }

    // Create Stripe checkout for upgrade
    const appUrl = new URL(req.url).origin;
    const stripeSession = await base44.functions.invoke('createStripeCheckout', {
      orgId: org.id,
      planSlug: newPlanSlug,
      billingFrequency: billingFrequency || 'monthly',
      isUpgrade: true,
      proRatedCredit: (billingCycle.price - proRatedAmount).toFixed(2),
    });

    return Response.json({
      success: true,
      checkoutUrl: stripeSession.data.checkoutUrl,
      sessionId: stripeSession.data.sessionId,
      proRatedAmount: proRatedAmount.toFixed(2),
      planName: newPlan.name,
    });
  } catch (error) {
    console.error('Error processing plan upgrade:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});