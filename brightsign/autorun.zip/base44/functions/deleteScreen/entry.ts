/**
 * deleteScreen — Hard delete an archived screen
 *
 * Prerequisites:
 * - Screen.status must be "archived"
 * - All dependent records must be cleaned up (archiveScreen handles this)
 *
 * Flow:
 * 1. Verify screen is archived
 * 2. Call Player API to fully delete token
 * 3. Hard delete Screen record
 * 4. Log audit entry
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { screen_id } = await req.json();
    if (!screen_id) {
      return Response.json({ error: 'screen_id required' }, { status: 400 });
    }

    // ── Load screen ───────────────────────────────────────────────────────────
    const screens = await base44.entities.Screen.filter({ id: screen_id });
    const screen = screens[0];
    if (!screen) {
      return Response.json({ error: 'Screen not found' }, { status: 404 });
    }

    // Verify org membership for non-platform-admins
    if (user.role !== 'admin' && screen.org_id) {
      const memberships = await base44.asServiceRole.entities.OrgMember.filter({ user_email: user.email, org_id: screen.org_id });
      const member = memberships[0];
      if (!member || !['owner', 'admin', 'manager', 'ops_manager'].includes(member.org_role)) {
        return Response.json({ error: 'Forbidden: insufficient org permissions' }, { status: 403 });
      }
    }

    if (screen.status !== 'archived') {
      return Response.json(
        { error: 'Only archived screens can be permanently deleted' },
        { status: 400 }
      );
    }

    const org_id = screen.org_id;

    // ── Call Player API to fully delete token ───────────────────────────────────
    const config = (await base44.entities.AppConfig.list())[0];
    const playerOrigin = config?.player_app_origin?.replace(/\/$/, '');
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');

    let playerDeleteResult = null;
    if (playerOrigin && syncSecret && screen.public_token) {
      const playerRes = await fetch(`${playerOrigin}/functions/syncScreenData`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-sync-secret': syncSecret,
        },
        body: JSON.stringify({
          action: 'delete',
          public_token: screen.public_token,
          cms_screen_id: screen_id,
        }),
      }).catch((err) => {
        console.warn(`[deleteScreen] Player delete failed: ${err.message}`);
        return null;
      });

      if (playerRes?.ok) {
        playerDeleteResult = await playerRes.json();
      } else {
        console.warn(`[deleteScreen] Player delete returned ${playerRes?.status}`);
      }
    }

    // ── Hard delete Screen record ──────────────────────────────────────────────
    await base44.entities.Screen.delete(screen_id);

    // ── Create audit log ───────────────────────────────────────────────────────
    const auditEntry = {
      action: 'delete_screen',
      user_email: user.email,
      screen_id,
      screen_name: screen.name,
      org_id,
      public_token: screen.public_token,
      player_delete_status: playerDeleteResult ? 'success' : 'failed_or_skipped',
      timestamp: new Date().toISOString(),
    };

    console.log('[deleteScreen] Audit:', JSON.stringify(auditEntry));

    return Response.json({
      ok: true,
      screen_id,
      screen_name: screen.name,
      deleted: true,
      player_result: playerDeleteResult,
    });
  } catch (error) {
    console.error('[deleteScreen] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});