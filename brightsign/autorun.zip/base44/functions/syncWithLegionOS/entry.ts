import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { orgId } = await req.json();
    const legionOSKey = Deno.env.get('LEGIONOS_API_KEY');

    if (!legionOSKey) {
      return Response.json({ error: 'LegionOS integration not configured' }, { status: 500 });
    }

    // Fetch org and asset data
    const orgs = await base44.asServiceRole.entities.Organization.filter({ id: orgId });
    if (orgs.length === 0) {
      return Response.json({ error: 'Organization not found' }, { status: 404 });
    }

    const org = orgs[0];
    const trucks = await base44.asServiceRole.entities.Truck.filter({ org_id: orgId });

    // Sync to LegionOS
    const response = await fetch('https://legionos.legionledtrucks.com/api/assets/sync', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${legionOSKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        orgId: org.id,
        orgName: org.name,
        assets: trucks.map(t => ({
          id: t.id,
          name: t.name,
          type: t.asset_type,
          status: t.status,
          screenCount: t.screen_count,
          playerType: t.player_type,
          location: t.location
        }))
      })
    });

    if (!response.ok) {
      throw new Error(`LegionOS sync failed: ${response.statusText}`);
    }

    const result = await response.json();
    return Response.json({ success: true, result, assetsCount: trucks.length });
  } catch (error) {
    console.error('LegionOS sync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});