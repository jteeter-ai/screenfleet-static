import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { checksum } = await req.json();
    if (!checksum || typeof checksum !== 'string') {
      return Response.json({ error: 'Missing checksum' }, { status: 400 });
    }

    const existing = await base44.asServiceRole.entities.MediaAsset.filter({ checksum });
    const isDuplicate = existing.length > 0;

    return Response.json({
      checksum,
      isDuplicate,
      existingAssetId: isDuplicate ? existing[0].id : null,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});