import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token } = await req.json();

    if (!token) {
      return Response.json({ error: 'Token is required' }, { status: 400 });
    }

    const tokens = await base44.asServiceRole.entities.AppToken.filter({ token });
    if (!tokens || tokens.length === 0) {
      return Response.json({ valid: false, code: 'INVALID_TOKEN', error: 'Invalid or unrecognized token.' });
    }

    const appToken = tokens[0];

    if (appToken.used_at) {
      return Response.json({ valid: false, code: 'TOKEN_USED', error: 'This setup link has already been used.' });
    }

    if (new Date(appToken.expires_at) < new Date()) {
      return Response.json({ valid: false, code: 'TOKEN_EXPIRED', error: 'This setup link has expired. Please contact your administrator.' });
    }

    return Response.json({
      valid: true,
      user_email: appToken.user_email,
      org_name: appToken.org_name,
      org_id: appToken.org_id,
    });
  } catch (error) {
    console.error('validateSetupToken error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});