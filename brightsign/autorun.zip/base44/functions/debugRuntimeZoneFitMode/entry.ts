import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * DEBUG: Inspect RuntimeZone fit_mode values for a screen by public_token
 * POST { public_token }
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { public_token } = await req.json();
    
    if (!public_token) {
      return Response.json({ error: 'public_token required' }, { status: 400 });
    }

    // Find screen by public_token
    const screens = await base44.entities.Screen.filter({ public_token });
    if (!screens.length) {
      return Response.json({ error: `Screen not found for public_token: ${public_token}` }, { status: 404 });
    }

    const screen = screens[0];
    console.log('[debugRuntimeZoneFitMode] Found screen:', {
      id: screen.id,
      name: screen.name,
      width: screen.width,
      height: screen.height,
      org_id: screen.org_id,
      asset_id: screen.asset_id,
    });

    // Find published screens
    const publishedScreens = await base44.entities.PublishedScreen.filter({ screen_id: screen.id });
    if (!publishedScreens.length) {
      return Response.json({
        screen: {
          id: screen.id,
          name: screen.name,
          width: screen.width,
          height: screen.height,
        },
        published_screens: [],
        runtime_zones: [],
        message: 'No published screens found',
      });
    }

    const publishedScreen = publishedScreens[0]; // Use most recent
    console.log('[debugRuntimeZoneFitMode] Found PublishedScreen:', {
      id: publishedScreen.id,
      content_version: publishedScreen.content_version,
      is_stale: publishedScreen.is_stale,
      published_at: publishedScreen.published_at,
    });

    // Fetch all RuntimeZones for this published screen
    const runtimeZones = await base44.entities.RuntimeZone.filter({ published_screen_id: publishedScreen.id });
    console.log('[debugRuntimeZoneFitMode] Found RuntimeZones:', runtimeZones.length);

    // Detailed report per zone
    const zonesReport = runtimeZones.map(rz => ({
      id: rz.id,
      layout_zone_id: rz.layout_zone_id,
      name: rz.name,
      x: rz.x,
      y: rz.y,
      width: rz.width,
      height: rz.height,
      z_index: rz.z_index,
      fit_mode: rz.fit_mode,
      fit_mode_explicitly_set: rz.fit_mode && rz.fit_mode !== null && rz.fit_mode !== undefined,
      content_source_type: rz.content_source_type,
      content_source_id: rz.content_source_id,
      playback_track_items_count: rz.playback_track?.items?.length || 0,
    }));

    return Response.json({
      status: 'ok',
      screen: {
        id: screen.id,
        name: screen.name,
        width: screen.width,
        height: screen.height,
        public_token: screen.public_token,
        org_id: screen.org_id,
        asset_id: screen.asset_id,
      },
      published_screen: {
        id: publishedScreen.id,
        content_version: publishedScreen.content_version,
        is_stale: publishedScreen.is_stale,
        published_at: publishedScreen.published_at,
      },
      runtime_zones: zonesReport,
    });
  } catch (error) {
    console.error('[debugRuntimeZoneFitMode] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});