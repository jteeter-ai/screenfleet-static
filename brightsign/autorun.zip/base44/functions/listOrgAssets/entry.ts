import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { org_id } = await req.json();
    if (!org_id) return Response.json({ error: 'org_id required' }, { status: 400 });

    if (user.role !== 'admin') {
      const members = await base44.asServiceRole.entities.OrgMember.filter({
        user_email: user.email,
        org_id,
      });
      if (!members.length) return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const assets = await base44.asServiceRole.entities.Asset.filter({ org_id });
    return Response.json(assets);
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
});