// ARCHIVED: Contains unique logic — review before permanent deletion.
// This generates a completely standalone SD card boot test with NO network, NO HDMI, NO player.js,
// NO config.json — just autorun.brs + a self-contained index.html proving the device can boot at all.
// generateBrightSignCleanStages has no equivalent: all its stages require config.json and the JS bridge.

/**
 * Minimal BrightSign Native Boot Test Package
 * 
 * PURPOSE: Isolate whether standalone SD card boot works at all.
 * 
 * This package does ONLY:
 * - Boots from SD card as standalone native package
 * - Runs autorun.brs
 * - Opens a simple local HTML page
 * - Displays obvious text proving boot success
 * 
 * This package does NOT:
 * - No HDMI logic
 * - No network calls
 * - No screenPayload
 * - No BSMessagePort bridge
 * - No service worker
 * - No remote fetch logic
 * - No runtime canvas
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';
import { ZipWriter, BlobWriter, TextReader } from 'npm:@zip.js/zip.js@2.7.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { assetId } = body;
    if (!assetId) return Response.json({ error: 'assetId is required' }, { status: 400 });

    const assets = await base44.asServiceRole.entities.Asset.filter({ id: assetId });
    const asset = assets[0];
    if (!asset) return Response.json({ error: 'Asset not found' }, { status: 404 });

    // ── autorun.brs — MINIMAL NATIVE BOOT ─────────────────────────────────────
    // Does ONLY: create roHtmlWidget, load local index.html, show it, stay alive.
    // No HDMI, no network, no message bridge, no complex logic.
    const autorunBrs = `' ScreenFleet Minimal Native Boot Test
' Asset: ${asset.name}
' Generated: ${new Date().toISOString()}
'
' PURPOSE: Prove standalone SD card boot works.
' No HDMI. No network. No message bridge. Just boot and show HTML.

Sub Main()
    Print "[SF-BOOTTEST] ═══════════════════════════════"
    Print "[SF-BOOTTEST] ScreenFleet Minimal Native Boot Test"
    Print "[SF-BOOTTEST] Asset: ${asset.name}"
    Print "[SF-BOOTTEST] Generated: ${new Date().toISOString()}"
    Print "[SF-BOOTTEST] ═══════════════════════════════"

    msgPort = CreateObject("roMessagePort")
    
    ' Create basic HTML widget covering full screen
    r = CreateObject("roRectangle", 0, 0, 1920, 1080)
    config = { url: "file:///index.html" }
    h = CreateObject("roHtmlWidget", r, config)
    
    h.EnableJavaScript(True)
    h.SetPort(msgPort)
    
    Print "[SF-BOOTTEST] roHtmlWidget created"
    Print "[SF-BOOTTEST] Loading local file:///index.html"
    
    ' CRITICAL: Show() must be called before message loop
    h.Show()
    Print "[SF-BOOTTEST] roHtmlWidget.Show() called — HTML should now be visible"
    Print "[SF-BOOTTEST] Entering message loop..."

    ' Simple message loop — just stay alive
    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            payload = msg.GetData()
            If Type(payload) = "roAssociativeArray" Then
                If payload.reason = "load-error" Then
                    Print "[SF-BOOTTEST] HTML load ERROR — retrying in 3s"
                    Sleep(3000)
                    h.SetUrl("file:///index.html")
                Else If payload.reason = "message" Then
                    Print "[SF-BOOTTEST] BSMessagePort message received: " + payload.message.type
                End If
            End If
        End If
    End While
End Sub
`;

    // ── index.html — MINIMAL BOOT DISPLAY ──────────────────────────────────────
    // Plain background, large obvious text proving HTML loaded.
    const indexHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=1920, height=1080">
  <title>ScreenFleet Boot Test</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body {
      width: 1920px;
      height: 1080px;
      background: #1e3a5f;
      font-family: monospace;
      overflow: hidden;
    }
    .container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      gap: 24px;
    }
    h1 {
      font-size: 72px;
      color: #ffffff;
      text-align: center;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
    }
    .status {
      font-size: 36px;
      color: #4ade80;
      text-align: center;
      padding: 16px 32px;
      background: rgba(0,0,0,0.3);
      border-radius: 8px;
      border: 2px solid #4ade80;
    }
    .meta {
      font-size: 20px;
      color: #94a3b8;
      text-align: center;
      margin-top: 32px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>ScreenFleet Native Boot Test</h1>
    <div class="status">✓ autorun.brs started<br/>✓ HTML widget loaded</div>
    <div class="meta">
      Minimal BrightSign Package<br/>
      No HDMI • No Network • No Bridge<br/>
      If you see this, native SD boot works.
    </div>
  </div>
  <script>
    console.log('[SF-BOOTTEST] HTML loaded successfully');
    console.log('[SF-BOOTTEST] This is a minimal native boot test package');
    console.log('[SF-BOOTTEST] No HDMI, no network calls, no complexity');
  </script>
</body>
</html>`;

    // ── README.txt — CLEAR INSTRUCTIONS ────────────────────────────────────────
    const readme = `ScreenFleet Minimal Native Boot Test
=====================================
Asset: ${asset.name}
Generated: ${new Date().toUTCString()}

PURPOSE
-------
This package proves whether a standalone BrightSign SD card boot works at all.
It strips away ALL complexity: no HDMI, no network, no message bridge.

FILES
-----
autorun.brs  - Minimal BrightScript boot (creates roHtmlWidget, shows index.html)
index.html   - Simple HTML page with obvious "boot success" message
README.txt   - This file

SETUP
-----
1. Format SD card as FAT32 (any size works for this test)
2. Extract ALL files to the ROOT of the SD card
3. Insert SD card into BrightSign player
4. Power cycle or reboot the player

WHAT YOU SHOULD SEE
-------------------
If native boot works:
  - Blue background (#1e3a5f)
  - Large white text: "ScreenFleet Native Boot Test"
  - Green status box: "✓ autorun.brs started ✓ HTML widget loaded"
  - Gray meta text: "Minimal BrightSign Package..."

If you see this:
  - Native SD boot is working
  - roHtmlWidget is functioning
  - Local HTML rendering works
  - The issue is in the FULL package (HDMI/runtime logic)

If you see blank/black screen:
  - Native SD boot is failing
  - Issue is more fundamental than HDMI
  - Check: SD card format, BrightSign model compatibility, autorun.brs syntax

WHAT THIS PACKAGE DOES NOT DO
-----------------------------
- No HDMI input activation
- No network calls (screenPayload, version check)
- No BSMessagePort bridge to BrightScript
- No service worker or caching
- No runtime canvas or zone rendering
- No remote content fetching

NEXT STEPS
----------
If this boots cleanly:
  → The full ScreenFleet package has a bug (likely HDMI or payload logic)
  → We can incrementally add complexity back to find the crash point

If this also fails:
  → Issue is fundamental (SD card, BrightSign model, autorun.brs syntax)
  → Not related to HDMI or runtime complexity

LOGS
----
BrightSign prints [SF-BOOTTEST] prefixed logs.
If you have serial access, watch for:
  [SF-BOOTTEST] roHtmlWidget created
  [SF-BOOTTEST] roHtmlWidget.Show() called
  [SF-BOOTTEST] HTML loaded successfully
`;

    // ── Build ZIP ─────────────────────────────────────────────────────────────
    const zipBlobWriter = new BlobWriter('application/zip');
    const zipWriter = new ZipWriter(zipBlobWriter);

    await zipWriter.add('autorun.brs', new TextReader(autorunBrs));
    await zipWriter.add('index.html', new TextReader(indexHtml));
    await zipWriter.add('README.txt', new TextReader(readme));

    await zipWriter.close();
    const zipBlob = await zipBlobWriter.getData();

    const arrayBuffer = await zipBlob.arrayBuffer();
    const uint8 = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < uint8.length; i++) binary += String.fromCharCode(uint8[i]);
    const base64 = btoa(binary);
    const filename = `brightsign-boot-test-${asset.name.toLowerCase().replace(/\s+/g, '-')}.zip`;

    return Response.json({ base64, filename });

  } catch (error) {
    console.error('generateBrightSignBootTest error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});