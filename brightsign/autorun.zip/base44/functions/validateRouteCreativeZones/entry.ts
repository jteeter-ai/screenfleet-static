import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { layout_template_id, zone_assignments } = await req.json();
    if (!layout_template_id || !zone_assignments) {
      return Response.json({ error: 'Missing layout_template_id or zone_assignments' }, { status: 400 });
    }

    // Fetch layout zones for the template
    const layoutZones = await base44.entities.LayoutZone.filter({ 
      layout_template_id: layout_template_id 
    });
    const validZoneIds = new Set(layoutZones.map(z => z.id));

    // Validate all zone_assignments reference valid layout zones
    const invalidZones = Object.keys(zone_assignments).filter(zoneId => !validZoneIds.has(zoneId));
    if (invalidZones.length > 0) {
      return Response.json({ 
        valid: false,
        error: 'Invalid zone IDs', 
        invalid_zones: invalidZones 
      }, { status: 400 });
    }

    // Validate: reject uploads to duplicate zones
    const zoneMap = {};
    layoutZones.forEach(z => { zoneMap[z.id] = z; });
    
    for (const zoneId of Object.keys(zone_assignments)) {
      const zone = zoneMap[zoneId];
      if (zone && zone.duplicated_from_zone_id && Object.keys(zone_assignments[zoneId] || {}).length > 0) {
        return Response.json({ 
          valid: false,
          error: `Cannot upload to duplicate zone: ${zone.name}` 
        }, { status: 400 });
      }
    }

    // Validate all media_asset_ids exist
    const mediaAssets = await Promise.all(
      Object.values(zone_assignments)
        .map(a => a.media_asset_id ? base44.entities.MediaAsset.get(a.media_asset_id) : Promise.resolve(null))
    );
    const missingAssets = mediaAssets.filter(a => a === null);
    if (missingAssets.length > 0) {
      return Response.json({ valid: false, error: 'Some media assets not found' }, { status: 400 });
    }

    return Response.json({ valid: true, layout_template_id: layout_template_id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});