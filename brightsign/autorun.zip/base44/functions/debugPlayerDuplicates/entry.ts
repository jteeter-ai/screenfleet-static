/**
 * debugPlayerDuplicates — Check for duplicate / stale PlayerScreen rows on the Player side.
 *
 * Queries the Player app's entity store directly via syncScreenData (admin list action)
 * and its internal base44 SDK for all screens matching a given public_token or cms_screen_id.
 *
 * If the Player app doesn't expose a list endpoint, falls back to probing via
 * getScreenByToken with both old and new tokens to surface stale rows.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const configs = await base44.asServiceRole.entities.AppConfig.list();
    const appConfig = configs[0];
    const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '');
    const syncSecret = Deno.env.get('PLAYER_SYNC_SECRET');
    if (!playerOrigin || !syncSecret) return Response.json({ error: 'AppConfig or secret missing' }, { status: 400 });

    // Load ALL screens from CMS to build a full token inventory
    const allScreens = await base44.asServiceRole.entities.Screen.list();
    console.log(`[debugPlayerDuplicates] CMS screens total: ${allScreens.length}`);

    // For each CMS screen, probe the Player for its current row
    // Use both the current token AND check for any stale cms_screen_id mismatches
    const TARGET_SCREENS = [
      { name: 'Poster 2095',          id: '69d24c106543f10ff962e6bd', token: '4cd0497f-fd5e-4460-a1d9-a78622558349' },
      { name: 'P1.9 Indoor Rental',   id: '69d24c56e07ee6d36cfca41b', token: 'b8a6e8a2-7fe7-4b91-806f-566f6097802a' },
      { name: 'Truck 119 3-Zone',     id: '69d322a4aa43c998cd0995ff', token: '2d51a5f8-b322-4d3b-be49-b606820be68a' },
    ];

    const results = await Promise.all(TARGET_SCREENS.map(async (s) => {
      // Probe 1: current token
      const r1 = await fetch(`${playerOrigin}/functions/getScreenByToken`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
        body: JSON.stringify({ token: s.token }),
      });
      const body1 = await r1.json().catch(() => null);
      const zones1 = body1?.zones || [];

      // Probe 2: ask syncScreenData for list of all records (if supported)
      const r2 = await fetch(`${playerOrigin}/functions/syncScreenData`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
        body: JSON.stringify({ action: 'list' }),
      });
      const body2 = await r2.json().catch(() => null);

      // Probe 3: ask syncScreenData for all records matching cms_screen_id
      const r3 = await fetch(`${playerOrigin}/functions/syncScreenData`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
        body: JSON.stringify({ action: 'query', cms_screen_id: s.id }),
      });
      const body3 = await r3.json().catch(() => null);

      // Probe 4: ask syncScreenData for all records matching public_token
      const r4 = await fetch(`${playerOrigin}/functions/syncScreenData`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
        body: JSON.stringify({ action: 'query', public_token: s.token }),
      });
      const body4 = await r4.json().catch(() => null);

      // Probe 5: direct entity read via admin debug endpoint (if Player exposes it)
      const r5 = await fetch(`${playerOrigin}/functions/debugScreenRecord`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-sync-secret': syncSecret },
        body: JSON.stringify({ public_token: s.token, cms_screen_id: s.id }),
      });
      const body5 = await r5.json().catch(() => null);

      const liveRecord = body1;
      const liveCmsScreenId = liveRecord?.cms_screen_id || liveRecord?.screen_id || null;
      const liveToken = liveRecord?.public_token || liveRecord?.token || null;
      const liveZoneCount = zones1.length;
      const liveItemCount = zones1.reduce((sum, z) => sum + (z?.playback_track?.items?.length || 0), 0);
      const liveContentVersion = liveRecord?.content_version || null;

      // Detect mismatch: Player row has different cms_screen_id than what CMS sent
      const hasCmsIdMismatch = liveCmsScreenId && liveCmsScreenId !== s.id;
      const hasTokenMismatch = liveToken && liveToken !== s.token;

      return {
        screen: s.name,
        cms_id: s.id,
        cms_token: s.token,
        // Player row
        player_getScreenByToken_status: r1.status,
        player_zone_count: liveZoneCount,
        player_item_count: liveItemCount,
        player_content_version: liveContentVersion,
        player_cms_screen_id: liveCmsScreenId,
        player_token: liveToken,
        // Mismatch flags
        cms_id_mismatch: hasCmsIdMismatch,
        token_mismatch: hasTokenMismatch,
        // List/query probes for duplicates
        list_action_status: r2.status,
        list_action_result_keys: body2 ? Object.keys(body2) : [],
        query_by_cms_id_status: r3.status,
        query_by_cms_id_result: body3,
        query_by_token_status: r4.status,
        query_by_token_result: body4,
        debug_endpoint_status: r5.status,
        debug_endpoint_result: body5,
        // Full live record for forensics
        raw_player_record: liveRecord,
      };
    }));

    return Response.json({ screens: results });

  } catch (error) {
    console.error('[debugPlayerDuplicates] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});