import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

/**
 * assignAssetLayout — server-side enforced AssetLayout assignment.
 * 
 * HARD BLOCK: Rejects assignment if Screen.width !== LayoutTemplate.canvas_width
 *             OR Screen.height !== LayoutTemplate.canvas_height.
 * 
 * This is the authoritative enforcement layer. UI validation is supplementary.
 * 
 * Payload: { asset_id, screen_id, layout_template_id }
 * Returns: { assetLayout } on success, 400 with error on dimension mismatch.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { asset_id, screen_id, layout_template_id } = await req.json();

    if (!asset_id || !screen_id || !layout_template_id) {
      return Response.json(
        { error: 'asset_id, screen_id, and layout_template_id are all required' },
        { status: 400 }
      );
    }

    // Fetch screen and template in parallel
    let screen, template;
    try {
      const [screenList, templateList] = await Promise.all([
        base44.asServiceRole.entities.Screen.filter({ id: screen_id }),
        base44.asServiceRole.entities.LayoutTemplate.filter({ id: layout_template_id }),
      ]);
      screen = screenList[0];
      template = templateList[0];
    } catch (fetchErr) {
      return Response.json({ error: `Entity not found: ${fetchErr.message}` }, { status: 404 });
    }

    if (!screen) {
      return Response.json({ error: `Screen not found: ${screen_id}` }, { status: 404 });
    }
    if (!template) {
      return Response.json({ error: `LayoutTemplate not found: ${layout_template_id}` }, { status: 404 });
    }

    // HARD BLOCK: dimension enforcement
    const screenW = Number(screen.width);
    const screenH = Number(screen.height);
    const tplW = Number(template.canvas_width);
    const tplH = Number(template.canvas_height);

    if (screenW !== tplW || screenH !== tplH) {
      return Response.json(
        {
          error: 'DIMENSION_MISMATCH',
          message: `Cannot assign: Screen "${screen.name}" is ${screenW}×${screenH}px but ` +
                   `LayoutTemplate "${template.name}" is ${tplW}×${tplH}px. ` +
                   `Dimensions must match exactly.`,
          screen_dimensions: { width: screenW, height: screenH },
          template_dimensions: { width: tplW, height: tplH },
        },
        { status: 400 }
      );
    }

    if (template.is_archived) {
      return Response.json(
        { error: 'Cannot assign an archived LayoutTemplate.' },
        { status: 400 }
      );
    }

    // Enforce one AssetLayout per screen — upsert
    const existing = await base44.asServiceRole.entities.AssetLayout.filter({ screen_id });

    let assetLayout;
    if (existing.length > 0) {
      assetLayout = await base44.asServiceRole.entities.AssetLayout.update(existing[0].id, {
        layout_template_id,
      });
    } else {
      assetLayout = await base44.asServiceRole.entities.AssetLayout.create({
        asset_id,
        screen_id,
        layout_template_id,
      });
    }

    console.log(`[assignAssetLayout] Assigned template "${template.name}" to screen "${screen.name}" (${screenW}×${screenH}px)`);

    return Response.json({ assetLayout });
  } catch (error) {
    console.error('[assignAssetLayout] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});