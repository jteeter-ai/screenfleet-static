import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

/**
 * GPS Location Ingest Endpoint
 * Allows hardware players (BrightSign, etc.) to report GPS location data
 * Used for future geo-aware scheduling and route-based content targeting
 */
Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const { screenId, truckId, latitude, longitude, speed, heading } = body;

    if (!screenId && !truckId) {
      return Response.json({ error: 'screenId or truckId required' }, { status: 400 });
    }

    if (latitude === undefined || longitude === undefined) {
      return Response.json({ error: 'latitude and longitude required' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const timestamp = new Date().toISOString();

    // Update screen GPS data if screenId provided
    if (screenId) {
      await base44.asServiceRole.entities.Screen.update(screenId, {
        last_known_lat: latitude,
        last_known_lng: longitude,
        last_gps_at: timestamp,
      });
    }

    // Update truck GPS data if truckId provided
    if (truckId) {
      await base44.asServiceRole.entities.Truck.update(truckId, {
        last_known_lat: latitude,
        last_known_lng: longitude,
        last_gps_at: timestamp,
      });
    }

    return Response.json({
      success: true,
      message: 'GPS location recorded',
      timestamp,
    });
  } catch (error) {
    console.error('reportGPSLocation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});