import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { org_id, actor_email, action, target_type, target_id, details } = body;

    if (!action) {
      return Response.json({ error: 'action is required' }, { status: 400 });
    }

    const ip_address = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || null;

    await base44.asServiceRole.entities.AuditLog.create({
      org_id: org_id || null,
      actor_email: actor_email || null,
      action,
      target_type: target_type || null,
      target_id: target_id || null,
      details: details || null,
      ip_address,
    });

    return Response.json({ ok: true });
  } catch (error) {
    console.error('[writeAuditLog] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});