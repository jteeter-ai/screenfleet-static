/**
 * V2 screenPayload
 *
 * CLASSIFICATION: PLAYER-DELIVERY ONLY
 * This is a pure device/player content delivery API. It has no CMS admin purpose.
 *
 * MIGRATION TARGET — must move to the ScreenFleet Player app.
 * When the Player app is deployed:
 *   - Move this function to the Player app backend
 *   - Player app calls the CMS API internally to fetch PublishedScreen + RuntimeZone data
 *   - Devices/hardware players call the Player app endpoint instead of the CMS
 *   - Remove this function from the CMS
 *
 * Public, no auth required (devices poll this without user sessions).
 *
 * POST { screenId }
 *
 * POST { screenId }
 *
 * Returns the full render-ready payload for a screen:
 * - PublishedScreen metadata
 * - RuntimeZones with resolved playback_track
 * - Deduplicated media_manifest
 * - device_safe_mode flag
 *
 * READ-ONLY delivery layer. No business logic, no content reconstruction.
 * All content resolution happened at publish time (publishAsset function).
 *
 * Data sources: PublishedScreen, RuntimeZone, MediaAsset, AppConfig only.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

const FALLBACK_ORIGIN = 'https://app.screenfleet.io';
const PAYLOAD_CACHE_SECONDS = 60;

Deno.serve(async (req) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': `public, max-age=${PAYLOAD_CACHE_SECONDS}`,
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers });
  }

  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const screenId = body.screenId || body.screen_id;
    const { native_mode } = body;

    if (!screenId) {
      return Response.json({ error: 'screenId required', status: 'error' }, { status: 400, headers });
    }

    // ── Load AppConfig (best-effort, non-fatal) ───────────────────────────────
    let appConfig = null;
    try {
      const configs = await base44.asServiceRole.entities.AppConfig.list();
      appConfig = configs[0] || null;
    } catch (_) { /* fallback silently */ }

    const publicOrigin = appConfig?.public_app_origin || FALLBACK_ORIGIN;

    // ── Load Screen ───────────────────────────────────────────────────────────
    // screenId may be:
    //   - internal DB id (hex 24-char, e.g. "69d24c106543f10ff962e6bd")
    //   - public_token UUID (hyphenated, e.g. "4cd0497f-fd5e-4460-a1c9-a78622558349")
    // Player app uses public_token in its URLs. Resolve whichever is supplied.
    const isPublicToken = screenId.includes('-');
    let screens;
    if (isPublicToken) {
      // Look up by public_token — do NOT fall back to id lookup (UUID format will throw)
      screens = await base44.asServiceRole.entities.Screen.filter({ public_token: screenId });
    } else {
      screens = await base44.asServiceRole.entities.Screen.filter({ id: screenId });
    }
    const screen = screens[0];

    // ── Load PublishedScreen ──────────────────────────────────────────────────
    // CRITICAL: use screen.id (internal DB id) not screenId (which may be a public_token)
    const internalScreenId = screen.id;
    const publishedList = await base44.asServiceRole.entities.PublishedScreen.filter({ screen_id: internalScreenId });
    if (!publishedList.length) {
      return Response.json({
        screen_id: screenId,
        screen_name: screen.name,
        content_version: null,
        expires_hint: PAYLOAD_CACHE_SECONDS,
        status: 'no_published_state',
        zones: [],
        media_manifest: [],
      }, { status: 200, headers });
    }

    const publishedScreen = publishedList.sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0];
    console.log(`[screenPayload] publishedScreen=${publishedScreen.id} content_version=${publishedScreen.content_version}`);

    // ── Resolve device_safe_mode ──────────────────────────────────────────────
    // Screen-level setting overrides org-level default
    const deviceSafeMode = screen.device_safe_mode ?? appConfig?.default_device_safe_mode ?? false;

    // ── Load RuntimeZones ─────────────────────────────────────────────────────
    const runtimeZones = await base44.asServiceRole.entities.RuntimeZone.filter({
      published_screen_id: publishedScreen.id,
    });

    // Sort zones by z_index for deterministic render order
    const sortedZones = runtimeZones.sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1));
    const totalItems = sortedZones.reduce((sum, rz) => sum + (rz.playback_track?.items?.length || 0), 0);
    console.log(`[screenPayload] RESULT zones=${sortedZones.length} totalItems=${totalItems}`);
    if (sortedZones.length > 0) {
      const sample = sortedZones[0]?.playback_track?.items?.[0];
      console.log(`[screenPayload] ITEM_CONTRACT sample keys=${sample ? Object.keys(sample).join(',') : 'no items'}`);
    }

    // ── Build media_manifest ──────────────────────────────────────────────────
    // Collect all file_urls across all playback_track items, deduplicate by url
    const urlSet = new Set();
    for (const rz of sortedZones) {
      const items = rz.playback_track?.items || [];
      for (const item of items) {
        if (item.file_url) urlSet.add(item.file_url);
      }
    }

    // Load MediaAsset records by file_url for checksum/size metadata
    const mediaManifest = [];
    if (urlSet.size > 0) {
      const allFileUrls = [...urlSet];
      // Batch fetch — filter each url. Deduplicate by checksum.
      const checksumSeen = new Set();
      for (const fileUrl of allFileUrls) {
        const assets = await base44.asServiceRole.entities.MediaAsset.filter({ file_url: fileUrl });
        const asset = assets[0];
        const checksum = asset?.checksum || null;

        // If two URLs share a checksum, include only once
        if (checksum && checksumSeen.has(checksum)) continue;
        if (checksum) checksumSeen.add(checksum);

        // local_path: derive filename from url for player's local cache key
        const urlObj = new URL(fileUrl);
        const localPath = urlObj.pathname.split('/').pop() || `media_${checksumSeen.size}`;

        mediaManifest.push({
          url: fileUrl,
          local_path: localPath,
          file_type: asset?.file_type || guessFileType(fileUrl),
          size_bytes: asset?.file_size || null,
          checksum,
          width: asset?.width || null,
          height: asset?.height || null,
          duration: asset?.duration || null,
        });
      }
    }

    // ── Build zone output ─────────────────────────────────────────────────────
    const zones = sortedZones.map(rz => ({
      id: rz.id,
      layout_zone_id: rz.layout_zone_id,
      name: rz.name,
      x: rz.x ?? 0,
      y: rz.y ?? 0,
      width: rz.width,
      height: rz.height,
      z_index: rz.z_index ?? 1,
      fit_mode: rz.fit_mode || 'contain',
      background_color: rz.background_color || '#000000',
      volume: rz.volume ?? 100,
      content_source_type: rz.content_source_type || 'empty',
      canvas_creative_data: rz.canvas_creative_data || null,
      is_duplicate_of: rz.is_duplicate_of || null,
      playback_track: rz.playback_track || { loop: true, items: [] },
    }));

    // ── Native media manifest (roAssetFetcher format) ─────────────────────────
    // Only included when native_mode: true is in the request body.
    // BrightSign autorun.brs uses this to download all media to sd:/pool/
    // via roAssetFetcher + roAssetPool before launching the HTML canvas.
    let media_manifest = [];
    if (native_mode) {
      const seen = new Set();
      for (const zone of zones) {
        const items = zone.playback_track?.items || [];
        for (const item of items) {
          if (!item.file_url || seen.has(item.file_url)) continue;
          seen.add(item.file_url);

          // Build a filesystem-safe filename from the URL
          const urlPath = item.file_url.split('?')[0];
          const rawName = urlPath.split('/').pop() || 'asset';
          const safeName = rawName.replace(/[^a-zA-Z0-9._-]/g, '_');

          // Add local_name to the item so player.js can use sd:// path
          item.local_name = safeName;

          media_manifest.push({
            name: safeName,           // Used as roAssetFetcher Name field
            url: item.file_url,       // Original CDN URL for download
            sha1: item.checksum || null, // Checksum for cache validation (if stored)
            size: item.file_size || null, // File size in bytes (if stored)
            file_type: item.file_type || 'image',
          });
        }
      }
    }

    // ── Final payload ─────────────────────────────────────────────────────────
    return Response.json({
      status: 'ok',
      screen_id: screenId,
      screen_name: screen.name,
      screen_width: screen.width,
      screen_height: screen.height,
      asset_id: publishedScreen.asset_id,
      content_version: publishedScreen.content_version,
      published_at: publishedScreen.published_at,
      device_safe_mode: deviceSafeMode,
      expires_hint: PAYLOAD_CACHE_SECONDS,
      public_origin: publicOrigin,
      zones,
      media_manifest: mediaManifest,
      ...(native_mode ? { native_media_manifest: media_manifest } : {}),
    }, { status: 200, headers });

  } catch (error) {
    return Response.json({ error: error.message, status: 'error' }, { status: 500, headers });
  }
});

function guessFileType(url) {
  const ext = url.split('?')[0].split('.').pop()?.toLowerCase();
  if (['mp4', 'mov', 'webm', 'avi'].includes(ext)) return 'video';
  return 'image';
}