/**
 * generateWindowsInstaller — Electron-based Windows Player Setup Generator
 *
 * CLASSIFICATION: PLAYER-DELIVERY ONLY
 * Generates an Electron app launcher that points Windows PCs at the ScreenFleet Player app.
 *
 * MIGRATION NOTE:
 *   This function must be migrated to the ScreenFleet Player app once it exists.
 *   The generated Electron app must target the Player app origin, never the CMS.
 *   playerUrl MUST come from AppConfig.player_app_origin — never req.headers.get('origin').
 *
 * TODO (Player app migration):
 *   - Move this generator into the Player app backend
 *   - Generated app should load: ${PLAYER_APP_ORIGIN}/player?screenId=XXX
 *   - Remove from CMS once Player app is live
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // IMPORTANT: playerUrl MUST come from AppConfig.player_app_origin.
    // NEVER use req.headers.get('origin') — that is the CMS URL, not the Player app.
    // Accept from request body, or resolve from AppConfig.
    const body2 = await req.json().catch(() => ({}));
    let playerUrl = body2.playerUrl || null;
    if (!playerUrl) {
      // Try to resolve from AppConfig
      const configs = await base44.asServiceRole.entities.AppConfig.list().catch(() => []);
      playerUrl = configs[0]?.player_app_origin || null;
    }
    if (!playerUrl) {
      return Response.json({
        error: 'player_app_origin not configured. Set AppConfig.player_app_origin to the ScreenFleet Player app URL.',
        hint: 'This generator must target the Player app, not the CMS.',
      }, { status: 400 });
    }
    // Use /player route on the Player app
    const playerAppUrl = `${playerUrl.replace(/\/$/, '')}/player`;

    // Create electron-main.js
    const electronMain = `const { app, BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');
const Store = require('electron-store');

const store = new Store();
let mainWindow;

function getDisplays() {
  const displays = screen.getAllDisplays();
  return displays.map((display, index) => ({
    index,
    id: display.id,
    name: display.label || \`Monitor \${index + 1}\`,
    bounds: display.bounds,
    isPrimary: display.bounds.x === 0 && display.bounds.y === 0
  }));
}

function createWindow(screenId = null) {
  const displays = getDisplays();
  let targetDisplay = displays[0];

  if (screenId) {
    const found = displays.find(d => d.id.toString() === screenId.toString());
    if (found) targetDisplay = found;
  }

  mainWindow = new BrowserWindow({
    x: targetDisplay.bounds.x,
    y: targetDisplay.bounds.y,
    width: targetDisplay.bounds.width,
    height: targetDisplay.bounds.height,
    webPreferences: {
      preload: path.join(__dirname, 'electron-preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    },
    fullscreen: true,
    show: false
  });

  // PLAYER APP URL — points to ScreenFleet Player app, not the CMS.
  mainWindow.loadURL('${playerAppUrl}');
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
  mainWindow.show();
}

function createMonitorSelector() {
  const displays = getDisplays();
  const width = 400;
  const height = 300;
  const primary = screen.getPrimaryDisplay();
  
  const selectorWindow = new BrowserWindow({
    width,
    height,
    x: primary.bounds.x + (primary.bounds.width - width) / 2,
    y: primary.bounds.y + (primary.bounds.height - height) / 2,
    webPreferences: {
      preload: path.join(__dirname, 'electron-preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    },
    show: true
  });

  const html = \`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; margin: 0; }
        h1 { color: #333; margin-top: 0; }
        .monitor-list { margin: 20px 0; }
        .monitor-btn { 
          width: 100%; padding: 15px; margin: 8px 0; border: none; 
          background: #0066cc; color: white; border-radius: 5px; 
          cursor: pointer; font-size: 16px; font-weight: bold;
        }
        .monitor-btn:hover { background: #0052a3; }
      </style>
    </head>
    <body>
      <h1>Select Display Monitor</h1>
      <p>Which monitor should show your content?</p>
      <div class="monitor-list" id="monitors"></div>
      <script>
        const displays = \${JSON.stringify(displays)};
        const container = document.getElementById('monitors');
        displays.forEach(display => {
          const btn = document.createElement('button');
          btn.className = 'monitor-btn';
          btn.textContent = display.name + (display.isPrimary ? ' (Primary)' : '');
          btn.onclick = () => window.electronAPI.selectMonitor(display.id);
          container.appendChild(btn);
        });
      </script>
    </body>
    </html>
  \`;

  selectorWindow.loadDataURL(\`data:text/html;charset=utf-8,\${encodeURIComponent(html)}\`);
  return selectorWindow;
}

ipcMain.handle('select-monitor', (event, displayId) => {
  store.set('selectedMonitor', displayId);
  const selectorWindow = BrowserWindow.getAllWindows().find(w => w !== mainWindow);
  if (selectorWindow) selectorWindow.close();
  createWindow(displayId);
});

app.on('ready', () => {
  const savedMonitor = store.get('selectedMonitor');
  if (savedMonitor) {
    createWindow(savedMonitor);
  } else {
    createMonitorSelector();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (!mainWindow) createWindow();
});

if (process.platform === 'win32') {
  app.setLoginItemSettings({
    openAtLogin: true,
    path: app.getPath('exe')
  });
}`;

    // Create electron-preload.js
    const electronPreload = `const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  selectMonitor: (displayId) => ipcRenderer.invoke('select-monitor', displayId)
});`;

    // Create package.json
    const packageJson = {
      name: "screenfleet-player",
      version: "1.0.0",
      description: "ScreenFleet LED Display Player",
      main: "electron-main.js",
      scripts: {
        "build": "electron-builder"
      },
      devDependencies: {
        "electron": "^latest",
        "electron-builder": "^latest",
        "electron-store": "^latest"
      }
    };

    // Create a PowerShell script to set up the project
    const setupScript = `# ScreenFleet Player Setup Script
# Save this file as setup.ps1 and run it in PowerShell

$projectPath = "$env:USERPROFILE\\Documents\\screenfleet-player"

if (Test-Path $projectPath) {
    Write-Host "Project folder already exists. Using: $projectPath"
} else {
    New-Item -ItemType Directory -Path $projectPath | Out-Null
    Write-Host "Created project folder: $projectPath"
}

cd $projectPath

# Download the setup files from the server
$files = @{
    'electron-main.js' = '${electronMain.replace(/'/g, "''")}';
    'electron-preload.js' = '${electronPreload.replace(/'/g, "''")}';
    'package.json' = '${JSON.stringify(packageJson, null, 2).replace(/'/g, "''")}'
}

foreach ($file in $files.GetEnumerator()) {
    Set-Content -Path $file.Name -Value $file.Value -Encoding UTF8
    Write-Host "Created: $($file.Name)"
}

Write-Host ""
Write-Host "Setup complete! Installing dependencies..."
npm install

Write-Host ""
Write-Host "Building the application..."
npm run build

Write-Host ""
Write-Host "Success! Your installer is in the 'dist' folder."`;

    return Response.json({
      success: true,
      message: "Windows installer setup generated",
      files: {
        electronMain: electronMain,
        electronPreload: electronPreload,
        packageJson: packageJson,
        setupScript: setupScript
      },
      instructions: [
        "1. Download setup.ps1 (the PowerShell script)",
        "2. Right-click setup.ps1 and select 'Run with PowerShell'",
        "3. If prompted, type 'Y' to allow the script to run",
        "4. The script will create the project folder and install everything automatically"
      ]
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});