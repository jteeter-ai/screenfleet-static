import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import { ZipWriter, BlobWriter, TextReader, HttpReader } from 'npm:@zip.js/zip.js@2.7.52';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { truckId } = await req.json();
    if (!truckId) {
      return Response.json({ error: 'truckId is required' }, { status: 400 });
    }

    const truck = await base44.asServiceRole.entities.Truck.get(truckId);
    if (!truck) {
      return Response.json({ error: 'Truck not found' }, { status: 404 });
    }

    // Fetch screens and their zones
    const screens = await base44.asServiceRole.entities.Screen.filter({ truck_id: truckId });
    const schedules = await base44.asServiceRole.entities.Schedule.filter({ truck_id: truckId });

    // Collect all media files needed
    const mediaFiles = []; // { url, localPath }
    const urlToLocal = {};

    const addMedia = (url, folder) => {
      if (!url || urlToLocal[url]) return;
      const ext = url.split('?')[0].split('.').pop().split('/').pop() || 'bin';
      const fileName = `${folder}_${Object.keys(urlToLocal).length}.${ext}`;
      const localPath = `media/${fileName}`;
      urlToLocal[url] = localPath;
      mediaFiles.push({ url, localPath });
    };

    // Collect playlist items
    const playlists = await base44.asServiceRole.entities.Playlist.list();
    const playlistItems = await base44.asServiceRole.entities.PlaylistItem.list();
    for (const item of playlistItems) {
      if (item.file_url) addMedia(item.file_url, 'playlist');
    }

    // Collect rotation creatives
    const creatives = await base44.asServiceRole.entities.Creative.list();
    for (const c of creatives) {
      if (c.side_file_url) addMedia(c.side_file_url, 'creative');
      if (c.rear_file_url) addMedia(c.rear_file_url, 'creative');
      if (c.front_file_url) addMedia(c.front_file_url, 'creative');
    }

    // Collect zone media
    for (const screen of screens) {
      const zones = await base44.asServiceRole.entities.Zone.filter({ screen_id: screen.id });
      for (const zone of zones) {
        if (zone.media_url) addMedia(zone.media_url, 'zone');
      }
    }

    // Build schedule JSON for offline player
    const scheduleData = {
      truck: { id: truck.id, name: truck.name },
      generatedAt: new Date().toISOString(),
      screens: [],
      schedules: schedules.map(s => ({
        id: s.id,
        name: s.name,
        content_type: s.content_type,
        playlist_id: s.playlist_id,
        rotation_id: s.rotation_id,
        play_all_day: s.play_all_day,
        days_of_week: s.days_of_week,
        start_time: s.start_time,
        end_time: s.end_time,
        is_active: s.is_active,
        priority: s.priority,
        interrupt_others: s.interrupt_others,
      })),
      playlists: playlists.map(pl => ({
        id: pl.id,
        name: pl.name,
        default_duration: pl.default_duration || 8,
        loop: pl.loop !== false,
        items: playlistItems
          .filter(i => i.playlist_id === pl.id)
          .sort((a, b) => (a.order || 0) - (b.order || 0))
          .map(i => ({
            id: i.id,
            order: i.order,
            file_url: i.file_url ? `media/${urlToLocal[i.file_url]?.split('/').pop() || ''}` : null,
            local_path: i.file_url ? urlToLocal[i.file_url] : null,
            file_type: i.file_type,
            duration: i.duration,
          })),
      })),
      urlToLocal,
    };

    for (const screen of screens) {
      const zones = await base44.asServiceRole.entities.Zone.filter({ screen_id: screen.id });
      scheduleData.screens.push({
        id: screen.id,
        name: screen.name,
        width: screen.width,
        height: screen.height,
        zones: zones.map(z => ({
          ...z,
          media_url: z.media_url ? urlToLocal[z.media_url] : null,
        })),
      });
    }

    // Build the offline HTML player
    const offlinePlayer = buildOfflinePlayer(scheduleData);

    // Build the autorun.brs to load the offline player
    const autorunBrs = `' ScreenFleet BrightSign Offline Backup Autorun
' Asset: ${truck.name}
' Generated: ${new Date().toISOString()}

Sub Main()
    msgPort = CreateObject("roMessagePort")
    r = CreateObject("roRectangle", 0, 0, ${screens[0]?.width || 1920}, ${screens[0]?.height || 1080})

    config = { url: "file:///offline_player.html" }
    h = CreateObject("roHtmlWidget", r, config)
    h.SetPort(msgPort)
    Sleep(2000)
    h.Show()

    While True
        msg = Wait(0, msgPort)
        If Type(msg) = "roHtmlWidgetEvent" Then
            eventData = msg.GetData()
            If eventData.reason = "load-error" Then
                Sleep(3000)
                h.SetUrl("file:///offline_player.html")
            End If
        End If
    End While
End Sub
`;

    const readme = `ScreenFleet BrightSign OFFLINE BACKUP
======================================
Asset: ${truck.name}
Generated: ${new Date().toUTCString()}

This package is a FULL OFFLINE BACKUP of your current schedule and media.
If internet is lost, the BrightSign will play this cached content from the SD card.

CONTENTS
--------
autorun.brs          - BrightSign boot script (DO NOT RENAME)
offline_player.html  - Self-contained offline HTML player
schedule.json        - Schedule and playlist data
media/               - All media files (images, videos)

SETUP
-----
1. Format SD card as FAT32
2. Extract ALL files to the ROOT of the SD card (not in a subfolder)
3. Insert into BrightSign and power on

The offline player reads schedule.json and plays media/ files locally.
No internet connection is required.

Schedules included: ${schedules.length}
Media files: ${mediaFiles.length}
Screens: ${screens.length}
`;

    // Build ZIP
    const zipBlobWriter = new BlobWriter('application/zip');
    const zipWriter = new ZipWriter(zipBlobWriter);

    await zipWriter.add('autorun.brs', new TextReader(autorunBrs));
    await zipWriter.add('offline_player.html', new TextReader(offlinePlayer));
    await zipWriter.add('schedule.json', new TextReader(JSON.stringify(scheduleData, null, 2)));
    await zipWriter.add('README.txt', new TextReader(readme));

    // Download and embed media files
    for (const { url, localPath } of mediaFiles) {
      try {
        const mediaResponse = await fetch(url);
        if (mediaResponse.ok) {
          await zipWriter.add(localPath, new HttpReader(url));
        }
      } catch (e) {
        console.warn(`Failed to fetch media: ${url}`, e.message);
      }
    }

    await zipWriter.close();
    const zipBlob = await zipBlobWriter.getData();

    const arrayBuffer = await zipBlob.arrayBuffer();
    const uint8 = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < uint8.length; i++) {
      binary += String.fromCharCode(uint8[i]);
    }
    const base64 = btoa(binary);
    const filename = `${truck.name.replace(/\s+/g, '-').toLowerCase()}-offline-backup.zip`;

    return Response.json({ base64, filename, mediaCount: mediaFiles.length });

  } catch (error) {
    console.error('Error generating offline backup:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function buildOfflinePlayer(data) {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ScreenFleet Offline - ${data.truck.name}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: 100vw; height: 100vh; overflow: hidden; background: #000; }
    #player { width: 100%; height: 100%; position: relative; }
    .zone { position: absolute; overflow: hidden; }
    .zone img, .zone video { width: 100%; height: 100%; object-fit: cover; display: block; }
  </style>
</head>
<body>
  <div id="player"></div>
  <script>
    const scheduleData = ${JSON.stringify(data)};

    // Find current active schedule
    function getActiveSchedule() {
      const now = new Date();
      const day = now.getDay();
      const time = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
      const active = scheduleData.schedules
        .filter(s => {
          if (!s.is_active) return false;
          if (s.play_all_day) return true;
          return (s.days_of_week || []).includes(day) && s.start_time <= time && s.end_time >= time;
        })
        .sort((a, b) => {
          if (b.interrupt_others !== a.interrupt_others) return b.interrupt_others ? 1 : -1;
          return (b.priority || 1) - (a.priority || 1);
        });
      return active[0] || scheduleData.schedules.find(s => s.is_active) || null;
    }

    // Playlist player
    function playPlaylist(container, playlistId) {
      const playlist = scheduleData.playlists.find(p => p.id === playlistId);
      if (!playlist || !playlist.items.length) return;
      const items = playlist.items.filter(i => i.local_path);
      if (!items.length) return;

      let idx = 0;
      function showItem() {
        container.innerHTML = '';
        const item = items[idx];
        const duration = (item.duration || playlist.default_duration || 8) * 1000;
        let el;
        if (item.file_type === 'video') {
          el = document.createElement('video');
          el.autoplay = true;
          el.muted = true;
          el.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
          el.onended = () => { idx = (idx + 1) % items.length; showItem(); };
          el.src = item.local_path;
        } else {
          el = document.createElement('img');
          el.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;';
          el.src = item.local_path;
          setTimeout(() => { idx = (idx + 1) % items.length; showItem(); }, duration);
        }
        container.appendChild(el);
      }
      showItem();
    }

    function renderScreen(screen) {
      const player = document.getElementById('player');
      player.innerHTML = '';
      player.style.width = (screen.width || window.innerWidth) + 'px';
      player.style.height = (screen.height || window.innerHeight) + 'px';

      const schedule = getActiveSchedule();

      // Override zones based on schedule content
      const zones = screen.zones || [];
      zones.filter(z => z.is_visible !== false).sort((a,b) => (a.z_index||0)-(b.z_index||0)).forEach(zone => {
        const div = document.createElement('div');
        div.className = 'zone';
        div.style.left = (zone.x || 0) + 'px';
        div.style.top = (zone.y || 0) + 'px';
        div.style.width = (zone.width || 0) + 'px';
        div.style.height = (zone.height || 0) + 'px';
        div.style.zIndex = zone.z_index || 1;
        div.style.background = zone.background_color || '#000';

        // Use scheduled content if available
        let contentType = zone.content_type;
        let playlistId = zone.playlist_id;
        if (schedule && schedule.content_type === 'playlist' && schedule.playlist_id) {
          contentType = 'playlist';
          playlistId = schedule.playlist_id;
        }

        if (contentType === 'playlist' && playlistId) {
          playPlaylist(div, playlistId);
        } else if (contentType === 'image' && zone.media_url) {
          const img = document.createElement('img');
          img.src = zone.media_url;
          div.appendChild(img);
        } else if (contentType === 'video' && zone.media_url) {
          const vid = document.createElement('video');
          vid.src = zone.media_url;
          vid.autoplay = true;
          vid.loop = true;
          vid.muted = true;
          div.appendChild(vid);
        }

        player.appendChild(div);
      });
    }

    // Start playback
    if (scheduleData.screens && scheduleData.screens.length > 0) {
      renderScreen(scheduleData.screens[0]);
    }

    // Re-check schedule every minute
    setInterval(() => {
      if (scheduleData.screens && scheduleData.screens.length > 0) {
        renderScreen(scheduleData.screens[0]);
      }
    }, 60000);
  </script>
</body>
</html>`;
}