import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const DEFAULTS = {
  public_app_origin: 'https://app.screenfleet.io',
  player_app_origin: 'https://player.screenfleet.io',
  player_route: '/player',
  payload_function: 'screenPayload',
  version_function: 'screenVersionCheck',
  environment: 'production',
};

/**
 * getAppConfig — reads the singleton AppConfig record.
 * Auto-seeds with defaults if no record exists (safe idempotent operation).
 * No auth required — config is non-sensitive and needed by players.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const existing = await base44.asServiceRole.entities.AppConfig.list();

    if (existing.length > 0) {
      const merged = { ...DEFAULTS, ...existing[0] };
      return Response.json({ config: merged });
    }

    // Auto-seed on first access
    console.log('[getAppConfig] No config found — seeding defaults');
    const config = await base44.asServiceRole.entities.AppConfig.create(DEFAULTS);

    return Response.json({ config, seeded: true });
  } catch (error) {
    console.error('[getAppConfig] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});