import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Map Legion Hub plan tiers to ScreenFleet plan slugs and modules
const HUB_PLAN_MAP = {
  hub_starter:    { plan_slug: 'starter',  modules: ['module_assets', 'module_playlists', 'module_scheduling'] },
  hub_pro:        { plan_slug: 'growth',   modules: ['module_assets', 'module_playlists', 'module_scheduling', 'module_studio', 'module_media_library'] },
  hub_enterprise: { plan_slug: 'total360', modules: ['module_assets', 'module_playlists', 'module_scheduling', 'module_studio', 'module_media_library', 'module_ooh_operator', 'module_ooh_reporting'] },
};

Deno.serve(async (req) => {
  try {
    // Verify the request is from Legion Hub using a shared secret
    const hubSecret = Deno.env.get('LEGION_HUB_WEBHOOK_SECRET');
    const signature = req.headers.get('x-legion-hub-signature');
    if (!hubSecret || signature !== hubSecret) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { hub_org_id, hub_plan_tier, screenfleet_org_id, action } = body;
    // action: 'grant' | 'revoke' | 'upgrade' | 'downgrade'

    if (!screenfleet_org_id || !action) {
      return Response.json({ error: 'Missing screenfleet_org_id or action' }, { status: 400 });
    }

    const orgs = await base44.asServiceRole.entities.Organization.filter({ id: screenfleet_org_id });
    const org = orgs[0];
    if (!org) return Response.json({ error: 'Org not found' }, { status: 404 });

    if (action === 'grant' || action === 'upgrade' || action === 'downgrade') {
      const mapping = HUB_PLAN_MAP[hub_plan_tier] || HUB_PLAN_MAP['hub_starter'];
      await base44.asServiceRole.entities.Organization.update(org.id, {
        plan_source: 'legion_hub',
        legion_hub_org_id: hub_org_id,
        legion_hub_plan_tier: hub_plan_tier,
        plan_slug: mapping.plan_slug,
        plan_modules_resolved: mapping.modules,
        subscription_status: 'active',
        plan_expires_at: null,
      });
      console.log(`[legionHubWebhook] ${action} org=${org.id} hub_tier=${hub_plan_tier}`);
      return Response.json({ ok: true, action, org_id: org.id, plan_slug: mapping.plan_slug });
    }

    if (action === 'revoke') {
      await base44.asServiceRole.entities.Organization.update(org.id, {
        subscription_status: 'canceled',
        plan_slug: null,
        plan_modules_resolved: [],
        legion_hub_plan_tier: null,
      });
      console.log(`[legionHubWebhook] revoked org=${org.id}`);
      return Response.json({ ok: true, action: 'revoked', org_id: org.id });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (err) {
    console.error('[legionHubWebhook] error:', err?.message);
    return Response.json({ error: err?.message }, { status: 500 });
  }
});