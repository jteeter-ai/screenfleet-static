import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

/**
 * DIRECT FIX: Update RuntimeZone fit_mode from 'fill' to 'contain'
 * POST { asset_id }
 * 
 * This directly patches existing RuntimeZone records to correct the fit_mode.
 * After the screenPayload fix, new publishes will use 'contain' by default.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { asset_id } = await req.json();
    if (!asset_id) return Response.json({ error: 'asset_id required' }, { status: 400 });

    console.log('[fixRuntimeZoneFitMode] Fixing RuntimeZones for asset:', asset_id);

    // Get asset
    const assets = await base44.asServiceRole.entities.Asset.filter({ id: asset_id });
    const asset = assets[0];
    if (!asset) return Response.json({ error: `Asset not found: ${asset_id}` }, { status: 404 });

    // Validate org access
    if (user.role !== 'admin') {
      const memberships = await base44.entities.OrgMember.filter({ user_email: user.email, org_id: asset.org_id });
      if (!memberships.length) {
        return Response.json({ error: `Forbidden: access denied to org ${asset.org_id}` }, { status: 403 });
      }
    }

    // Get all PublishedScreens for this asset
    const publishedScreens = await base44.asServiceRole.entities.PublishedScreen.filter({ asset_id });
    console.log('[fixRuntimeZoneFitMode] Found PublishedScreens:', publishedScreens.length);

    const fixedZones = [];
    for (const ps of publishedScreens) {
      const runtimeZones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: ps.id });
      console.log(`[fixRuntimeZoneFitMode] Processing PublishedScreen ${ps.id}: ${runtimeZones.length} zones`);

      for (const rz of runtimeZones) {
        if (rz.fit_mode === 'fill') {
          await base44.asServiceRole.entities.RuntimeZone.update(rz.id, { fit_mode: 'contain' });
          fixedZones.push({
            id: rz.id,
            name: rz.name,
            old_fit_mode: 'fill',
            new_fit_mode: 'contain',
          });
          console.log(`[fixRuntimeZoneFitMode] Updated zone ${rz.id} "${rz.name}": fill -> contain`);
        }
      }
    }

    // Verify the changes
    const verification = [];
    for (const ps of publishedScreens) {
      const runtimeZones = await base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: ps.id });
      verification.push({
        published_screen_id: ps.id,
        zones: runtimeZones.map(rz => ({ id: rz.id, name: rz.name, fit_mode: rz.fit_mode })),
      });
    }

    return Response.json({
      status: 'ok',
      asset_id,
      asset_name: asset.name,
      zones_fixed: fixedZones.length,
      fixed_zones: fixedZones,
      verification,
    });
  } catch (error) {
    console.error('[fixRuntimeZoneFitMode] ERROR:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});