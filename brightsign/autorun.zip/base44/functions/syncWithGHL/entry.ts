import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { orgId, ghlAccountId } = await req.json();
    const ghlKey = Deno.env.get('GHL_API_KEY');

    if (!ghlKey) {
      return Response.json({ error: 'GHL integration not configured' }, { status: 500 });
    }

    // Fetch org data
    const orgs = await base44.asServiceRole.entities.Organization.filter({ id: orgId });
    if (orgs.length === 0) {
      return Response.json({ error: 'Organization not found' }, { status: 404 });
    }

    const org = orgs[0];

    // Sync org data to GHL
    const response = await fetch(`https://services.leadconnectorhq.com/agencies/${ghlAccountId}/organizations`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${ghlKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: org.name,
        email: org.billing_email || org.owner_email,
        address: org.address,
        phone: org.phone,
        website: org.website,
        customData: {
          adtruckOrgId: org.id,
          subscriptionStatus: org.subscription_status,
          plan: org.plan_slug
        }
      })
    });

    if (!response.ok) {
      throw new Error(`GHL sync failed: ${response.statusText}`);
    }

    const result = await response.json();
    return Response.json({ success: true, result });
  } catch (error) {
    console.error('GHL sync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});