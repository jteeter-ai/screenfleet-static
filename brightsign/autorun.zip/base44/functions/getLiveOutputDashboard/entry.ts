/**
 * getLiveOutputDashboard
 * POST { org_id }
 *
 * V2 ONLY — PublishedScreen + RuntimeZone. No Zone, Truck, Layout, liveOutputData, getScreenPayload.
 * Returns warnings array and debug block so UI can surface real failures.
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { org_id } = await req.json();
    if (!org_id) return Response.json({ error: 'org_id required' }, { status: 400 });

    // Validate membership (platform admins bypass; org members need a recognized role)
    if (user.role !== 'admin') {
      const memberships = await base44.asServiceRole.entities.OrgMember.filter({ user_email: user.email, org_id });
      const member = memberships[0];
      if (!member || !['owner', 'admin', 'manager', 'ops_manager', 'operator', 'viewer', 'content_manager', 'scheduler', 'screen_operator', 'analyst'].includes(member.org_role)) {
        return Response.json({ error: 'Forbidden: insufficient org permissions' }, { status: 403 });
      }
    }

    // Use service role to read PublishedScreen regardless of entity permissions
    const publishedScreens = await base44.asServiceRole.entities.PublishedScreen.filter({ org_id });

    console.log('[getLiveOutputDashboard] fetched published screens', {
      org_id,
      published_count: publishedScreens.length,
      ids: publishedScreens.map(ps => ps.id),
    });

    const warnings = [];

    if (!publishedScreens.length) {
      return Response.json({
        org_id,
        published_count: 0,
        assets: [],
        warnings: [],
        debug: { published_screen_ids: [], asset_ids: [], screen_ids: [] },
      });
    }

    // Deduplicate: per screen_id keep newest published_at
    const newestByScreen = {};
    for (const ps of publishedScreens) {
      const existing = newestByScreen[ps.screen_id];
      if (!existing || new Date(ps.published_at) > new Date(existing.published_at)) {
        newestByScreen[ps.screen_id] = ps;
      }
    }
    const dedupedScreens = Object.values(newestByScreen);

    const screenIds = [...new Set(dedupedScreens.map(ps => ps.screen_id))];
    const assetIds = [...new Set(dedupedScreens.map(ps => ps.asset_id).filter(Boolean))];
    const psIds = dedupedScreens.map(ps => ps.id);

    // Load screens, assets, runtime zones in parallel using batch $in queries
    const [screenResults, assetResults, runtimeZoneResults] = await Promise.all([
      screenIds.length ? base44.asServiceRole.entities.Screen.filter({ id: { $in: screenIds } }) : Promise.resolve([]),
      assetIds.length ? base44.asServiceRole.entities.Asset.filter({ id: { $in: assetIds } }) : Promise.resolve([]),
      psIds.length ? base44.asServiceRole.entities.RuntimeZone.filter({ published_screen_id: { $in: psIds } }) : Promise.resolve([]),
    ]);

    const screenMap = Object.fromEntries(screenResults.filter(Boolean).map(s => [s.id, s]));
    const assetMap = Object.fromEntries(assetResults.filter(Boolean).map(a => [a.id, a]));
    const runtimeZoneMap = {};
    for (const rz of runtimeZoneResults) {
      if (!runtimeZoneMap[rz.published_screen_id]) runtimeZoneMap[rz.published_screen_id] = [];
      runtimeZoneMap[rz.published_screen_id].push(rz);
    }

    // Check for missing screen records
    for (const ps of dedupedScreens) {
      if (!screenMap[ps.screen_id]) {
        warnings.push(`PublishedScreen ${ps.id} references screen_id=${ps.screen_id} but no Screen record was found. Screen may be deleted.`);
      }
      if (!runtimeZoneMap[ps.id]?.length) {
        warnings.push(`PublishedScreen ${ps.id} (screen=${ps.screen_id}) has no RuntimeZone records. Publish may have failed or zones were deleted.`);
      }
    }

    // Check for missing asset records
    for (const assetId of assetIds) {
      if (!assetMap[assetId]) {
        warnings.push(`PublishedScreen references asset_id=${assetId} but no Asset record was found.`);
      }
    }

    // Group by asset_id
    const assetGroups = {};
    for (const ps of dedupedScreens) {
      const key = ps.asset_id || 'unknown';
      if (!assetGroups[key]) assetGroups[key] = [];
      const screen = screenMap[ps.screen_id] || {};
      assetGroups[key].push({
        published_screen_id: ps.id,
        screen_id: ps.screen_id,
        public_token: screen.public_token || null,
        screen_name: screen.name || `[Screen ${ps.screen_id}]`,
        width: screen.width || 1920,
        height: screen.height || 1080,
        position: screen.position || null,
        published_at: ps.published_at,
        content_version: ps.content_version,
        runtime_zones: runtimeZoneMap[ps.id] || [],
      });
    }

    const resultAssets = Object.entries(assetGroups).map(([asset_id, screenList]) => {
      const asset = assetMap[asset_id] || {};
      return {
        asset_id,
        asset_name: asset.name || `[Asset ${asset_id}]`,
        asset_type: asset.asset_type || null,
        screens: screenList,
      };
    });

    console.log('[getLiveOutputDashboard] result', {
      org_id,
      published_count: dedupedScreens.length,
      asset_count: resultAssets.length,
      warning_count: warnings.length,
      warnings,
    });

    return Response.json({
      org_id,
      published_count: dedupedScreens.length,
      assets: resultAssets,
      warnings,
      debug: {
        published_screen_ids: psIds,
        asset_ids: assetIds,
        screen_ids: screenIds,
      },
    });

  } catch (error) {
    console.error('[getLiveOutputDashboard] ERROR:', error.message, error.stack);
    return Response.json({ error: error.message }, { status: 500 });
  }
});