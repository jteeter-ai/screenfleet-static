import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { orgId } = await req.json();

    if (!orgId) {
      return Response.json({ error: 'orgId is required' }, { status: 400 });
    }

    // Fetch organization
    const orgs = await base44.asServiceRole.entities.Organization.filter({ id: orgId });
    if (!orgs || orgs.length === 0) {
      return Response.json({ error: 'Organization not found' }, { status: 404 });
    }

    const org = orgs[0];
    const billingEmail = org.billing_email || org.owner_email;
    const trialEndsAt = org.trial_ends_at ? new Date(org.trial_ends_at) : null;
    const planExpiresAt = org.plan_expires_at ? new Date(org.plan_expires_at) : null;
    const expiryDate = trialEndsAt || planExpiresAt;

    if (!expiryDate) {
      return Response.json({ success: false, reason: 'No trial or plan expiry date' });
    }

    const appUrl = new URL(req.url).origin;
    const upgradeUrl = `${appUrl}/auth/login?redirect=app-settings`;

    const emailBody = `
<h2>Your ScreenFleet Plan Renewal Notice</h2>
<p>Hello,</p>
<p>This is a friendly reminder that your <strong>${org.name}</strong> ScreenFleet plan will expire on <strong>${expiryDate.toLocaleDateString()}</strong>.</p>

<h3>What Happens Next?</h3>
<ul>
  <li>Your organization will remain active until the expiry date</li>
  <li>After expiration, your screens will go offline</li>
  <li>Content and schedules will be preserved</li>
</ul>

<h3>Renew Your Plan</h3>
<p>
  <a href="${upgradeUrl}" style="display: inline-block; padding: 10px 20px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px;">View Plan Options</a>
</p>

<p style="margin-top: 20px; font-size: 12px; color: #666;">
  Questions? Contact our support team at support@screenfleet.com
</p>
<p>Best regards,<br>ScreenFleet Team</p>
    `;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: billingEmail,
      subject: `Action Required: Renew Your ScreenFleet Plan - Expires ${expiryDate.toLocaleDateString()}`,
      body: emailBody,
      from_name: 'ScreenFleet Billing'
    });

    return Response.json({ success: true, sentTo: billingEmail });
  } catch (error) {
    console.error('Error sending billing reminder:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});