# Screen Lifecycle Implementation Checklist

## ✅ PART 1: Screen Lifecycle States

**Deliverable:** Screen entity with new `status` field

- [x] Added `status` enum: `["active", "archived", "deleted_internal"]`
- [x] Added `token_regenerated_at` field for token regeneration tracking
- [x] Renamed old `status` (online/offline/error) to `lifecycle_status` to avoid confusion
- [x] Default: `status = "active"`
- [x] File: `entities/Screen.json`

---

## ✅ PART 2: Stable Public Token

**Deliverable:** Token immutability + explicit regeneration action

- [x] `public_token` remains unchanged during normal screen edits
- [x] Only explicit admin action `regenerateScreenToken()` creates new token
- [x] Old token is deactivated on Player when regenerated
- [x] New field `token_regenerated_at` tracks regeneration history
- [x] File: `functions/regenerateScreenToken.js`

---

## ✅ PART 3: Transactional Delete/Archive Cleanup

**Deliverable:** Archive and Delete functions with automated cleanup

### Archive Flow
- [x] Function: `functions/archiveScreen.js`
  - [x] Validate screen exists and is active
  - [x] Delete all AssetLayout records
  - [x] Delete all PublishedScreen records
  - [x] Change Screen.status to "archived"
  - [x] Call Player API: `action: "deactivate"`
  - [x] Audit logging
  - [x] Return cleanup summary

### Hard Delete Flow
- [x] Function: `functions/deleteScreen.js`
  - [x] Admin-only validation
  - [x] Verify screen is archived first
  - [x] Call Player API: `action: "delete"`
  - [x] Hard delete Screen record
  - [x] Audit logging

---

## ✅ PART 4: Data Integrity Constraints

**Deliverable:** Validators + constraint enforcement

- [x] Function: `functions/validateScreenIntegrity.js`
  - [x] Rule 1: No duplicate active tokens
  - [x] Rule 2: No duplicate active screens per asset (warning if found)
  - [x] Rule 3: No AssetLayout pointing to non-existent screen
  - [x] Rule 4: No PublishedScreen pointing to non-existent screen
  - [x] Rule 5: All RuntimeZones have valid published_screen_id
  - [x] Returns violations with severity levels
  - [x] Admin-only access

---

## ✅ PART 5: Orphan Detection & Repair

**Deliverable:** Enhanced repair function with lifecycle awareness

- [x] Function: `functions/repairScreenIntegrity.js`
  - [x] Enhanced to distinguish between active/archived/deleted screens
  - [x] Find AssetLayout pointing to non-active screens
  - [x] Find PublishedScreen pointing to non-active screens
  - [x] Find orphaned RuntimeZones
  - [x] Find Player ghost rows (if Player supports delete API)
  - [x] Dry-run mode for preview
  - [x] Safe cleanup with audit logging
  - [x] Admin-only access

---

## ✅ PART 6: Delete/Archive UX Warnings

**Deliverable:** Pre-delete modal with impact summary

- [x] Component: `components/ScreenDeleteWarning.jsx`
  - [x] Shows screen name, token, player URL
  - [x] Displays AssetLayout count to be deleted
  - [x] Displays PublishedScreen count to be deleted
  - [x] Shows Player impact (deactivate/delete)
  - [x] Warns about device reprovisioning
  - [x] Accessible modal with confirm/cancel
  - [x] Supports both archive and permanent delete modes

---

## ✅ PART 7: Deliverables Complete

| Item | Delivered | File |
|---|---|---|
| 1 | Lifecycle/state model | `entities/Screen.json`, `SCREEN_LIFECYCLE_DESIGN.md` |
| 2 | CMS archive flow | `functions/archiveScreen.js` |
| 3 | CMS delete flow | `functions/deleteScreen.js` |
| 4 | Token regeneration | `functions/regenerateScreenToken.js` |
| 5 | Player API spec | `PLAYER_API_CHANGES.md` |
| 6 | Orphan detection/repair | `functions/repairScreenIntegrity.js` |
| 7 | Integrity validation | `functions/validateScreenIntegrity.js` |
| 8 | Pre-delete UX warning | `components/ScreenDeleteWarning.jsx` |
| 9 | Design documentation | `SCREEN_LIFECYCLE_DESIGN.md` |

---

## Next Steps: Integration into UI

To complete the hardening, the following screens should be updated to use these functions:

1. **Asset → Screens list**: Update delete button to call `archiveScreen()` instead of hard delete
2. **Screen detail**: Add "Archive Screen" action with `ScreenDeleteWarning` modal
3. **Screen detail**: Add admin-only "Regenerate Player URL" action
4. **Admin tools**: Add "Run Integrity Check" button → `validateScreenIntegrity()`
5. **Admin tools**: Add "Repair Orphaned Records" button → `repairScreenIntegrity()`

---

## Verification Checklist

After UI integration:

- [ ] Deleting a screen no longer hard deletes immediately
- [ ] Archive action cleans up AssetLayout + PublishedScreen records
- [ ] Archive action deactivates token on Player
- [ ] `public_token` remains stable across screen edits
- [ ] `public_token` only changes on explicit admin regeneration
- [ ] No duplicate active screens per asset after cleanup
- [ ] Player has no multiple active rows for same token
- [ ] All delete/archive actions are logged
- [ ] Orphan detection finds orphaned records correctly
- [ ] UI warns users of impact before archiving
- [ ] Archived screens are hidden from normal workflows (UI filter)