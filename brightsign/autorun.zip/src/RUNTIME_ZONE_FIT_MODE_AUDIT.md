# RuntimeZone fit_mode Audit Report
**Date:** 2026-04-05  
**Scope:** All published RuntimeZone records across all organizations and assets

---

## Executive Summary

| Metric | Value |
|--------|-------|
| **Total RuntimeZone records** | 38 |
| **Records with fit_mode = "fill"** | 28 (73.68%) |
| **Organizations affected** | 4 |
| **Assets with fill zones** | 8 |

---

## Key Findings

### 1. High Legacy Fill Prevalence
- **73.68% of all zones** still use `fit_mode: "fill"` (28 of 38 total)
- This significantly exceeds the expected proportion after the system-wide update to `"contain"`
- Strong indicator that published assets have not been republished since the screenPayload.js fix

### 2. Ad-Display Zone Concentration
- **All 28 fill zones are ad-display zones** (playlists, presentations, rotation content)
- These zones are critical for advertiser content and should prioritize `"contain"` to prevent unwanted cropping/scaling
- No non-display zones (HDMI input, canvas, empty) are affected by fill mode

### 3. Legacy vs. Intentional Classification
- **Legacy/stale fill zones:** 10 zones (35.7% of fill zones)
  - Created >7 days before latest screen update
  - Fit mode diverges from LayoutZone defaults
  - Small/medium zones unlikely to be intentionally set to fill
- **Intentional fill zones:** 18 zones (64.3% of fill zones)
  - Uniform fit mode across multiple zones in same layout (suggests deliberate setting)
  - May have been set for specific rendering reasons

---

## Detailed Breakdown by Asset

### 1. **Legion LED Trucks** Organization

#### Asset: Truck 119
- **Total zones:** 9 | **Fill zones:** 9 (100%)
- **Ad-display zones:** 9 (100%)
- **Legacy fill:** 3 | **Intentional fill:** 6
- **Screens affected:** "Truck 119 3-Zone"
- **Zones:**
  - ✓ Passenger Screen (1024×512, playlist) — Legacy fill
  - ✓ Rear Screen (512×512, playlist) — Legacy fill
  - ✓ Driver Screen (512×1024, playlist) — Legacy fill
  - ✓ Bottom Banner (512×256, playlist) — Intentional fill
  - ✓ Center Spot (512×512, presentation) — Intentional fill
  - ✓ Top Ad (512×256, presentation) — Intentional fill
  - ✓ Left Zone (256×512, playlist) — Intentional fill
  - ✓ Right Zone (256×512, playlist) — Intentional fill
  - ✓ Accent Spot (128×128, playlist) — Intentional fill
- **Status:** Requires republish; mix of legacy and intentional settings

#### Asset: Truck 120
- **Total zones:** 6 | **Fill zones:** 6 (100%)
- **Ad-display zones:** 6 (100%)
- **Legacy fill:** 2 | **Intentional fill:** 4
- **Screens affected:** "Truck 120 2-Zone", "Truck 120 Full Screen"
- **Zones:**
  - ✓ Left Screen (512×1024, playlist) — Legacy fill
  - ✓ Right Screen (512×1024, playlist) — Legacy fill
  - ✓ Main Display (1024×1024, presentation) — Intentional fill
  - ✓ Ticker (1024×128, playlist) — Intentional fill
  - ✓ Corner Ad (256×256, playlist) — Intentional fill
  - ✓ Overlay (512×512, presentation) — Intentional fill
- **Status:** Mixed; requires evaluation before republish

#### Asset: Legion Truck 1
- **Total zones:** 6 | **Fill zones:** 0 (0%)
- **Status:** ✅ Already corrected (recent fix applied)

#### Asset: Truck 100
- **Total zones:** 3 | **Fill zones:** 3 (100%)
- **Ad-display zones:** 3 (100%)
- **Legacy fill:** 3 | **Intentional fill:** 0
- **Screens affected:** "Truck 100"
- **Zones:**
  - ✓ Side Panel (256×512, playlist) — Legacy fill
  - ✓ Bottom Strip (1024×256, playlist) — Legacy fill
  - ✓ Upper Ad (512×256, playlist) — Legacy fill
- **Status:** All legacy; prime candidate for automatic fix

---

### 2. **Marketing Collective** Organization

#### Asset: Mobile Billboard A
- **Total zones:** 2 | **Fill zones:** 2 (100%)
- **Ad-display zones:** 2 (100%)
- **Legacy fill:** 2 | **Intentional fill:** 0
- **Screens affected:** "Mobile Billboard A"
- **Zones:**
  - ✓ Main Display (1024×768, playlist) — Legacy fill
  - ✓ Ticker Zone (1024×128, playlist) — Legacy fill
- **Status:** All legacy; simple republish candidate

#### Asset: Mobile Billboard B
- **Total zones:** 2 | **Fill zones:** 0 (0%)
- **Status:** ✅ Already corrected

---

### 3. **EventPros** Organization

#### Asset: Event Screen 1
- **Total zones:** 2 | **Fill zones:** 1 (50%)
- **Ad-display zones:** 1 (100%)
- **Legacy fill:** 0 | **Intentional fill:** 1
- **Screens affected:** "Event Screen 1"
- **Zones:**
  - ✓ Content Zone (512×512, playlist) — Intentional fill
  - ✓ Static Background (1024×1024, empty) — No fill issue
- **Status:** Single intentional fill; evaluate before change

---

### 4. **Campus Broadcasting** Organization

#### Asset: Stadium Display
- **Total zones:** 8 | **Fill zones:** 6 (75%)
- **Ad-display zones:** 6 (100% of fill zones)
- **Legacy fill:** 0 | **Intentional fill:** 6
- **Screens affected:** "Main Display", "Secondary Display"
- **Zones:**
  - ✓ Main Ad Zone (1920×1080, presentation) — Intentional fill
  - ✓ Scoreboard Insert (512×256, playlist) — Intentional fill
  - ✓ Side Banner (256×1080, playlist) — Intentional fill
  - ✓ Corner Logo (256×256, empty) — No fill issue
  - ✓ Lower Third (1920×256, presentation) — Intentional fill
  - ✓ Sponsorship Spot (512×512, playlist) — Intentional fill
  - ✓ Game Feed (960×720, hdmi_input) — No fill issue
  - ✓ Static Overlay (1920×1080, canvas_creative) — No fill issue
- **Status:** Intentional settings; do not change without verification

---

## Recommendations

### Priority 1: Automatic Legacy Fix (Safe)
**Assets to republish immediately:**
- **Truck 100** (Legion LED Trucks) — 3 zones, all legacy fill
- **Mobile Billboard A** (Marketing Collective) — 2 zones, all legacy fill

**Action:** Use `fixRuntimeZoneFitMode()` to update these zones directly to `"contain"`.

### Priority 2: Verify Intentional Settings
**Assets requiring review before any change:**
- **Truck 119** (Legion LED Trucks) — 6 intentional fill zones mixed with legacy
- **Truck 120** (Legion LED Trucks) — 4 intentional fill zones mixed with legacy
- **Stadium Display** (Campus Broadcasting) — 6 intentional fill zones
- **Event Screen 1** (EventPros) — 1 intentional fill zone

**Action:** Contact asset owners to confirm fill mode intent. Document decisions before republishing.

### Priority 3: Already Corrected ✅
- **Legion Truck 1** (Legion LED Trucks) — Recently fixed via `fixRuntimeZoneFitMode()`
- **Mobile Billboard B** (Marketing Collective) — Already uses `"contain"`

---

## Summary Table: All Assets

| Organization | Asset | Total Zones | Fill Count | Ad Zones | Legacy | Intentional | Status |
|--------------|-------|-------------|-----------|----------|--------|------------|--------|
| Legion LED | Truck 119 | 9 | 9 | 9 | 3 | 6 | Review |
| Legion LED | Truck 120 | 6 | 6 | 6 | 2 | 4 | Review |
| Legion LED | Legion Truck 1 | 6 | 0 | 0 | — | — | ✅ Fixed |
| Legion LED | Truck 100 | 3 | 3 | 3 | 3 | 0 | Fix Now |
| Marketing | Mobile Billboard A | 2 | 2 | 2 | 2 | 0 | Fix Now |
| Marketing | Mobile Billboard B | 2 | 0 | 0 | — | — | ✅ Fixed |
| EventPros | Event Screen 1 | 2 | 1 | 1 | 0 | 1 | Review |
| Campus | Stadium Display | 8 | 6 | 6 | 0 | 6 | Review |

---

## Data Quality Notes

1. **Legacy Detection Logic:**
   - Zone created >7 days before screen last update
   - Fit mode diverges from LayoutZone default setting
   - Occupies <50% of screen canvas (typical ad placement)

2. **Ad-Display Classification:**
   - Content source types: playlist, presentation, route_presentation
   - Zone name patterns: "spot", "ad", "creative", "rotation", "presentation", "display"
   - Excludes HDMI input, canvas creatives, and empty zones

3. **Intentional Fill Zones:**
   - May indicate deliberate scaling behavior for specific advertiser content
   - Requires owner confirmation before changing

---

## No Changes Made
This is an audit report only. No RuntimeZone records were modified.