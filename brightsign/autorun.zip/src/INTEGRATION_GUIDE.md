# Integration Guide: Screen Lifecycle Hardening

This guide shows how to integrate the new lifecycle system into existing screens and components.

---

## 1. Screen List / Asset Details Page

### Current Delete Behavior
```jsx
// OLD: Direct hard delete
const handleDelete = async (screenId) => {
  await base44.entities.Screen.delete(screenId);
  refetch();
};
```

### New Archive Behavior
```jsx
import { useState } from 'react';
import ScreenDeleteWarning from '@/components/ScreenDeleteWarning';
import { base44 } from '@/api/base44Client';

function ScreenListItem({ screen }) {
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleArchive = async () => {
    setDeleting(true);
    try {
      await base44.functions.invoke('archiveScreen', { screen_id: screen.id });
      // Refresh list
      refetch();
    } catch (err) {
      alert('Archive failed: ' + err.message);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <>
      <div className="flex items-center justify-between p-4">
        <div>
          <h3>{screen.name}</h3>
          <p className="text-xs text-slate-500">{screen.public_token}</p>
        </div>
        <button
          onClick={() => setDeleteModalOpen(true)}
          className="text-red-600 hover:text-red-700"
        >
          Archive
        </button>
      </div>

      <ScreenDeleteWarning
        screen={screen}
        open={deleteModalOpen}
        onOpenChange={setDeleteModalOpen}
        onConfirm={handleArchive}
        isArchive={true}
      />
    </>
  );
}
```

---

## 2. Screen Detail / Edit Page

### Add Token Regeneration Admin Action
```jsx
import { Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

function ScreenDetail({ screen }) {
  const [regenerating, setRegenerating] = useState(false);
  const user = useUser();

  const handleRegenerateToken = async () => {
    if (!window.confirm(
      'This will deactivate the old player URL and require devices to be reprovisioned. Continue?'
    )) {
      return;
    }

    setRegenerating(true);
    try {
      const result = await base44.functions.invoke('regenerateScreenToken', {
        screen_id: screen.id,
      });
      alert(`New player URL: ${result.player_url}`);
      refetch();
    } catch (err) {
      alert('Regeneration failed: ' + err.message);
    } finally {
      setRegenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Existing form fields */}

      {/* Token Section */}
      <div className="bg-slate-50 p-4 rounded-lg">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-semibold">Player URL</h4>
            <code className="text-xs bg-white p-2 rounded block mt-2">
              https://player.screenfleet.io/player/{screen.public_token}
            </code>
            {screen.token_regenerated_at && (
              <p className="text-xs text-slate-500 mt-2">
                Token regenerated: {new Date(screen.token_regenerated_at).toLocaleString()}
              </p>
            )}
          </div>
          {user?.role === 'admin' && (
            <Button
              onClick={handleRegenerateToken}
              disabled={regenerating}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Zap className="w-4 h-4" />
              Regenerate URL
            </Button>
          )}
        </div>
      </div>

      {/* Status Section */}
      <div className="bg-blue-50 p-4 rounded-lg">
        <h4 className="font-semibold text-blue-900">Lifecycle Status</h4>
        <p className="text-sm text-blue-800 mt-2">
          {screen.status === 'active' && '✓ Active and in use'}
          {screen.status === 'archived' && '⚠️ Archived (soft deleted)'}
          {screen.status === 'deleted_internal' && '✗ Permanently deleted'}
        </p>
        {screen.status === 'active' && (
          <Button
            onClick={() => setDeleteModalOpen(true)}
            variant="outline"
            size="sm"
            className="mt-3 text-red-600"
          >
            Archive This Screen
          </Button>
        )}
      </div>
    </div>
  );
}
```

---

## 3. Admin Integrity Tools Page

### Create New Admin Dashboard Section
```jsx
// pages/AdminScreenIntegrity.jsx
import { useState } from 'react';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';

export default function AdminScreenIntegrity() {
  const [validateResult, setValidateResult] = useState(null);
  const [repairResult, setRepairResult] = useState(null);
  const [validating, setValidating] = useState(false);
  const [repairing, setRepairing] = useState(false);
  const [dryRun, setDryRun] = useState(true);

  const handleValidate = async () => {
    setValidating(true);
    try {
      const result = await base44.functions.invoke('validateScreenIntegrity', {});
      setValidateResult(result);
    } catch (err) {
      alert('Validation failed: ' + err.message);
    } finally {
      setValidating(false);
    }
  };

  const handleRepair = async () => {
    if (dryRun) {
      const ok = window.confirm('Preview orphaned records without deleting?');
      if (!ok) return;
    } else {
      const ok = window.confirm(
        'DELETE all orphaned records? This cannot be undone. Continue?'
      );
      if (!ok) return;
    }

    setRepairing(true);
    try {
      const result = await base44.functions.invoke('repairScreenIntegrity', {
        dryRun,
      });
      setRepairResult(result);
    } catch (err) {
      alert('Repair failed: ' + err.message);
    } finally {
      setRepairing(false);
    }
  };

  return (
    <div className="space-y-6 p-6">
      <h1 className="text-3xl font-bold">Screen Data Integrity Tools</h1>

      {/* Validation Card */}
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold">Integrity Check</h2>
          <p className="text-sm text-slate-500">
            Scan for duplicate tokens, orphaned records, and constraint violations
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={handleValidate} disabled={validating}>
            {validating ? 'Validating...' : 'Run Integrity Check'}
          </Button>

          {validateResult && (
            <div className="bg-slate-50 p-4 rounded-lg space-y-3">
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <div className="text-xs text-slate-500">Total Screens</div>
                  <div className="text-2xl font-bold">
                    {validateResult.summary.total_screens}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Violations</div>
                  <div className={`text-2xl font-bold ${
                    validateResult.summary.total_violations > 0 ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {validateResult.summary.total_violations}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Critical</div>
                  <div className="text-2xl font-bold text-red-600">
                    {validateResult.summary.critical}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Warnings</div>
                  <div className="text-2xl font-bold text-amber-600">
                    {validateResult.summary.warning}
                  </div>
                </div>
              </div>

              {validateResult.violations.length > 0 && (
                <div className="mt-4">
                  <h3 className="font-semibold text-sm mb-2">Violations:</h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {validateResult.violations.map((v, i) => (
                      <div
                        key={i}
                        className={`text-xs p-2 rounded ${
                          v.severity === 'critical'
                            ? 'bg-red-100 text-red-800'
                            : v.severity === 'high'
                            ? 'bg-orange-100 text-orange-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        <strong>{v.type}</strong>: {JSON.stringify(v, null, 2)}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Repair Card */}
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold">Orphan Repair</h2>
          <p className="text-sm text-slate-500">
            Remove AssetLayout, PublishedScreen, and RuntimeZone records pointing to
            non-existent screens
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={dryRun}
                onChange={(e) => setDryRun(e.target.checked)}
              />
              <span className="text-sm">Dry run (preview only)</span>
            </label>
          </div>

          <Button
            onClick={handleRepair}
            disabled={repairing}
            variant={dryRun ? 'outline' : 'destructive'}
          >
            {repairing ? 'Running...' : dryRun ? 'Preview Repairs' : 'Execute Repairs'}
          </Button>

          {repairResult && (
            <div className="bg-slate-50 p-4 rounded-lg space-y-3">
              <div className="grid grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-xs text-slate-500">Orphaned Layouts</div>
                  <div className="font-bold">{repairResult.summary.orphaned_asset_layouts}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Orphaned Published</div>
                  <div className="font-bold">{repairResult.summary.orphaned_published_screens}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Orphaned Zones</div>
                  <div className="font-bold">{repairResult.summary.orphaned_runtime_zones}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Dry Run</div>
                  <div className="font-bold">{repairResult.dry_run ? 'Yes' : 'No'}</div>
                </div>
              </div>

              {repairResult.deleted_asset_layout_ids.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold mb-2">Deleted AssetLayouts:</h4>
                  <pre className="text-xs bg-white p-2 rounded overflow-x-auto max-h-32 overflow-y-auto">
                    {JSON.stringify(repairResult.deleted_asset_layout_ids, null, 2)}
                  </pre>
                </div>
              )}

              {repairResult.deleted_published_screen_ids.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold mb-2">Deleted PublishedScreens:</h4>
                  <pre className="text-xs bg-white p-2 rounded overflow-x-auto max-h-32 overflow-y-auto">
                    {JSON.stringify(repairResult.deleted_published_screen_ids, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
```

---

## 4. Filter for Archived Screens

### Hide Archived Screens from Normal Workflows
```jsx
// When loading screens, filter by status
const activeScreens = allScreens.filter(s => s.status === 'active');

// In Live Output Dashboard, Playlists, etc.
// Always use: base44.entities.Screen.filter({ status: 'active' })
```

---

## 5. Automation: Auto-Cleanup After Archive

Optional: Create a scheduled function to hard-delete archived screens after N days:

```js
// functions/cleanupArchivedScreens.js
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  // Find screens archived > 30 days ago
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const allScreens = await base44.asServiceRole.entities.Screen.list();
  const oldArchived = allScreens.filter(
    (s) =>
      s.status === 'archived' &&
      new Date(s.updated_date) < thirtyDaysAgo
  );

  // Harddelete each via deleteScreen function
  for (const screen of oldArchived) {
    await base44.asServiceRole.functions.invoke('deleteScreen', {
      screen_id: screen.id,
    });
  }

  console.log(`[cleanupArchivedScreens] Deleted ${oldArchived.length} old archived screens`);
  return Response.json({ deleted: oldArchived.length });
});
```

Then create a scheduled automation:
- `automation_type: "scheduled"`
- `schedule_type: "simple"`
- `repeat_interval: 1, repeat_unit: "days"`
- `start_time: "03:00"` (3 AM)
- `function_name: "cleanupArchivedScreens"`

---

## Summary

The hardening is now complete and integration-ready. After adding these UI integrations:

✅ **No more orphaned records** — Archive workflow cleans up automatically
✅ **Stable tokens** — `public_token` doesn't change on edit
✅ **Transactional integrity** — CMS + Player stay in sync
✅ **Audit trail** — All deletes/archives logged
✅ **Admin tools** — Validation + repair for edge cases