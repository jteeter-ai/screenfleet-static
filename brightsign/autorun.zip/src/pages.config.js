/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AdminAssets from './pages/AdminAssets';
import AdminBilling from './pages/AdminBilling';
import AdminDashboard from './pages/AdminDashboard';
import AppSettings from './pages/AppSettings';
import Controls from './pages/Controls';
import Dashboard from './pages/Dashboard';
import LiveOutput from './pages/LiveOutput';
import MediaLibrary from './pages/MediaLibrary';
import Organizations from './pages/Organizations';
import Plans from './pages/Plans';
import Player from './pages/Player';
import Playlists from './pages/Playlists';
import Rotations from './pages/Rotations';
import Scheduling from './pages/Scheduling';
// ScreenEditor is a V1/legacy page — retained for backward compat but excluded from primary routing
import ScreenEditor from './pages/ScreenEditor';
import ScreenPlayer from './pages/ScreenPlayer';
import Sequences from './pages/Sequences';
// Trucks is a V1/legacy page — retained for backward compat but excluded from primary routing
import Trucks from './pages/Trucks';
import Users from './pages/Users';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AdminAssets": AdminAssets,
    "AdminBilling": AdminBilling,
    "AdminDashboard": AdminDashboard,
    "AppSettings": AppSettings,
    "Controls": Controls,
    "Dashboard": Dashboard,
    "LiveOutput": LiveOutput,
    "MediaLibrary": MediaLibrary,
    "Organizations": Organizations,
    "Plans": Plans,
    "Player": Player,
    "Playlists": Playlists,
    "Rotations": Rotations,
    "Scheduling": Scheduling,
    "ScreenEditor": ScreenEditor,
    "ScreenPlayer": ScreenPlayer,
    "Sequences": Sequences,
    "Trucks": Trucks,
    "Users": Users,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};