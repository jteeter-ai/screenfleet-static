import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl as createPageUrlImport } from "@/utils";
import { base44 } from "@/api/base44Client";
import { OrgProvider, useOrg } from "@/components/OrgContext";
import { useFeatureAccess } from "@/lib/useFeatureAccess";
import { useAuthority } from "@/lib/useAuthority";
import TrialGate from "@/components/TrialGate";
import {
  Monitor,
  Truck,
  RefreshCw,
  ListVideo,
  CalendarClock,
  SlidersHorizontal,
  LayoutGrid,
  Image,
  Settings,
  Menu,
  X,
  ChevronDown,
  LogOut,
  User,
  Zap,
  BarChart3,
  Repeat2,
  DollarSign,
  Building2,
  Shield,
  CreditCard,
  Users,
  FileBarChart,
  Megaphone
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Org Operations - available to all org members
const ORG_NAV_ITEMS = [
  { name: "Dashboard", page: "Dashboard", icon: BarChart3 },
  { name: "Assets", page: "Assets", icon: Truck, module: "module_assets" },
  { name: "Layout Templates", page: "LayoutTemplates", icon: LayoutGrid, module: "module_layouts" },
  { name: "Playlists", page: "Playlists", icon: ListVideo, module: "module_playlists" },
  { name: "Scheduling", page: "Scheduling", icon: CalendarClock, module: "module_scheduling" },
  { name: "Media Library", page: "MediaLibrary", icon: Image, module: "module_media_library" },
  { name: "Controls", page: "Controls", icon: SlidersHorizontal, module: "module_screen_controls" },
  { name: "Live Output", page: "ScreenPlayer", icon: Monitor, module: "module_live_output" },
  { name: "Studio", page: "Studio", icon: Zap, module: "module_studio" },
  { name: "Users", page: "Users", icon: Users, permission: "manage_members" },
  { name: "Settings", page: "AppSettings", icon: Settings },
];

// OOH Operator Tools — separate nav section, gated by module_ooh_operator
const OOH_NAV_ITEMS = [
  { name: "Route Presentations", page: "Rotations",   icon: RefreshCw,    module: "module_route_presentations" },
  { name: "Sequences",           page: "Sequences",   icon: Repeat2,      module: "module_sequences" },
  { name: "Advertisers",         page: "Advertisers", icon: Building2,    module: "module_ooh_advertisers" },
  { name: "Campaigns",           page: "Campaigns",   icon: Megaphone,    module: "module_ooh_campaigns" },
  { name: "Reporting",           page: "Reporting",   icon: FileBarChart, module: "module_ooh_reporting" },
];

// Platform Admin - only for Legion LED admins
const PLATFORM_NAV_ITEMS = [
  { name: "Dashboard", page: "AdminDashboard", icon: BarChart3 },
  { name: "Admin Assets", page: "AdminAssets", icon: Truck },
  { name: "Plans", page: "Plans", icon: DollarSign },
  { name: "Organizations", page: "Organizations", icon: Building2 },
  { name: "Billing", page: "AdminBilling", icon: CreditCard },
  { name: "Super Admin Users", page: "SuperAdminUsers", icon: Users },
];

// Pages that should render without the layout wrapper (full-screen)
// ScreenPlayer with a screenId param bypasses layout entirely (used by BrightSign/kiosk players)
const isPlayerMode = () => {
  const params = new URLSearchParams(window.location.search);
  return params.get("screenId") !== null;
};

const FULL_SCREEN_PAGES = ["ScreenPlayer"];

function LayoutContent({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [adminMode, setAdminMode] = useState(true);

  const hubToken = sessionStorage.getItem("legion_hub_token")
    ? JSON.parse(sessionStorage.getItem("legion_hub_token"))
    : null;
  const isHubSession = hubToken && hubToken.expires_at > Date.now(); // true = platform admin view, false = organization view
  const navigate = useNavigate();
  const { user, userOrgs, activeOrgId, activeOrg, isPlatformAdmin, switchOrg } = useOrg();
  const { canAccess } = useFeatureAccess();
  const { canAccessModule, canDo } = useAuthority();

  const handleLogout = () => {
    base44.auth.logout("/");
  };

  // Platform admins can view org features when switched to org mode
  const showOrgNav = !isPlatformAdmin || (isPlatformAdmin && !adminMode && activeOrg);
  const baseNavItems = showOrgNav ? ORG_NAV_ITEMS : PLATFORM_NAV_ITEMS;
  const navItems = baseNavItems.filter(item => {
    if (item.feature && !canAccess(item.feature)) return false;
    if (item.module && !canAccessModule(item.module)) return false;
    if (item.permission && !canDo(item.permission)) return false;
    return true;
  });

  // OOH Operator nav section
  const oohNavItems = showOrgNav ? OOH_NAV_ITEMS.filter(item =>
    !item.module || canAccessModule(item.module)
  ) : [];
  const showOohSection = oohNavItems.length > 0;

  // Redirect platform admin to AdminDashboard only when no specific org is selected
  React.useEffect(() => {
    if (isPlatformAdmin && !activeOrg && currentPageName === "Dashboard") {
      navigate(createPageUrlImport("AdminDashboard"));
    }
  }, [isPlatformAdmin, activeOrg, currentPageName, navigate]);

  if (FULL_SCREEN_PAGES.includes(currentPageName)) {
    return <>{children}</>;
  }

  // Trial enforcement: block non-admin orgs with expired trial
  const isTrialExpired = !isPlatformAdmin && activeOrg?.trial_expired === true
    && activeOrg?.subscription_status !== 'active';

  return (
    <>
    {isTrialExpired && <TrialGate org={activeOrg} />}
    <div className="flex h-dvh bg-slate-50 overflow-hidden">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed md:static inset-y-0 left-0 z-50
          flex flex-col bg-white border-r border-slate-200
          transition-all duration-300 ease-out
          ${sidebarOpen ? "w-64" : "w-[72px]"}
          ${mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
        `}
      >
        {/* Logo */}
        <div className="flex items-center h-16 px-5 border-b border-slate-100">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl flex-shrink-0 overflow-hidden">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699e82a2479ad26532b0b448/19f40cc91_ScreenFleetIcon.png" alt="ScreenFleet" className="w-full h-full object-cover" />
            </div>
            {sidebarOpen && (
              <div className="truncate">
                <h1 className="text-base font-bold text-slate-900 tracking-tight">ScreenFleet</h1>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-medium">CMS</p>
              </div>
            )}
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = currentPageName === item.page;
            const Icon = item.icon;
            return (
              <Link
                key={item.page}
                to={createPageUrlImport(item.page)}
                onClick={() => setMobileOpen(false)}
                className={`
                  flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150
                  ${isActive
                    ? "bg-blue-50 text-blue-700 shadow-sm"
                    : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
                  }
                  ${!sidebarOpen ? "justify-center" : ""}
                `}
              >
                <Icon className={`w-[18px] h-[18px] flex-shrink-0 ${isActive ? "text-blue-600" : ""}`} />
                {sidebarOpen && <span className="truncate">{item.name}</span>}
              </Link>
            );
          })}

          {/* OOH Operator Tools section */}
          {showOohSection && oohNavItems.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-100">
              {sidebarOpen && (
                <div className="text-[10px] font-semibold text-slate-400 px-3 py-1.5 uppercase tracking-widest">OOH Operator</div>
              )}
              {oohNavItems.map((item) => {
                const isActive = currentPageName === item.page;
                const Icon = item.icon;
                return (
                  <Link
                    key={item.page}
                    to={createPageUrlImport(item.page)}
                    onClick={() => setMobileOpen(false)}
                    className={`
                      flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150
                      ${isActive
                        ? "bg-purple-50 text-purple-700 shadow-sm"
                        : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
                      }
                      ${!sidebarOpen ? "justify-center" : ""}
                    `}
                  >
                    <Icon className={`w-[18px] h-[18px] flex-shrink-0 ${isActive ? "text-purple-600" : ""}`} />
                    {sidebarOpen && <span className="truncate">{item.name}</span>}
                  </Link>
                );
              })}
            </div>
          )}

          {/* Platform Controls section: ONLY for super admins */}
          {isPlatformAdmin && showOrgNav && (
            <>
              <div className="mt-4 pt-4 border-t border-slate-200">
                <div className="text-xs font-semibold text-slate-400 px-3 py-2 uppercase tracking-wide">
                  {sidebarOpen ? "Platform Controls" : "Admin"}
                </div>
                {PLATFORM_NAV_ITEMS.map((item) => {
                  const isActive = currentPageName === item.page;
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.page}
                      to={createPageUrlImport(item.page)}
                      onClick={() => {
                        setMobileOpen(false);
                        setAdminMode(true);
                      }}
                      className={`
                        flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150
                        ${isActive
                          ? "bg-blue-50 text-blue-700 shadow-sm"
                          : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
                        }
                        ${!sidebarOpen ? "justify-center" : ""}
                      `}
                    >
                      <Icon className={`w-[18px] h-[18px] flex-shrink-0 ${isActive ? "text-blue-600" : ""}`} />
                      {sidebarOpen && <span className="truncate">{item.name}</span>}
                    </Link>
                  );
                })}
              </div>
            </>
          )}
        </nav>

        {/* Collapse toggle (desktop) */}
        <div className="hidden md:flex items-center justify-center py-3 border-t border-slate-100">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-slate-400 hover:text-slate-600"
          >
            <Menu className="w-4 h-4" />
          </Button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden overflow-x-hidden">
        {/* Top bar */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-6 flex-shrink-0">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-slate-500"
              onClick={() => setMobileOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </Button>
            <h2 className="text-lg font-semibold text-slate-900 tracking-tight flex items-center gap-2">
              {navItems.find((n) => n.page === currentPageName)?.name || oohNavItems.find((n) => n.page === currentPageName)?.name || currentPageName}
              {isPlatformAdmin && !adminMode && activeOrg && (
                <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-700 rounded font-medium">Managing: {activeOrg.name}</span>
              )}
              {/* Regular users always see their org name locked */}
              {!isPlatformAdmin && activeOrg && (
                <span className="text-xs px-2 py-0.5 bg-slate-100 text-slate-500 rounded font-medium">{activeOrg.name}</span>
              )}
              {isHubSession && (
                <span className="text-[10px] px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded font-medium">
                  via LegionOS
                </span>
              )}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Org switcher: ONLY shown to platform admins */}
            {isPlatformAdmin && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2 text-sm">
                    <Building2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline max-w-[150px] truncate">
                      {adminMode ? "Platform Admin" : (activeOrg?.name || "Select Org")}
                    </span>
                    <ChevronDown className="w-3.5 h-3.5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  {isPlatformAdmin && !adminMode && (
                    <>
                      <DropdownMenuItem
                        onClick={() => {
                          setAdminMode(true);
                          navigate(createPageUrlImport("Organizations"));
                        }}
                        className="text-xs font-medium text-slate-700"
                      >
                        <Shield className="w-3.5 h-3.5 mr-2" /> Back to Platform Admin
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  {userOrgs.map((org) => (
                    <DropdownMenuItem
                      key={org.id}
                      onClick={() => {
                        switchOrg(org.id);
                        setAdminMode(false);
                        navigate(createPageUrlImport("Dashboard"));
                      }}
                      className="flex items-center gap-2"
                    >
                      {activeOrgId === org.id && !adminMode && <div className="w-2 h-2 rounded-full bg-blue-600" />}
                      <div>
                        <div className="text-sm font-medium">{org.name}</div>
                        <div className="text-[10px] text-slate-400">{org.plan_slug}</div>
                      </div>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 text-slate-600 hover:text-slate-900">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                    <span className="text-white text-xs font-bold">
                      {user?.full_name?.[0]?.toUpperCase() || "U"}
                    </span>
                  </div>
                  <span className="hidden sm:inline text-sm font-medium">{user?.full_name || "User"}</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem className="text-xs text-slate-400">{user?.email}</DropdownMenuItem>
                {user?.role === "admin" && <DropdownMenuItem className="text-xs text-amber-600"><Shield className="w-3 h-3 mr-1" /> Platform Admin</DropdownMenuItem>}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate(createPageUrlImport("AppSettings"))}>
                  <Settings className="w-4 h-4 mr-2" /> Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <LogOut className="w-4 h-4 mr-2" /> Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto" style={{ touchAction: 'pan-y', WebkitOverflowScrolling: 'touch' }}>
          {children}
        </main>
      </div>
    </div>
    </>
  );
}

export default function Layout({ children, currentPageName }) {
  if (FULL_SCREEN_PAGES.includes(currentPageName)) {
    return <>{children}</>;
  }
  // Pure player mode: ScreenPlayer renders without layout
  if (currentPageName === "ScreenPlayer") {
    return <>{children}</>;
  }
  return (
    <OrgProvider>
      <LayoutContent children={children} currentPageName={currentPageName} />
    </OrgProvider>
  );
}