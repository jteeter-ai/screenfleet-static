import { Toaster } from "@/components/ui/toaster"
import { Toaster as SonnerToaster } from "sonner"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScreenPlayer from './pages/ScreenPlayer';
// NOTE: Player (public playback) has been removed from CMS. Playback is handled by the separate ScreenFleet Player app.
import Assets from './pages/Assets';
import LayoutTemplates from './pages/LayoutTemplates';
import LiveOutput from './pages/LiveOutput';
import Studio from './pages/Studio';
import SetPassword from './pages/SetPassword';
import SuperAdminUsers from './pages/SuperAdminUsers';
import Advertisers from './pages/Advertisers';
import ImpersonateView from './pages/ImpersonateView';
import Campaigns from './pages/Campaigns';
import Reporting from './pages/Reporting';
import SSOLogin from './pages/SSOLogin';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

// ─── Public routes — ONLY invite-based account setup ────────────────────────
// CMS is private and invite-only. /player is NOT served by this app.
// SetPassword remains public ONLY for secure token-based invite completion.
function PublicRoutes() {
  const path = window.location.pathname;

  // SetPassword + SSOLogin are the only public routes
  if (path === "/SetPassword" || path === "/SetPassword/") return <SetPassword />;
  if (path === "/SSOLogin" || path === "/SSOLogin/") return <SSOLogin />;

  return null; // not a public route
}

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Render public player routes before any auth check
  const publicRoute = PublicRoutes();
  if (publicRoute) return publicRoute;

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={
        <LayoutWrapper currentPageName={mainPageKey}>
          <MainPage />
        </LayoutWrapper>
      } />
      {Object.entries(Pages).map(([path, Page]) => (
        <Route
          key={path}
          path={`/${path}`}
          element={
            <LayoutWrapper currentPageName={path}>
              <Page />
            </LayoutWrapper>
          }
        />
      ))}
      {/* Canonical player route - explicit to ensure it's always available */}
      <Route 
        path="/ScreenPlayer" 
        element={
          <LayoutWrapper currentPageName="ScreenPlayer">
            <ScreenPlayer />
          </LayoutWrapper>
        } 
      />
      {/* V2 Phase 1: Assets and Layout Templates */}
      <Route
        path="/Assets"
        element={
          <LayoutWrapper currentPageName="Assets">
            <Assets />
          </LayoutWrapper>
        }
      />
      <Route
        path="/LayoutTemplates"
        element={
          <LayoutWrapper currentPageName="LayoutTemplates">
            <LayoutTemplates />
          </LayoutWrapper>
        }
      />
      {/* /player is NOT served by this CMS app. Playback is handled by the separate ScreenFleet Player app. */}
      {/* V2 Live Output Dashboard */}
      <Route
        path="/LiveOutput"
        element={
          <LayoutWrapper currentPageName="LiveOutput">
            <LiveOutput />
          </LayoutWrapper>
        }
      />
      {/* V2 Studio */}
      <Route
        path="/Studio"
        element={
          <LayoutWrapper currentPageName="Studio">
            <Studio />
          </LayoutWrapper>
        }
      />
      {/* Platform Admin: Super Admin Users */}
      <Route
        path="/SuperAdminUsers"
        element={
          <LayoutWrapper currentPageName="SuperAdminUsers">
            <SuperAdminUsers />
          </LayoutWrapper>
        }
      />
      {/* OOH Reporting */}
      <Route path="/Advertisers" element={<LayoutWrapper currentPageName="Advertisers"><Advertisers /></LayoutWrapper>} />
      <Route path="/ImpersonateView" element={<LayoutWrapper currentPageName="ImpersonateView"><ImpersonateView /></LayoutWrapper>} />
      <Route path="/Campaigns" element={<LayoutWrapper currentPageName="Campaigns"><Campaigns /></LayoutWrapper>} />
      <Route path="/Reporting" element={<LayoutWrapper currentPageName="Reporting"><Reporting /></LayoutWrapper>} />
      <Route path="/SSOLogin" element={<SSOLogin />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <QueryClientProvider client={queryClientInstance}>
      <AuthProvider>
        <Router>
          <AuthenticatedApp />
          <Toaster />
          <SonnerToaster position="top-right" richColors />
        </Router>
      </AuthProvider>
    </QueryClientProvider>
  )
}

export default App