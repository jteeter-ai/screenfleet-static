import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useFeatureAccess } from "@/lib/useFeatureAccess";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, GripVertical, ArrowRight, Repeat, Play, Loader2, Search, ListVideo, RefreshCw } from "lucide-react";
import SplitLayout from "@/components/layout/SplitLayout";

// Step content type toggle + searchable content picker + duration config
function SequenceStepRow({ step, index, playlists, routePresentations, onUpdate, onDelete }) {
  const [search, setSearch] = useState("");

  const contentType = step.type || "playlist";
  const durationType = step.duration_type || "rotations";
  const durationValue = step.duration_value ?? 1;
  const items = contentType === "playlist" ? playlists : routePresentations;

  // Sort newest first (by created_date desc)
  const sortedItems = [...items].sort((a, b) =>
    new Date(b.created_date || 0) - new Date(a.created_date || 0)
  );
  const filtered = sortedItems.filter((i) =>
    (i.name || "").toLowerCase().includes(search.toLowerCase())
  );

  const selectedId = contentType === "playlist" ? step.playlist_id : step.presentation_id;
  const selectedItem = items.find((i) => i.id === selectedId);

  const setContentType = (type) => {
    onUpdate({ type, playlist_id: null, presentation_id: null });
  };

  const setContentId = (id) => {
    if (contentType === "playlist") onUpdate({ playlist_id: id });
    else onUpdate({ presentation_id: id });
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 flex items-start gap-3">
      <GripVertical className="w-4 h-4 text-slate-300 flex-shrink-0 mt-2" />
      <div className="w-7 h-7 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-1">
        {index + 1}
      </div>

      <div className="flex-1 space-y-3">
        {/* Content type toggle */}
        <div className="flex gap-2">
          <button
            onClick={() => setContentType("playlist")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              contentType === "playlist"
                ? "bg-blue-600 text-white border-blue-600"
                : "bg-white text-slate-600 border-slate-200 hover:border-blue-400"
            }`}
          >
            <ListVideo className="w-3.5 h-3.5" /> Playlist
          </button>
          <button
           onClick={() => setContentType("presentation")}
           className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
             contentType === "presentation"
               ? "bg-blue-600 text-white border-blue-600"
               : "bg-white text-slate-600 border-slate-200 hover:border-blue-400"
           }`}
          >
           <RefreshCw className="w-3.5 h-3.5" /> Route Presentation
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Content picker */}
          <div>
            <Label className="text-[10px] text-slate-500 uppercase tracking-wide">
              {contentType === "playlist" ? "Playlist" : "Route Presentation"}
            </Label>
            <Select
              value={selectedId || ""}
              onValueChange={setContentId}
            >
              <SelectTrigger className="h-8 text-xs mt-1">
                <SelectValue placeholder={`Choose ${contentType === "playlist" ? "playlist" : "presentation"}…`} />
              </SelectTrigger>
              <SelectContent>
                {/* Search box inside dropdown */}
                <div className="flex items-center gap-2 px-2 py-1.5 border-b border-slate-100">
                  <Search className="w-3 h-3 text-slate-400 flex-shrink-0" />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search…"
                    className="flex-1 text-xs outline-none bg-transparent"
                    onClick={(e) => e.stopPropagation()}
                    onKeyDown={(e) => e.stopPropagation()}
                  />
                </div>
                {filtered.length === 0 && (
                  <div className="text-xs text-slate-400 px-3 py-2">No results</div>
                )}
                {filtered.map((item) => (
                  <SelectItem key={item.id} value={item.id} className="text-xs">
                    {item.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Duration */}
          <div>
            <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Duration</Label>
            <div className="flex gap-1.5 mt-1">
              <Input
                type="number"
                min="1"
                value={durationValue}
                onChange={(e) => onUpdate({ duration_value: Number(e.target.value) })}
                className="h-8 text-xs w-20 flex-shrink-0"
              />
              <Select value={durationType} onValueChange={(v) => onUpdate({ duration_type: v })}>
                <SelectTrigger className="h-8 text-xs flex-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rotations" className="text-xs">Full Rotation(s)</SelectItem>
                  <SelectItem value="minutes" className="text-xs">Minutes</SelectItem>
                  <SelectItem value="seconds" className="text-xs">Seconds</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      <Button
        size="icon"
        variant="ghost"
        className="h-8 w-8 text-slate-300 hover:text-red-500 flex-shrink-0 mt-1"
        onClick={onDelete}
      >
        <Trash2 className="w-4 h-4" />
      </Button>
    </div>
  );
}

function getDurationLabel(step) {
  const val = step.duration_value ?? step.duration_minutes ?? 1;
  const type = step.duration_type || "rotations";
  if (type === "rotations") return `${val}× rotation`;
  if (type === "seconds") return `${val}s`;
  return `${val}min`;
}

export default function Sequences() {
  const queryClient = useQueryClient();
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  const { canAccess } = useFeatureAccess();
  const hasAccess = canAccess("sequences");
  const [selectedAssetId, setSelectedAssetId] = useState(null);
  const [selectedSequenceId, setSelectedSequenceId] = useState(null);
  const [localName, setLocalName] = useState("");

  const { data: assets = [] } = useQuery({
    queryKey: ["assets", activeOrgId],
    queryFn: () => activeOrgId ? base44.entities.Asset.filter({ org_id: activeOrgId }) : Promise.resolve([]),
    enabled: !!activeOrgId,
  });

  const { data: playlists = [] } = useQuery({
    queryKey: ["playlists", activeOrgId],
    queryFn: () => activeOrgId ? base44.entities.Playlist.filter({ org_id: activeOrgId }) : Promise.resolve([]),
    enabled: !!activeOrgId,
  });

  const { data: routePresentations = [] } = useQuery({
    queryKey: ["routePresentations", activeOrgId],
    queryFn: () => activeOrgId ? base44.entities.RoutePresentation.filter({ org_id: activeOrgId }) : Promise.resolve([]),
    enabled: !!activeOrgId,
  });

  const { data: sequences = [] } = useQuery({
    queryKey: ["sequences", activeOrgId, selectedAssetId],
    queryFn: () => {
      if (!activeOrgId) return Promise.resolve([]);
      const query = { org_id: activeOrgId };
      if (selectedAssetId) query.asset_id = selectedAssetId;
      return base44.entities.Sequence.filter(query);
    },
    enabled: !!activeOrgId && hasAccess,
  });

  const { data: steps = [] } = useQuery({
    queryKey: ["sequenceItems", selectedSequenceId],
    queryFn: () => base44.entities.SequenceItem.filter({ sequence_id: selectedSequenceId }),
    enabled: !!selectedSequenceId,
  });

  useEffect(() => { if (assets.length > 0 && !selectedAssetId) setSelectedAssetId(assets[0].id); }, [assets]);
  useEffect(() => { if (sequences.length > 0 && !selectedSequenceId) setSelectedSequenceId(sequences[0].id); }, [sequences]);

  const selectedSequence = sequences.find((s) => s.id === selectedSequenceId);
  const sortedSteps = [...steps].sort((a, b) => a.order - b.order);

  // Sync localName when selected sequence changes
  useEffect(() => {
    if (selectedSequence) setLocalName(selectedSequence.name || "");
  }, [selectedSequenceId]);

  const createSeqMutation = useMutation({
    mutationFn: () => base44.entities.Sequence.create({
      org_id: activeOrgId,
      asset_id: selectedAssetId || null,
      name: "New Sequence",
      loop: true,
      is_active: false,
    }),
    onSuccess: (s) => { queryClient.invalidateQueries({ queryKey: ["sequences", activeOrgId, selectedAssetId] }); setSelectedSequenceId(s.id); },
  });

  const updateSeqMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Sequence.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["sequences", activeOrgId, selectedAssetId] }),
  });

  const deleteSeqMutation = useMutation({
    mutationFn: (id) => base44.entities.Sequence.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["sequences", activeOrgId, selectedAssetId] }); setSelectedSequenceId(null); },
  });

  const addStepMutation = useMutation({
    mutationFn: () => base44.entities.SequenceItem.create({
      sequence_id: selectedSequenceId,
      order: sortedSteps.length + 1,
      type: "playlist",
    }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["sequenceItems", selectedSequenceId] }),
  });

  const updateStepMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SequenceItem.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["sequenceItems", selectedSequenceId] }),
  });

  const deleteStepMutation = useMutation({
    mutationFn: (id) => base44.entities.SequenceItem.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["sequenceItems", selectedSequenceId] }),
  });

  const setActiveSequence = (seqId) => {
    sequences.forEach((s) => {
      updateSeqMutation.mutate({ id: s.id, data: { is_active: s.id === seqId } });
    });
  };

  const getStepLabel = (step) => {
    if (step.type === "presentation") {
      return routePresentations.find((r) => r.id === step.presentation_id)?.name;
    }
    return playlists.find((p) => p.id === step.playlist_id)?.name;
  };

  const sidebar = (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="p-4 border-b border-slate-100">
        <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-1">Assets</div>
        <Select value={selectedAssetId || ""} onValueChange={(v) => { setSelectedAssetId(v || null); setSelectedSequenceId(null); }}>
          <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="Select asset (optional)…" /></SelectTrigger>
          <SelectContent>
            <SelectItem value={null}>All Assets</SelectItem>
            {assets.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="p-4 flex-1 overflow-y-auto">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Sequences</div>
          {activeOrgId && hasAccess && (
            <Button variant="ghost" size="sm" className="h-5 w-5 p-0" onClick={() => createSeqMutation.mutate()} disabled={createSeqMutation.isPending}>
              {createSeqMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
            </Button>
          )}
        </div>
        <div className="space-y-1">
          {sequences.map((seq) => (
            <button key={seq.id} onClick={() => setSelectedSequenceId(seq.id)} className={`w-full text-left text-sm px-2 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${selectedSequenceId === seq.id ? "bg-blue-50 text-blue-700 font-medium" : "text-slate-600 hover:bg-slate-50"}`}>
              <span className="truncate flex-1">{seq.name}</span>
              {seq.is_active && <span className="w-1.5 h-1.5 rounded-full bg-green-500 flex-shrink-0" />}
            </button>
          ))}
          {sequences.length === 0 && activeOrgId && (
            <p className="text-xs text-slate-400 text-center py-4">No sequences yet.<br /><button className="text-blue-500 hover:underline mt-1" onClick={() => createSeqMutation.mutate()}>Create one</button></p>
          )}
        </div>
      </div>
    </div>
  );

  // Hard page-level guard — blocks URL-direct access
  if (!canAccessModule('module_sequences')) return <AccessDenied reason="module" />;

  return (
    <SplitLayout sidebar={sidebar} sidebarLabel="Sequences">
      <div className="overflow-auto bg-slate-50 p-6 h-full">
          {!hasAccess && (
            <div className="mb-5 p-4 rounded-xl border border-amber-200 bg-amber-50 flex items-start gap-3">
              <Lock className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-amber-800">Sequences not included in your plan</p>
                <p className="text-xs text-amber-700 mt-1">Existing sequences continue to play. Upgrade your plan to create or edit sequences.</p>
              </div>
            </div>
          )}
        {!selectedSequence ? (
          <div className="flex items-center justify-center h-full text-slate-400">
            <div className="text-center">
              <Repeat className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">Select or create a sequence</p>
            </div>
          </div>
        ) : (
          <div className="max-w-2xl space-y-5">
            {/* Header */}
            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex-1 min-w-36">
                  <Label className="text-[10px] text-slate-500 uppercase tracking-widest">Name</Label>
                  <Input
                   value={localName}
                   onChange={(e) => setLocalName(e.target.value)}
                   onBlur={() => {
                     if (localName !== selectedSequence.name) {
                       updateSeqMutation.mutate({ id: selectedSequenceId, data: { name: localName } });
                     }
                   }}
                   className="h-8 text-sm mt-1"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={selectedSequence.loop} onCheckedChange={(v) => updateSeqMutation.mutate({ id: selectedSequenceId, data: { loop: v } })} />
                  <Label className="text-sm flex items-center gap-1"><Repeat className="w-3.5 h-3.5 text-blue-500" /> Loop</Label>
                </div>
                <div className="flex items-center gap-2 ml-auto">
                  {selectedSequence.is_active ? (
                    <Badge className="bg-green-100 text-green-700 border-green-200 gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> Active
                    </Badge>
                  ) : (
                    <Button size="sm" variant="outline" className="h-8 text-xs gap-1.5" onClick={() => setActiveSequence(selectedSequenceId)}>
                      <Play className="w-3 h-3" /> Set Active
                    </Button>
                  )}
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-red-400 hover:text-red-600" onClick={() => deleteSeqMutation.mutate(selectedSequenceId)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Steps */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-slate-700">Presentation Order ({sortedSteps.length} steps)</h3>
                <Button size="sm" variant="outline" className="h-8 text-xs gap-1" onClick={() => addStepMutation.mutate()} disabled={addStepMutation.isPending}>
                  {addStepMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3.5 h-3.5" />} Add Step
                </Button>
              </div>

              {/* Visual flow */}
              {sortedSteps.length > 0 && (
                <div className="flex items-center gap-2 flex-wrap mb-5 p-3 bg-white rounded-xl border border-slate-200">
                  {sortedSteps.map((step, i) => {
                    const label = getStepLabel(step);
                    const isRotation = step.type === "presentation";
                    return (
                      <React.Fragment key={step.id}>
                        <div className="flex flex-col items-center gap-1">
                          <div className={`px-3 py-1.5 rounded-lg text-xs font-semibold text-center max-w-28 truncate flex items-center gap-1 ${
                            isRotation ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800"
                          }`}>
                            {isRotation ? <RefreshCw className="w-3 h-3 flex-shrink-0" /> : <ListVideo className="w-3 h-3 flex-shrink-0" />}
                            <span className="truncate">{label || <span className="italic opacity-60">None</span>}</span>
                          </div>
                          <span className="text-[9px] text-slate-400">{getDurationLabel(step)}</span>
                        </div>
                        {i < sortedSteps.length - 1 && <ArrowRight className="w-4 h-4 text-slate-300 flex-shrink-0" />}
                      </React.Fragment>
                    );
                  })}
                  {selectedSequence.loop && (
                    <>
                      <ArrowRight className="w-4 h-4 text-slate-300 flex-shrink-0" />
                      <div className="px-2 py-1 rounded-lg border border-dashed border-slate-300 text-[10px] text-slate-400 flex items-center gap-1">
                        <Repeat className="w-3 h-3" /> Loop
                      </div>
                    </>
                  )}
                </div>
              )}

              <div className="space-y-2">
                {sortedSteps.map((step, i) => (
                  <SequenceStepRow
                   key={step.id}
                   step={step}
                   index={i}
                   playlists={playlists}
                   routePresentations={routePresentations}
                   onUpdate={(data) => updateStepMutation.mutate({ id: step.id, data })}
                   onDelete={() => deleteStepMutation.mutate(step.id)}
                  />
                ))}
                {sortedSteps.length === 0 && (
                  <div className="text-center py-10 text-slate-400 bg-white rounded-xl border border-dashed border-slate-200">
                    <Repeat className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">Add steps to build your sequence</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </SplitLayout>
  );
}