import { useState, useCallback, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Layers, Save, X, ZoomIn, ZoomOut, Eye, ArrowLeft, ChevronLeft, ChevronRight, PanelLeftClose, PanelLeftOpen, PanelRightClose, PanelRightOpen } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { useOrg } from "@/components/OrgContext";
import WidgetPanel from "@/components/studio/WidgetPanel";
import CanvasArea from "@/components/studio/CanvasArea";
import PropertiesPanel from "@/components/studio/PropertiesPanel";
import CanvasCreativeRenderer from "@/components/studio/CanvasCreativeRenderer";
import ZoneLayersPanel from "@/components/studio/ZoneLayersPanel";

let layerIdCounter = Date.now();
const newLayerId = () => `layer_${++layerIdCounter}`;

const DEFAULT_CREATIVE = { name: "Untitled Creative", width: 1280, height: 640, background_color: "#000000", layers_json: [] };

// ─── Studio Editor (embedded in normal page layout) ────────────────────────────
function StudioEditor({ creative: initialCreative, onClose, onSave }) {
  const [creative, setCreative] = useState(() => ({
    ...DEFAULT_CREATIVE,
    ...initialCreative,
    layers_json: initialCreative?.layers_json || [],
  }));
  const [saving, setSaving] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [scale, setScale] = useState(0.5);
  const [previewing, setPreviewing] = useState(false);
  const [widgetsOpen, setWidgetsOpen] = useState(true);
  const [layersOpen, setLayersOpen] = useState(true);
  const [propsOpen, setPropsOpen] = useState(true);

  // Re-sync when initialCreative changes
  useEffect(() => {
    if (initialCreative?.id) {
      setCreative({
        ...DEFAULT_CREATIVE,
        ...initialCreative,
        layers_json: initialCreative.layers_json || [],
      });
    }
  }, [initialCreative?.id]);

  const selectedLayer = creative.layers_json.find(l => l.id === selectedId) || null;

  const handleAddWidget = useCallback((type, defaultProps) => {
    const layer = {
      id: newLayerId(),
      type,
      x: Math.round(creative.width / 2 - 150),
      y: Math.round(creative.height / 2 - 75),
      width: type === "text" ? 300 : type === "shape" ? 200 : type === "weather_widget" ? 700 : type === "html_widget" ? 400 : 300,
      height: type === "text" ? 80 : type === "shape" ? 150 : type === "weather_widget" ? 90 : type === "html_widget" ? 200 : 200,
      rotation: 0, opacity: 1,
      z_index: (creative.layers_json.length > 0 ? Math.max(...creative.layers_json.map(l => l.z_index ?? 1)) + 1 : 1),
      locked: false,
      props: { ...defaultProps },
    };
    setCreative(c => ({ ...c, layers_json: [...c.layers_json, layer] }));
    setSelectedId(layer.id);
  }, [creative.width, creative.height, creative.layers_json]);

  const handleRenameLayer = useCallback((id, name) => {
    setCreative(c => ({ ...c, layers_json: c.layers_json.map(l => l.id === id ? { ...l, name } : l) }));
  }, []);

  const handleToggleVisible = useCallback((id) => {
    setCreative(c => ({ ...c, layers_json: c.layers_json.map(l => l.id === id ? { ...l, visible: l.visible === false ? true : false } : l) }));
  }, []);

  const handleToggleLock = useCallback((id) => {
    setCreative(c => ({ ...c, layers_json: c.layers_json.map(l => l.id === id ? { ...l, locked: !l.locked } : l) }));
  }, []);

  // HDMI Input is a Layout Zone concept — not a canvas layer.
  // Removed: handleAssignHdmi. HDMI zones are defined in Layout Templates only.

  const handleUpdateLayer = useCallback((id, updates) => {
    setCreative(c => ({
      ...c,
      layers_json: c.layers_json.map(l => l.id === id ? { ...l, ...updates, props: updates.props !== undefined ? updates.props : l.props } : l),
    }));
  }, []);

  const handleDeleteLayer = useCallback((id) => {
    setCreative(c => ({ ...c, layers_json: c.layers_json.filter(l => l.id !== id) }));
    setSelectedId(null);
  }, []);

  const handleReorderLayer = useCallback((id, dir) => {
    setCreative(c => {
      const layers = [...c.layers_json];
      const idx = layers.findIndex(l => l.id === id);
      if (idx < 0) return c;
      const swapIdx = dir === "up" ? idx + 1 : idx - 1;
      if (swapIdx < 0 || swapIdx >= layers.length) return c;
      const tmpZ = layers[idx].z_index;
      layers[idx] = { ...layers[idx], z_index: layers[swapIdx].z_index };
      layers[swapIdx] = { ...layers[swapIdx], z_index: tmpZ };
      return { ...c, layers_json: layers };
    });
  }, []);

  const handleUpdateCreative = useCallback((updates) => {
    setCreative(c => ({ ...c, ...updates }));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await onSave(creative);
    setSaving(false);
  };

  if (!creative) return null;

  return (
    <div className="flex flex-col h-full bg-slate-950">
      {/* Top toolbar */}
      <div className="h-12 bg-slate-900 border-b border-slate-700 flex items-center px-4 gap-3 flex-shrink-0">
        <div className="flex items-center gap-2 mr-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span className="text-sm font-semibold text-white">Studio</span>
          <span className="text-slate-500 text-sm">—</span>
          <Input
            value={creative.name}
            onChange={(e) => handleUpdateCreative({ name: e.target.value })}
            className="h-7 w-48 text-sm bg-slate-800 border-slate-600 text-white"
          />
        </div>

        <div className="flex items-center gap-1 border border-slate-700 rounded px-1">
          <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-white" onClick={() => setScale(s => Math.max(0.1, +(s - 0.1).toFixed(1)))}>
            <ZoomOut className="w-3.5 h-3.5" />
          </Button>
          <span className="text-xs text-slate-400 w-10 text-center">{Math.round(scale * 100)}%</span>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-white" onClick={() => setScale(s => Math.min(2, +(s + 0.1).toFixed(1)))}>
            <ZoomIn className="w-3.5 h-3.5" />
          </Button>
        </div>

        <Button variant="ghost" size="sm" className={`h-7 gap-1.5 text-xs ${previewing ? "text-blue-400" : "text-slate-400 hover:text-white"}`} onClick={() => setPreviewing(p => !p)}>
          <Eye className="w-3.5 h-3.5" /> Preview
        </Button>

        <div className="flex items-center gap-1.5 border-l border-slate-700 pl-3">
          <span className="text-[10px] text-slate-500 uppercase tracking-wider font-medium whitespace-nowrap">Loop Sync</span>
          <Select value={creative.sync_mode || 'independent'} onValueChange={(v) => handleUpdateCreative({ sync_mode: v })}>
            <SelectTrigger className="h-7 w-44 text-xs bg-slate-800 border-slate-600 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="independent">Independent loops</SelectItem>
              <SelectItem value="longest">Wait for longest zone</SelectItem>
              <SelectItem value="shortest">Advance on shortest zone</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="sm" className="h-7 text-slate-400 hover:text-white gap-1.5" onClick={onClose}>
            <ArrowLeft className="w-3.5 h-3.5" /> Back
          </Button>
          <Button size="sm" className="h-7 bg-blue-600 hover:bg-blue-700 gap-1.5 text-xs" onClick={handleSave} disabled={saving}>
            <Save className="w-3.5 h-3.5" /> {saving ? "Saving…" : "Save"}
          </Button>
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">

        {/* Widgets panel + toggle */}
        {!previewing && (
          <div className="flex flex-shrink-0">
            {widgetsOpen && <WidgetPanel onAddWidget={handleAddWidget} />}
            <button
              onClick={() => setWidgetsOpen(o => !o)}
              title={widgetsOpen ? "Collapse widgets" : "Expand widgets"}
              className="w-5 bg-slate-900 border-r border-slate-700 hover:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-white transition-colors flex-shrink-0"
            >
              {widgetsOpen ? <ChevronLeft className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            </button>
          </div>
        )}

        {/* Zone layers panel + toggle */}
        {!previewing && (
          <div className="flex flex-shrink-0">
            {layersOpen && (
              <ZoneLayersPanel
                layers={creative.layers_json}
                selectedId={selectedId}
                onSelect={setSelectedId}
                onReorder={handleReorderLayer}
                onToggleVisible={handleToggleVisible}
                onToggleLock={handleToggleLock}
                onRename={handleRenameLayer}
              />
            )}
            <button
              onClick={() => setLayersOpen(o => !o)}
              title={layersOpen ? "Collapse layers" : "Expand layers"}
              className="w-5 bg-slate-900 border-r border-slate-700 hover:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-white transition-colors flex-shrink-0"
            >
              {layersOpen ? <ChevronLeft className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            </button>
          </div>
        )}

        {/* Canvas scroll area */}
        <div className="flex-1 overflow-auto bg-slate-800 flex items-start justify-center p-8">
          {previewing ? (
            <CanvasCreativeRenderer creative={creative} scale={scale} />
          ) : (
            <CanvasArea
              creative={creative}
              selectedId={selectedId}
              scale={scale}
              onSelectLayer={setSelectedId}
              onUpdateLayer={handleUpdateLayer}
            />
          )}
        </div>

        {/* Properties panel + toggle */}
        {!previewing && (
          <div className="flex flex-shrink-0">
            <button
              onClick={() => setPropsOpen(o => !o)}
              title={propsOpen ? "Collapse properties" : "Expand properties"}
              className="w-5 bg-slate-900 border-l border-slate-700 hover:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-white transition-colors flex-shrink-0"
            >
              {propsOpen ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
            </button>
            {propsOpen && (
              <PropertiesPanel
                creative={creative}
                selectedLayer={selectedLayer}
                onUpdateLayer={handleUpdateLayer}
                onDeleteLayer={handleDeleteLayer}
                onUpdateCreative={handleUpdateCreative}
                onReorderLayer={handleReorderLayer}
              />
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Studio List Page ─────────────────────────────────────────────────────────
export default function Studio() {
  const queryClient = useQueryClient();
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  const [editingCreative, setEditingCreative] = useState(null);
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [newName, setNewName] = useState("");
  const [newW, setNewW] = useState(1280);
  const [newH, setNewH] = useState(640);

  const { data: creatives = [] } = useQuery({
    queryKey: ["canvas_creatives", activeOrgId],
    queryFn: () => base44.entities.CanvasCreative.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.CanvasCreative.create(data),
    onSuccess: (created) => {
      queryClient.invalidateQueries({ queryKey: ["canvas_creatives"] });
      setShowNewDialog(false);
      setEditingCreative(created);
    },
  });

  const saveMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CanvasCreative.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["canvas_creatives"] }); toast.success("Saved"); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CanvasCreative.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["canvas_creatives"] }); toast.success("Deleted"); },
  });

  const handleCreate = () => {
    if (!newName.trim()) return toast.error("Enter a name");
    createMutation.mutate({ org_id: activeOrgId, name: newName, width: newW, height: newH, background_color: "#000000", layers_json: [] });
  };

  const handleSave = async (creative) => {
    console.log('[Studio] Saving creative:', { id: creative.id, layers: creative.layers_json?.length });
    await saveMutation.mutateAsync({ 
      id: creative.id, 
      data: { 
        name: creative.name, 
        width: creative.width, 
        height: creative.height, 
        background_color: creative.background_color, 
        layers_json: creative.layers_json,
        sync_mode: creative.sync_mode || 'independent',
      } 
    });
  };

  if (!canAccessModule('module_studio')) return <AccessDenied reason="module" />;

  // Editor view
  if (editingCreative) {
    return (
      <div className="h-full">
        <StudioEditor
          creative={editingCreative}
          onClose={() => setEditingCreative(null)}
          onSave={async (updated) => {
            await handleSave(updated);
            setEditingCreative(updated);
          }}
        />
      </div>
    );
  }

  // List view
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-600" /> ScreenFleet Studio
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">Create reusable canvas creatives for use in playlists and zones</p>
        </div>
        <Button onClick={() => setShowNewDialog(true)} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
          <Plus className="w-4 h-4" /> New Creative
        </Button>
      </div>

      {creatives.length === 0 ? (
        <div className="text-center py-20 text-slate-400">
          <Layers className="w-12 h-12 mx-auto mb-4 opacity-20" />
          <p className="text-sm font-medium">No creatives yet</p>
          <p className="text-xs mt-1">Create your first canvas creative to get started</p>
          <Button onClick={() => setShowNewDialog(true)} variant="outline" className="mt-4 gap-1.5">
            <Plus className="w-4 h-4" /> New Creative
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {creatives.map((c) => (
            <div key={c.id} className="group border border-slate-200 rounded-xl bg-white overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={() => setEditingCreative(c)}>
              <div className="aspect-video bg-slate-900 relative overflow-hidden flex items-center justify-center">
                <CanvasCreativeRenderer creative={c} scale={Math.min(240 / (c.width || 1280), 135 / (c.height || 640))} />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-800 truncate">{c.name}</p>
                  <p className="text-[10px] text-slate-400">{c.width}×{c.height}px · {(c.layers_json || []).length} layer{(c.layers_json || []).length !== 1 ? "s" : ""}</p>
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-blue-600" onClick={(e) => { e.stopPropagation(); setEditingCreative(c); }}>
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-500" onClick={(e) => { e.stopPropagation(); deleteMutation.mutate(c.id); }}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showNewDialog} onOpenChange={setShowNewDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>New Canvas Creative</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Name</label>
              <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="e.g. RAGBRAI Ad Slide" className="h-8" />
            </div>
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="text-xs font-medium text-slate-700 block mb-1">Width (px)</label>
                <Input type="number" value={newW} onChange={(e) => setNewW(Number(e.target.value))} className="h-8" />
              </div>
              <div className="flex-1">
                <label className="text-xs font-medium text-slate-700 block mb-1">Height (px)</label>
                <Input type="number" value={newH} onChange={(e) => setNewH(Number(e.target.value))} className="h-8" />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" size="sm" onClick={() => setShowNewDialog(false)}>Cancel</Button>
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={handleCreate} disabled={createMutation.isPending}>
                Create
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}