/**
 * Campaigns — manage campaigns linked to advertisers for OOH reporting.
 */
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Megaphone, Calendar, DollarSign, Edit2, Trash2, Search } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

const STATUS_STYLES = {
  draft:     "bg-slate-100 text-slate-600",
  active:    "bg-green-100 text-green-700",
  paused:    "bg-amber-100 text-amber-700",
  completed: "bg-blue-100 text-blue-700",
  archived:  "bg-slate-50 text-slate-400",
};

const EMPTY_FORM = {
  name: "", advertiser_id: "", status: "draft", start_date: "", end_date: "",
  sales_owner: "", internal_order_number: "", contract_value: "",
  contracted_play_count: "", contracted_hours: "", reporting_notes: "", is_active: true,
};

export default function Campaigns() {
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);

  const { data: advertisers = [] } = useQuery({
    queryKey: ["advertisers", activeOrgId],
    queryFn: () => base44.entities.Advertiser.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const { data: campaigns = [], isLoading } = useQuery({
    queryKey: ["campaigns", activeOrgId],
    queryFn: () => base44.entities.Campaign.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const payload = {
        ...data,
        contract_value: data.contract_value ? Number(data.contract_value) : null,
        contracted_play_count: data.contracted_play_count ? Number(data.contracted_play_count) : null,
        contracted_hours: data.contracted_hours ? Number(data.contracted_hours) : null,
      };
      if (editing) return base44.entities.Campaign.update(editing.id, payload);
      return base44.entities.Campaign.create({ ...payload, org_id: activeOrgId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaigns"] });
      setDialogOpen(false);
      setEditing(null);
      setForm(EMPTY_FORM);
      toast.success(editing ? "Campaign updated" : "Campaign created");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Campaign.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["campaigns"] }); toast.success("Campaign deleted"); },
  });

  const openCreate = () => { setEditing(null); setForm(EMPTY_FORM); setDialogOpen(true); };
  const openEdit = (c) => { setEditing(c); setForm({ ...EMPTY_FORM, ...c, contract_value: c.contract_value ?? "", contracted_play_count: c.contracted_play_count ?? "", contracted_hours: c.contracted_hours ?? "" }); setDialogOpen(true); };

  const getAdvertiserName = (id) => advertisers.find(a => a.id === id)?.name || "—";

  if (!canAccessModule('module_ooh_campaigns')) return <AccessDenied reason="module" />;

  const filtered = campaigns.filter(c =>
    c.name?.toLowerCase().includes(search.toLowerCase()) ||
    getAdvertiserName(c.advertiser_id).toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 lg:p-8 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Campaigns</h1>
          <p className="text-sm text-slate-500 mt-0.5">Track contracted campaigns and delivery against commitments</p>
        </div>
        <Button onClick={openCreate} className="gap-2">
          <Plus className="w-4 h-4" /> New Campaign
        </Button>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input placeholder="Search campaigns…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      {isLoading && <p className="text-sm text-slate-400 text-center py-8">Loading…</p>}
      {!isLoading && filtered.length === 0 && (
        <div className="text-center py-16 text-slate-400">
          <Megaphone className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No campaigns yet. Create advertisers first, then build campaigns.</p>
        </div>
      )}

      <div className="space-y-2">
        {filtered.map(campaign => (
          <div key={campaign.id} className="bg-white border border-slate-200 rounded-xl p-4 hover:border-blue-300 transition-all">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="font-semibold text-slate-900">{campaign.name}</span>
                  <Badge className={`text-[10px] capitalize px-2 ${STATUS_STYLES[campaign.status] || STATUS_STYLES.draft}`}>
                    {campaign.status}
                  </Badge>
                </div>
                <div className="flex flex-wrap gap-4 text-xs text-slate-500">
                  <span className="font-medium text-slate-600">{getAdvertiserName(campaign.advertiser_id)}</span>
                  {campaign.start_date && campaign.end_date && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {campaign.start_date} → {campaign.end_date}
                    </span>
                  )}
                  {campaign.contract_value && (
                    <span className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      ${Number(campaign.contract_value).toLocaleString()}
                    </span>
                  )}
                  {campaign.contracted_play_count && (
                    <span>{Number(campaign.contracted_play_count).toLocaleString()} plays contracted</span>
                  )}
                  {campaign.internal_order_number && (
                    <span className="text-slate-400">IO# {campaign.internal_order_number}</span>
                  )}
                </div>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => openEdit(campaign)}>
                  <Edit2 className="w-3.5 h-3.5" />
                </Button>
                <Button
                  variant="ghost" size="sm" className="h-7 w-7 p-0 text-red-400 hover:text-red-600"
                  onClick={() => { if (confirm(`Delete "${campaign.name}"?`)) deleteMutation.mutate(campaign.id); }}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? "Edit Campaign" : "New Campaign"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-2">
            <div className="col-span-2">
              <Label className="text-xs">Campaign Name *</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Q2 Brand Awareness" className="mt-1" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Advertiser *</Label>
              <Select value={form.advertiser_id} onValueChange={v => setForm(f => ({ ...f, advertiser_id: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select advertiser…" /></SelectTrigger>
                <SelectContent>
                  {advertisers.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["draft","active","paused","completed","archived"].map(s => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">IO Number</Label>
              <Input value={form.internal_order_number} onChange={e => setForm(f => ({ ...f, internal_order_number: e.target.value }))} placeholder="IO-2024-001" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Start Date</Label>
              <Input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">End Date</Label>
              <Input type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Contract Value ($)</Label>
              <Input type="number" value={form.contract_value} onChange={e => setForm(f => ({ ...f, contract_value: e.target.value }))} placeholder="0.00" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Contracted Plays</Label>
              <Input type="number" value={form.contracted_play_count} onChange={e => setForm(f => ({ ...f, contracted_play_count: e.target.value }))} placeholder="0" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Contracted Hours</Label>
              <Input type="number" value={form.contracted_hours} onChange={e => setForm(f => ({ ...f, contracted_hours: e.target.value }))} placeholder="0" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Sales Owner</Label>
              <Input value={form.sales_owner} onChange={e => setForm(f => ({ ...f, sales_owner: e.target.value }))} placeholder="Name or email" className="mt-1" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Reporting Notes</Label>
              <Input value={form.reporting_notes} onChange={e => setForm(f => ({ ...f, reporting_notes: e.target.value }))} placeholder="Internal notes for reports…" className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => saveMutation.mutate(form)} disabled={!form.name || !form.advertiser_id || saveMutation.isPending}>
              {saveMutation.isPending ? "Saving…" : editing ? "Save Changes" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}