import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, DollarSign, AlertCircle, TrendingUp } from "lucide-react";

const SUBSCRIPTION_STATUS_COLORS = {
  active: "bg-green-100 text-green-800",
  past_due: "bg-yellow-100 text-yellow-800",
  canceled: "bg-slate-100 text-slate-800",
  trialing: "bg-blue-100 text-blue-800",
  unpaid: "bg-red-100 text-red-800",
};

export default function AdminBilling() {
  const { hasPlatformRole } = useAuthority();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [planFilter, setPlanFilter] = useState("all");

  const { data: orgs = [] } = useQuery({
    queryKey: ["orgs"],
    queryFn: () => base44.entities.Organization.list(),
  });

  // Filter organizations (must run on every render, before conditional returns)
  const filteredOrgs = useMemo(() => {
    return orgs.filter((org) => {
      const matchesStatus = statusFilter === "all" || org.subscription_status === statusFilter;
      const matchesPlan = planFilter === "all" || org.plan_slug === planFilter;
      const matchesSearch =
        !searchQuery ||
        org.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        org.owner_email?.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesStatus && matchesPlan && matchesSearch;
    });
  }, [orgs, statusFilter, planFilter, searchQuery]);

  // Calculate billing stats (must run on every render, before conditional returns)
  const stats = {
    totalOrgs: orgs.length,
    activeSubscriptions: orgs.filter((o) => o.subscription_status === "active").length,
    totalMRR: orgs.filter((o) => o.subscription_status === "active").reduce((sum, org) => {
      const prices = { starter: 99, growth: 299, total360: 999 };
      return sum + (prices[org.plan_slug] || 0);
    }, 0),
    pastDue: orgs.filter((o) => o.subscription_status === "past_due").length,
  };

  if (!hasPlatformRole(['platform_owner', 'platform_admin', 'platform_support'])) return <AccessDenied reason="platform" />;

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Billing & Subscriptions</h1>
        <p className="text-sm text-slate-500 mt-1">Manage organization subscriptions and billing status</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Total Organizations</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-slate-900">{stats.totalOrgs}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Active Subscriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{stats.activeSubscriptions}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" /> Est. Monthly Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600">${stats.totalMRR.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Past Due</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-yellow-600">{stats.pastDue}</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Filters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Search</label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Organization name or email…"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="h-8 pl-8"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Subscription Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="trialing">Trialing</SelectItem>
                  <SelectItem value="past_due">Past Due</SelectItem>
                  <SelectItem value="canceled">Canceled</SelectItem>
                  <SelectItem value="unpaid">Unpaid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Plan</label>
              <Select value={planFilter} onValueChange={setPlanFilter}>
                <SelectTrigger className="h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Plans</SelectItem>
                  <SelectItem value="starter">Starter</SelectItem>
                  <SelectItem value="growth">Growth</SelectItem>
                  <SelectItem value="total360">Total360</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Organizations <span className="text-sm font-normal text-slate-500">({filteredOrgs.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredOrgs.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <DollarSign className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No organizations match the current filters</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                   <TableHead>Organization</TableHead>
                    <TableHead>Owner Email</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Subscription Status</TableHead>
                    <TableHead>Est. Monthly</TableHead>
                    <TableHead>Trial Ends</TableHead>
                    <TableHead>Plan Expires</TableHead>
                    <TableHead>Billing</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrgs.map((org) => {
                    const planPrices = { starter: 99, growth: 299, total360: 999 };
                    const monthlyPrice = planPrices[org.plan_slug] || 0;

                    return (
                      <TableRow key={org.id}>
                        <TableCell className="font-medium text-slate-900">
                           <div className="flex items-center gap-2">
                             {org.name}
                             {org.plan_source === "legion_hub"
                               ? <Badge className="text-[10px] bg-orange-100 text-orange-700">Hub</Badge>
                               : <Badge className="text-[10px] bg-blue-100 text-blue-700">Direct</Badge>
                             }
                           </div>
                         </TableCell>
                        <TableCell className="text-sm text-slate-600">{org.owner_email}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs capitalize">
                            {org.plan_slug}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={`text-xs ${
                              SUBSCRIPTION_STATUS_COLORS[org.subscription_status] ||
                              "bg-slate-100 text-slate-800"
                            }`}
                          >
                            {org.subscription_status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm font-medium text-slate-900">
                          ${monthlyPrice}
                          {org.subscription_status === "active" && <span className="text-slate-500 font-normal">/mo</span>}
                          {org.subscription_status !== "active" && (
                            <span className="text-slate-400 font-normal text-xs ml-1">inactive</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-slate-600">
                          {org.trial_ends_at ? new Date(org.trial_ends_at).toLocaleDateString() : "—"}
                        </TableCell>
                        <TableCell className="text-sm text-slate-600">
                           {org.plan_expires_at ? new Date(org.plan_expires_at).toLocaleDateString() : "—"}
                         </TableCell>
                         <TableCell>
                           {org.plan_source === 'legion_hub' ? (
                             <div className="flex flex-col gap-1">
                               <span className="text-xs bg-orange-50 text-orange-600 border border-orange-200 px-2 py-1 rounded-full font-medium w-fit">
                                 Legion Hub
                               </span>
                               <span className="text-xs text-slate-400">
                                 {org.legion_hub_plan_tier || 'unknown tier'}
                               </span>
                             </div>
                           ) : (
                             <span className="text-xs bg-blue-50 text-blue-600 border border-blue-200 px-2 py-1 rounded-full font-medium">
                               Stripe Direct
                             </span>
                           )}
                         </TableCell>
                        </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}