import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, LayoutGrid, Square } from "lucide-react";
import LayoutTemplateDialog from "@/components/layouts/LayoutTemplateDialog";
import LayoutZoneEditor from "@/components/layouts/LayoutZoneEditor";

export default function LayoutTemplates() {
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  console.log("[LayoutTemplates] ACTIVE ORG:", activeOrgId);
  const qc = useQueryClient();
  const [templateDialog, setTemplateDialog] = useState(null);
  const [editingTemplate, setEditingTemplate] = useState(null);

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ["layout_templates", activeOrgId],
    queryFn: () => base44.entities.LayoutTemplate.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  // Scope zone loading to this org's templates only — never load globally
  const templateIds = templates.map(t => t.id);
  const { data: allZones = [] } = useQuery({
    queryKey: ["layout_zones_scoped", activeOrgId, templateIds.length],
    queryFn: async () => {
      if (templateIds.length === 0) return [];
      const results = await Promise.all(
        templateIds.map(id => base44.entities.LayoutZone.filter({ layout_template_id: id }))
      );
      return results.flat();
    },
    enabled: !!activeOrgId && templateIds.length > 0,
  });

  const deleteTemplate = useMutation({
    mutationFn: async (template) => {
      const zones = allZones.filter(z => z.layout_template_id === template.id);
      await Promise.all(zones.map(z => base44.entities.LayoutZone.delete(z.id)));
      await base44.entities.LayoutTemplate.delete(template.id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["layout_templates"] });
      qc.invalidateQueries({ queryKey: ["layout_zones_scoped"] });
    },
  });

  if (!canAccessModule('module_layouts')) return <AccessDenied reason="module" />;

  // Full-screen zone editor mode
  if (editingTemplate) {
    return (
      <LayoutZoneEditor
        template={editingTemplate}
        onBack={() => {
          setEditingTemplate(null);
          qc.invalidateQueries({ queryKey: ["layout_zones_scoped"] });
        }}
      />
    );
  }

  if (!activeOrgId) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-400">
        No organization selected.
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <LayoutGrid className="w-6 h-6 text-blue-600" /> Layout Templates
          </h1>
          <p className="text-slate-500 text-sm mt-1">
            Define reusable zone layouts. Templates are org-scoped and can be assigned to any screen with matching dimensions.
          </p>
        </div>
        <Button onClick={() => setTemplateDialog({ mode: "create" })}>
          <Plus className="w-4 h-4" /> New Template
        </Button>
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-slate-300 border-t-blue-600 rounded-full animate-spin" />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {templates.map(template => {
          const zones = allZones.filter(z => z.layout_template_id === template.id);
          const aspect = template.canvas_height / template.canvas_width;

          return (
            <div key={template.id} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col hover:shadow-md transition-shadow">
              {/* Canvas thumbnail */}
              <div
                className="relative bg-slate-900 cursor-pointer group"
                style={{ paddingTop: `${Math.min(aspect * 100, 75)}%` }}
                onClick={() => setEditingTemplate(template)}
              >
                <div className="absolute inset-0 p-2">
                  {zones.map(zone => (
                    <div
                      key={zone.id}
                      className="absolute border border-blue-400/50 bg-blue-500/10 rounded-sm"
                      style={{
                        left: `${(zone.x / template.canvas_width) * 100}%`,
                        top: `${(zone.y / template.canvas_height) * 100}%`,
                        width: `${(zone.width / template.canvas_width) * 100}%`,
                        height: `${(zone.height / template.canvas_height) * 100}%`,
                      }}
                    >
                      <span className="text-[7px] text-blue-300 p-0.5 leading-none truncate block">
                        {zone.name}
                      </span>
                    </div>
                  ))}
                  {zones.length === 0 && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-white/20 text-xs">No zones — click to add</span>
                    </div>
                  )}
                </div>
                {/* Edit overlay */}
                <div className="absolute inset-0 bg-blue-600/0 group-hover:bg-blue-600/10 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <span className="bg-blue-600 text-white text-xs px-3 py-1 rounded-full font-medium shadow">
                    Edit Zones
                  </span>
                </div>
              </div>

              {/* Info */}
              <div className="p-4 flex-1 flex flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900 truncate">{template.name}</div>
                    <div className="text-xs text-slate-400 mt-0.5 font-mono">
                      {template.canvas_width}×{template.canvas_height}px · {zones.length} zone{zones.length !== 1 ? "s" : ""}
                    </div>
                  </div>
                  {template.is_archived && <Badge variant="secondary" className="text-xs flex-shrink-0">Archived</Badge>}
                </div>

                {template.description && (
                  <p className="text-xs text-slate-400 mt-2 line-clamp-2">{template.description}</p>
                )}

                <div className="flex gap-2 mt-auto pt-3">
                  <Button
                    size="sm"
                    className="flex-1 h-8 text-xs"
                    onClick={() => setEditingTemplate(template)}
                  >
                    <Square className="w-3 h-3 mr-1" /> Edit Zones
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8"
                    onClick={() => setTemplateDialog({ mode: "edit", template })}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8 text-red-400 hover:text-red-600"
                    onClick={() => deleteTemplate.mutate(template)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}

        {!isLoading && templates.length === 0 && (
          <div className="col-span-full text-center py-20 text-slate-400">
            <LayoutGrid className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No layout templates yet</p>
            <p className="text-sm mt-1">Create a template to define zone structures for your screens</p>
          </div>
        )}
      </div>

      {templateDialog && (
        <LayoutTemplateDialog
          mode={templateDialog.mode}
          template={templateDialog.template}
          orgId={activeOrgId}
          onClose={() => setTemplateDialog(null)}
          onSaved={() => {
            setTemplateDialog(null);
            qc.invalidateQueries({ queryKey: ["layout_templates"] });
          }}
        />
      )}
    </div>
  );
}