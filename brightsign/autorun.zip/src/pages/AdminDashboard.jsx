import React from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Building2, Layers, CreditCard, AlertCircle,
  Clock, AlertTriangle, DollarSign, Users, ArrowRight, Check, Monitor, Link2, RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

const StatCard = ({ label, value, icon: Icon, trend, color = "blue" }) => (
  <div className="bg-white rounded-xl border border-slate-200 p-5">
    <div className="flex items-start justify-between">
      <div className="flex-1">
        <p className="text-xs text-slate-500 uppercase tracking-widest font-medium mb-1">{label}</p>
        <p className={`text-3xl font-bold text-${color}-700`}>{value}</p>
        {trend && <p className="text-xs text-slate-400 mt-1.5">{trend}</p>}
      </div>
      <div className={`w-12 h-12 rounded-lg bg-${color}-50 flex items-center justify-center flex-shrink-0`}>
        <Icon className={`w-6 h-6 text-${color}-600`} />
      </div>
    </div>
  </div>
);

const QuickLinkCard = ({ title, description, icon: Icon, page }) => (
  <Link
    to={createPageUrl(page)}
    className="bg-white border border-slate-200 rounded-xl p-5 hover:border-blue-400 hover:shadow-md transition-all group"
  >
    <div className="flex items-start justify-between mb-3">
      <div>
        <p className="text-xs text-slate-500 mb-1">{description}</p>
        <p className="text-sm font-bold text-slate-800 group-hover:text-blue-700 transition-colors">{title}</p>
      </div>
      <div className="w-10 h-10 rounded-lg bg-blue-50 group-hover:bg-blue-100 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-blue-600" />
      </div>
    </div>
    <div className="flex items-center gap-1 text-xs text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity">
      Manage <ArrowRight className="w-3 h-3" />
    </div>
  </Link>
);

const BillingAlert = ({ org, type }) => {
  const now = new Date();
  let message = "";
  let severity = "info";

  if (type === "past_due") {
    message = `Past due since ${new Date(org.updated_date).toLocaleDateString()}`;
    severity = "error";
  } else if (type === "expiring_soon") {
    const daysLeft = Math.ceil((new Date(org.plan_expires_at) - now) / (1000 * 60 * 60 * 24));
    message = `Trial expires in ${daysLeft} days`;
    severity = daysLeft < 7 ? "error" : "warning";
  }

  const icons = { error: AlertTriangle, warning: AlertCircle, info: Clock };
  const Icon = icons[severity];
  const bgColors = { error: "bg-red-50 border-red-200", warning: "bg-amber-50 border-amber-200", info: "bg-blue-50 border-blue-200" };
  const textColors = { error: "text-red-700", warning: "text-amber-700", info: "text-blue-700" };

  return (
    <div className={`flex items-start gap-3 rounded-lg border p-3 ${bgColors[severity]}`}>
      <Icon className={`w-4 h-4 flex-shrink-0 mt-0.5 ${textColors[severity]}`} />
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium ${textColors[severity]}`}>{org.name}</p>
        <p className={`text-xs mt-0.5 ${textColors[severity]}`}>{message}</p>
      </div>
    </div>
  );
};

function HubStatusPanel({ orgs }) {
  const [syncing, setSyncing] = useState(false);
  const hubOrgs = orgs.filter(o => o.plan_source === 'legion_hub');
  const directOrgs = orgs.filter(o => o.plan_source !== 'legion_hub');

  const handleSyncStatus = async () => {
    setSyncing(true);
    try {
      for (const org of hubOrgs) {
        await base44.functions.invoke('publishToHub', {
          event_type: 'screenfleet.status.updated',
          org_id: org.id,
          payload: { plan_slug: org.plan_slug, subscription_status: org.subscription_status, legion_hub_plan_tier: org.legion_hub_plan_tier },
        });
      }
      toast.success(`Synced ${hubOrgs.length} Hub org${hubOrgs.length !== 1 ? 's' : ''} to Legion Hub`);
    } catch (err) {
      toast.error('Hub sync failed: ' + err?.message);
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Link2 className="w-4 h-4 text-orange-500" />
          <h2 className="text-sm font-semibold text-slate-700">Legion Hub Connection</h2>
        </div>
        <Button size="sm" variant="outline" onClick={handleSyncStatus} disabled={syncing || hubOrgs.length === 0} className="h-7 text-xs gap-1.5">
          <RefreshCw className={`w-3 h-3 ${syncing ? 'animate-spin' : ''}`} />
          {syncing ? 'Syncing…' : 'Sync Status to Hub'}
        </Button>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
          <p className="text-[10px] text-orange-600 uppercase tracking-widest font-medium mb-1">Hub-Authorized</p>
          <p className="text-2xl font-bold text-orange-700">{hubOrgs.length}</p>
          <p className="text-[10px] text-orange-500 mt-0.5">orgs via Legion Hub</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-[10px] text-blue-600 uppercase tracking-widest font-medium mb-1">Direct Billing</p>
          <p className="text-2xl font-bold text-blue-700">{directOrgs.length}</p>
          <p className="text-[10px] text-blue-500 mt-0.5">orgs via Stripe</p>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-medium mb-1">Last Hub Sync</p>
          <p className="text-sm font-bold text-slate-700 mt-1">
            {hubOrgs.length > 0 && hubOrgs.some(o => o.last_hub_sync_at)
              ? new Date(Math.max(...hubOrgs.filter(o => o.last_hub_sync_at).map(o => new Date(o.last_hub_sync_at)))).toLocaleDateString()
              : '—'}
          </p>
        </div>
      </div>
      {hubOrgs.length > 0 && (
        <div className="mt-3 space-y-1.5">
          {hubOrgs.slice(0, 5).map(org => (
            <div key={org.id} className="flex items-center justify-between text-xs px-2 py-1.5 bg-slate-50 rounded">
              <span className="font-medium text-slate-700">{org.name}</span>
              <div className="flex items-center gap-2">
                <Badge className="text-[10px] bg-orange-100 text-orange-700">{org.legion_hub_plan_tier || 'hub'}</Badge>
                <Badge className={`text-[10px] ${org.subscription_status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}`}>{org.subscription_status}</Badge>
              </div>
            </div>
          ))}
          {hubOrgs.length > 5 && <p className="text-[10px] text-slate-400 text-center">+{hubOrgs.length - 5} more hub orgs</p>}
        </div>
      )}
    </div>
  );
}

export default function AdminDashboard() {
  const { hasPlatformRole } = useAuthority();

  const { data: orgs = [] } = useQuery({
    queryKey: ["all-orgs"],
    queryFn: () => base44.entities.Organization.list()
  });

  // V2 Assets — replaces V1 Trucks
  const { data: assets = [] } = useQuery({
    queryKey: ["all-assets"],
    queryFn: () => base44.entities.Asset.list(),
    refetchInterval: 60000,
  });

  // V2 Screens
  const { data: v2Screens = [] } = useQuery({
    queryKey: ["all-v2-screens"],
    queryFn: () => base44.entities.Screen.list(),
    refetchInterval: 60000,
  });

  const { data: heartbeats = [] } = useQuery({
    queryKey: ["all-heartbeats"],
    queryFn: () => base44.entities.PlayerHeartbeat.list(),
    refetchInterval: 60000,
  });

  const { data: orgMembers = [] } = useQuery({
    queryKey: ["all-org-members"],
    queryFn: () => base44.entities.OrgMember.list(),
    refetchInterval: 60000,
  });

  if (!hasPlatformRole(['platform_owner', 'platform_admin', 'platform_support'])) return <AccessDenied reason="platform" />;

  const ONLINE_MS = 2 * 60 * 1000;
  const onlineScreenIds = new Set(
    heartbeats
      .filter(h => h.last_seen_at && (Date.now() - new Date(h.last_seen_at).getTime()) < ONLINE_MS)
      .map(h => h.screen_id)
  );
  const onlineCount = v2Screens.filter(s => onlineScreenIds.has(s.id)).length;
  const screenHealthPct = v2Screens.length > 0 ? Math.round((onlineCount / v2Screens.length) * 100) : 0;

  // Calculate KPIs
  const activeOrgs = orgs.filter(o => o.is_active !== false);
  const activeSubsOrgs = orgs.filter(o => o.subscription_status === "active");
  const now = new Date();
  const trialExpiringOrgs = orgs.filter(o => {
    if (o.trial_ends_at) {
      const daysLeft = (new Date(o.trial_ends_at) - now) / (1000 * 60 * 60 * 24);
      return daysLeft > 0 && daysLeft <= 7;
    }
    return false;
  });
  const pastDueOrgs = orgs.filter(o => o.subscription_status === "past_due");
  const billingAlertOrgs = [...pastDueOrgs, ...trialExpiringOrgs];

  const estimatedMRR = orgs.reduce((sum, org) => {
    if (org.subscription_status !== "active" && org.subscription_status !== "past_due") return sum;
    return sum + (org.plan_slug === "total360" ? 299 : org.plan_slug === "growth" ? 99 : 29);
  }, 0);

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-6 bg-slate-50 min-h-full">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Platform Dashboard</h1>
        <p className="text-sm text-slate-500 mt-1">System health, billing overview, and platform management</p>
      </div>

      {/* Billing Alerts */}
      {billingAlertOrgs.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h2 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            Billing Attention Required
          </h2>
          <div className="space-y-2">
            {pastDueOrgs.map(org => (
              <BillingAlert key={org.id} org={org} type="past_due" />
            ))}
            {trialExpiringOrgs.map(org => (
              <BillingAlert key={org.id} org={org} type="expiring_soon" />
            ))}
          </div>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Organizations" value={orgs.length} icon={Building2} color="blue" trend={`${activeOrgs.length} active`} />
        <StatCard label="Active Subscriptions" value={activeSubsOrgs.length} icon={Check} color="green" trend={`${pastDueOrgs.length} past due`} />
        <StatCard label="Estimated MRR" value={`$${estimatedMRR}`} icon={DollarSign} color="emerald" trend="Monthly recurring" />
        <StatCard label="Total Assets (V2)" value={assets.length} icon={Layers} color="purple" trend={`${onlineCount}/${v2Screens.length} screens online`} />
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Left: Organization Overview */}
        <div className="lg:col-span-1 bg-white rounded-xl border border-slate-200 p-5">
          <h2 className="text-sm font-semibold text-slate-700 mb-4">Organization Summary</h2>
          
          <div className="space-y-4 mb-6">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div>
                <p className="text-xs text-slate-500 mb-1">Active Organizations</p>
                <p className="text-2xl font-bold text-slate-800">{activeOrgs.length}</p>
              </div>
              <span className="text-xs font-medium text-green-700 bg-green-50 px-2 py-1 rounded">{Math.round((activeOrgs.length / orgs.length) * 100)}%</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div>
                <p className="text-xs text-slate-500 mb-1">Total Users</p>
                <p className="text-2xl font-bold text-slate-800">{orgMembers.filter(m => m.status === "active" || m.status === "joined").length}</p>
              </div>
              <Users className="w-6 h-6 text-slate-400" />
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div>
                <p className="text-xs text-slate-500 mb-1">V2 Assets</p>
                <p className="text-2xl font-bold text-slate-800">{assets.length}</p>
              </div>
              <span className="text-xs font-medium text-blue-700 bg-blue-50 px-2 py-1 rounded">
                {assets.length > 0 ? Math.round((assets.filter(a => a.status === "active").length / assets.length) * 100) : 0}% active
              </span>
            </div>
          </div>

          <Link 
            to={createPageUrl("Organizations")}
            className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1"
          >
            View All <ArrowRight className="w-3.5 h-3.5" />
          </Link>

          {/* Plan Distribution */}
          <div className="mt-5 pt-4 border-t border-slate-100">
            <p className="text-xs font-semibold text-slate-700 mb-3">Plan Distribution</p>
            <div className="space-y-2">
              {["starter", "growth", "total360"].map(plan => {
                const count = orgs.filter(o => o.plan_slug === plan).length;
                return (
                  <div key={plan} className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 capitalize">{plan}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-500"
                          style={{ width: orgs.length > 0 ? `${(count / orgs.length) * 100}%` : "0%" }}
                        />
                      </div>
                      <span className="font-medium text-slate-700 w-6">{count}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Quick Actions & Health */}
        <div className="lg:col-span-2 space-y-6">

          {/* System Health */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h2 className="text-sm font-semibold text-slate-700 mb-4">System Health</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg border border-green-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-green-700">Screen Uptime</span>
                  <Check className="w-4 h-4 text-green-600" />
                </div>
                <p className="text-2xl font-bold text-green-700">{screenHealthPct}%</p>
                <p className="text-[10px] text-green-600 mt-1">{onlineCount} of {v2Screens.length} online (live heartbeat)</p>
              </div>

              <div className={`p-4 rounded-lg border ${pastDueOrgs.length > 0 ? "bg-red-50 border-red-200" : "bg-green-50 border-green-200"}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-slate-700">Billing Status</span>
                  {pastDueOrgs.length > 0 ? (
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                  ) : (
                    <Check className="w-4 h-4 text-green-600" />
                  )}
                </div>
                <p className={`text-2xl font-bold ${pastDueOrgs.length > 0 ? "text-red-700" : "text-green-700"}`}>
                  {pastDueOrgs.length > 0 ? `${pastDueOrgs.length} Past Due` : "All Current"}
                </p>
                <p className={`text-[10px] mt-1 ${pastDueOrgs.length > 0 ? "text-red-600" : "text-green-600"}`}>
                  {activeSubsOrgs.length} subscriptions active
                </p>
              </div>
            </div>
          </div>

          {/* Hub Status */}
          <HubStatusPanel orgs={orgs} />

          {/* Quick Links */}
          <div>
            <h2 className="text-sm font-semibold text-slate-700 mb-3">Platform Management</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <QuickLinkCard 
                title="Manage Organizations" 
                description="View and manage all sub-accounts"
                icon={Building2}
                page="Organizations"
              />
              <QuickLinkCard 
                title="Subscription Plans" 
                description="Configure pricing and features"
                icon={DollarSign}
                page="Plans"
              />
              <QuickLinkCard 
                title="Billing Overview" 
                description="Monitor subscriptions and revenue"
                icon={CreditCard}
                page="AdminBilling"
              />
              <QuickLinkCard 
                title="V2 Assets" 
                description="Platform-wide assets and screens"
                icon={Layers}
                page="AdminAssets"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}