/**
 * Live Output — routed page. Thin wrapper around the canonical LiveOutputDashboard component.
 */
import LiveOutputDashboard from "@/components/live/LiveOutputDashboard";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";

export default function LiveOutput() {
  const { canAccessModule } = useAuthority();
  if (!canAccessModule('module_live_output')) return <AccessDenied reason="module" />;
  return <LiveOutputDashboard />;
}