import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import LegacyPageBanner from "@/components/LegacyPageBanner";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Undo2, Monitor, Layers, ZoomIn, ZoomOut, ArrowLeft, PenLine, CheckCircle2, Loader2 } from "lucide-react";
import ScreenSpecBadges from "@/components/screens/ScreenSpecBadges";
import { Slider } from "@/components/ui/slider";
import CanvasWorkspace from "@/components/editor/CanvasWorkspace";
import ZonePropertiesPanel from "@/components/editor/ZonePropertiesPanel";
import LayoutManager from "@/components/editor/LayoutManager";
import ScreenEditorLanding from "@/components/editor/ScreenEditorLanding";

export default function ScreenEditor() {
  const queryClient = useQueryClient();

  // Landing vs editor view
  const [editorTruckId, setEditorTruckId] = useState(null);
  const [editorLayout, setEditorLayout] = useState(null);

  // Canvas editor state
  const [selectedScreenId, setSelectedScreenId] = useState(null);
  const [selectedZoneId, setSelectedZoneId] = useState(null);
  const [showAllScreens, setShowAllScreens] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [editingLayoutName, setEditingLayoutName] = useState(false);
  const [layoutNameDraft, setLayoutNameDraft] = useState("");
  const [autoSaving, setAutoSaving] = useState(false);
  const [autoSaved, setAutoSaved] = useState(false);
  const [editingZone, setEditingZone] = useState(null);
  const autoSaveTimer = React.useRef(null);

  // Data queries
  const { data: trucks = [] } = useQuery({
    queryKey: ["trucks"],
    queryFn: () => base44.entities.Truck.list(),
  });

  const { data: allScreens = [] } = useQuery({
    queryKey: ["screens"],
    queryFn: () => base44.entities.Screen.list(),
  });

  // CRITICAL FIX: Load ONLY template zones (zone_scope="template")
  const { data: allZones = [] } = useQuery({
    queryKey: ["zones", editorLayout?.id, editorTruckId],
    queryFn: async () => {
      if (editorLayout?.id) {
        // When editing a layout, load ONLY template zones for that layout
        return base44.entities.Zone.filter({ 
          layout_id: editorLayout.id,
          zone_scope: "template"
        });
      } else if (editorTruckId) {
        // When in truck context without layout, still load template zones only
        const screens = await base44.entities.Screen.filter({ truck_id: editorTruckId });
        const screenIds = screens.map(s => s.id);
        const allZones = await base44.entities.Zone.list();
        // Return ONLY template zones that belong to these screens
        return allZones.filter(z => 
          screenIds.includes(z.screen_id) && 
          z.zone_scope === "template"
        );
      }
      return [];
    },
    enabled: !!(editorLayout?.id || editorTruckId),
  });

  const truckScreens = allScreens.filter((s) => s.truck_id === editorTruckId);
  const selectedScreen = allScreens.find((s) => s.id === selectedScreenId);

  // Get zones for current context: either layout-scoped or screen-scoped
  const displayZones = editorLayout
    ? allZones.filter((z) => z.layout_id === editorLayout.id)
    : selectedScreenId
    ? allZones.filter((z) => z.screen_id === selectedScreenId && !z.layout_id)
    : [];

  // Auto-select first screen when entering editor
  useEffect(() => {
    if (editorTruckId && truckScreens.length > 0 && !selectedScreenId) {
      setSelectedScreenId(truckScreens[0].id);
    }
  }, [editorTruckId, truckScreens, selectedScreenId]);

  // Reset selection when layout changes
  useEffect(() => {
    setSelectedZoneId(null);
    setEditingZone(null);
  }, [editorLayout?.id]);

  // Reset editing state when zone changes
  useEffect(() => {
    setEditingZone(null);
  }, [selectedZoneId]);

  const handleEnterEditor = (truckId, layout) => {
    setEditorTruckId(truckId);
    setEditorLayout(layout);
    setSelectedZoneId(null);
    setShowAllScreens(false);
    // Auto-select first screen of the truck
    const truckScreensForTruck = allScreens.filter((s) => s.truck_id === truckId);
    if (truckScreensForTruck.length > 0) {
      setSelectedScreenId(truckScreensForTruck[0].id);
    }
  };

  const handleBackToLanding = () => {
    setEditorTruckId(null);
    setEditorLayout(null);
    setSelectedZoneId(null);
  };

  const handleAddZone = async () => {
    const targetScreenId = editorLayout ? displayZones[0]?.screen_id || selectedScreenId : selectedScreenId;
    if (!targetScreenId) return;

    const newZone = {
      screen_id: targetScreenId,
      layout_id: editorLayout?.id || null,
      zone_scope: "template", // CRITICAL: Always create template zones in Screen Editor
      name: `Zone ${displayZones.length + 1}`,
      x: 0,
      y: 0,
      width: 100,
      height: 100,
      z_index: displayZones.length + 1,
      content_type: "empty",
      background_color: "#000000",
      is_visible: true,
      volume: 100,
      fit_mode: "fill",
    };

    const created = await base44.entities.Zone.create(newZone);
    setSelectedZoneId(created.id);
    queryClient.invalidateQueries({ queryKey: ["zones", editorLayout?.id, editorTruckId] });
  };

  const handleUpdateZone = (zoneId, updates) => {
    clearTimeout(autoSaveTimer.current);
    autoSaveTimer.current = setTimeout(async () => {
      setAutoSaving(true);
      try {
        await base44.entities.Zone.update(zoneId, updates);
        queryClient.invalidateQueries({ queryKey: ["zones", editorLayout?.id, editorTruckId] });
        setAutoSaved(true);
        setTimeout(() => setAutoSaved(false), 3000);
      } finally {
        setAutoSaving(false);
      }
    }, 1000);
  };

  const handleDeleteZone = async (zoneId) => {
    await base44.entities.Zone.delete(zoneId);
    queryClient.invalidateQueries({ queryKey: ["zones", editorLayout?.id, editorTruckId] });
    if (selectedZoneId === zoneId) setSelectedZoneId(null);
  };

  const handleRevert = () => {
    if (editorLayout) {
      queryClient.invalidateQueries({ queryKey: ["zones", editorLayout.id, editorTruckId] });
    }
  };

  const selectedZone = displayZones.find((z) => z.id === selectedZoneId);

  // ── LANDING ──
  if (!editorTruckId) {
    return (
      <div>
        <LegacyPageBanner
          pageName="Screen Editor (V1)"
          replacement="Layout Templates"
          replacementPath="/LayoutTemplates"
        />
        <ScreenEditorLanding
        trucks={trucks}
        allScreens={allScreens}
          onEnterEditor={handleEnterEditor}
        />
      </div>
    );
  }

  const handleRenameLayout = async () => {
    if (!editorLayout?.id || !layoutNameDraft.trim()) return;
    await base44.entities.Layout.update(editorLayout.id, { name: layoutNameDraft.trim() });
    setEditorLayout((prev) => ({ ...prev, name: layoutNameDraft.trim() }));
    queryClient.invalidateQueries({ queryKey: ["layouts", editorTruckId] });
    queryClient.invalidateQueries({ queryKey: ["allLayouts"] });
    setEditingLayoutName(false);
  };

  return (
    <div className="h-[calc(100vh-64px)] flex flex-col">
      {/* Toolbar */}
      <div className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 flex-shrink-0">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={handleBackToLanding} className="text-xs h-8 gap-1 text-slate-500 hover:text-slate-800">
            <ArrowLeft className="w-3.5 h-3.5" /> Back
          </Button>

          <div className="w-px h-6 bg-slate-200" />

          {editorLayout && (
            editingLayoutName ? (
              <div className="flex items-center gap-1">
                <input
                  autoFocus
                  value={layoutNameDraft}
                  onChange={(e) => setLayoutNameDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleRenameLayout();
                    if (e.key === "Escape") setEditingLayoutName(false);
                  }}
                  className="h-7 text-sm font-semibold border border-blue-400 rounded px-2 w-40 outline-none"
                />
                <Button size="sm" className="h-7 px-2 text-xs bg-blue-600 hover:bg-blue-700" onClick={handleRenameLayout}>Save</Button>
                <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setEditingLayoutName(false)}>Cancel</Button>
              </div>
            ) : (
              <button
                className="flex items-center gap-1.5 group"
                onClick={() => { setLayoutNameDraft(editorLayout.name); setEditingLayoutName(true); }}
              >
                <span className="text-sm font-semibold text-slate-700 group-hover:text-blue-600 transition-colors">{editorLayout.name}</span>
                <PenLine className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-500 transition-colors" />
              </button>
            )
          )}

          <div className="w-px h-6 bg-slate-200" />

          <div className="flex items-center gap-2">
            <Monitor className="w-4 h-4 text-slate-400" />
            <Select value={selectedScreenId || ""} onValueChange={setSelectedScreenId}>
              <SelectTrigger className="h-8 w-44 text-sm">
                <SelectValue placeholder="Select screen" />
              </SelectTrigger>
              <SelectContent>
                {truckScreens.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name}{s.width && s.height ? ` — ${s.width}×${s.height}` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="w-px h-6 bg-slate-200" />

          <Button variant="outline" size="sm" onClick={handleAddZone} disabled={!selectedScreenId} className="text-xs h-8">
            <Plus className="w-3.5 h-3.5 mr-1" /> Add Zone
          </Button>
        </div>

        <div className="flex items-center gap-2">
          {autoSaving && <span className="text-xs text-slate-400 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> Saving…</span>}
          {autoSaved && !autoSaving && <span className="text-xs text-green-600 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Saved</span>}
          {displayZones.length > 0 && !autoSaving && (
            <Button variant="ghost" size="sm" onClick={handleRevert} className="text-xs h-8 text-slate-500">
              <Undo2 className="w-3.5 h-3.5 mr-1" /> Reload
            </Button>
          )}

          <LayoutManager truckId={editorTruckId} onLoadLayout={handleEnterEditor} />

          <div className="w-px h-6 bg-slate-200" />

          <button
            onClick={() => setShowAllScreens(!showAllScreens)}
            className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border transition-all h-8 ${
              showAllScreens ? "bg-blue-50 border-blue-300 text-blue-700" : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            All Screens
          </button>

          <div className="w-px h-6 bg-slate-200" />

          <div className="flex items-center gap-2">
            <ZoomOut className="w-3.5 h-3.5 text-slate-400" />
            <Slider value={[zoom]} onValueChange={([v]) => setZoom(v)} min={20} max={200} step={5} className="w-24" />
            <ZoomIn className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs text-slate-500 w-9">{zoom}%</span>
          </div>
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 flex overflow-hidden">
        {showAllScreens && truckScreens.length > 0 ? (
          <>
            <div className="flex-1 bg-slate-200 overflow-auto p-6">
              <div className="flex flex-wrap gap-6 justify-center">
                {[...truckScreens].sort((a, b) => {
                  const order = { left_side: 0, rear: 1, right_side: 2, front: 3 };
                  return (order[a.position] ?? 99) - (order[b.position] ?? 99);
                }).map((screen) => {
                  const screenZones = displayZones.filter((z) => z.screen_id === screen.id);
                  const scale = Math.min((300 / (screen.width || 1920)), (200 / (screen.height || 1080))) * (zoom / 100);
                  return (
                    <div key={screen.id} className="flex-shrink-0 cursor-pointer"
                      onClick={() => { setSelectedScreenId(screen.id); setShowAllScreens(false); }}>
                      <div className="text-xs text-slate-600 font-medium mb-1 text-center">{screen.name}</div>
                      <div
                        className="relative bg-slate-100 border-2 border-slate-300 hover:border-blue-400 transition-colors shadow"
                        style={{ width: (screen.width || 1920) * scale, height: (screen.height || 1080) * scale }}
                      >
                        {screenZones.map((zone, i) => {
                          const colors = ["bg-blue-400/30 border-blue-400", "bg-emerald-400/30 border-emerald-400", "bg-violet-400/30 border-violet-400", "bg-amber-400/30 border-amber-400", "bg-rose-400/30 border-rose-400"];
                          return (
                            <div key={zone.id} className={`absolute border ${colors[i % colors.length]}`}
                              style={{ left: (zone.x || 0) * scale, top: (zone.y || 0) * scale, width: zone.width * scale, height: zone.height * scale }}>
                              <span className="text-[8px] font-medium text-slate-700 bg-white/70 px-0.5 rounded leading-none absolute top-0.5 left-0.5">{zone.name}</span>
                            </div>
                          );
                        })}
                      </div>
                      <div className="mt-1 flex justify-center">
                        <ScreenSpecBadges screen={screen} compact />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <ZonePropertiesPanel zone={selectedZone} onUpdate={handleUpdateZone} onDelete={handleDeleteZone} allScreens={truckScreens} currentScreenId={selectedScreenId} allZones={displayZones} />
          </>
        ) : selectedScreen ? (
          <>
            <CanvasWorkspace
              screen={selectedScreen}
              zones={displayZones.filter((z) => z.screen_id === selectedScreenId)}
              selectedZoneId={selectedZoneId}
              onSelectZone={setSelectedZoneId}
              onUpdateZone={handleUpdateZone}
              zoom={zoom}
              editingZone={editingZone}
            />
            <ZonePropertiesPanel zone={selectedZone} onUpdate={handleUpdateZone} onDelete={handleDeleteZone} allScreens={truckScreens} currentScreenId={selectedScreenId} allZones={displayZones} onEditingStateChange={setEditingZone} />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-slate-50">
            <div className="text-center">
              <Monitor className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-slate-600 mb-1">No Screen Selected</h3>
              <p className="text-sm text-slate-400">Add a truck and configure screens to start editing</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}