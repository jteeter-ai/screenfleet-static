import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Trash2, Eye, CheckCircle2, Loader2, ShieldAlert } from "lucide-react";
import { toast } from "sonner";

export default function AdminAssets() {
  const [preview, setPreview] = useState(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [done, setDone] = useState(false);
  const [result, setResult] = useState(null);

  const { data: user } = useQuery({
    queryKey: ["user"],
    queryFn: () => base44.auth.me(),
  });

  if (user && user.role !== "admin") {
    return (
      <div className="p-6 max-w-xl mx-auto">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-red-900">Access Denied</h3>
              <p className="text-sm text-red-700">You must be a platform administrator.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const runPreview = async () => {
    setPreviewLoading(true);
    setPreview(null);
    try {
      const res = await base44.functions.invoke("deleteAdminAssets", { dryRun: true });
      setPreview(res.data);
    } catch (e) {
      toast.error("Preview failed: " + e.message);
    } finally {
      setPreviewLoading(false);
    }
  };

  const runDelete = async () => {
    if (!window.confirm("This will permanently delete all V1 Admin Assets and their dependencies. Are you sure?")) return;
    setDeleting(true);
    try {
      const res = await base44.functions.invoke("deleteAdminAssets", { dryRun: false });
      setResult(res.data);
      setDone(true);
      setPreview(null);
      toast.success("V1 Admin Assets deleted successfully");
    } catch (e) {
      toast.error("Deletion failed: " + e.message);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="p-6 lg:p-8 max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">V1 Legacy Asset Cleanup</h1>
        <p className="text-sm text-slate-500 mt-1">
          Safely remove all global-scope (no org_id) V1 Truck/Asset records and their dependencies.
          V2 organization assets are not affected.
        </p>
      </div>

      <Card className="border-amber-200 bg-amber-50">
        <CardContent className="pt-5 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-800 space-y-1">
            <p className="font-semibold">What will be deleted:</p>
            <ul className="list-disc list-inside space-y-0.5 text-amber-700">
              <li>All <strong>Truck</strong> records with no org_id (V1 admin assets)</li>
              <li>Their associated <strong>Screens</strong>, <strong>Zones</strong>, <strong>Layouts</strong></li>
              <li>Any linked <strong>Schedules</strong>, <strong>PublishedScreens</strong>, <strong>RuntimeZones</strong></li>
            </ul>
            <p className="mt-2 font-semibold">What is preserved:</p>
            <ul className="list-disc list-inside space-y-0.5 text-amber-700">
              <li>All V2 <strong>Asset</strong> records (org-scoped)</li>
              <li>All <strong>Playlists</strong>, <strong>Route Presentations</strong>, <strong>Sequences</strong></li>
              <li>All <strong>Media Assets</strong> and <strong>Layout Templates</strong></li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {done && result && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-5">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <span className="font-semibold text-green-800">Cleanup Complete</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm text-green-700">
              {Object.entries(result.deleted || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between bg-white/60 rounded px-2 py-1">
                  <span className="capitalize">{k}</span>
                  <Badge className="bg-green-100 text-green-800 border-green-200">{v} deleted</Badge>
                </div>
              ))}
            </div>
            {result.errors && (
              <p className="text-xs text-red-600 mt-2">{result.errors.join(", ")}</p>
            )}
          </CardContent>
        </Card>
      )}

      {preview && !done && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Eye className="w-4 h-4" /> Dry Run Preview — Will Delete
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {preview.willDelete?.trucks?.length === 0 ? (
              <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg p-3">
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-sm font-medium">No V1 Admin Assets found. System is already clean.</span>
              </div>
            ) : (
              <>
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest">Admin Trucks to Delete</p>
                  {preview.willDelete.trucks.map(t => (
                    <div key={t.id} className="flex items-center gap-2 text-sm text-slate-700 bg-slate-50 rounded px-2 py-1">
                      <Trash2 className="w-3 h-3 text-red-400" />
                      {t.name} <span className="text-slate-400 text-xs">({t.id})</span>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {[
                    ["Screens", preview.willDelete.screens],
                    ["Zones", preview.willDelete.zones],
                    ["Layouts", preview.willDelete.layouts],
                    ["Schedules", preview.willDelete.schedules],
                    ["Published Screens", preview.willDelete.publishedScreens],
                    ["Runtime Zones", preview.willDelete.runtimeZones],
                  ].map(([label, count]) => (
                    <div key={label} className="flex justify-between bg-slate-50 rounded px-2 py-1">
                      <span className="text-slate-600">{label}</span>
                      <Badge variant="outline">{count}</Badge>
                    </div>
                  ))}
                </div>
                <Button
                  variant="destructive"
                  className="w-full gap-2"
                  onClick={runDelete}
                  disabled={deleting}
                >
                  {deleting ? <><Loader2 className="w-4 h-4 animate-spin" /> Deleting…</> : <><Trash2 className="w-4 h-4" /> Confirm & Delete All</>}
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      )}

      {!done && (
        <Button
          variant="outline"
          className="gap-2"
          onClick={runPreview}
          disabled={previewLoading}
        >
          {previewLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> Scanning…</> : <><Eye className="w-4 h-4" /> Preview What Will Be Deleted</>}
        </Button>
      )}
    </div>
  );
}