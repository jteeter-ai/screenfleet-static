import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useOrg } from "@/components/OrgContext";
import { Button } from "@/components/ui/button";
import { Shield, ArrowLeft, User, Building2 } from "lucide-react";

/**
 * ImpersonateView — Platform admin lands here after "View as user".
 * The admin's own session is preserved. This just switches org context
 * so they see the org exactly as org users see it, with a banner reminder.
 *
 * URL params: ?email=X&orgId=Y&orgName=Z
 */
export default function ImpersonateView() {
  const navigate = useNavigate();
  const { switchOrg, isPlatformAdmin, user } = useOrg();

  const params = new URLSearchParams(window.location.search);
  const targetEmail = params.get("email") || "—";
  const targetOrgId = params.get("orgId");
  const targetOrgName = decodeURIComponent(params.get("orgName") || "this organization");

  // Only platform admins can use this
  useEffect(() => {
    if (!isPlatformAdmin) navigate("/");
  }, [isPlatformAdmin]);

  const exitImpersonation = () => {
    navigate("/Organizations");
  };

  return (
    <div className="min-h-full bg-slate-50">
      {/* Impersonation Banner */}
      <div className="bg-amber-500 text-white px-4 py-2.5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 text-sm font-medium">
          <Shield className="w-4 h-4 flex-shrink-0" />
          <span>
            Viewing as <strong>{targetEmail}</strong> in <strong>{targetOrgName}</strong>
            <span className="font-normal opacity-80 ml-2">— Your admin session is active. You are not logged in as this user.</span>
          </span>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={exitImpersonation}
          className="bg-white/20 border-white/40 text-white hover:bg-white/30 flex-shrink-0 gap-1.5"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Exit View
        </Button>
      </div>

      {/* Context card */}
      <div className="p-8 max-w-xl mx-auto mt-10">
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center">
              <User className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Viewing org context for</p>
              <p className="font-bold text-slate-900 text-lg">{targetEmail}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 rounded-lg px-3 py-2">
            <Building2 className="w-4 h-4 text-slate-400" />
            Org: <span className="font-medium text-slate-800">{targetOrgName}</span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            The sidebar and navigation now reflect this organization's feature access and configuration.
            Navigate to Dashboard, Assets, or any other page to see what this user's experience looks like.
          </p>

          <div className="flex gap-2 pt-1">
            <Button onClick={async () => {
              if (targetOrgId) await switchOrg(targetOrgId);
              navigate('/Dashboard');
            }} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
              Go to Dashboard
            </Button>
            <Button variant="outline" onClick={exitImpersonation} className="gap-1.5">
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Organizations
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}