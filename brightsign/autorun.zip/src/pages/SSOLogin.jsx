import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, AlertCircle, CheckCircle } from "lucide-react";

export default function SSOLogin() {
  const [status, setStatus] = useState("validating"); // validating | success | error
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get("token");

    if (!token) {
      setErrorMsg("No SSO token found in URL.");
      setStatus("error");
      return;
    }

    async function validateAndRedirect() {
      try {
        const res = await base44.functions.invoke("validateSSOToken", { token });
        const data = res.data;

        if (!data.valid) {
          setErrorMsg(data.error || "Invalid SSO token.");
          setStatus("error");
          return;
        }

        // Token is valid — redirect to login with the user's email pre-filled
        // Base44 auth: redirect to login and let the platform handle session
        // Since Base44 manages auth, we redirect to login with next pointing to dashboard
        setStatus("success");

        // Brief pause so user sees the success state, then redirect
        setTimeout(() => {
          // Store org context for post-login pickup
          localStorage.setItem("sf_activeOrgId", data.org_id);
          // Redirect to Base44 login (platform handles session creation)
          base44.auth.redirectToLogin("/");
        }, 1500);
      } catch (err) {
        setErrorMsg(err?.message || "An error occurred during SSO validation.");
        setStatus("error");
      }
    }

    validateAndRedirect();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-lg p-10 max-w-sm w-full text-center">
        <div className="w-14 h-14 rounded-xl overflow-hidden mx-auto mb-6">
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699e82a2479ad26532b0b448/19f40cc91_ScreenFleetIcon.png"
            alt="ScreenFleet"
            className="w-full h-full object-cover"
          />
        </div>

        {status === "validating" && (
          <>
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-800 mb-1">Signing you in…</h2>
            <p className="text-sm text-slate-500">Verifying your Legion Hub session</p>
          </>
        )}

        {status === "success" && (
          <>
            <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-800 mb-1">Verified!</h2>
            <p className="text-sm text-slate-500">Redirecting to your dashboard…</p>
          </>
        )}

        {status === "error" && (
          <>
            <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-800 mb-2">Sign-in Failed</h2>
            <p className="text-sm text-red-600 mb-6">{errorMsg}</p>
            <a
              href="/"
              className="text-sm text-blue-600 hover:underline font-medium"
            >
              Return to ScreenFleet
            </a>
          </>
        )}
      </div>
    </div>
  );
}