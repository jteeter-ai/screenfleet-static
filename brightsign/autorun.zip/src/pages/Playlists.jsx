import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useOrg } from "@/components/OrgContext";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import PlaylistSidebar from "@/components/playlists/PlaylistSidebar";
import PlaylistEditor from "@/components/playlists/PlaylistEditor";
import SplitLayout from "@/components/layout/SplitLayout";

export default function Playlists() {
  const { activeOrgId } = useOrg();
  const validOrgId = activeOrgId && activeOrgId !== "PLATFORM_ADMIN" ? activeOrgId : null;
  const { canAccessModule } = useAuthority();
  const [selectedId, setSelectedId] = useState(null);

  const { data: playlists = [] } = useQuery({
    queryKey: ["playlists", validOrgId],
    queryFn: () =>
      validOrgId
        ? base44.entities.Playlist.filter({ org_id: validOrgId }, "-created_date")
        : Promise.resolve([]),
    enabled: !!validOrgId,
  });

  if (!canAccessModule('module_playlists')) return <AccessDenied reason="module" />;

  return (
    <SplitLayout sidebar={<PlaylistSidebar playlists={playlists} selectedId={selectedId} onSelect={setSelectedId} />} sidebarLabel="Playlists">
      <PlaylistEditor playlistId={selectedId} />
    </SplitLayout>
  );
}