import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sun, Volume2, VolumeX, Truck, Power, Zap, Monitor, Link2, Unlink2 } from "lucide-react";
import ScreenSpecBadges from "@/components/screens/ScreenSpecBadges";
import { BrightnessHelpButton } from "@/components/controls/BrightnessInstructionsModal";
import AutoBrightnessEditor from "@/components/controls/AutoBrightnessEditor";

function ScreenControlCard({ screen, control, onChange, brightnessLocked, truckName }) {
  const brightness = control?.brightness ?? 100;
  const volume = control?.volume ?? 50;
  const muted = control?.muted ?? false;
  const autoBrightness = control?.auto_brightness ?? false;
  const audioSource = control?.audio_source ?? "none";
  const power = control?.power ?? true;

  return (
    <div className={`bg-white rounded-xl border p-5 space-y-5 transition-opacity ${!power ? "opacity-60" : ""}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-0.5">
          <div className="text-xs text-slate-500 font-medium mb-1">{truckName}</div>
          <div className="flex items-center gap-2">
            <Monitor className="w-4 h-4 text-slate-500" />
            <h3 className="font-semibold text-slate-900">{screen.name}</h3>
          </div>
          <div className="pl-6">
            <ScreenSpecBadges screen={screen} compact />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">Power</span>
          <Switch
            checked={power}
            onCheckedChange={(v) => onChange({ power: v })}
          />
          <Power className={`w-4 h-4 ${power ? "text-green-500" : "text-slate-300"}`} />
        </div>
      </div>

      {/* Brightness */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label className="text-sm flex items-center gap-1.5">
            <Sun className="w-4 h-4 text-amber-500" />
            Brightness
          </Label>
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-700 w-8 text-right">{brightness}%</span>
            <div className="flex items-center gap-1.5">
              <Switch checked={autoBrightness} onCheckedChange={(v) => onChange({ auto_brightness: v })} />
              <span className="text-xs text-slate-500">Auto</span>
              {autoBrightness && (
                <Badge className="text-[9px] bg-amber-100 text-amber-700 border-amber-200 gap-1">
                  <Zap className="w-2.5 h-2.5" /> Sensor
                </Badge>
              )}
            </div>
          </div>
        </div>
        <Slider
          value={[brightness]}
          onValueChange={([v]) => onChange({ brightness: v })}
          min={0}
          max={100}
          step={1}
          disabled={autoBrightness || !power || brightnessLocked}
          className={autoBrightness || brightnessLocked ? "opacity-40" : ""}
        />
        {brightnessLocked && (
          <p className="text-[10px] text-slate-400">Controlled by master slider</p>
        )}
        <div className="flex justify-between text-[10px] text-slate-400">
          <span>0%</span>
          <span>25%</span>
          <span>50%</span>
          <span>75%</span>
          <span>100%</span>
        </div>
      </div>

      {/* Audio */}
      <div className="space-y-3 pt-1 border-t border-slate-100">
        <div className="flex items-center justify-between">
          <Label className="text-sm flex items-center gap-1.5">
            {muted || volume === 0 ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-blue-500" />}
            Audio
          </Label>
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-700 w-8 text-right">{muted ? "—" : `${volume}%`}</span>
            <div className="flex items-center gap-1.5">
              <Switch checked={muted} onCheckedChange={(v) => onChange({ muted: v })} />
              <span className="text-xs text-slate-500">Mute</span>
            </div>
          </div>
        </div>

        <Slider
          value={[volume]}
          onValueChange={([v]) => onChange({ volume: v })}
          min={0}
          max={100}
          step={1}
          disabled={muted || !power}
          className={muted ? "opacity-40" : ""}
        />

        <div>
          <Label className="text-[10px] text-slate-500 uppercase tracking-wide mb-1 block">Audio Source</Label>
          <Select value={audioSource} onValueChange={(v) => onChange({ audio_source: v })} disabled={!power}>
            <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None</SelectItem>
              <SelectItem value="internal">Internal</SelectItem>
              <SelectItem value="hdmi">HDMI</SelectItem>
              <SelectItem value="line_in">Line In</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}

export default function Controls() {
  const { canAccessModule } = useAuthority();
  const queryClient = useQueryClient();
  const [selectedTruckId, setSelectedTruckId] = useState(null);
  const [linkedBrightness, setLinkedBrightness] = useState(true);
  const [masterBrightness, setMasterBrightness] = useState(100);
  const [masterBrightnessMode, setMasterBrightnessMode] = useState("manual");
  const [autoCurvePoints, setAutoCurvePoints] = useState([]);

  const { data: trucks = [] } = useQuery({ queryKey: ["trucks"], queryFn: () => base44.entities.Truck.list() });
  const { data: screens = [] } = useQuery({
    queryKey: ["screens", selectedTruckId],
    queryFn: () => base44.entities.Screen.filter({ truck_id: selectedTruckId }),
    enabled: !!selectedTruckId,
  });
  const { data: controls = [] } = useQuery({
    queryKey: ["screenControls", selectedTruckId],
    queryFn: () => base44.entities.ScreenControl.filter({ truck_id: selectedTruckId }),
    enabled: !!selectedTruckId,
  });

  useEffect(() => { if (trucks.length > 0 && !selectedTruckId) setSelectedTruckId(trucks[0].id); }, [trucks]);

  const updateMutation = useMutation({
    mutationFn: async ({ screenId, data }) => {
      const existing = controls.find((c) => c.screen_id === screenId);
      if (existing) {
        return base44.entities.ScreenControl.update(existing.id, data);
      } else {
        return base44.entities.ScreenControl.create({ screen_id: screenId, truck_id: selectedTruckId, ...data });
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["screenControls"] }),
  });

  const handleBulkBrightness = (value) => {
    screens.forEach((s) => updateMutation.mutate({ screenId: s.id, data: { brightness: value } }));
  };

  const handleMasterBrightnessChange = (value) => {
    setMasterBrightness(value);
    if (linkedBrightness) {
      screens.forEach((s) => updateMutation.mutate({ screenId: s.id, data: { brightness: value } }));
    }
  };

  if (!canAccessModule('module_screen_controls')) return <AccessDenied reason="module" />;

  const getControl = (screenId) => controls.find((c) => c.screen_id === screenId);

  const selectedTruck = trucks.find((t) => t.id === selectedTruckId);

  return (
    <div className="p-3 sm:p-6 max-w-5xl space-y-6">
      {/* Header row */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Truck className="w-4 h-4 text-slate-400" />
          <Select value={selectedTruckId || ""} onValueChange={setSelectedTruckId}>
            <SelectTrigger className="h-8 w-full sm:w-52 text-sm"><SelectValue placeholder="Select asset…" /></SelectTrigger>
            <SelectContent>
              {trucks.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <BrightnessHelpButton />
      </div>

      {/* Master brightness control */}
      {screens.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Sun className="w-4 h-4 text-amber-500" />
              <span className="font-semibold text-slate-800 text-sm">Master Brightness</span>
              {masterBrightnessMode === "manual" && (
                <span className="text-sm text-slate-500 font-medium">{masterBrightness}%</span>
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {/* Manual / Auto toggle */}
              <div className="flex border border-slate-200 rounded-lg overflow-hidden text-xs">
                <button
                  onClick={() => setMasterBrightnessMode("manual")}
                  className={`px-3 py-1.5 font-medium transition-colors ${masterBrightnessMode === "manual" ? "bg-slate-900 text-white" : "bg-white text-slate-500 hover:bg-slate-50"}`}
                >
                  Manual
                </button>
                <button
                  onClick={() => setMasterBrightnessMode("auto")}
                  className={`px-3 py-1.5 font-medium transition-colors flex items-center gap-1 ${masterBrightnessMode === "auto" ? "bg-amber-500 text-white" : "bg-white text-slate-500 hover:bg-slate-50"}`}
                >
                  <Zap className="w-3 h-3" /> Auto
                </button>
              </div>
              <button
                onClick={() => setLinkedBrightness(!linkedBrightness)}
                className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border transition-all ${
                  linkedBrightness
                    ? "bg-blue-50 border-blue-300 text-blue-700"
                    : "bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300"
                }`}
              >
                {linkedBrightness ? <Link2 className="w-3.5 h-3.5" /> : <Unlink2 className="w-3.5 h-3.5" />}
                {linkedBrightness ? "All screens linked" : "Screens independent"}
              </button>
            </div>
          </div>

          {masterBrightnessMode === "manual" ? (
            <>
              <Slider
                value={[masterBrightness]}
                onValueChange={([v]) => handleMasterBrightnessChange(v)}
                min={0} max={100} step={1}
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>0%</span><span>25%</span><span>50%</span><span>75%</span><span>100%</span>
              </div>
              {linkedBrightness && (
                <p className="text-xs text-slate-400">
                  All screens will use the same brightness. Click <strong>"All screens linked"</strong> to control each screen independently.
                </p>
              )}
            </>
          ) : (
            <div className="border-t border-slate-100 pt-4">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span className="text-xs font-semibold text-slate-700">Auto Brightness Curve</span>
                <span className="text-[10px] text-slate-400">Set brightness at each ambient light level (lux)</span>
              </div>
              <AutoBrightnessEditor points={autoCurvePoints} onChange={setAutoCurvePoints} />
            </div>
          )}
        </div>
      )}

      {/* Per-screen cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {screens.map((screen) => (
          <ScreenControlCard
            key={screen.id}
            screen={screen}
            control={getControl(screen.id)}
            brightnessLocked={linkedBrightness}
            truckName={selectedTruck?.name}
            onChange={(data) => updateMutation.mutate({ screenId: screen.id, data })}
          />
        ))}
      </div>

      {screens.length === 0 && selectedTruckId && (
        <div className="text-center py-16 text-slate-400">
          <Monitor className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No screens configured for this truck yet.</p>
        </div>
      )}
    </div>
  );
}