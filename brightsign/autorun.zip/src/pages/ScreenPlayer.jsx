/**
 * ScreenPlayer — CMS ADMIN PREVIEW TOOL
 *
 * ═══════════════════════════════════════════════════════════════════════
 * IMPORTANT: This is a PRIVATE CMS component. It is NOT a public device endpoint.
 * Physical screens, BrightSign units, Windows PCs, or any hardware player
 * must NEVER be configured to load this URL.
 *
 * Device players must point to the SEPARATE ScreenFleet Player app.
 * Set AppConfig.player_app_origin to the Player app URL.
 * ═══════════════════════════════════════════════════════════════════════
 *
 * PURPOSE (admin-only, inside CMS):
 *   Authenticated admin preview of published screen content.
 *   Accessible only by logged-in CMS users.
 *   Used by Live Output dashboard and screen management pages.
 *
 * Routes (CMS-internal only — all require CMS authentication):
 *   /ScreenPlayer                        → Admin dashboard (LiveOutputDashboard)
 *   /ScreenPlayer?screenId=XXX           → Admin full-screen preview (no UI)
 *   /ScreenPlayer?screenId=XXX&preview=1 → Admin scaled preview with overlay
 *
 * Data pipeline: screenPayload (V2) → RuntimeZone.playback_track → RuntimeCanvas
 *
 * MIGRATION NOTE:
 *   The screenPayload + screenVersionCheck backend functions powering this
 *   preview are player-delivery APIs that must move to the Player app.
 *   When migrated, admin preview should call the Player app's equivalent endpoints.
 */

import React, { useState, useEffect, useRef, useCallback } from "react";
import ReactDOM from "react-dom";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, ChevronRight, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import LiveOutputDashboard from "@/components/live/LiveOutputDashboard";
import RuntimeCanvas from "@/components/player/RuntimeCanvas";
import { OrgProvider } from "@/components/OrgContext";

const VERSION_POLL_MS = 60000;

// ─── Pure player: exact pixels, no UI ────────────────────────────────────────
function PurePlayer({ payload, performanceMode }) {
  const { screen_width, screen_height, zones } = payload;
  return ReactDOM.createPortal(
    <div style={{ position: "fixed", top: 0, left: 0, background: "#000" }}>
      <RuntimeCanvas zones={zones} width={screen_width} height={screen_height} performanceMode={performanceMode} />
    </div>,
    document.body
  );
}

// ─── Preview player: scaled with status overlay ───────────────────────────────
function PreviewPlayer({ payload, screenId, setScreenId, performanceMode }) {
  const { screen_width, screen_height, zones, screen_name } = payload;
  const [showOverlay, setShowOverlay] = useState(true);

  useEffect(() => {
    if (!zones.length) return;
    const t = setTimeout(() => setShowOverlay(false), 3000);
    return () => clearTimeout(t);
  }, [zones.length]);

  const scale = Math.min(window.innerWidth / screen_width, window.innerHeight / screen_height);

  return ReactDOM.createPortal(
    <div style={{ position: "fixed", inset: 0, background: "#111", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
      {showOverlay && (
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, zIndex: 9999, background: "linear-gradient(to bottom, rgba(0,0,0,0.6), transparent)", padding: "12px 16px" }}>
          <div style={{ color: "#fff", fontSize: 12, fontFamily: "monospace" }}>
            {screen_name} · {screen_width}×{screen_height}
          </div>
        </div>
      )}
      <div style={{
        position: "relative",
        width: screen_width,
        height: screen_height,
        transform: `scale(${scale})`,
        transformOrigin: "top center",
        flexShrink: 0,
        overflow: "hidden",
      }}>
        <RuntimeCanvas zones={zones} width={screen_width} height={screen_height} performanceMode={performanceMode} />
      </div>
    </div>,
    document.body
  );
}

// ─── Main ScreenPlayer ────────────────────────────────────────────────────────
export default function ScreenPlayer() {
  const urlParams   = new URLSearchParams(window.location.search);
  const initialId   = urlParams.get("screenId");
  const previewMode = urlParams.get("preview") === "1";
  const urlMode     = urlParams.get("performanceMode");

  const [screenId, setScreenId]   = useState(initialId);
  const [payload, setPayload]     = useState(null);
  const [loading, setLoading]     = useState(!!initialId);
  const [error, setError]         = useState(null);
  const knownVersionRef           = useRef(null);
  const pollRef                   = useRef(null);

  // ── Load payload via V2 screenPayload function ──────────────────────────────
  const fetchPayload = useCallback(async (id) => {
    if (!id) return;
    try {
      const res  = await base44.functions.invoke("screenPayload", { screenId: id });
      const data = res.data;
      if (data?.status === "error") throw new Error(data.error || "No published content");
      knownVersionRef.current = data.content_version;
      setPayload(data);
      setError(null);
      // Offline cache
      try { localStorage.setItem(`v2_payload_${id}`, JSON.stringify(data)); } catch (_) {}
    } catch (e) {
      // Offline fallback
      try {
        const cached = localStorage.getItem(`v2_payload_${id}`);
        if (cached) { setPayload(JSON.parse(cached)); return; }
      } catch (_) {}
      if (!payload) setError(e.message);
      // If payload already playing, stay silent — do not interrupt
    } finally {
      setLoading(false);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Version poll ────────────────────────────────────────────────────────────
  const pollVersion = useCallback(async (id) => {
    if (!id) return;
    try {
      const res  = await base44.functions.invoke("screenVersionCheck", { screenId: id });
      const data = res.data;
      if (data?.content_version && data.content_version !== knownVersionRef.current) {
        // Clear stale cache before fetching so offline fallback doesn't revert
        try { localStorage.removeItem(`v2_payload_${id}`); } catch (_) {}
        fetchPayload(id);
      }
    } catch (_) { /* silent — continue playback on network loss */ }
  }, [fetchPayload]);

  // Initial load + poll on screenId change
  useEffect(() => {
    if (!screenId) return;
    setLoading(true);
    // Skip stale localStorage cache — always fetch fresh on mount.
    // Stale cache was causing old image-only payloads to persist after republish.
    fetchPayload(screenId);
  }, [screenId]);

  useEffect(() => {
    if (!screenId) return;
    pollRef.current = setInterval(() => pollVersion(screenId), VERSION_POLL_MS);
    return () => clearInterval(pollRef.current);
  }, [screenId, pollVersion]);

  // ── Dashboard mode ──────────────────────────────────────────────────────────
  // LiveOutputDashboard internally handles PLATFORM_ADMIN suppression via useOrg()
  if (!screenId) return <OrgProvider><LiveOutputDashboard /></OrgProvider>;

  // ── Loading ─────────────────────────────────────────────────────────────────
  if (loading && !payload) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#ffffff22", fontFamily: "monospace", fontSize: 12 }}>Loading…</div>
      </div>
    );
  }

  // ── Error (no cached fallback) ───────────────────────────────────────────────
  if (error && !payload) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#fff", fontFamily: "monospace", textAlign: "center", padding: 32 }}>
          <div style={{ color: "#ff4444", fontSize: 18, marginBottom: 12 }}>⚠ Screen Unavailable</div>
          <div style={{ color: "#fff8", fontSize: 13 }}>{error}</div>
          <div style={{ color: "#fff3", fontSize: 11, marginTop: 8 }}>Screen ID: {screenId}</div>
        </div>
      </div>
    );
  }

  if (!payload || payload.status === "no_published_state") {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#ffffff33", fontFamily: "monospace", fontSize: 12 }}>No published content</div>
      </div>
    );
  }

  // ── Performance mode resolution ─────────────────────────────────────────────
  // Priority: URL param (explicit override) → player_config → default "full"
  // This ensures config-based mode works for BrightSign deployments while
  // still allowing URL-based override for testing/manual provisioning.
  const configMode = payload?.player_config?.performance_mode;
  let performanceMode = "full";
  if (urlMode === "limited" || urlMode === "full") {
    performanceMode = urlMode; // URL override takes precedence
  } else if (configMode === "limited") {
    performanceMode = "limited"; // fall back to saved config
  }
  console.log("Performance Mode Resolution:", { url: urlMode, config: configMode, final: performanceMode });

  if (previewMode) return <PreviewPlayer payload={payload} screenId={screenId} setScreenId={setScreenId} performanceMode={performanceMode} />;
  return <PurePlayer payload={payload} performanceMode={performanceMode} />;
}