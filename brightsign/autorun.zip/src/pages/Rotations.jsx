import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Repeat2, Clock, Loader2, Copy, Trash2, LayoutGrid, CheckCircle2, Save } from "lucide-react";
import SplitLayout from "@/components/layout/SplitLayout";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import SpotCardV2 from "@/components/rotations/SpotCardV2";
import RotationTimeline from "@/components/rotations/RotationTimeline";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useOrg } from "@/components/OrgContext";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useFeatureAccess } from "@/lib/useFeatureAccess";
import { Lock } from "lucide-react";

const DEFAULT_SPOTS = [
  { spot_number: 1, tier: "impact", play_every_n_rotations: 1, rotation_offset: 0, dwell_time: 8 },
  { spot_number: 2, tier: "impact", play_every_n_rotations: 1, rotation_offset: 0, dwell_time: 8 },
  { spot_number: 3, tier: "impact", play_every_n_rotations: 1, rotation_offset: 0, dwell_time: 8 },
  { spot_number: 4, tier: "impact", play_every_n_rotations: 1, rotation_offset: 0, dwell_time: 8 },
  { spot_number: 5, tier: "impact", play_every_n_rotations: 1, rotation_offset: 0, dwell_time: 8 },
  { spot_number: 6, tier: "impact", play_every_n_rotations: 1, rotation_offset: 0, dwell_time: 8 },
  { spot_number: 7, tier: "growth", play_every_n_rotations: 2, rotation_offset: 0, dwell_time: 8 },
  { spot_number: 8, tier: "launch", play_every_n_rotations: 4, rotation_offset: 0, dwell_time: 8 },
];

export default function Rotations() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  const { canAccess } = useFeatureAccess();
  const hasAccess = canAccess("route_presentations");
  const [selectedLayoutTemplateId, setSelectedLayoutTemplateId] = useState(null);
  const [selectedPresentationId, setSelectedPresentationId] = useState(null);
  const [showTimeline, setShowTimeline] = useState(true);
  const [copyDialogOpen, setCopyDialogOpen] = useState(false);
  const [copyingPresentationId, setCopyingPresentationId] = useState(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newPresentationName, setNewPresentationName] = useState("");
  const [newPresentationTemplateId, setNewPresentationTemplateId] = useState("");
  const [savingZones, setSavingZones] = useState(false);
  const [savedZones, setSavedZones] = useState(false);
  const isRestoringTemplate = useRef(true);

  // V2: Load RoutePresentation — only when feature is enabled
  const { data: presentations = [] } = useQuery({
    queryKey: ["routePresentations", activeOrgId],
    queryFn: () => base44.entities.RoutePresentation.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId && hasAccess,
  });

  // V2: Load RouteSpots for selected RoutePresentation
  const { data: spots = [] } = useQuery({
    queryKey: ["routeSpots", selectedPresentationId],
    queryFn: () => selectedPresentationId ? base44.entities.RouteSpot.filter({ route_presentation_id: selectedPresentationId }) : Promise.resolve([]),
    enabled: !!selectedPresentationId,
  });

  // V2: Load RouteCreatives for selected RoutePresentation
  const spotIds = spots.map((s) => s.id);
  const { data: creatives = [] } = useQuery({
    queryKey: ["routeCreatives", selectedPresentationId],
    queryFn: async () => {
      if (spotIds.length === 0) return [];
      const results = await Promise.all(
        spotIds.map((id) => base44.entities.RouteCreative.filter({ route_spot_id: id }))
      );
      return results.flat();
    },
    enabled: spotIds.length > 0,
  });

  // V2: Load LayoutTemplates scoped by org
  const { data: layoutTemplates = [] } = useQuery({
    queryKey: ["layoutTemplates", activeOrgId],
    queryFn: () => activeOrgId ? base44.entities.LayoutTemplate.filter({ org_id: activeOrgId }) : Promise.resolve([]),
    enabled: !!activeOrgId,
  });

  // V2: Load LayoutZones for selected LayoutTemplate
  const { data: layoutZones = [] } = useQuery({
    queryKey: ["layoutZonesForTemplate", selectedLayoutTemplateId],
    queryFn: async () => {
      if (!selectedLayoutTemplateId) return [];
      const zones = await base44.entities.LayoutZone.filter({ layout_template_id: selectedLayoutTemplateId });
      console.log(`[Rotations] Loaded ${zones.length} LayoutZones for template ${selectedLayoutTemplateId}`);
      return zones;
    },
    enabled: !!selectedLayoutTemplateId,
    staleTime: 0,
  });

  // Auto-select first presentation
  useEffect(() => {
    if (presentations.length > 0 && !selectedPresentationId) setSelectedPresentationId(presentations[0].id);
  }, [presentations]);

  const selectedPresentation = presentations.find((p) => p.id === selectedPresentationId);

  // V2 MUTATIONS
  const createPresentationMutation = useMutation({
    mutationFn: async ({ name, layoutTemplateId }) => {
      console.log("[Rotations] Creating RoutePresentation", { org_id: activeOrgId, name, layout_template_id: layoutTemplateId });
      const presentation = await base44.entities.RoutePresentation.create({
        org_id: activeOrgId,
        layout_template_id: layoutTemplateId || null,
        name: name || "New Route Presentation",
        default_dwell_time: 8,
        is_active: true,
      });
      console.log("[Rotations] Created RoutePresentation", presentation.id);
      
      // Create default 8 spots
      console.log("[Rotations] Creating 8 RouteSpots");
      await Promise.all(
        DEFAULT_SPOTS.map((s) => base44.entities.RouteSpot.create({ 
          route_presentation_id: presentation.id,
          spot_number: s.spot_number,
          tier: s.tier,
          play_every_n_rotations: s.play_every_n_rotations,
          rotation_offset: s.rotation_offset,
          dwell_time: s.dwell_time,
        }))
      );
      console.log("[Rotations] RouteSpots created successfully");
      return presentation;
    },
    onSuccess: (presentation) => {
      console.log("[Rotations] Create mutation succeeded", presentation.id);
      queryClient.invalidateQueries({ queryKey: ["routePresentations"] });
      queryClient.invalidateQueries({ queryKey: ["routeSpots"] });
      setSelectedPresentationId(presentation.id);
      setCreateDialogOpen(false);
      setNewPresentationName("");
      setNewPresentationTemplateId("");
      toast.success("Route Presentation created!");
    },
    onError: (error) => {
      console.error("[Rotations] Create mutation failed", error);
      toast.error(`Failed to create: ${error.message}`);
    },
  });

  const handleOpenCreateDialog = () => {
    if (!activeOrgId) {
      toast.error("Organization context not available");
      return;
    }
    console.log("[Rotations] Opening create dialog");
    setNewPresentationName("");
    setNewPresentationTemplateId("");
    setCreateDialogOpen(true);
  };

  const handleCreatePresentation = () => {
    if (!newPresentationTemplateId) {
      toast.error("Select a layout template");
      return;
    }
    console.log("[Rotations] handleCreatePresentation triggered", { name: newPresentationName, templateId: newPresentationTemplateId });
    createPresentationMutation.mutate({ name: newPresentationName, layoutTemplateId: newPresentationTemplateId });
  };

  const updatePresentationMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RoutePresentation.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["routePresentations"] }),
  });

  const updateSpotV2Mutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RouteSpot.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["routeSpots"] }),
  });

  const addCreativeV2Mutation = useMutation({
    mutationFn: async ({ spotId, extraData = {} }) => {
      const spotCreatives = creatives.filter((c) => c.route_spot_id === spotId);
      // Ensure advertiser_name and rotation_offset are explicitly set
      const creativeData = {
        route_spot_id: spotId,
        order: spotCreatives.length + 1,
        is_active: true,
        zone_assignments: {},
        advertiser_name: extraData.advertiser_name || "",
        rotation_offset: extraData.rotation_offset ?? 0,
        ...extraData,
      };
      console.log("[addCreativeV2Mutation] Creating with data:", creativeData);
      const asset = await base44.entities.RouteCreative.create(creativeData);
      console.log("[addCreativeV2Mutation] Created creative:", asset);
      return asset;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["routeCreatives"] }),
  });

  const updateCreativeV2Mutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RouteCreative.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["routeCreatives"] }),
  });

  const deleteCreativeV2Mutation = useMutation({
    mutationFn: (id) => base44.entities.RouteCreative.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["routeCreatives"] }),
  });

  const deletePresentationMutation = useMutation({
    mutationFn: async (presentationId) => {
      const sourceSpots = await base44.entities.RouteSpot.filter({ route_presentation_id: presentationId });
      const sourceCreatives = sourceSpots.length > 0
        ? (await Promise.all(sourceSpots.map((s) => base44.entities.RouteCreative.filter({ route_spot_id: s.id })))).flat()
        : [];
      await Promise.all(sourceCreatives.map((c) => base44.entities.RouteCreative.delete(c.id)));
      await Promise.all(sourceSpots.map((s) => base44.entities.RouteSpot.delete(s.id)));
      await base44.entities.RoutePresentation.delete(presentationId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["routePresentations"] });
      queryClient.invalidateQueries({ queryKey: ["routeSpots"] });
      queryClient.invalidateQueries({ queryKey: ["routeCreatives"] });
      setSelectedPresentationId(null);
    },
  });

  const copyPresentationMutation = useMutation({
    mutationFn: async ({ presentationId }) => {
      const sourcePresentation = presentations.find((p) => p.id === presentationId);
      const sourceSpots = await base44.entities.RouteSpot.filter({ route_presentation_id: presentationId });
      const sourceCreatives = sourceSpots.length > 0
        ? (await Promise.all(sourceSpots.map((s) => base44.entities.RouteCreative.filter({ route_spot_id: s.id })))).flat()
        : [];

      const newPresentation = await base44.entities.RoutePresentation.create({
        org_id: activeOrgId,
        layout_template_id: sourcePresentation.layout_template_id,
        name: `${sourcePresentation.name} (copy)`,
        default_dwell_time: sourcePresentation.default_dwell_time,
        is_active: false,
      });

      const spotIdMap = {};
      await Promise.all(
        sourceSpots.map(async (s) => {
          const { id, created_date, updated_date, created_by, route_presentation_id, ...spotData } = s;
          const newSpot = await base44.entities.RouteSpot.create({ ...spotData, route_presentation_id: newPresentation.id });
          spotIdMap[s.id] = newSpot.id;
        })
      );

      await Promise.all(
        sourceCreatives.map((c) => {
          const { id, created_date, updated_date, created_by, route_spot_id, ...creativeData } = c;
          const newSpotId = spotIdMap[route_spot_id];
          if (!newSpotId) return;
          return base44.entities.RouteCreative.create({ ...creativeData, route_spot_id: newSpotId });
        })
      );

      return newPresentation;
    },
    onSuccess: (newPresentation) => {
      queryClient.invalidateQueries({ queryKey: ["routePresentations"] });
      queryClient.invalidateQueries({ queryKey: ["routeSpots"] });
      queryClient.invalidateQueries({ queryKey: ["routeCreatives"] });
      setCopyDialogOpen(false);
      setCopyingPresentationId(null);
      setSelectedPresentationId(newPresentation.id);
    },
  });

  // Handle dwell time change
  const handleDefaultDwellChange = (value) => {
    updatePresentationMutation.mutate({ id: selectedPresentationId, data: { default_dwell_time: Number(value) } });
  };

  // Restore template selection from presentation
  useEffect(() => {
    if (selectedPresentation?.layout_template_id && layoutTemplates.length > 0) {
      const found = layoutTemplates.find(t => t.id === selectedPresentation.layout_template_id);
      if (found) {
        console.log(`[Rotations] Restored layout_template_id ${selectedPresentation.layout_template_id}`);
        isRestoringTemplate.current = true;
        setSelectedLayoutTemplateId(selectedPresentation.layout_template_id);
        setTimeout(() => { isRestoringTemplate.current = false; }, 100);
      } else {
        setSelectedLayoutTemplateId(null);
      }
    } else if (selectedPresentation && !selectedPresentation.layout_template_id) {
      setSelectedLayoutTemplateId(null);
    }
  }, [selectedPresentationId, selectedPresentation?.id, layoutTemplates]);

  // Auto-save template selection
  useEffect(() => {
    if (isRestoringTemplate.current) return;
    if (!selectedPresentationId) return;
    updatePresentationMutation.mutate({ id: selectedPresentationId, data: { layout_template_id: selectedLayoutTemplateId || null } });
  }, [selectedLayoutTemplateId, selectedPresentationId]);

  // Validate and save creatives
  const handleSaveCreatives = async () => {
    if (!selectedLayoutTemplateId) {
      toast.error("Select a layout template first");
      return;
    }

    setSavingZones(true);
    try {
      // Collect all zone assignments from all creatives
      const allZoneAssignments = {};
      creatives.forEach(c => {
        Object.assign(allZoneAssignments, c.zone_assignments || {});
      });

      const validationResult = await base44.functions.invoke("validateRouteCreativeZones", {
        layout_template_id: selectedLayoutTemplateId,
        zone_assignments: allZoneAssignments,
      });

      if (!validationResult.data.valid) {
        toast.error(`Invalid zones: ${validationResult.data.error}`);
        return;
      }

      setSavedZones(true);
      setTimeout(() => setSavedZones(false), 3000);
      toast.success("Route presentation saved!");
    } catch (e) {
      toast.error(`Validation failed: ${e.message}`);
    } finally {
      setSavingZones(false);
    }
  };

  const sortedSpots = [...spots].sort((a, b) => a.spot_number - b.spot_number);

  const sidebar = (
    <div className="flex flex-col flex-1 overflow-hidden">
      <div className="p-4 border-b border-slate-100">
        <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Organization</div>
        <div className="text-sm font-medium text-slate-700 mt-1">From context</div>
      </div>

      <div className="p-4 flex-1 overflow-y-auto">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Route Presentations</div>
          {activeOrgId && hasAccess && (
            <Button variant="ghost" size="sm" className="h-5 w-5 p-0" onClick={handleOpenCreateDialog} disabled={createPresentationMutation.isPending}>
              {createPresentationMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
            </Button>
          )}
        </div>
        <div className="space-y-1">
          {presentations.map((p) => (
            <div key={p.id} className="flex items-center gap-1 group">
              <button onClick={() => setSelectedPresentationId(p.id)} className={`flex-1 text-left text-sm px-2 py-1.5 rounded-lg transition-colors truncate ${selectedPresentationId === p.id ? "bg-blue-50 text-blue-700 font-medium" : "text-slate-600 hover:bg-slate-50"}`}>
                {p.name}
              </button>
              <button title="Copy" onClick={() => { setCopyingPresentationId(p.id); setCopyDialogOpen(true); }} className="opacity-0 group-hover:opacity-100 p-1 rounded text-slate-400 hover:text-blue-500 transition-all">
                <Copy className="w-3 h-3" />
              </button>
              <button title="Delete" onClick={() => { if (confirm(`Delete "${p.name}"? This will remove all spots and creatives.`)) deletePresentationMutation.mutate(p.id); }} className="opacity-0 group-hover:opacity-100 p-1 rounded text-slate-400 hover:text-red-500 transition-all">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))}
          {presentations.length === 0 && activeOrgId && (
            <p className="text-xs text-slate-400 text-center py-4">No presentations yet.<br /><button className="text-blue-500 hover:underline mt-1" onClick={handleOpenCreateDialog}>Create one</button></p>
          )}
        </div>
      </div>
    </div>
  );

  // Hard page-level guard — blocks URL-direct access
  if (!canAccessModule('module_route_presentations')) return <AccessDenied reason="module" />;

  return (
    <>
      {/* Create Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Create Route Presentation</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label className="text-sm font-medium">Presentation Name</Label>
              <Input
                autoFocus
                placeholder="e.g., Main Campaign"
                value={newPresentationName}
                onChange={(e) => setNewPresentationName(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-sm font-medium">Layout Template *</Label>
              <Select value={newPresentationTemplateId} onValueChange={setNewPresentationTemplateId}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select a layout template…" />
                </SelectTrigger>
                <SelectContent>
                  {layoutTemplates.length === 0 && (
                    <SelectItem value="_none" disabled>
                      No templates available
                    </SelectItem>
                  )}
                  {layoutTemplates.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} ({t.canvas_width}×{t.canvas_height})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500 mt-1">Create templates in Layout Templates page</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreatePresentation}
              disabled={createPresentationMutation.isPending || !newPresentationTemplateId}
            >
              {createPresentationMutation.isPending ? (
                <><Loader2 className="w-3.5 h-3.5 animate-spin mr-2" /> Creating…</>
              ) : (
                "Create"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Copy Dialog */}
      <Dialog open={copyDialogOpen} onOpenChange={setCopyDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Copy Route Presentation</DialogTitle></DialogHeader>
          <div className="py-2"><p className="text-xs text-slate-500">This will create a copy with the same spots and creatives.</p></div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCopyDialogOpen(false)}>Cancel</Button>
            <Button disabled={copyPresentationMutation.isPending} onClick={() => copyPresentationMutation.mutate({ presentationId: copyingPresentationId })}>
              {copyPresentationMutation.isPending ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Copying…</> : "Copy"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SplitLayout sidebar={sidebar} sidebarLabel="Presentations">
        <div className="overflow-auto bg-slate-50 h-full">
          {!hasAccess && (
            <div className="m-6 p-4 rounded-xl border border-amber-200 bg-amber-50 flex items-start gap-3">
              <Lock className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-amber-800">Route Presentations not included in your plan</p>
                <p className="text-xs text-amber-700 mt-1">Existing presentations continue to play. Upgrade your plan to create or edit route presentations.</p>
              </div>
            </div>
          )}
          {!selectedPresentation ? (
            <div className="flex items-center justify-center h-full text-slate-400">
              <div className="text-center">
                <Repeat2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">Select a route presentation to get started</p>
              </div>
            </div>
          ) : (
            <div className="p-6 space-y-6 max-w-5xl">
              <div className="bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex flex-wrap items-center gap-6">
                  <div>
                    <Label className="text-[10px] text-slate-500 uppercase tracking-widest">Presentation Name</Label>
                    <Input value={selectedPresentation.name} onChange={(e) => updatePresentationMutation.mutate({ id: selectedPresentationId, data: { name: e.target.value } })} className="h-8 text-sm w-44 mt-1" />
                  </div>
                  <div>
                    <Label className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-1"><Clock className="w-3 h-3" /> Default Dwell (s)</Label>
                    <Input type="number" min="1" value={selectedPresentation.default_dwell_time ?? 8} onChange={(e) => handleDefaultDwellChange(e.target.value)} className="h-8 text-sm w-20 mt-1" />
                  </div>
                  <div className="flex items-center gap-2 ml-auto">
                    <Label className="text-xs text-slate-500">Timeline</Label>
                    <Switch checked={showTimeline} onCheckedChange={setShowTimeline} />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4">
                <div className="flex items-center gap-2">
                  <LayoutGrid className="w-4 h-4 text-blue-500" />
                  <h3 className="text-sm font-semibold text-slate-700">Assign Layout Template &amp; Zones</h3>
                  {savingZones && <span className="text-xs text-slate-400 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> Saving…</span>}
                  {savedZones && !savingZones && <span className="text-xs text-green-600 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Saved</span>}
                </div>
                <div>
                  <Label className="text-xs text-slate-500 mb-1 block">
                    Select a Layout Template
                    {selectedPresentation?.layout_template_id && selectedLayoutTemplateId && <span className="ml-2 text-[10px] font-normal text-green-600">✓ Saved</span>}
                  </Label>
                  <Select value={selectedLayoutTemplateId || ""} onValueChange={(v) => { setSelectedLayoutTemplateId(v); isRestoringTemplate.current = false; }}>
                    <SelectTrigger className="h-8 text-sm w-64"><SelectValue placeholder="Choose a layout template…" /></SelectTrigger>
                    <SelectContent>
                      {layoutTemplates.length === 0 && <SelectItem value="_none" disabled>No templates — create in Layout Templates page</SelectItem>}
                      {layoutTemplates.map((t) => <SelectItem key={t.id} value={t.id}>{t.name} ({t.canvas_width}×{t.canvas_height})</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {showTimeline && sortedSpots.length > 0 && <RotationTimeline spots={sortedSpots} creatives={creatives} />}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-slate-700">Spots ({sortedSpots.length})</h3>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="outline" className="text-[10px] gap-1"><span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />Impact = every rotation</Badge>
                    <Badge variant="outline" className="text-[10px] gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />Growth = every 2nd</Badge>
                    <Badge variant="outline" className="text-[10px] gap-1"><span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />Launch = every 4th</Badge>
                  </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                  {sortedSpots.map((spot) => (
                    <SpotCardV2
                      key={spot.id}
                      spot={spot}
                      creatives={creatives.filter((c) => c.route_spot_id === spot.id).sort((a, b) => a.order - b.order)}
                      layoutZones={layoutZones}
                      defaultDwellTime={selectedPresentation.default_dwell_time ?? 8}
                      onUpdateSpot={(id, data) => updateSpotV2Mutation.mutate({ id, data })}
                      onAddCreative={(spotId, extraData) => addCreativeV2Mutation.mutate({ spotId, extraData })}
                      onDeleteCreative={(id) => deleteCreativeV2Mutation.mutate(id)}
                      onUpdateCreative={(id, data) => updateCreativeV2Mutation.mutate({ id, data })}
                    />
                  ))}
                </div>
                {sortedSpots.length > 0 && (
                  <div className="flex gap-2 pt-4">
                    <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={handleSaveCreatives} disabled={savingZones}>
                      {savingZones ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Saving…</> : savedZones ? <><CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Saved!</> : <><Save className="w-3.5 h-3.5" /> Save Creatives</>}
                    </Button>
                    <Button size="sm" className="h-8 bg-blue-600 hover:bg-blue-700 text-xs gap-1.5" onClick={() => { handleSaveCreatives(); navigate(createPageUrl("Scheduling")); }} disabled={savingZones}>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Save &amp; Go to Schedule
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </SplitLayout>
    </>
  );
}