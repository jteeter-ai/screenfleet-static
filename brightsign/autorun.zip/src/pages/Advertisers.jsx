/**
 * Advertisers — manage advertiser/customer records for OOH reporting.
 * Used by Route Presentations (spot assignment) and Reporting pages.
 */
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Building2, Mail, Phone, Edit2, Trash2, Users, Search } from "lucide-react";
import { toast } from "sonner";

const COMPANY_TYPES = [
  { value: "brand", label: "Brand" },
  { value: "agency", label: "Agency" },
  { value: "local_business", label: "Local Business" },
  { value: "nonprofit", label: "Nonprofit" },
  { value: "government", label: "Government" },
  { value: "other", label: "Other" },
];

const EMPTY_FORM = {
  name: "", legal_name: "", contact_name: "", email: "",
  phone: "", company_type: "brand", billing_notes: "",
  external_account_id: "", is_active: true,
};

export default function Advertisers() {
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);

  const { data: advertisers = [], isLoading } = useQuery({
    queryKey: ["advertisers", activeOrgId],
    queryFn: () => base44.entities.Advertiser.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ["campaigns", activeOrgId],
    queryFn: () => base44.entities.Campaign.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (editing) return base44.entities.Advertiser.update(editing.id, data);
      return base44.entities.Advertiser.create({ ...data, org_id: activeOrgId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["advertisers"] });
      setDialogOpen(false);
      setEditing(null);
      setForm(EMPTY_FORM);
      toast.success(editing ? "Advertiser updated" : "Advertiser created");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Advertiser.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["advertisers"] });
      toast.success("Advertiser deleted");
    },
  });

  const openCreate = () => { setEditing(null); setForm(EMPTY_FORM); setDialogOpen(true); };
  const openEdit = (adv) => { setEditing(adv); setForm({ ...EMPTY_FORM, ...adv }); setDialogOpen(true); };

  const filtered = advertisers.filter(a =>
    a.name?.toLowerCase().includes(search.toLowerCase()) ||
    a.contact_name?.toLowerCase().includes(search.toLowerCase()) ||
    a.email?.toLowerCase().includes(search.toLowerCase())
  );

  const getCampaignCount = (advId) => campaigns.filter(c => c.advertiser_id === advId).length;

  if (!canAccessModule('module_ooh_advertisers')) return <AccessDenied reason="module" />;

  return (
    <div className="p-6 lg:p-8 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Advertisers</h1>
          <p className="text-sm text-slate-500 mt-0.5">Manage advertiser/customer records for campaigns and reporting</p>
        </div>
        <Button onClick={openCreate} className="gap-2">
          <Plus className="w-4 h-4" /> New Advertiser
        </Button>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input
          placeholder="Search advertisers…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading && <p className="text-sm text-slate-400 text-center py-8">Loading…</p>}

      {!isLoading && filtered.length === 0 && (
        <div className="text-center py-16 text-slate-400">
          <Building2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No advertisers yet. Create your first one to start linking campaigns to spots.</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map(adv => (
          <div key={adv.id} className="bg-white border border-slate-200 rounded-xl p-4 hover:border-blue-300 transition-all">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-slate-900 truncate">{adv.name}</span>
                  <Badge variant="outline" className="text-[10px] capitalize flex-shrink-0">
                    {adv.company_type?.replace("_", " ") || "brand"}
                  </Badge>
                  {!adv.is_active && <Badge variant="outline" className="text-[10px] bg-slate-50 text-slate-400 flex-shrink-0">Inactive</Badge>}
                </div>
                {adv.legal_name && adv.legal_name !== adv.name && (
                  <p className="text-xs text-slate-400 mb-1">{adv.legal_name}</p>
                )}
                <div className="flex flex-wrap gap-3 mt-2">
                  {adv.contact_name && (
                    <span className="flex items-center gap-1 text-xs text-slate-500">
                      <Users className="w-3 h-3" /> {adv.contact_name}
                    </span>
                  )}
                  {adv.email && (
                    <span className="flex items-center gap-1 text-xs text-slate-500">
                      <Mail className="w-3 h-3" /> {adv.email}
                    </span>
                  )}
                  {adv.phone && (
                    <span className="flex items-center gap-1 text-xs text-slate-500">
                      <Phone className="w-3 h-3" /> {adv.phone}
                    </span>
                  )}
                </div>
                <div className="mt-2 text-xs text-slate-400">
                  {getCampaignCount(adv.id)} campaign{getCampaignCount(adv.id) !== 1 ? "s" : ""}
                </div>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => openEdit(adv)}>
                  <Edit2 className="w-3.5 h-3.5" />
                </Button>
                <Button
                  variant="ghost" size="sm" className="h-7 w-7 p-0 text-red-400 hover:text-red-600"
                  onClick={() => { if (confirm(`Delete "${adv.name}"?`)) deleteMutation.mutate(adv.id); }}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Advertiser" : "New Advertiser"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-xs">Display Name *</Label>
                <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Acme Corp" className="mt-1" />
              </div>
              <div className="col-span-2">
                <Label className="text-xs">Legal Name</Label>
                <Input value={form.legal_name} onChange={e => setForm(f => ({ ...f, legal_name: e.target.value }))} placeholder="Legal entity name" className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Company Type</Label>
                <Select value={form.company_type} onValueChange={v => setForm(f => ({ ...f, company_type: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {COMPANY_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">External Account ID</Label>
                <Input value={form.external_account_id} onChange={e => setForm(f => ({ ...f, external_account_id: e.target.value }))} placeholder="CRM / IO #" className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Contact Name</Label>
                <Input value={form.contact_name} onChange={e => setForm(f => ({ ...f, contact_name: e.target.value }))} placeholder="Jane Smith" className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Phone</Label>
                <Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1 555 000 0000" className="mt-1" />
              </div>
              <div className="col-span-2">
                <Label className="text-xs">Email</Label>
                <Input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="contact@acme.com" className="mt-1" />
              </div>
              <div className="col-span-2">
                <Label className="text-xs">Billing Notes</Label>
                <Input value={form.billing_notes} onChange={e => setForm(f => ({ ...f, billing_notes: e.target.value }))} placeholder="Internal billing notes…" className="mt-1" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => saveMutation.mutate(form)} disabled={!form.name || saveMutation.isPending}>
              {saveMutation.isPending ? "Saving…" : editing ? "Save Changes" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}