import React, { useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  Upload, Search, Image, Film, MoreVertical, Trash2, Copy,
  Grid3X3, List, Loader2, FolderPlus, Folder, FolderOpen,
  ChevronRight, FolderX, Move, Home, CheckSquare, Square,
} from "lucide-react";
import { toast } from "sonner";
import BulkActionBar from "@/components/media/BulkActionBar";
import BulkDeleteDialog from "@/components/media/BulkDeleteDialog";

// currentFolder = null  → All Media (no filter)
// currentFolder = ""    → Unfiled (no folder assigned)
// currentFolder = id    → specific MediaFolder record

export default function MediaLibrary() {
  const queryClient = useQueryClient();
  const { activeOrgId, activeOrg } = useOrg();
  const { canAccessModule } = useAuthority();

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [viewMode, setViewMode] = useState("grid");
  const [uploading, setUploading] = useState(false);
  const [previewAsset, setPreviewAsset] = useState(null);
  const [currentFolderId, setCurrentFolderId] = useState(null); // null = All Media
  const [newFolderName, setNewFolderName] = useState("");
  const [showNewFolderInput, setShowNewFolderInput] = useState(false);
  const [creatingFolder, setCreatingFolder] = useState(false);
  const [folderSidebarOpen, setFolderSidebarOpen] = useState(false);

  // Single-item move
  const [movingAsset, setMovingAsset] = useState(null);
  const [moveTargetId, setMoveTargetId] = useState(null);

  // Bulk selection
  const [selectedIds, setSelectedIds] = useState(new Set());

  // Bulk move
  const [showBulkMoveDialog, setShowBulkMoveDialog] = useState(false);
  const [bulkMoveTargetId, setBulkMoveTargetId] = useState(null);
  const [isBulkMoving, setIsBulkMoving] = useState(false);

  // Bulk delete
  const [showBulkDeleteDialog, setShowBulkDeleteDialog] = useState(false);
  const [usageMap, setUsageMap] = useState({});
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);
  const [isCheckingUsage, setIsCheckingUsage] = useState(false);

  // ── Org ID resolution ─────────────────────────────────────────────────────
  // Use activeOrg.id for member users, or first real org for platform admins
  const orgId = activeOrg?.id || null;

  // ── Data fetching ─────────────────────────────────────────────────────────
  const { data: folders = [], isLoading: foldersLoading } = useQuery({
    queryKey: ["mediaFolders", orgId],
    queryFn: () => orgId ? base44.entities.MediaFolder.filter({ org_id: orgId }) : [],
    enabled: !!orgId,
  });

  const { data: media = [], isLoading: mediaLoading } = useQuery({
    queryKey: ["media", orgId],
    queryFn: () => orgId ? base44.entities.MediaAsset.filter({ org_id: orgId }) : Promise.resolve([]),
    enabled: !!orgId,
  });

  const isLoading = foldersLoading || mediaLoading;

  // ── Mutations ─────────────────────────────────────────────────────────────
  const updateMediaMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MediaAsset.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["media"] }),
  });

  const deleteMediaMutation = useMutation({
    mutationFn: (id) => base44.entities.MediaAsset.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["media"] }),
  });

  const deleteFolderMutation = useMutation({
    mutationFn: (id) => base44.entities.MediaFolder.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["mediaFolders"] }),
  });

  // ── Folder helpers ────────────────────────────────────────────────────────
  const folderMap = Object.fromEntries(folders.map(f => [f.id, f]));

  const getFolderName = (folderId) => {
    if (!folderId) return "Unfiled";
    return folderMap[folderId]?.name || "Unknown";
  };

  // ── Create folder ─────────────────────────────────────────────────────────
  const handleCreateFolder = async () => {
    const name = newFolderName.trim();
    if (!name || !orgId) return;

    setCreatingFolder(true);
    try {
      const payload = {
        org_id: orgId,
        name,
        // parent_folder_id: if inside a specific folder, nest under it
        parent_folder_id: (currentFolderId && currentFolderId !== "") ? currentFolderId : null,
      };
      const created = await base44.entities.MediaFolder.create(payload);
      await queryClient.invalidateQueries({ queryKey: ["mediaFolders"] });
      setNewFolderName("");
      setShowNewFolderInput(false);
      // Navigate into the new folder immediately
      setCurrentFolderId(created.id);
      toast.success(`Folder "${name}" created`);
    } catch (err) {
      console.error("[MediaLibrary] Folder create failed:", err);
      toast.error("Failed to create folder");
    } finally {
      setCreatingFolder(false);
    }
  };

  // ── Upload ────────────────────────────────────────────────────────────────
  const handleUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploading(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        await base44.entities.MediaAsset.create({
          org_id: orgId || undefined,
          name: file.name,
          file_url,
          file_type: file.type.startsWith("video/") ? "video" : "image",
          file_size: file.size,
          // assign to current folder (null/undefined = unfiled)
          folder_id: (currentFolderId && currentFolderId !== "") ? currentFolderId : null,
          // keep legacy folder string for backwards compat
          folder: currentFolderId ? getFolderName(currentFolderId) : "",
        });
      }
      queryClient.invalidateQueries({ queryKey: ["media"] });
      toast.success(`Uploaded ${files.length} file${files.length !== 1 ? "s" : ""}`);
    } finally {
      setUploading(false);
    }
  };

  // ── Single move ───────────────────────────────────────────────────────────
  const handleMove = async () => {
    if (!movingAsset) return;
    const targetId = moveTargetId || null;
    const targetName = targetId ? getFolderName(targetId) : "";
    // Optimistic update
    queryClient.setQueryData(["media", orgId], (old = []) =>
      old.map(m => m.id === movingAsset.id ? { ...m, folder_id: targetId, folder: targetName } : m)
    );
    setMovingAsset(null);
    setMoveTargetId(null);
    await base44.entities.MediaAsset.update(movingAsset.id, { folder_id: targetId, folder: targetName });
    queryClient.invalidateQueries({ queryKey: ["media"] });
    toast.success("Media moved");
  };

  // ── Delete folder (move its assets to unfiled) ────────────────────────────
  const handleDeleteFolder = async (folderId) => {
    // Move all assets in this folder to unfiled
    const inFolder = media.filter(m => m.folder_id === folderId);
    await Promise.all(inFolder.map(m =>
      base44.entities.MediaAsset.update(m.id, { folder_id: null, folder: "" })
    ));
    await deleteFolderMutation.mutateAsync(folderId);
    if (currentFolderId === folderId) setCurrentFolderId(null);
    queryClient.invalidateQueries({ queryKey: ["media"] });
    toast.success("Folder removed");
  };

  // ── Filter logic ──────────────────────────────────────────────────────────
  const assetsInView = media.filter((m) => {
    if (currentFolderId === null) return true;            // All Media
    if (currentFolderId === "") return !m.folder_id && !m.folder; // Unfiled
    return m.folder_id === currentFolderId;
  });

  const filtered = assetsInView.filter((m) => {
    const matchesSearch = m.name?.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === "all" || m.file_type === filter;
    return matchesSearch && matchesFilter;
  });

  const unfiledCount = media.filter((m) => !m.folder_id && !m.folder).length;
  const mediaMap = Object.fromEntries(media.map(m => [m.id, m]));

  // ── Selection ─────────────────────────────────────────────────────────────
  const toggleSelect = useCallback((id, e) => {
    e?.stopPropagation();
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, []);

  const selectAll = useCallback(() => setSelectedIds(new Set(filtered.map(a => a.id))), [filtered]);
  const clearSelection = useCallback(() => setSelectedIds(new Set()), []);
  const selectedAssets = [...selectedIds].map(id => mediaMap[id]).filter(Boolean);

  // ── Bulk move ─────────────────────────────────────────────────────────────
  const handleBulkMove = async () => {
    setIsBulkMoving(true);
    const targetId = bulkMoveTargetId || null;
    const targetName = targetId ? getFolderName(targetId) : "";
    const movingIds = new Set(selectedAssets.map(a => a.id));

    // Optimistic: update cache immediately so UI reflects change without server round-trip
    queryClient.setQueryData(["media", orgId], (old = []) =>
      old.map(m => movingIds.has(m.id) ? { ...m, folder_id: targetId } : m)
    );

    // Close dialog and clear selection immediately — UI feels instant
    setShowBulkMoveDialog(false);
    setBulkMoveTargetId(null);
    clearSelection();
    setIsBulkMoving(false);

    // Persist all items in parallel
    const results = await Promise.allSettled(
      selectedAssets.map(a => base44.entities.MediaAsset.update(a.id, { folder_id: targetId, folder: targetName }))
    );

    const failed = results.filter(r => r.status === "rejected");
    if (failed.length > 0) {
      toast.error(`${failed.length} file${failed.length !== 1 ? "s" : ""} failed to move`);
    } else {
      toast.success(`Moved ${selectedAssets.length} file${selectedAssets.length !== 1 ? "s" : ""} to ${targetName || "Unfiled"}`);
    }
    queryClient.invalidateQueries({ queryKey: ["media"] });
  };

  // ── Bulk delete usage check ───────────────────────────────────────────────
  const handleBulkDeleteRequest = async () => {
    setIsCheckingUsage(true);
    const fileUrls = new Set(selectedAssets.map(a => a.file_url));
    const fileUrlToId = Object.fromEntries(selectedAssets.map(a => [a.file_url, a.id]));

    const [playlistItems, routeCreatives] = await Promise.all([
      base44.entities.PlaylistItem.list(),
      base44.entities.RouteCreative.list(),
    ]);

    const counts = {};
    const init = (id) => { if (!counts[id]) counts[id] = { playlists: 0, presentations: 0, total: 0 }; };

    for (const pi of playlistItems) {
      for (const v of Object.values(pi.zone_assignments || {})) {
        if (fileUrls.has(v?.file_url)) {
          const id = fileUrlToId[v.file_url];
          if (id) { init(id); counts[id].playlists++; counts[id].total++; }
        }
      }
    }
    for (const rc of routeCreatives) {
      for (const v of Object.values(rc.zone_assignments || {})) {
        if (fileUrls.has(v?.file_url)) {
          const id = fileUrlToId[v.file_url];
          if (id) { init(id); counts[id].presentations++; counts[id].total++; }
        }
      }
    }

    setUsageMap(counts);
    setIsCheckingUsage(false);
    setShowBulkDeleteDialog(true);
  };

  const handleBulkDeleteConfirm = async () => {
    setIsBulkDeleting(true);
    await Promise.all(selectedAssets.map(a => base44.entities.MediaAsset.delete(a.id)));
    queryClient.invalidateQueries({ queryKey: ["media"] });
    setIsBulkDeleting(false);
    setShowBulkDeleteDialog(false);
    clearSelection();
    toast.success(`Deleted ${selectedAssets.length} file${selectedAssets.length !== 1 ? "s" : ""}`);
  };

  const formatSize = (bytes) => {
    if (!bytes) return "—";
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / 1048576).toFixed(1) + " MB";
  };

  // ── Folder picker component (reused in move dialogs) ─────────────────────
  const FolderPicker = ({ value, onChange }) => (
    <div className="space-y-1 max-h-48 overflow-y-auto">
      <button onClick={() => onChange(null)} className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-left transition-colors ${value === null ? "bg-blue-50 text-blue-700" : "hover:bg-slate-50 text-slate-600"}`}>
        <Folder className="w-4 h-4 text-slate-300" /> Unfiled
      </button>
      {folders.map((f) => (
        <button key={f.id} onClick={() => onChange(f.id)} className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-left transition-colors ${value === f.id ? "bg-blue-50 text-blue-700" : "hover:bg-slate-50 text-slate-600"}`}>
          <Folder className="w-4 h-4 text-amber-400" /> {f.name}
        </button>
      ))}
    </div>
  );

  if (!canAccessModule('module_media_library')) return <AccessDenied reason="module" />;

  return (
    <div className="flex h-full">
      {/* Mobile folder sidebar overlay */}
      {folderSidebarOpen && (
        <div className="fixed inset-0 bg-black/40 z-40 md:hidden" onClick={() => setFolderSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed md:static inset-y-0 left-0 z-50
        w-56 flex-shrink-0 bg-white border-r border-slate-200 flex flex-col
        transition-transform duration-300 ease-out
        ${folderSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
      `}>
        <div className="p-3 border-b border-slate-100">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Client Folders</span>
            <button onClick={() => setShowNewFolderInput(!showNewFolderInput)} className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-blue-600 transition-colors" title="New folder">
              <FolderPlus className="w-3.5 h-3.5" />
            </button>
          </div>
          {showNewFolderInput && (
            <div className="mt-2 flex gap-1">
              <Input
                autoFocus
                placeholder="Client name..."
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleCreateFolder();
                  if (e.key === "Escape") { setShowNewFolderInput(false); setNewFolderName(""); }
                }}
                className="h-7 text-xs"
                disabled={creatingFolder}
              />
              <Button size="sm" className="h-7 px-2 text-xs bg-blue-600 hover:bg-blue-700" onClick={handleCreateFolder} disabled={creatingFolder || !newFolderName.trim()}>
                {creatingFolder ? <Loader2 className="w-3 h-3 animate-spin" /> : "Add"}
              </Button>
            </div>
          )}
        </div>
        <nav className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
          <button onClick={() => { setCurrentFolderId(null); setFolderSidebarOpen(false); }} className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors ${currentFolderId === null ? "bg-blue-50 text-blue-700 font-medium" : "text-slate-600 hover:bg-slate-50"}`}>
            <Home className="w-3.5 h-3.5 flex-shrink-0" />
            <span className="truncate flex-1 text-left">All Media</span>
            <span className="text-[10px] text-slate-400">{media.length}</span>
          </button>

          {folders.map((folder) => {
            const count = media.filter((m) => m.folder_id === folder.id).length;
            const isActive = currentFolderId === folder.id;
            return (
              <div key={folder.id} className="group flex items-center gap-1">
                <button onClick={() => { setCurrentFolderId(folder.id); setFolderSidebarOpen(false); }} className={`flex-1 flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors ${isActive ? "bg-blue-50 text-blue-700 font-medium" : "text-slate-600 hover:bg-slate-50"}`}>
                  {isActive ? <FolderOpen className="w-3.5 h-3.5 flex-shrink-0 text-blue-500" /> : <Folder className="w-3.5 h-3.5 flex-shrink-0 text-amber-400" />}
                  <span className="truncate flex-1 text-left">{folder.name}</span>
                  <span className="text-[10px] text-slate-400">{count}</span>
                </button>
                <button onClick={() => handleDeleteFolder(folder.id)} className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-50 hover:text-red-500 text-slate-300 transition-all" title="Remove folder">
                  <FolderX className="w-3 h-3" />
                </button>
              </div>
            );
          })}

          {unfiledCount > 0 && (
            <button onClick={() => { setCurrentFolderId(""); setFolderSidebarOpen(false); }} className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors ${currentFolderId === "" ? "bg-blue-50 text-blue-700 font-medium" : "text-slate-400 hover:bg-slate-50 hover:text-slate-600"}`}>
              <Folder className="w-3.5 h-3.5 flex-shrink-0 text-slate-300" />
              <span className="truncate flex-1 text-left italic">Unfiled</span>
              <span className="text-[10px] text-slate-400">{unfiledCount}</span>
            </button>
          )}
        </nav>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Toolbar */}
        <div className="p-3 md:p-5 border-b border-slate-100 bg-white flex-shrink-0">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm text-slate-500">
              {/* Mobile folder toggle */}
              <button onClick={() => setFolderSidebarOpen(true)} className="md:hidden p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors">
                <Folder className="w-4 h-4" />
              </button>
              <button onClick={() => setCurrentFolderId(null)} className="hover:text-slate-800 transition-colors">All Media</button>
              {currentFolderId && currentFolderId !== "" && (
                <><ChevronRight className="w-3.5 h-3.5" /><span className="text-slate-900 font-medium">{getFolderName(currentFolderId)}</span></>
              )}
              {currentFolderId === "" && (
                <><ChevronRight className="w-3.5 h-3.5" /><span className="text-slate-500 italic">Unfiled</span></>
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                <Input placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 h-8 w-40 text-sm" />
              </div>
              <div className="flex border border-slate-200 rounded-lg overflow-hidden">
                {["all", "image", "video"].map((f) => (
                  <button key={f} onClick={() => setFilter(f)} className={`px-2.5 py-1 text-xs font-medium transition-colors ${filter === f ? "bg-slate-900 text-white" : "bg-white text-slate-500 hover:bg-slate-50"}`}>
                    {f === "all" ? "All" : f === "image" ? "Images" : "Videos"}
                  </button>
                ))}
              </div>
              <div className="flex border border-slate-200 rounded-lg overflow-hidden">
                <button onClick={() => setViewMode("grid")} className={`p-1.5 ${viewMode === "grid" ? "bg-slate-100" : ""}`}><Grid3X3 className="w-3.5 h-3.5 text-slate-500" /></button>
                <button onClick={() => setViewMode("list")} className={`p-1.5 ${viewMode === "list" ? "bg-slate-100" : ""}`}><List className="w-3.5 h-3.5 text-slate-500" /></button>
              </div>
              <label>
                <input type="file" accept="image/*,video/*" multiple onChange={handleUpload} className="hidden" />
                <Button asChild className="bg-blue-600 hover:bg-blue-700 h-8 text-sm">
                  <span>
                    {uploading ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Upload className="w-3.5 h-3.5 mr-1.5" />}
                    Upload
                  </span>
                </Button>
              </label>
            </div>
          </div>
        </div>

        {/* Bulk action bar */}
        {selectedIds.size > 0 && (
          <BulkActionBar
            selectedCount={selectedIds.size}
            totalCount={filtered.length}
            onSelectAll={selectAll}
            onClearSelection={clearSelection}
            onMoveToFolder={() => { setBulkMoveTargetId(null); setShowBulkMoveDialog(true); }}
            onDelete={handleBulkDeleteRequest}
          />
        )}

        {/* Asset Grid / List */}
        <div className="flex-1 overflow-auto p-5">
          {viewMode === "grid" ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {filtered.map((asset) => {
                const isSelected = selectedIds.has(asset.id);
                return (
                  <Card
                    key={asset.id}
                    className={`group border-0 shadow-sm hover:shadow-md transition-all overflow-hidden cursor-pointer relative ${isSelected ? "ring-2 ring-blue-500" : ""}`}
                    onClick={() => isSelected || selectedIds.size > 0 ? toggleSelect(asset.id) : setPreviewAsset(asset)}
                  >
                    <div
                      className={`absolute top-2 left-2 z-10 transition-opacity ${isSelected || selectedIds.size > 0 ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}
                      onClick={(e) => { e.stopPropagation(); toggleSelect(asset.id); }}
                    >
                      <div className={`w-5 h-5 rounded flex items-center justify-center shadow ${isSelected ? "bg-blue-600" : "bg-white/90 border border-slate-300"}`}>
                        {isSelected && <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 12 12"><path d="M10 3L5 8.5 2 5.5" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                      </div>
                    </div>
                    <div className="aspect-video bg-slate-100 relative overflow-hidden">
                      {asset.file_type === "image" ? (
                        <img src={asset.file_url} alt={asset.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-slate-900">
                          <Film className="w-8 h-8 text-slate-500" />
                        </div>
                      )}
                      <div className="absolute top-1.5 right-1.5">
                        <Badge variant="secondary" className="text-[9px] bg-black/50 text-white border-0 backdrop-blur-sm">{asset.file_type}</Badge>
                      </div>
                      <div className={`absolute inset-0 transition-colors ${isSelected ? "bg-blue-500/10" : "bg-black/0 group-hover:bg-black/20"}`} />
                      <div className="absolute bottom-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="secondary" size="icon" className="h-6 w-6 bg-black/60 border-0 hover:bg-black/80">
                              <MoreVertical className="w-3 h-3 text-white" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(asset.file_url)}><Copy className="w-4 h-4 mr-2" /> Copy URL</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => { setMovingAsset(asset); setMoveTargetId(asset.folder_id || null); }}><Move className="w-4 h-4 mr-2" /> Move to folder</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600" onClick={() => deleteMediaMutation.mutate(asset.id)}><Trash2 className="w-4 h-4 mr-2" /> Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <div className="p-2.5">
                      <p className="text-xs font-medium text-slate-700 truncate">{asset.name}</p>
                      <p className="text-[10px] text-slate-400">{formatSize(asset.file_size)}</p>
                    </div>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((asset) => {
                const isSelected = selectedIds.has(asset.id);
                return (
                  <div
                    key={asset.id}
                    className={`flex items-center gap-4 p-3 rounded-lg transition-colors cursor-pointer ${isSelected ? "bg-blue-50 ring-1 ring-blue-200" : "hover:bg-slate-50"}`}
                    onClick={() => toggleSelect(asset.id)}
                  >
                    <div onClick={(e) => e.stopPropagation()} className="flex-shrink-0">
                      <button onClick={() => toggleSelect(asset.id)} className="text-slate-300 hover:text-blue-500 transition-colors">
                        {isSelected ? <CheckSquare className="w-4 h-4 text-blue-600" /> : <Square className="w-4 h-4" />}
                      </button>
                    </div>
                    <div className="w-12 h-12 rounded-lg bg-slate-100 overflow-hidden flex-shrink-0" onClick={(e) => { e.stopPropagation(); setPreviewAsset(asset); }}>
                      {asset.file_type === "image" ? (
                        <img src={asset.file_url} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-slate-900"><Film className="w-5 h-5 text-slate-500" /></div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0" onClick={(e) => { e.stopPropagation(); setPreviewAsset(asset); }}>
                      <p className="text-sm font-medium text-slate-700 truncate">{asset.name}</p>
                      <p className="text-xs text-slate-400">{formatSize(asset.file_size)}</p>
                    </div>
                    {asset.folder_id && (
                      <Badge variant="outline" className="text-[10px] text-slate-500 flex items-center gap-1">
                        <Folder className="w-2.5 h-2.5" /> {getFolderName(asset.folder_id)}
                      </Badge>
                    )}
                    <Badge variant="outline" className="text-xs">{asset.file_type}</Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={(e) => e.stopPropagation()}>
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(asset.file_url); }}><Copy className="w-4 h-4 mr-2" /> Copy URL</DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); setMovingAsset(asset); setMoveTargetId(asset.folder_id || null); }}><Move className="w-4 h-4 mr-2" /> Move to folder</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600" onClick={(e) => { e.stopPropagation(); deleteMediaMutation.mutate(asset.id); }}><Trash2 className="w-4 h-4 mr-2" /> Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                );
              })}
            </div>
          )}

          {filtered.length === 0 && !isLoading && (
            <div className="text-center py-20">
              <Image className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-slate-600 mb-1">
                {currentFolderId && currentFolderId !== "" ? `No media in "${getFolderName(currentFolderId)}"` : "No media found"}
              </h3>
              <p className="text-sm text-slate-400">Upload files to add media{currentFolderId && currentFolderId !== "" ? " to this folder" : ""}</p>
            </div>
          )}
        </div>
      </div>

      {/* Preview Dialog */}
      <Dialog open={!!previewAsset} onOpenChange={() => setPreviewAsset(null)}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader><DialogTitle>{previewAsset?.name}</DialogTitle></DialogHeader>
          <div className="rounded-lg overflow-hidden bg-black">
            {previewAsset?.file_type === "image" ? (
              <img src={previewAsset?.file_url} alt="" className="w-full max-h-[70vh] object-contain" />
            ) : (
              <video src={previewAsset?.file_url} controls className="w-full max-h-[70vh]" />
            )}
          </div>
          <div className="flex justify-between items-center mt-2">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">{formatSize(previewAsset?.file_size)}</span>
              {previewAsset?.folder_id && (
                <Badge variant="outline" className="text-xs flex items-center gap-1"><Folder className="w-3 h-3" /> {getFolderName(previewAsset.folder_id)}</Badge>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => navigator.clipboard.writeText(previewAsset?.file_url)}><Copy className="w-3.5 h-3.5 mr-1" /> Copy URL</Button>
              <Button variant="outline" size="sm" className="text-red-600" onClick={() => { deleteMediaMutation.mutate(previewAsset.id); setPreviewAsset(null); }}><Trash2 className="w-3.5 h-3.5 mr-1" /> Delete</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Single Move Dialog */}
      <Dialog open={!!movingAsset} onOpenChange={() => setMovingAsset(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Move className="w-4 h-4" /> Move to Folder</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-sm text-slate-500">Move <strong>{movingAsset?.name}</strong> to:</p>
            <FolderPicker value={moveTargetId} onChange={setMoveTargetId} />
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setMovingAsset(null)}>Cancel</Button>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={handleMove}>Move</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Move Dialog */}
      <Dialog open={showBulkMoveDialog} onOpenChange={setShowBulkMoveDialog}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><FolderOpen className="w-4 h-4" /> Move {selectedIds.size} files to Folder</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <FolderPicker value={bulkMoveTargetId} onChange={setBulkMoveTargetId} />
            <p className="text-xs text-slate-400">Moving files only updates their folder. All existing playlist and presentation references remain intact.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setShowBulkMoveDialog(false)} disabled={isBulkMoving}>Cancel</Button>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={handleBulkMove} disabled={isBulkMoving}>
              {isBulkMoving ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> Moving…</> : <>Move {selectedIds.size} files</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Usage check loading */}
      {isCheckingUsage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-xl px-6 py-5 flex items-center gap-3 shadow-lg">
            <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
            <span className="text-sm font-medium text-slate-700">Checking usage…</span>
          </div>
        </div>
      )}

      {/* Bulk Delete Dialog */}
      <BulkDeleteDialog
        open={showBulkDeleteDialog}
        onOpenChange={setShowBulkDeleteDialog}
        selectedAssets={selectedAssets}
        usageMap={usageMap}
        onConfirm={handleBulkDeleteConfirm}
        isDeleting={isBulkDeleting}
      />
    </div>
  );
}