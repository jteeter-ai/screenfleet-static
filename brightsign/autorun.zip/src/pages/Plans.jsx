import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import PlanModulesEditor from "@/components/plans/PlanModulesEditor";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Star, Check, DollarSign, Trash } from "lucide-react";
import { toast } from "sonner";

const FEATURE_OPTIONS = [
  { key: "basic_scheduling", label: "Basic Scheduling" },
  { key: "sequences", label: "Presentation Sequences" },
  { key: "rotations", label: "Standard Rotations" },
  { key: "total360_rotation", label: "Total360 Rotation" },
  { key: "multi_zone", label: "Multi-Zone Layouts" },
  { key: "analytics", label: "Analytics & Reports" },
  { key: "api_access", label: "API Access" },
  { key: "priority_support", label: "Priority Support" },
  { key: "custom_branding", label: "Custom Branding" },
  { key: "unlimited_trucks", label: "Unlimited Trucks" },
  { key: "white_label", label: "White-Label Solution" },
  { key: "sso", label: "Single Sign-On (SSO)" },
  { key: "advanced_reporting", label: "Advanced Reporting & Analytics" },
];

const BILLING_FREQUENCIES = [
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly (3 months)" },
  { value: "annually", label: "Annually" },
];

const GATED_FEATURES = [
  { key: "playlists", label: "Playlists", description: "Core content playlists", alwaysOn: true },
  { key: "route_presentations", label: "Route Presentations", description: "Ad rotation / route presentations" },
  { key: "sequences", label: "Sequences", description: "Ordered multi-step content scheduling" },
];

function PlanForm({ plan, onSave, onClose }) {
  const defaultFeatureFlags = {
    playlists: true,
    route_presentations: false,
    sequences: false,
  };
  const [form, setForm] = useState(plan || {
    name: "",
    slug: "",
    description: "",
    billing_cycles: [{ frequency: "monthly", price: 0, discount_percent: 0 }],
    max_trucks: 1,
    max_screens_per_truck: 3,
    max_users: 2,
    features: [],
    feature_flags: defaultFeatureFlags,
    modules_included: [],
    support_tier: "standard",
    is_active: true,
    is_highlighted: false,
    display_order: 999,
    trial_enabled: false,
    trial_days: null,
  });

  const featureFlags = { ...defaultFeatureFlags, ...(form.feature_flags || {}) };

  const toggleFeatureFlag = (key) => {
    if (key === "playlists") return; // always on
    setForm((f) => ({
      ...f,
      feature_flags: { ...featureFlags, [key]: !featureFlags[key] },
    }));
  };

  const toggleFeature = (key) => {
    setForm((f) => ({
      ...f,
      features: f.features.includes(key) ? f.features.filter((k) => k !== key) : [...f.features, key],
    }));
  };

  const updateBillingCycle = (idx, field, value) => {
    const updated = [...form.billing_cycles];
    updated[idx] = { ...updated[idx], [field]: value };
    setForm({ ...form, billing_cycles: updated });
  };

  const addBillingCycle = () => {
    setForm({
      ...form,
      billing_cycles: [...form.billing_cycles, { frequency: "quarterly", price: 0, discount_percent: 0 }],
    });
  };

  const removeBillingCycle = (idx) => {
    setForm({
      ...form,
      billing_cycles: form.billing_cycles.filter((_, i) => i !== idx),
    });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="col-span-2">
          <Label className="text-xs">Plan Name</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="h-8 mt-1" placeholder="e.g. Professional, Enterprise" />
        </div>
        <div>
          <Label className="text-xs">Slug (machine key)</Label>
          <Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value.toLowerCase().replace(/\s/g, "_") })} className="h-8 mt-1" placeholder="e.g. professional" />
        </div>
        <div>
          <Label className="text-xs">Display Order</Label>
          <Input type="number" min="0" value={form.display_order} onChange={(e) => setForm({ ...form, display_order: Number(e.target.value) })} className="h-8 mt-1" />
        </div>
        <div className="col-span-2">
          <Label className="text-xs">Description</Label>
          <Input value={form.description || ""} onChange={(e) => setForm({ ...form, description: e.target.value })} className="h-8 mt-1" placeholder="Brief plan description" />
        </div>
        <div>
          <Label className="text-xs">Max Trucks</Label>
          <Input type="number" min="1" value={form.max_trucks} onChange={(e) => setForm({ ...form, max_trucks: Number(e.target.value) })} className="h-8 mt-1" placeholder="999 = unlimited" />
        </div>
        <div>
          <Label className="text-xs">Max Users</Label>
          <Input type="number" min="1" value={form.max_users} onChange={(e) => setForm({ ...form, max_users: Number(e.target.value) })} className="h-8 mt-1" placeholder="999 = unlimited" />
        </div>
        <div className="col-span-2">
          <Label className="text-xs">Support Tier</Label>
          <div className="flex gap-2 mt-1">
            {["community", "standard", "priority"].map((tier) => (
              <button
                key={tier}
                onClick={() => setForm({ ...form, support_tier: tier })}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  form.support_tier === tier
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                {tier.charAt(0).toUpperCase() + tier.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Billing Cycles */}
      <div className="border-t border-slate-200 pt-4">
        <div className="flex items-center justify-between mb-3">
          <Label className="text-sm font-semibold">Billing Options</Label>
          <Button size="sm" variant="outline" onClick={addBillingCycle} className="h-7 gap-1">
            <Plus className="w-3 h-3" /> Add Frequency
          </Button>
        </div>
        <div className="space-y-2">
          {form.billing_cycles.map((cycle, idx) => (
            <div key={idx} className="flex gap-2 items-end bg-slate-50 p-3 rounded-lg">
              <div className="flex-1">
                <Label className="text-[10px] text-slate-500">Frequency</Label>
                <select
                  value={cycle.frequency}
                  onChange={(e) => updateBillingCycle(idx, "frequency", e.target.value)}
                  className="w-full h-8 mt-1 px-2 rounded border border-slate-200 text-sm"
                >
                  {BILLING_FREQUENCIES.map((f) => (
                    <option key={f.value} value={f.value}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex-1">
                <Label className="text-[10px] text-slate-500">Price ($)</Label>
                <Input type="number" min="0" step="0.01" value={cycle.price} onChange={(e) => updateBillingCycle(idx, "price", Number(e.target.value))} className="h-8 mt-1" />
              </div>
              <div className="flex-1">
                <Label className="text-[10px] text-slate-500">Discount %</Label>
                <Input type="number" min="0" max="100" value={cycle.discount_percent || 0} onChange={(e) => updateBillingCycle(idx, "discount_percent", Number(e.target.value))} className="h-8 mt-1" placeholder="0" />
              </div>
              {form.billing_cycles.length > 1 && (
                <button onClick={() => removeBillingCycle(idx)} className="text-red-500 hover:text-red-700">
                  <Trash className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Feature Gating */}
      <div className="border-t border-slate-200 pt-4">
        <Label className="text-xs mb-1 block font-semibold">Feature Access</Label>
        <p className="text-[10px] text-slate-400 mb-3">Control which platform features are available on this plan.</p>
        <div className="space-y-2">
          {GATED_FEATURES.map((f) => {
            const enabled = featureFlags[f.key] ?? (f.alwaysOn ? true : false);
            return (
              <label
                key={f.key}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border cursor-pointer transition-colors ${
                  f.alwaysOn
                    ? "bg-slate-50 border-slate-200 opacity-70 cursor-not-allowed"
                    : enabled
                    ? "bg-blue-50 border-blue-300"
                    : "border-slate-200 hover:border-slate-300"
                }`}
              >
                <input
                  type="checkbox"
                  checked={enabled}
                  disabled={f.alwaysOn}
                  onChange={() => toggleFeatureFlag(f.key)}
                  className="hidden"
                />
                <div className={`w-4 h-4 rounded flex-shrink-0 flex items-center justify-center ${
                  enabled ? "bg-blue-600" : "border border-slate-300"
                }`}>
                  {enabled && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                <div className="flex-1">
                  <div className={`text-sm font-medium ${enabled ? "text-blue-800" : "text-slate-700"}`}>
                    {f.label}
                    {f.alwaysOn && <span className="ml-2 text-[10px] font-normal text-slate-400">(always enabled)</span>}
                  </div>
                  <div className="text-[10px] text-slate-400">{f.description}</div>
                </div>
              </label>
            );
          })}
        </div>
      </div>

      {/* Marketing Features */}
      <div className="border-t border-slate-200 pt-4">
        <Label className="text-xs mb-2 block font-semibold">Marketing Features (displayed on pricing page)</Label>
        <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto">
          {FEATURE_OPTIONS.map((f) => (
            <label key={f.key} className={`flex items-center gap-2 px-3 py-2 rounded-lg border cursor-pointer transition-colors text-sm ${
              form.features.includes(f.key) ? "bg-blue-50 border-blue-300 text-blue-800" : "border-slate-200 text-slate-600 hover:border-slate-300"
            }`}>
              <input type="checkbox" checked={form.features.includes(f.key)} onChange={() => toggleFeature(f.key)} className="hidden" />
              <div className={`w-4 h-4 rounded flex-shrink-0 flex items-center justify-center ${form.features.includes(f.key) ? "bg-blue-600" : "border border-slate-300"}`}>
                {form.features.includes(f.key) && <Check className="w-2.5 h-2.5 text-white" />}
              </div>
              {f.label}
            </label>
          ))}
        </div>
      </div>

      {/* Module Access */}
      <div className="border-t border-slate-200 pt-4">
        <PlanModulesEditor
          value={form.modules_included || []}
          onChange={(modules) => setForm({ ...form, modules_included: modules })}
          planSlug={form.slug}
        />
      </div>

      {/* Trial Configuration */}
      <div className="border-t border-slate-200 pt-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <Label className="text-sm font-semibold">Free Trial</Label>
            <p className="text-[10px] text-slate-400 mt-0.5">Allow new organizations to try this plan before paying</p>
          </div>
          <Switch
            checked={!!form.trial_enabled}
            onCheckedChange={(v) => setForm({ ...form, trial_enabled: v, trial_days: v ? (form.trial_days ?? 14) : null })}
          />
        </div>
        {form.trial_enabled && (
          <div className="flex items-end gap-3 bg-blue-50 border border-blue-200 rounded-lg px-4 py-3">
            <div className="flex-1">
              <Label className="text-xs text-blue-700 font-medium">Trial Duration (Days)</Label>
              <Input
                type="number"
                min="1"
                max="60"
                value={form.trial_days ?? ""}
                onChange={(e) => setForm({ ...form, trial_days: Math.min(60, Math.max(1, Number(e.target.value))) })}
                className="h-8 mt-1 w-32"
                placeholder="14"
              />
            </div>
            <p className="text-xs text-blue-600 pb-1">1–60 days</p>
          </div>
        )}
      </div>

      <div className="flex items-center gap-6 pt-2 border-t border-slate-100">

        <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
        <Button size="sm" onClick={() => onSave(form)} className="bg-blue-600 hover:bg-blue-700">Save Plan</Button>
      </div>
    </div>
  );
}

export default function Plans() {
  const { hasPlatformRole } = useAuthority();
  const queryClient = useQueryClient();
  const [editPlan, setEditPlan] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const { data: plans = [] } = useQuery({ queryKey: ["plans"], queryFn: () => base44.entities.Plan.list() });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Plan.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["plans"] }); setShowForm(false); toast.success("Plan created"); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Plan.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["plans"] }); setEditPlan(null); toast.success("Plan updated"); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Plan.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["plans"] }); toast.success("Plan deleted"); },
  });

  const PLAN_COLORS = { starter: "blue", growth: "violet", total360: "amber" };

  if (!hasPlatformRole(['platform_owner', 'platform_admin', 'platform_support'])) return <AccessDenied reason="platform" />;

  return (
    <div className="p-6 max-w-6xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Subscription Plans</h2>
          <p className="text-sm text-slate-500 mt-0.5">Define the plans available to customers on your platform</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
          <Plus className="w-4 h-4" /> New Plan
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative border ${plan.is_highlighted ? "border-amber-300 shadow-amber-100 shadow-md" : "border-slate-200"}`}>
            {plan.is_highlighted && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <Badge className="bg-amber-500 text-white border-0 gap-1 shadow-sm"><Star className="w-3 h-3" /> Recommended</Badge>
              </div>
            )}
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-base">{plan.name}</CardTitle>
                  {plan.description && <p className="text-xs text-slate-500 mt-0.5">{plan.description}</p>}
                  <code className="text-[10px] text-slate-400 block mt-1">{plan.slug}</code>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-blue-600" onClick={() => setEditPlan(plan)}>
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-500" onClick={() => deleteMutation.mutate(plan.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
              {plan.trial_enabled && plan.trial_days && (
                <Badge className="mt-2 bg-emerald-100 text-emerald-700 border-emerald-200 text-[10px] gap-1">
                  {plan.trial_days}-day free trial
                </Badge>
              )}
              <div className="mt-3 space-y-1">
                {(plan.billing_cycles || []).map((cycle) => (
                  <div key={cycle.frequency} className="flex items-baseline gap-2">
                    <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-lg font-bold text-slate-900">{cycle.price.toFixed(2)}</span>
                    <span className="text-slate-400 text-sm">/{cycle.frequency}</span>
                    {cycle.discount_percent > 0 && (
                      <Badge variant="secondary" className="text-[10px] ml-auto">{cycle.discount_percent}% off</Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex flex-wrap gap-1.5 text-xs text-slate-500">
                <span>{plan.max_trucks === 999 ? "Unlimited" : plan.max_trucks} trucks</span>
                <span>·</span>
                <span>{plan.max_users === 999 ? "Unlimited" : plan.max_users} users</span>
                <span>·</span>
                <Badge variant="outline" className="text-[10px] capitalize">{plan.support_tier || "standard"} support</Badge>
              </div>
              <div className="space-y-1">
                {(plan.features || []).map((fKey) => {
                  const feat = FEATURE_OPTIONS.find((f) => f.key === fKey);
                  return (
                    <div key={fKey} className="flex items-center gap-2 text-xs text-slate-700">
                      <Check className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                      {feat?.label || fKey}
                    </div>
                  );
                })}
              </div>
              {!plan.is_active && (
                <Badge variant="outline" className="text-[10px] text-slate-400 border-slate-200">Inactive</Badge>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {plans.length === 0 && (
        <div className="text-center py-16 text-slate-400">
          <DollarSign className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No plans yet. Create your first plan.</p>
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Plan</DialogTitle></DialogHeader>
          <PlanForm onSave={(data) => createMutation.mutate(data)} onClose={() => setShowForm(false)} />
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editPlan} onOpenChange={() => setEditPlan(null)}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Edit Plan: {editPlan?.name}</DialogTitle></DialogHeader>
          {editPlan && (
            <PlanForm plan={editPlan} onSave={(data) => updateMutation.mutate({ id: editPlan.id, data })} onClose={() => setEditPlan(null)} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}