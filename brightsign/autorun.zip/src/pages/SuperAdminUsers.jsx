import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Edit2, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

const PLATFORM_ROLES = [
  { value: "platform_owner", label: "Platform Owner" },
  { value: "platform_admin", label: "Platform Admin" },
  { value: "platform_developer", label: "Platform Developer" },
  { value: "platform_accounting", label: "Platform Accounting" },
];

function InviteUserModal({ onSuccess }) {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("platform_admin");
  const queryClient = useQueryClient();

  const inviteMutation = useMutation({
    mutationFn: async () => {
      const res = await base44.functions.invoke("managePlatformUser", {
        action: "invite",
        email,
        role,
      });
      return res.data;
    },
    onSuccess: () => {
      toast.success("Platform user invited");
      setEmail("");
      setRole("platform_admin");
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["platform-users"] });
      onSuccess?.();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to invite user");
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="w-4 h-4" /> Invite Platform User
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Invite Platform User</DialogTitle>
          <DialogDescription>
            Add a new internal ScreenFleet platform user
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Email
            </label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="user@screenfleet.io"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Platform Role
            </label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PLATFORM_ROLES.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button
            onClick={() => inviteMutation.mutate()}
            disabled={!email || inviteMutation.isPending}
            className="w-full"
          >
            {inviteMutation.isPending ? "Inviting..." : "Send Invite"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EditRoleModal({ user, onSuccess }) {
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState(user.role || "platform_admin");
  const queryClient = useQueryClient();

  const editMutation = useMutation({
    mutationFn: async () => {
      const res = await base44.functions.invoke("managePlatformUser", {
        action: "edit",
        userId: user.id,
        role,
      });
      return res.data;
    },
    onSuccess: () => {
      toast.success("Role updated");
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["platform-users"] });
      onSuccess?.();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update role");
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Edit2 className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Platform Role</DialogTitle>
          <DialogDescription>{user.email}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Select value={role} onValueChange={setRole}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PLATFORM_ROLES.map((r) => (
                <SelectItem key={r.value} value={r.value}>
                  {r.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            onClick={() => editMutation.mutate()}
            disabled={role === user.role || editMutation.isPending}
            className="w-full"
          >
            {editMutation.isPending ? "Updating..." : "Update Role"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function SuperAdminUsers() {
  const { hasPlatformRole, isPlatformAdmin: isPlatformAdminUser } = useAuthority();
  const queryClient = useQueryClient();

  // Fetch all hooks before any conditional rendering
  const { data: platformUsers = [], isLoading } = useQuery({
    queryKey: ["platform-users"],
    queryFn: async () => {
      const allUsers = await base44.entities.User.list();
      // Filter to only platform users (those with platform roles)
      return allUsers.filter((u) =>
        [
          "platform_owner",
          "platform_admin",
          "platform_developer",
          "platform_accounting",
        ].includes(u.role)
      );
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (userId) => {
      const res = await base44.functions.invoke("managePlatformUser", {
        action: "remove",
        userId,
      });
      return res.data;
    },
    onSuccess: () => {
      toast.success("Platform user removed");
      queryClient.invalidateQueries({ queryKey: ["platform-users"] });
    },
    onError: (error) => {
      toast.error(error.message || "Failed to remove user");
    },
  });

  // Only platform_owner and platform_admin can access
  if (!hasPlatformRole(["platform_owner", "platform_admin"])) {
    return <AccessDenied reason="platform" />;
  }

  return (
    <div className="p-6 lg:p-8 max-w-6xl mx-auto space-y-6 bg-slate-50 min-h-full">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Super Admin Users
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage internal ScreenFleet platform users
          </p>
        </div>
        <InviteUserModal onSuccess={() => queryClient.invalidateQueries({ queryKey: ["platform-users"] })} />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="text-slate-400">Loading platform users...</div>
        </div>
      ) : platformUsers.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center">
          <p className="text-slate-500">No platform users yet</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Platform Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {platformUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">
                    {user.full_name || "—"}
                  </TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <span className="text-sm px-2 py-1 rounded-full bg-blue-50 text-blue-700 font-medium">
                      {PLATFORM_ROLES.find((r) => r.value === user.role)?.label ||
                        user.role}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm px-2 py-1 rounded-full bg-green-50 text-green-700">
                      Active
                    </span>
                  </TableCell>
                  <TableCell className="text-sm text-slate-500">
                    {user.created_date
                      ? new Date(user.created_date).toLocaleDateString()
                      : "—"}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <EditRoleModal user={user} onSuccess={() => queryClient.invalidateQueries({ queryKey: ["platform-users"] })} />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        if (
                          confirm(
                            `Remove ${user.email} from platform users?`
                          )
                        ) {
                          deleteMutation.mutate(user.id);
                        }
                      }}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}