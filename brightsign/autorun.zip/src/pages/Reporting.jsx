/**
 * Reporting — Phase B: Real ProofOfPlayEvent-powered OOH reporting.
 *
 * Tabs:
 *   Fleet Summary     — asset/screen status (heartbeat-based, Phase A)
 *   Uptime            — per-screen heartbeat status table
 *   Campaign Delivery — ProofOfPlayEvent aggregated by campaign
 *   Creative Delivery — per creative breakdown
 *   Spot Delivery     — per spot breakdown
 *   Screen Delivery   — per screen breakdown
 *   Exceptions        — interrupted/skipped/failed events
 *   Inventory         — spot sold/available status
 */
import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BarChart3, Download, CheckCircle2, XCircle, AlertCircle, Clock,
  Monitor, Megaphone, Building2, Layers, FileText, TrendingUp, RefreshCw
} from "lucide-react";
import { format, subDays, startOfDay, parseISO, isWithinInterval, isValid } from "date-fns";

// ── Utilities ─────────────────────────────────────────────────────────────────

const ONLINE_MS  = 90 * 1000;
const WARNING_MS = 5 * 60 * 1000;

function hbStatus(screenId, heartbeats) {
  const hb = heartbeats.find(h => h.screen_id === screenId);
  if (!hb?.last_seen_at) return "never";
  const age = Date.now() - new Date(hb.last_seen_at).getTime();
  if (age <= ONLINE_MS)  return "online";
  if (age <= WARNING_MS) return "warning";
  return "offline";
}

function fmtSecs(s) {
  if (!s && s !== 0) return "—";
  if (s < 60) return `${Math.round(s)}s`;
  if (s < 3600) return `${Math.round(s / 60)}m`;
  return `${(s / 3600).toFixed(1)}h`;
}

function fmtTs(iso) {
  if (!iso) return "—";
  try { return format(parseISO(iso), "MMM d, HH:mm"); } catch { return iso; }
}

function exportCSV(rows, filename) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const csv = [headers.join(","), ...rows.map(r => headers.map(h => JSON.stringify(r[h] ?? "")).join(","))].join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = filename;
  a.click();
}

function SummaryCard({ label, value, sub, color = "text-slate-900" }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className={`text-2xl font-bold ${color}`}>{value}</div>
      <div className="text-xs font-medium text-slate-700 mt-0.5">{label}</div>
      {sub && <div className="text-[10px] text-slate-400 mt-0.5">{sub}</div>}
    </div>
  );
}

function EmptyState({ message }) {
  return (
    <div className="text-center py-16 text-slate-400">
      <FileText className="w-8 h-8 mx-auto mb-3 opacity-30" />
      <p className="text-sm font-medium">No delivery events found</p>
      <p className="text-xs mt-1 max-w-xs mx-auto">{message || "Adjust your filters or check back once the Player is reporting events."}</p>
    </div>
  );
}

// ── Global Filters Component ──────────────────────────────────────────────────

function ReportFilters({ filters, onChange, advertisers, campaigns, presentations, spots, screens, assets }) {
  const campaignsForAdv = filters.advertiser_id
    ? campaigns.filter(c => c.advertiser_id === filters.advertiser_id)
    : campaigns;
  const spotsForPres = filters.presentation_id
    ? spots.filter(s => s.route_presentation_id === filters.presentation_id)
    : spots;

  return (
    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-5 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
      <div>
        <Label className="text-[10px] text-slate-500 uppercase tracking-wide">From</Label>
        <Input type="date" value={filters.date_from} onChange={e => onChange({ date_from: e.target.value })} className="h-8 text-xs mt-0.5" />
      </div>
      <div>
        <Label className="text-[10px] text-slate-500 uppercase tracking-wide">To</Label>
        <Input type="date" value={filters.date_to} onChange={e => onChange({ date_to: e.target.value })} className="h-8 text-xs mt-0.5" />
      </div>
      <div>
        <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Advertiser</Label>
        <Select value={filters.advertiser_id || "_all"} onValueChange={v => onChange({ advertiser_id: v === "_all" ? null : v, campaign_id: null })}>
          <SelectTrigger className="h-8 text-xs mt-0.5"><SelectValue placeholder="All" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="_all">All Advertisers</SelectItem>
            {advertisers.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Campaign</Label>
        <Select value={filters.campaign_id || "_all"} onValueChange={v => onChange({ campaign_id: v === "_all" ? null : v })}>
          <SelectTrigger className="h-8 text-xs mt-0.5"><SelectValue placeholder="All" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="_all">All Campaigns</SelectItem>
            {campaignsForAdv.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Presentation</Label>
        <Select value={filters.presentation_id || "_all"} onValueChange={v => onChange({ presentation_id: v === "_all" ? null : v, spot_id: null })}>
          <SelectTrigger className="h-8 text-xs mt-0.5"><SelectValue placeholder="All" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="_all">All Presentations</SelectItem>
            {presentations.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Status</Label>
        <Select value={filters.status || "_all"} onValueChange={v => onChange({ status: v === "_all" ? null : v })}>
          <SelectTrigger className="h-8 text-xs mt-0.5"><SelectValue placeholder="All" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="_all">All Statuses</SelectItem>
            <SelectItem value="played">Played</SelectItem>
            <SelectItem value="interrupted">Interrupted</SelectItem>
            <SelectItem value="skipped">Skipped</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}

// ── Filter events helper ──────────────────────────────────────────────────────

function applyFilters(events, filters) {
  return events.filter(ev => {
    if (filters.date_from) {
      const evDate = ev.playback_started_at?.substring(0, 10);
      if (!evDate || evDate < filters.date_from) return false;
    }
    if (filters.date_to) {
      const evDate = ev.playback_started_at?.substring(0, 10);
      if (!evDate || evDate > filters.date_to) return false;
    }
    if (filters.advertiser_id && ev.advertiser_id !== filters.advertiser_id) return false;
    if (filters.campaign_id   && ev.campaign_id   !== filters.campaign_id)   return false;
    if (filters.presentation_id && ev.route_presentation_id !== filters.presentation_id) return false;
    if (filters.spot_id       && ev.route_spot_id  !== filters.spot_id)      return false;
    if (filters.screen_id     && ev.screen_id      !== filters.screen_id)    return false;
    if (filters.status        && ev.status         !== filters.status)       return false;
    return true;
  });
}

function aggMetrics(events) {
  const played       = events.filter(e => e.status === "played");
  const total_secs   = events.reduce((s, e) => s + (e.delivered_seconds || 0), 0);
  const interrupted  = events.filter(e => e.status === "interrupted").length;
  const skipped      = events.filter(e => e.status === "skipped").length;
  const failed       = events.filter(e => e.status === "failed").length;
  const offline      = events.filter(e => e.was_offline).length;
  const dates        = events.map(e => e.playback_started_at).filter(Boolean).sort();
  const screens      = new Set(events.map(e => e.screen_id)).size;
  const assets       = new Set(events.map(e => e.asset_id).filter(Boolean)).size;
  return {
    total: events.length,
    played: played.length,
    interrupted,
    skipped,
    failed,
    offline,
    total_secs,
    first_play: dates[0] ? fmtTs(dates[0]) : "—",
    last_play: dates[dates.length - 1] ? fmtTs(dates[dates.length - 1]) : "—",
    unique_screens: screens,
    unique_assets: assets,
  };
}

// ── Campaign Delivery Report ──────────────────────────────────────────────────

function CampaignDeliveryReport({ events, campaigns, advertisers, spots }) {
  const rows = useMemo(() => {
    return campaigns.map(campaign => {
      const adv = advertisers.find(a => a.id === campaign.advertiser_id);
      const evs = events.filter(e => e.campaign_id === campaign.id);
      const m = aggMetrics(evs);
      return {
        campaign: campaign.name,
        advertiser: adv?.name || "—",
        status: campaign.status,
        contracted_plays: campaign.contracted_play_count || null,
        total_plays: m.played,
        total_events: m.total,
        delivered_secs: m.total_secs,
        pacing: campaign.contracted_play_count ? `${Math.round((m.played / campaign.contracted_play_count) * 100)}%` : "—",
        interrupted: m.interrupted,
        failed: m.failed,
        unique_screens: m.unique_screens,
        first_play: m.first_play,
        last_play: m.last_play,
      };
    }).filter(r => r.total_events > 0 || campaigns.length < 20);
  }, [events, campaigns, advertisers]);

  const totals = aggMetrics(events);
  const filename = `campaign-delivery-${format(new Date(), "yyyy-MM-dd")}.csv`;

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <SummaryCard label="Total Plays" value={totals.played.toLocaleString()} color="text-green-600" />
        <SummaryCard label="Delivered Seconds" value={fmtSecs(totals.total_secs)} color="text-blue-600" />
        <SummaryCard label="Interrupted / Failed" value={`${totals.interrupted + totals.failed}`} color={totals.interrupted + totals.failed > 0 ? "text-red-500" : "text-slate-400"} />
        <SummaryCard label="Unique Screens" value={totals.unique_screens} />
      </div>
      <div className="flex justify-end mb-3">
        <Button variant="outline" size="sm" className="gap-2" onClick={() => exportCSV(rows, filename)}>
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>
      {rows.filter(r => r.total_events > 0).length === 0 ? (
        <EmptyState message="No proof-of-play events received yet. Configure the Player to emit reportProofOfPlay events." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-200">
                {["Campaign","Advertiser","Status","Plays","Contracted","Pacing","Delivered","Interrupted","Failed","Screens","First Play","Last Play"].map(h => (
                  <th key={h} className="text-left font-semibold text-slate-500 pb-2 pr-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.filter(r => r.total_events > 0).map((r, i) => (
                <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-2 pr-3 font-medium text-slate-900 whitespace-nowrap">{r.campaign}</td>
                  <td className="py-2 pr-3 text-slate-600">{r.advertiser}</td>
                  <td className="py-2 pr-3">
                    <Badge className={`text-[10px] ${r.status === "active" ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-500"}`}>{r.status}</Badge>
                  </td>
                  <td className="py-2 pr-3 font-bold text-green-700">{r.total_plays.toLocaleString()}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.contracted_plays?.toLocaleString() || "—"}</td>
                  <td className="py-2 pr-3 font-medium">{r.pacing}</td>
                  <td className="py-2 pr-3 text-slate-600">{fmtSecs(r.delivered_secs)}</td>
                  <td className="py-2 pr-3 text-amber-600">{r.interrupted || 0}</td>
                  <td className="py-2 pr-3 text-red-500">{r.failed || 0}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.unique_screens}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.first_play}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.last_play}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Spot Delivery Report ──────────────────────────────────────────────────────

function SpotDeliveryReport({ events, spots, presentations, advertisers }) {
  const rows = useMemo(() => {
    const spotsWithEvents = spots.filter(s => events.some(e => e.route_spot_id === s.id));
    return spotsWithEvents.map(spot => {
      const pres  = presentations.find(p => p.id === spot.route_presentation_id);
      const adv   = advertisers.find(a => a.id === spot.advertiser_id);
      const evs   = events.filter(e => e.route_spot_id === spot.id);
      const m     = aggMetrics(evs);
      return {
        spot_number: spot.spot_number,
        presentation: pres?.name || "—",
        tier: spot.tier || "impact",
        advertiser: adv?.name || spot.advertiser_name || "—",
        total_plays: m.played,
        delivered_secs: m.total_secs,
        interrupted: m.interrupted,
        failed: m.failed,
        offline: m.offline,
        unique_screens: m.unique_screens,
        first_play: m.first_play,
        last_play: m.last_play,
      };
    }).sort((a, b) => a.spot_number - b.spot_number);
  }, [events, spots, presentations, advertisers]);

  const filename = `spot-delivery-${format(new Date(), "yyyy-MM-dd")}.csv`;
  const totals = aggMetrics(events);

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <SummaryCard label="Total Spot Plays" value={totals.played.toLocaleString()} color="text-green-600" />
        <SummaryCard label="Delivered" value={fmtSecs(totals.total_secs)} color="text-blue-600" />
        <SummaryCard label="Offline Delivered" value={totals.offline} sub="buffered events" />
        <SummaryCard label="Issues" value={totals.interrupted + totals.failed} color={totals.interrupted + totals.failed > 0 ? "text-red-500" : "text-slate-400"} />
      </div>
      <div className="flex justify-end mb-3">
        <Button variant="outline" size="sm" className="gap-2" onClick={() => exportCSV(rows, filename)}>
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>
      {rows.length === 0 ? (
        <EmptyState message="No spot-level delivery events yet." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-200">
                {["Spot","Presentation","Tier","Advertiser","Plays","Delivered","Interrupted","Failed","Offline","Screens","First","Last"].map(h => (
                  <th key={h} className="text-left font-semibold text-slate-500 pb-2 pr-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-2 pr-3 font-bold text-slate-800">#{r.spot_number}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.presentation}</td>
                  <td className="py-2 pr-3">
                    <Badge className={`text-[10px] ${r.tier === "impact" ? "bg-blue-100 text-blue-700" : r.tier === "growth" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>{r.tier}</Badge>
                  </td>
                  <td className="py-2 pr-3 text-slate-700 font-medium">{r.advertiser}</td>
                  <td className="py-2 pr-3 font-bold text-green-700">{r.total_plays.toLocaleString()}</td>
                  <td className="py-2 pr-3 text-slate-600">{fmtSecs(r.delivered_secs)}</td>
                  <td className="py-2 pr-3 text-amber-600">{r.interrupted}</td>
                  <td className="py-2 pr-3 text-red-500">{r.failed}</td>
                  <td className="py-2 pr-3 text-slate-400">{r.offline}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.unique_screens}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.first_play}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.last_play}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Creative Delivery Report ──────────────────────────────────────────────────

function CreativeDeliveryReport({ events, spots, advertisers }) {
  const rows = useMemo(() => {
    const byCreative = {};
    events.forEach(ev => {
      const key = ev.route_creative_id || ev.media_asset_id || "unknown";
      if (!byCreative[key]) byCreative[key] = { route_creative_id: ev.route_creative_id, media_asset_id: ev.media_asset_id, route_spot_id: ev.route_spot_id, events: [] };
      byCreative[key].events.push(ev);
    });
    return Object.values(byCreative).map(group => {
      const spot = spots.find(s => s.id === group.route_spot_id);
      const adv  = advertisers.find(a => a.id === spot?.advertiser_id);
      const m    = aggMetrics(group.events);
      return {
        creative_id: group.route_creative_id || "—",
        advertiser: adv?.name || spot?.advertiser_name || "—",
        spot: spot ? `#${spot.spot_number}` : "—",
        total_plays: m.played,
        delivered_secs: m.total_secs,
        interrupted: m.interrupted,
        failed: m.failed,
        unique_screens: m.unique_screens,
        first_play: m.first_play,
        last_play: m.last_play,
      };
    }).sort((a, b) => b.total_plays - a.total_plays);
  }, [events, spots, advertisers]);

  const totals = aggMetrics(events);
  const filename = `creative-delivery-${format(new Date(), "yyyy-MM-dd")}.csv`;

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <SummaryCard label="Total Creative Plays" value={totals.played.toLocaleString()} color="text-green-600" />
        <SummaryCard label="Delivered" value={fmtSecs(totals.total_secs)} color="text-blue-600" />
        <SummaryCard label="Unique Creatives" value={rows.length} />
        <SummaryCard label="Failures" value={totals.failed} color={totals.failed > 0 ? "text-red-500" : "text-slate-400"} />
      </div>
      <div className="flex justify-end mb-3">
        <Button variant="outline" size="sm" className="gap-2" onClick={() => exportCSV(rows, filename)}>
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>
      {rows.length === 0 ? <EmptyState message="No creative-level delivery events yet." /> : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-200">
                {["Creative ID","Advertiser","Spot","Plays","Delivered","Interrupted","Failed","Screens","First","Last"].map(h => (
                  <th key={h} className="text-left font-semibold text-slate-500 pb-2 pr-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-2 pr-3 font-mono text-[10px] text-slate-500 max-w-[120px] truncate">{r.creative_id}</td>
                  <td className="py-2 pr-3 font-medium text-slate-800">{r.advertiser}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.spot}</td>
                  <td className="py-2 pr-3 font-bold text-green-700">{r.total_plays.toLocaleString()}</td>
                  <td className="py-2 pr-3 text-slate-600">{fmtSecs(r.delivered_secs)}</td>
                  <td className="py-2 pr-3 text-amber-600">{r.interrupted}</td>
                  <td className="py-2 pr-3 text-red-500">{r.failed}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.unique_screens}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.first_play}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.last_play}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Screen / Asset Delivery Report ───────────────────────────────────────────

function ScreenDeliveryReport({ events, screens, assets, heartbeats }) {
  const rows = useMemo(() => {
    return screens.map(screen => {
      const asset = assets.find(a => a.id === screen.asset_id);
      const evs   = events.filter(e => e.screen_id === screen.id);
      const m     = aggMetrics(evs);
      const status = hbStatus(screen.id, heartbeats);
      return {
        screen: screen.name,
        asset: asset?.name || "—",
        resolution: `${screen.width}×${screen.height}`,
        status,
        total_plays: m.played,
        delivered_secs: m.total_secs,
        interrupted: m.interrupted,
        failed: m.failed,
        offline_plays: m.offline,
        first_play: m.first_play,
        last_play: m.last_play,
      };
    }).filter(r => r.total_plays > 0 || r.status !== "never");
  }, [events, screens, assets, heartbeats]);

  const totals = aggMetrics(events);
  const filename = `screen-delivery-${format(new Date(), "yyyy-MM-dd")}.csv`;
  const statusColors = { online: "text-green-600", warning: "text-amber-500", offline: "text-red-500", never: "text-slate-300" };
  const statusIcons = { online: <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />, warning: <AlertCircle className="w-3.5 h-3.5 text-amber-500" />, offline: <XCircle className="w-3.5 h-3.5 text-red-500" />, never: <Clock className="w-3.5 h-3.5 text-slate-300" /> };

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <SummaryCard label="Total Plays Across Screens" value={totals.played.toLocaleString()} color="text-green-600" />
        <SummaryCard label="Delivered" value={fmtSecs(totals.total_secs)} color="text-blue-600" />
        <SummaryCard label="Active Screens" value={screens.filter(s => hbStatus(s.id, heartbeats) === "online").length} sub="online now" />
        <SummaryCard label="Offline Plays" value={totals.offline} sub="buffered" />
      </div>
      <div className="flex justify-end mb-3">
        <Button variant="outline" size="sm" className="gap-2" onClick={() => exportCSV(rows.map(r => ({ ...r, status: r.status })), filename)}>
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>
      {rows.length === 0 ? <EmptyState message="No screen-level delivery events yet." /> : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-200">
                {["","Screen","Asset","Resolution","Plays","Delivered","Interrupted","Failed","Offline","First","Last"].map(h => (
                  <th key={h} className="text-left font-semibold text-slate-500 pb-2 pr-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-2 pr-2">{statusIcons[r.status]}</td>
                  <td className="py-2 pr-3 font-medium text-slate-900">{r.screen}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.asset}</td>
                  <td className="py-2 pr-3 text-slate-400">{r.resolution}</td>
                  <td className="py-2 pr-3 font-bold text-green-700">{r.total_plays.toLocaleString()}</td>
                  <td className="py-2 pr-3 text-slate-600">{fmtSecs(r.delivered_secs)}</td>
                  <td className="py-2 pr-3 text-amber-600">{r.interrupted}</td>
                  <td className="py-2 pr-3 text-red-500">{r.failed}</td>
                  <td className="py-2 pr-3 text-slate-400">{r.offline_plays}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.first_play}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.last_play}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Exceptions Report ─────────────────────────────────────────────────────────

function ExceptionsReport({ events, screens, spots, advertisers }) {
  const exceptions = events.filter(e => ["interrupted", "skipped", "failed"].includes(e.status));
  const filename = `exceptions-${format(new Date(), "yyyy-MM-dd")}.csv`;

  const rows = useMemo(() => exceptions.map(ev => {
    const screen = screens.find(s => s.id === ev.screen_id);
    const spot   = spots.find(s => s.id === ev.route_spot_id);
    const adv    = advertisers.find(a => a.id === ev.advertiser_id);
    return {
      status: ev.status,
      screen: screen?.name || ev.screen_id,
      advertiser: adv?.name || spot?.advertiser_name || "—",
      spot: spot ? `#${spot.spot_number}` : "—",
      started: fmtTs(ev.playback_started_at),
      delivered_secs: ev.delivered_seconds ?? "—",
      offline: ev.was_offline ? "Yes" : "No",
      error_code: ev.error_code || "—",
      player_version: ev.player_version || "—",
    };
  }), [exceptions, screens, spots, advertisers]);

  const statusBadge = {
    interrupted: "bg-amber-100 text-amber-700",
    skipped:     "bg-slate-100 text-slate-600",
    failed:      "bg-red-100 text-red-700",
  };

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-5">
        <SummaryCard label="Interrupted" value={exceptions.filter(e => e.status === "interrupted").length} color="text-amber-600" />
        <SummaryCard label="Skipped" value={exceptions.filter(e => e.status === "skipped").length} color="text-slate-600" />
        <SummaryCard label="Failed" value={exceptions.filter(e => e.status === "failed").length} color="text-red-600" />
      </div>
      <div className="flex justify-end mb-3">
        <Button variant="outline" size="sm" className="gap-2" onClick={() => exportCSV(rows, filename)}>
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>
      {rows.length === 0 ? (
        <div className="text-center py-12 text-slate-400">
          <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-green-300" />
          <p className="text-sm font-medium text-green-600">No exceptions — clean delivery!</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-200">
                {["Status","Screen","Advertiser","Spot","Started At","Delivered","Offline","Error","Player Ver"].map(h => (
                  <th key={h} className="text-left font-semibold text-slate-500 pb-2 pr-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-2 pr-3">
                    <Badge className={`text-[10px] ${statusBadge[r.status]}`}>{r.status}</Badge>
                  </td>
                  <td className="py-2 pr-3 font-medium text-slate-900">{r.screen}</td>
                  <td className="py-2 pr-3 text-slate-600">{r.advertiser}</td>
                  <td className="py-2 pr-3 text-slate-500">{r.spot}</td>
                  <td className="py-2 pr-3 text-slate-400 whitespace-nowrap">{r.started}</td>
                  <td className="py-2 pr-3 text-slate-500">{typeof r.delivered_secs === "number" ? fmtSecs(r.delivered_secs) : "—"}</td>
                  <td className="py-2 pr-3 text-slate-400">{r.offline}</td>
                  <td className="py-2 pr-3 text-red-400">{r.error_code}</td>
                  <td className="py-2 pr-3 text-slate-400">{r.player_version}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Fleet + Uptime (from Phase A, kept intact) ────────────────────────────────

function FleetSummaryReport({ assets, screens, publishedScreens, heartbeats }) {
  const rows = assets.map(asset => {
    const assetScreens = screens.filter(s => s.asset_id === asset.id);
    const published = publishedScreens.filter(ps => assetScreens.some(s => s.id === ps.screen_id));
    const online  = assetScreens.filter(s => hbStatus(s.id, heartbeats) === "online").length;
    const warning = assetScreens.filter(s => hbStatus(s.id, heartbeats) === "warning").length;
    const offline = assetScreens.filter(s => hbStatus(s.id, heartbeats) === "offline").length;
    const never   = assetScreens.filter(s => hbStatus(s.id, heartbeats) === "never").length;
    return { asset: asset.name, status: asset.status, screens: assetScreens.length, published: published.length, online, warning, offline, never };
  });
  return (
    <div>
      <div className="flex justify-end mb-3">
        <Button variant="outline" size="sm" className="gap-2" onClick={() => exportCSV(rows, `fleet-${format(new Date(),"yyyy-MM-dd")}.csv`)}>
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-slate-200">
              {["Asset","Status","Screens","Published","Online","Warning","Offline","Never"].map(h => (
                <th key={h} className="text-left font-semibold text-slate-500 pb-2 pr-4">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2 pr-4 font-medium text-slate-900">{r.asset}</td>
                <td className="py-2 pr-4"><Badge className={`text-[10px] ${r.status === "active" ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-500"}`}>{r.status}</Badge></td>
                <td className="py-2 pr-4">{r.screens}</td>
                <td className="py-2 pr-4">{r.published}</td>
                <td className="py-2 pr-4 text-green-600 font-medium">{r.online}</td>
                <td className="py-2 pr-4 text-amber-600 font-medium">{r.warning}</td>
                <td className="py-2 pr-4 text-red-500 font-medium">{r.offline}</td>
                <td className="py-2 pr-4 text-slate-400">{r.never}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={8} className="py-8 text-center text-slate-400">No assets found</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tab config ────────────────────────────────────────────────────────────────

const TABS = [
  { id: "fleet",      label: "Fleet Summary",      icon: Monitor    },
  { id: "campaign",   label: "Campaign Delivery",  icon: Megaphone  },
  { id: "spot",       label: "Spot Delivery",      icon: Layers     },
  { id: "creative",   label: "Creative Delivery",  icon: TrendingUp },
  { id: "screen",     label: "Screen Delivery",    icon: Monitor    },
  { id: "exceptions", label: "Exceptions",         icon: AlertCircle },
];

const DEFAULT_FILTERS = {
  date_from: format(subDays(new Date(), 30), "yyyy-MM-dd"),
  date_to:   format(new Date(), "yyyy-MM-dd"),
  advertiser_id: null,
  campaign_id:   null,
  presentation_id: null,
  spot_id:       null,
  screen_id:     null,
  status:        null,
};

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function Reporting() {
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  const [activeTab, setActiveTab] = useState("fleet");
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const mergeFilters = (patch) => setFilters(f => ({ ...f, ...patch }));

  // ── Data fetches ─────────────────────────────────────────────────────────

  const { data: assets = [] } = useQuery({
    queryKey: ["assets", activeOrgId],
    queryFn: () => base44.entities.Asset.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const { data: screens = [] } = useQuery({
    queryKey: ["v2screens", activeOrgId],
    queryFn: async () => {
      if (!assets.length) return [];
      const all = await Promise.all(assets.map(a => base44.entities.Screen.filter({ asset_id: a.id })));
      return all.flat();
    },
    enabled: assets.length > 0,
  });

  const { data: heartbeats = [] } = useQuery({
    queryKey: ["heartbeats", screens.map(s => s.id).join(",")],
    queryFn: async () => {
      if (!screens.length) return [];
      const all = await Promise.all(screens.map(s => base44.entities.PlayerHeartbeat.filter({ screen_id: s.id })));
      return all.flat();
    },
    enabled: screens.length > 0,
    refetchInterval: 60000,
  });

  const { data: publishedScreens = [] } = useQuery({
    queryKey: ["publishedScreens", activeOrgId],
    queryFn: async () => {
      if (!screens.length) return [];
      const all = await Promise.all(screens.map(s => base44.entities.PublishedScreen.filter({ screen_id: s.id })));
      return all.flat();
    },
    enabled: screens.length > 0,
  });

  const { data: advertisers = [] } = useQuery({
    queryKey: ["advertisers", activeOrgId],
    queryFn: () => base44.entities.Advertiser.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ["campaigns", activeOrgId],
    queryFn: () => base44.entities.Campaign.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const { data: presentations = [] } = useQuery({
    queryKey: ["routePresentations", activeOrgId],
    queryFn: () => base44.entities.RoutePresentation.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const { data: allSpots = [] } = useQuery({
    queryKey: ["allRouteSpots", presentations.map(p => p.id).join(",")],
    queryFn: async () => {
      if (!presentations.length) return [];
      const all = await Promise.all(presentations.map(p => base44.entities.RouteSpot.filter({ route_presentation_id: p.id })));
      return all.flat();
    },
    enabled: presentations.length > 0,
  });

  // ProofOfPlayEvents — load all for this org
  const { data: rawEvents = [], isLoading: eventsLoading, refetch: refetchEvents } = useQuery({
    queryKey: ["proofOfPlay", activeOrgId],
    queryFn: () => base44.entities.ProofOfPlayEvent.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
    staleTime: 30000,
  });

  // Apply filters
  const filteredEvents = useMemo(() => applyFilters(rawEvents, filters), [rawEvents, filters]);

  // Summary KPIs (top strip) — always over date-filtered events
  const kpiEvents = useMemo(() => applyFilters(rawEvents, { date_from: filters.date_from, date_to: filters.date_to }), [rawEvents, filters.date_from, filters.date_to]);
  const kpi = aggMetrics(kpiEvents);
  const onlineCount = screens.filter(s => hbStatus(s.id, heartbeats) === "online").length;

  if (!canAccessModule('module_ooh_reporting')) return <AccessDenied reason="module" />;

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" /> Reporting
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">Real delivery data from Proof of Play events</p>
        </div>
        <Button variant="outline" size="sm" className="gap-2" onClick={() => refetchEvents()}>
          <RefreshCw className="w-3.5 h-3.5" /> Refresh
        </Button>
      </div>

      {/* Top KPI strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
        <SummaryCard label="Screens Online"    value={`${onlineCount}/${screens.length}`} color="text-green-600" sub="live heartbeat" />
        <SummaryCard label="Plays (period)"    value={kpi.played.toLocaleString()}        color="text-blue-600"  sub={`${filters.date_from} → ${filters.date_to}`} />
        <SummaryCard label="Delivered (period)" value={fmtSecs(kpi.total_secs)}           color="text-slate-900" />
        <SummaryCard label="Exceptions"        value={kpi.interrupted + kpi.failed}       color={kpi.interrupted + kpi.failed > 0 ? "text-red-500" : "text-slate-400"} sub="interrupted + failed" />
        <SummaryCard label="Offline Delivered" value={kpi.offline}                        sub="buffered plays" />
      </div>

      {/* Filters */}
      <ReportFilters
        filters={filters}
        onChange={mergeFilters}
        advertisers={advertisers}
        campaigns={campaigns}
        presentations={presentations}
        spots={allSpots}
        screens={screens}
        assets={assets}
      />

      {/* Tab bar */}
      <div className="flex gap-1 bg-slate-100 rounded-lg p-1 mb-5 overflow-x-auto">
        {TABS.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-xs font-medium transition-all whitespace-nowrap ${activeTab === tab.id ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
            >
              <Icon className="w-3.5 h-3.5" /> {tab.label}
            </button>
          );
        })}
      </div>

      {/* Report panel */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
        {eventsLoading && <p className="text-sm text-slate-400 text-center py-8">Loading delivery events…</p>}
        {!eventsLoading && (
          <>
            {activeTab === "fleet"      && <FleetSummaryReport    assets={assets} screens={screens} publishedScreens={publishedScreens} heartbeats={heartbeats} />}
            {activeTab === "campaign"   && <CampaignDeliveryReport events={filteredEvents} campaigns={campaigns} advertisers={advertisers} spots={allSpots} />}
            {activeTab === "spot"       && <SpotDeliveryReport    events={filteredEvents} spots={allSpots} presentations={presentations} advertisers={advertisers} />}
            {activeTab === "creative"   && <CreativeDeliveryReport events={filteredEvents} spots={allSpots} advertisers={advertisers} />}
            {activeTab === "screen"     && <ScreenDeliveryReport  events={filteredEvents} screens={screens} assets={assets} heartbeats={heartbeats} />}
            {activeTab === "exceptions" && <ExceptionsReport      events={filteredEvents} screens={screens} spots={allSpots} advertisers={advertisers} />}
          </>
        )}
      </div>
    </div>
  );
}