import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import LegacyPageBanner from "@/components/LegacyPageBanner";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useOrg } from "@/components/OrgContext";
import TruckCard from "@/components/trucks/TruckCard";
import TruckFormDialog from "@/components/trucks/TruckFormDialog";
import ScreenSetupDialog from "@/components/trucks/ScreenSetupDialog";

export default function Trucks() {
  const queryClient = useQueryClient();
  const { activeOrgId, isPlatformAdmin } = useOrg();
  const [formOpen, setFormOpen] = useState(false);
  const [screenSetupOpen, setScreenSetupOpen] = useState(false);
  const [editingTruck, setEditingTruck] = useState(null);
  const [selectedTruck, setSelectedTruck] = useState(null);

  const { data: trucks = [] } = useQuery({
    queryKey: ["trucks", activeOrgId],
    queryFn: () => isPlatformAdmin 
      ? base44.entities.Truck.list("-created_date")
      : base44.entities.Truck.filter({ org_id: activeOrgId }, "-created_date"),
    enabled: !!activeOrgId
  });

  const { data: screens = [] } = useQuery({
    queryKey: ["screens", activeOrgId, isPlatformAdmin],
    queryFn: () => isPlatformAdmin
      ? base44.entities.Screen.list()
      : base44.entities.Screen.filter({ truck_id: trucks.map(t => t.id) }),
    enabled: isPlatformAdmin ? trucks.length > 0 : (!!activeOrgId && trucks.length > 0)
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Truck.create({ ...data, org_id: activeOrgId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["trucks", activeOrgId] });
      setFormOpen(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Truck.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["trucks", activeOrgId] });
      setFormOpen(false);
      setEditingTruck(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Truck.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["trucks", activeOrgId] }),
  });

  const handleSave = (data) => {
    if (editingTruck) {
      updateMutation.mutate({ id: editingTruck.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (truck) => {
    setEditingTruck(truck);
    setFormOpen(true);
  };

  const handleDelete = (truck) => {
    if (confirm(`Delete "${truck.name}"? This will also remove all screens and zones.`)) {
      deleteMutation.mutate(truck.id);
    }
  };

  const handleDuplicate = async (truck) => {
    const truckScreens = screens.filter((s) => s.truck_id === truck.id);
    
    // Create new truck with same properties but new name
    const newTruckData = { ...truck };
    delete newTruckData.id;
    delete newTruckData.created_date;
    delete newTruckData.updated_date;
    delete newTruckData.created_by;
    newTruckData.name = `${truck.name} (Copy)`;
    
    const newTruck = await base44.entities.Truck.create(newTruckData);
    
    // Duplicate screens with their zones
    for (const screen of truckScreens) {
      const screenData = { ...screen };
      delete screenData.id;
      delete screenData.created_date;
      delete screenData.updated_date;
      delete screenData.created_by;
      screenData.truck_id = newTruck.id;
      
      const newScreen = await base44.entities.Screen.create(screenData);
      
      // Fetch and duplicate zones
      const zones = await base44.entities.Zone.filter({ screen_id: screen.id });
      for (const zone of zones) {
        const zoneData = { ...zone };
        delete zoneData.id;
        delete zoneData.created_date;
        delete zoneData.updated_date;
        delete zoneData.created_by;
        zoneData.screen_id = newScreen.id;
        await base44.entities.Zone.create(zoneData);
      }
    }
    
    queryClient.invalidateQueries({ queryKey: ["trucks", activeOrgId] });
    queryClient.invalidateQueries({ queryKey: ["screens", activeOrgId] });
  };

  const handleManageScreens = (truck) => {
    setSelectedTruck(truck);
    setScreenSetupOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto">
      <LegacyPageBanner
        pageName="Trucks (V1)"
        replacement="Assets"
        replacementPath="/Assets"
      />
      <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-sm text-slate-500">Manage your LED advertising assets — trucks, trailers, poster panels, and video walls</p>
        </div>
        <Button onClick={() => { setEditingTruck(null); setFormOpen(true); }} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" /> Add Asset
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {trucks.map((truck) => {
          const truckScreens = screens.filter((s) => s.truck_id === truck.id);
          return (
            <TruckCard
              key={truck.id}
              truck={truck}
              screenCount={truckScreens.length}
              screens={truckScreens}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onDuplicate={handleDuplicate}
              onManageScreens={handleManageScreens}
            />
          );
        })}
      </div>

      {trucks.length === 0 && (
        <div className="text-center py-20">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center mb-4">
            <Plus className="w-6 h-6 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-700 mb-1">No assets yet</h3>
          <p className="text-sm text-slate-400 mb-4">Add your first advertising asset to get started</p>
          <Button onClick={() => setFormOpen(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" /> Add Your First Asset
          </Button>
        </div>
      )}

      <TruckFormDialog open={formOpen} onOpenChange={setFormOpen} truck={editingTruck} onSave={handleSave} />
      <ScreenSetupDialog open={screenSetupOpen} onOpenChange={setScreenSetupOpen} truck={selectedTruck} />
      </div>
    </div>
  );
}