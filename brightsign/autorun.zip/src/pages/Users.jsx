import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { ORG_ROLES } from "@/components/organizations/permissionsConfig";
import { ORG_ADMIN_ROLES, isLastOrgOwner } from "@/lib/orgAdminBoundaries";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Pencil, Trash2, Mail, Eye, RotateCcw, Search, AlertCircle, Loader2, Copy, CheckCircle2, ExternalLink, Shield } from "lucide-react";
import { toast } from "sonner";
import PermissionOverridesModal from "@/components/permissions/PermissionOverridesModal";

// Build role metadata from ORG_ROLES
const ROLE_COLORS = {
  owner: "bg-purple-100 text-purple-700",
  admin: "bg-red-100 text-red-700",
  manager: "bg-blue-100 text-blue-700",
  ops_manager: "bg-indigo-100 text-indigo-700",
  content_manager: "bg-cyan-100 text-cyan-700",
  scheduler: "bg-emerald-100 text-emerald-700",
  screen_operator: "bg-orange-100 text-orange-700",
  analyst: "bg-pink-100 text-pink-700",
  operator: "bg-slate-100 text-slate-700",
  viewer: "bg-gray-100 text-gray-700",
};

const ROLE_DESCRIPTIONS = Object.fromEntries(
  ORG_ROLES.map((r) => [r.value, r.description])
);

function UserForm({ member, org, onSave, onClose, isSaving }) {
  const [form, setForm] = useState(member || {
    user_email: "",
    org_role: "operator",
  });

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-xs">Email Address *</Label>
        <Input
          type="email"
          value={form.user_email}
          onChange={(e) => setForm({ ...form, user_email: e.target.value })}
          className="h-8 mt-1"
          placeholder="user@example.com"
          disabled={!!member}
        />
      </div>
      <div>
        <Label className="text-xs">Role *</Label>
        <Select value={form.org_role} onValueChange={(v) => setForm({ ...form, org_role: v })}>
          <SelectTrigger className="h-8 mt-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {ORG_ROLES.map((role) => (
              <SelectItem key={role.value} value={role.value}>
                {role.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-[10px] text-slate-500 mt-1">{ROLE_DESCRIPTIONS[form.org_role]}</p>
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
        <Button
          size="sm"
          onClick={() => onSave(form)}
          disabled={!form.user_email || !form.org_role || isSaving}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {isSaving ? <><Loader2 className="w-3 h-3 animate-spin" /> Sending…</> : (member ? "Update" : "Send Invite")}
        </Button>
      </div>
    </div>
  );
}

export default function Users() {
  const { canDo } = useAuthority();
  const { user } = useOrg();
  const queryClient = useQueryClient();
  const { activeOrgId, activeOrg, currentMember } = useOrg();
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [setupLinkData, setSetupLinkData] = useState(null);
  const [copied, setCopied] = useState(false);
  const [roleEditingId, setRoleEditingId] = useState(null);
  const [selectedRole, setSelectedRole] = useState(null);
  const [permissionsModalMember, setPermissionsModalMember] = useState(null);

  const copySetupLink = (url) => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const { data: members = [] } = useQuery({
    queryKey: ["org-members", activeOrgId],
    queryFn: () => base44.entities.OrgMember.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const existing = await base44.entities.OrgMember.filter({ org_id: activeOrgId, user_email: data.user_email });
      if (existing.length > 0) {
        throw new Error(`${data.user_email} is already a member of this organization.`);
      }
      const res = await base44.functions.invoke('createOrgUser', {
        userEmail: data.user_email,
        orgId: activeOrgId,
        orgName: activeOrg?.name || '',
        orgRole: data.org_role,
        appUrl: window.location.hostname.includes('base44.app')
          ? 'https://app.screenfleet.io'
          : window.location.origin,
      });
      if (!res.data?.success) throw new Error(res.data?.error || 'Failed to create user.');
      return res.data;
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["org-members", activeOrgId] });
      setShowForm(false);
      // Always show the setup link dialog so admin can copy it manually
      setSetupLinkData({
        email: result.user_email,
        setupUrl: result.setupUrl,
        emailStatus: result.emailStatus,
      });
      if (result.emailStatus === 'sent') {
        toast.success(`Invitation sent to ${result.user_email} — setup link also shown below as backup.`);
      } else {
        toast.warning(`Account created for ${result.user_email} but email failed. Copy the setup link below and send it manually.`);
      }
    },
    onError: (error) => toast.error(`Failed to create user: ${error.message}`),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.OrgMember.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["org-members", activeOrgId] });
      setEditingMember(null);
      setRoleEditingId(null);
      toast.success("User updated");
    },
  });

  const roleChangeMutation = useMutation({
    mutationFn: ({ id, newRole }) => base44.entities.OrgMember.update(id, { org_role: newRole }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["org-members", activeOrgId] });
      setRoleEditingId(null);
      setSelectedRole(null);
      toast.success("Role updated");
    },
    onError: (error) => toast.error(`Failed to update role: ${error.message}`),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.OrgMember.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["org-members", activeOrgId] });
      toast.success("User removed");
    },
  });

  const resendInviteMutation = useMutation({
    mutationFn: async (member) => {
      // Ensure user is registered before emailing
      try {
        await base44.users.inviteUser(member.user_email, 'user');
      } catch (e) {
        // May already exist — that's fine
      }
      const res = await base44.functions.invoke('generateSetupToken', {
        userEmail: member.user_email,
        orgId: activeOrgId,
        orgName: activeOrg?.name || '',
        userRole: 'user',
        type: 'member_invite',
        appUrl: window.location.hostname.includes('base44.app')
          ? 'https://app.screenfleet.io'
          : window.location.origin,
      });
      return res.data;
    },
    onSuccess: (tokenResult) => {
      toast.success("Invite resent — platform invite dispatched. Copy the setup link as a backup.");
      setSetupLinkData({ email: tokenResult.user_email, setupUrl: tokenResult.setupUrl, emailStatus: tokenResult.emailStatus });
    },
    onError: (error) => toast.error(`Failed to resend: ${error.message}`),
  });

  const permissionOverrideMutation = useMutation({
    mutationFn: ({ id, perms }) => base44.entities.OrgMember.update(id, { permissions: perms }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["org-members", activeOrgId] });
      setPermissionsModalMember(null);
    },
    onError: (error) => toast.error(`Failed to save permissions: ${error.message}`),
  });

  const viewAsUserMutation = useMutation({
    mutationFn: async (memberId) => {
      const result = await base44.functions.invoke('impersonateUser', {
        memberId: memberId,
      });
      return result.data.impersonationUrl;
    },
    onSuccess: (url) => {
      window.open(url, '_blank');
    },
    onError: (error) => toast.error(error.message),
  });

  // Safety: count owners to prevent removing last one
  const ownerCount = useMemo(() => members.filter((m) => m.org_role === "owner").length, [members]);
  const isCurrentUserOwner = currentMember?.org_role === "owner";

  if (!canDo('manage_members')) return <AccessDenied reason="permission" />;

  const filtered = members.filter((m) =>
    m.user_email.toLowerCase().includes(search.toLowerCase())
  );

  const suspendedCount = members.filter((m) => m.status === "suspended").length;
  const invitedCount = members.filter((m) => m.status === "invited").length;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Team Members</h2>
          <p className="text-sm text-slate-500 mt-0.5">Create, edit, and manage users within {activeOrg?.name}</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
          <Plus className="w-4 h-4" /> Invite User
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <p className="text-xs text-slate-500 uppercase tracking-widest mb-1">Total Members</p>
          <p className="text-2xl font-bold text-slate-800">{members.length}</p>
          <p className="text-xs text-slate-400 mt-1">{members.filter(m => m.status === "active").length} active</p>
        </div>
        {invitedCount > 0 && (
          <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
            <p className="text-xs text-blue-600 uppercase tracking-widest font-medium mb-1">Pending Invites</p>
            <p className="text-2xl font-bold text-blue-700">{invitedCount}</p>
          </div>
        )}
        {suspendedCount > 0 && (
          <div className="bg-amber-50 rounded-lg border border-amber-200 p-4">
            <p className="text-xs text-amber-600 uppercase tracking-widest font-medium mb-1">Suspended</p>
            <p className="text-2xl font-bold text-amber-700">{suspendedCount}</p>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-100 flex items-center gap-3">
          <Search className="w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search users…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-8 border-0 p-0 focus-visible:ring-0 text-sm flex-1"
          />
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead className="w-32" />
            </TableRow>
          </TableHeader>
          <TableBody>
           {filtered.map((member) => {
             const isOwner = member.org_role === "owner";
             const isLastOwner = isOwner && ownerCount === 1;
             const isCurrentUser = user?.email === member.user_email;
             const isOrgAdmin = currentMember && ORG_ADMIN_ROLES.includes(currentMember.org_role);
             const isPlatformAdmin = user?.role === "admin";

             // Org admins cannot edit other admins or the last owner
             const canEditRole = !isCurrentUser && !isLastOwner && (
               isPlatformAdmin || !isOrgAdmin || (isOrgAdmin && !ORG_ADMIN_ROLES.includes(member.org_role))
             );
             const isEditingRole = roleEditingId === member.id;

             // Determine why action is disabled
             const getDisabledReason = () => {
               if (isCurrentUser) return "You can't edit your own role";
               if (isLastOwner) return "Last owner cannot be removed";
               if (isOrgAdmin && ORG_ADMIN_ROLES.includes(member.org_role)) return "Org admins cannot manage other admins";
               return null;
             };

             return (
             <TableRow key={member.id}>
               <TableCell className="font-medium text-sm">{member.user_email}</TableCell>
               <TableCell>
                 {isEditingRole ? (
                   <Select value={selectedRole || member.org_role} onValueChange={setSelectedRole}>
                     <SelectTrigger className="h-7 w-40">
                       <SelectValue />
                     </SelectTrigger>
                     <SelectContent>
                       {ORG_ROLES.filter((r) => 
                         !(r.value === "owner" && ownerCount === 1)
                       ).map((role) => (
                         <SelectItem key={role.value} value={role.value}>
                           {role.label}
                         </SelectItem>
                       ))}
                     </SelectContent>
                   </Select>
                 ) : (
                   <div
                     className={`inline-block px-2 py-1 rounded text-[10px] font-medium ${ROLE_COLORS[member.org_role] || "bg-slate-100"} ${canEditRole ? 'cursor-pointer hover:opacity-75' : 'cursor-not-allowed opacity-60'}`}
                     onClick={() => canEditRole && setRoleEditingId(member.id)}
                     title={getDisabledReason() || "Click to change role"}
                   >
                     {isLastOwner && <span className="inline-block mr-1">🔒</span>}
                     {ORG_ROLES.find((r) => r.value === member.org_role)?.label || member.org_role}
                   </div>
                 )}
                 {isEditingRole && (
                   <div className="flex gap-1 mt-2">
                     <Button
                       size="sm"
                       variant="outline"
                       className="h-6 text-xs px-2"
                       onClick={() => {
                         if (selectedRole && selectedRole !== member.org_role) {
                           roleChangeMutation.mutate({ id: member.id, newRole: selectedRole });
                         } else {
                           setRoleEditingId(null);
                           setSelectedRole(null);
                         }
                       }}
                       disabled={roleChangeMutation.isPending}
                     >
                       {roleChangeMutation.isPending ? "Saving..." : "Save"}
                     </Button>
                     <Button
                       size="sm"
                       variant="ghost"
                       className="h-6 text-xs px-2"
                       onClick={() => {
                         setRoleEditingId(null);
                         setSelectedRole(null);
                       }}
                     >
                       Cancel
                     </Button>
                   </div>
                 )}
               </TableCell>
                <TableCell>
                  <Badge className={`text-[10px] ${
                    member.status === "active" ? "bg-green-100 text-green-700" :
                    member.status === "invited" ? "bg-blue-100 text-blue-700" :
                    "bg-amber-100 text-amber-700"
                  }`}>
                    {member.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-xs text-slate-500">
                  {member.joined_at ? new Date(member.joined_at).toLocaleDateString() : "—"}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    {member.status === "invited" && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => resendInviteMutation.mutate(member)}
                        title="Resend setup link"
                        disabled={resendInviteMutation.isPending}
                      >
                        <Mail className="w-3.5 h-3.5 text-blue-400" />
                      </Button>
                    )}
                    {member.status === "active" && (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => viewAsUserMutation.mutate(member.id)}
                          title={isPlatformAdmin ? "View as user (platform admin only)" : "View as user"}
                          disabled={!isPlatformAdmin}
                        >
                          <Eye className={`w-3.5 h-3.5 ${isPlatformAdmin ? "text-slate-400" : "text-slate-200"}`} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => resendInviteMutation.mutate(member)}
                          title="Resend setup link"
                          disabled={resendInviteMutation.isPending}
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                        </Button>
                      </>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => setPermissionsModalMember(member)}
                      title={canEditRole ? "Advanced permissions" : "Cannot manage this user"}
                      disabled={!canEditRole}
                    >
                      <Shield className={`w-3.5 h-3.5 ${canEditRole ? "text-slate-400" : "text-slate-200"}`} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => setEditingMember(member)}
                      title="Edit"
                    >
                      <Pencil className="w-3.5 h-3.5 text-slate-400" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => {
                       if (confirm(`Remove ${member.user_email} from the organization?`)) {
                         deleteMutation.mutate(member.id);
                       }
                      }}
                      title={isLastOwner ? "Last owner cannot be removed" : "Remove"}
                      disabled={isLastOwner || !canEditRole}
                    >
                      <Trash2 className={`w-3.5 h-3.5 ${isLastOwner || !canEditRole ? "text-slate-200" : "text-slate-400 hover:text-red-500"}`} />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
            })}
          </TableBody>
        </Table>

        {filtered.length === 0 && (
          <div className="py-12 text-center text-slate-400">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No users found</p>
          </div>
        )}
      </div>

      {/* Setup Link Fallback Dialog */}
      <Dialog open={!!setupLinkData} onOpenChange={() => setSetupLinkData(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" /> User Invited
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
              <p className="font-medium mb-1">Platform invite sent to <strong>{setupLinkData?.email}</strong></p>
              <p className="text-xs text-blue-600 mt-1">They will receive a login email from the platform. If it doesn't arrive, share the setup link below directly.</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 mb-1.5 font-medium">Setup link for {setupLinkData?.email}</p>
              <div className="flex gap-2">
                <input
                  readOnly
                  value={setupLinkData?.setupUrl || ''}
                  className="flex-1 text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1.5 font-mono"
                />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copySetupLink(setupLinkData?.setupUrl)}
                  className="gap-1.5"
                >
                  {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied' : 'Copy'}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => window.open(setupLinkData?.setupUrl, '_blank')}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
            <p className="text-xs text-slate-400">This link expires in 48 hours.</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialogs */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Invite Team Member</DialogTitle>
          </DialogHeader>
          <UserForm
            org={activeOrg}
            onSave={(data) => createMutation.mutate(data)}
            onClose={() => setShowForm(false)}
            isSaving={createMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingMember} onOpenChange={() => setEditingMember(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
          </DialogHeader>
          {editingMember && (
            <UserForm
              member={editingMember}
              org={activeOrg}
              onSave={(data) => updateMutation.mutate({ id: editingMember.id, data })}
              onClose={() => setEditingMember(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      <PermissionOverridesModal
        open={!!permissionsModalMember}
        member={permissionsModalMember}
        orgModules={activeOrg?.plan_modules_resolved || []}
        isPlatformAdmin={user?.role === "admin"}
        onSave={(perms) => permissionOverrideMutation.mutate({ id: permissionsModalMember.id, perms })}
        onOpenChange={() => setPermissionsModalMember(null)}
      />
    </div>
  );
}