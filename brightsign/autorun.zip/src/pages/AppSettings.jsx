import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import ProfileEditor from "../components/settings/ProfileEditor";
import OrgMemberList from "../components/organizations/OrgMemberList";
import OrgOOHPackageEditor from "../components/organizations/OrgOOHPackageEditor";
import { Building2, Shield, Radio } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AppSettings() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  const loadUser = () => base44.auth.me().then(setUser).catch(() => {});

  useEffect(() => { loadUser(); }, []);

  // Load the user's org if they belong to one
  const { data: org } = useQuery({
    queryKey: ["my-org", user?.org_id],
    queryFn: () => base44.entities.Organization.filter({ id: user.org_id }).then((r) => r[0]),
    enabled: !!user?.org_id,
  });

  // Load the current user's OrgMember record so we know their org_role / permissions
  const { data: myMembership } = useQuery({
    queryKey: ["my-membership", user?.email, user?.org_id],
    queryFn: () => base44.entities.OrgMember.filter({ org_id: user.org_id, user_email: user.email }).then((r) => r[0]),
    enabled: !!user?.org_id && !!user?.email,
  });

  const canManageMembers = !user?.org_id
    ? user?.role === "admin"  // platform admin
    : (myMembership?.permissions || []).includes("manage_members") || myMembership?.org_role === "owner" || myMembership?.org_role === "admin";

  return (
    <div className="p-6 lg:p-8 max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Settings</h2>
        <p className="text-sm text-slate-500 mt-0.5">Manage your profile and team.</p>
      </div>

      {/* Org context banner for sub-account users */}
      {org && (
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 border border-indigo-200">
          <Building2 className="w-4 h-4 text-indigo-500 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-medium text-indigo-900">{org.name}</p>
            <p className="text-xs text-indigo-600">{org.plan_slug} plan · {org.max_trucks} truck{org.max_trucks !== 1 ? "s" : ""} · {org.max_users} user{org.max_users !== 1 ? "s" : ""}</p>
          </div>
          {myMembership && (
            <Badge className="bg-indigo-100 text-indigo-700 border-indigo-200 capitalize text-xs">{myMembership.org_role}</Badge>
          )}
        </div>
      )}

      <ProfileEditor user={user} onUpdate={loadUser} />

      {canManageMembers && user?.org_id && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <OrgMemberList orgId={user.org_id} />
        </div>
      )}

      {/* OOH Package settings — visible to org owners/admins */}
      {org && (myMembership?.org_role === 'owner' || myMembership?.org_role === 'admin') && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-5">
            <Radio className="w-4 h-4 text-purple-600" />
            <h3 className="text-base font-semibold text-slate-900">OOH Operator Tools</h3>
            <span className="text-xs text-slate-400 ml-auto">Package + feature access controls</span>
          </div>
          <OrgOOHPackageEditor org={org} />
        </div>
      )}

      {/* Platform-level admin: no org, sees all settings */}
      {!user?.org_id && user?.role === "admin" && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-500" />
          <p className="text-sm text-amber-800">You are a platform admin. Manage organizations from the <strong>Organizations</strong> page.</p>
        </div>
      )}
    </div>
  );
}