/**
 * V2 Dashboard
 * Data sources: Asset, Screen, PublishedScreen, MediaAsset, Playlist, ScreenControl
 * NO V1 Truck entity references.
 */

import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { useOrg } from "@/components/OrgContext";
import {
  Monitor, Image, Layers, ListVideo, CalendarClock,
  SlidersHorizontal, LayoutGrid, RefreshCw, ArrowRight,
  CheckCircle2, XCircle, Sun, Zap, Repeat2, AlertCircle, Clock
} from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import LivePreviewGrid from "@/components/dashboard/LivePreviewGrid";

const QuickAction = ({ title, description, icon: Icon, page }) => (
  <Link
    to={createPageUrl(page)}
    className="flex items-center justify-between bg-white border border-slate-200 rounded-xl p-5 hover:border-blue-400 hover:shadow-md transition-all group"
  >
    <div className="flex-1 min-w-0 pr-4">
      <p className="text-xs text-slate-500 mb-1">{description}</p>
      <p className="text-base font-bold text-slate-800 flex items-center gap-1.5 group-hover:text-blue-700 transition-colors">
        {title}
        <ArrowRight className="w-4 h-4 opacity-60 group-hover:translate-x-0.5 transition-transform" />
      </p>
    </div>
    <div className="w-14 h-14 flex-shrink-0 flex items-center justify-center rounded-xl bg-blue-50 group-hover:bg-blue-100 transition-colors">
      <Icon className="w-7 h-7 text-blue-600" />
    </div>
  </Link>
);

export default function Dashboard() {
  const { activeOrgId, isPlatformAdmin } = useOrg();

  // V2: Assets — only use .list() in true platform-admin mode (no specific org selected)
  // When a platform admin switches into a specific org, scope to that org
  const { data: assets = [] } = useQuery({
    queryKey: ["assets", activeOrgId],
    queryFn: () => (isPlatformAdmin && activeOrgId === "PLATFORM_ADMIN")
      ? base44.entities.Asset.list()
      : base44.entities.Asset.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId && activeOrgId !== "PLATFORM_ADMIN",
  });

  // V2: Screens linked to assets (asset_id-scoped only)
  const { data: screens = [] } = useQuery({
    queryKey: ["v2screens", activeOrgId],
    queryFn: async () => {
      if (!assets.length) return [];
      const all = await Promise.all(assets.map(a => base44.entities.Screen.filter({ asset_id: a.id })));
      return all.flat();
    },
    enabled: assets.length > 0,
    refetchInterval: 30000,
  });

  const { data: appConfig = null } = useQuery({
    queryKey: ["app_config"],
    queryFn: async () => {
      const configs = await base44.entities.AppConfig.list();
      return configs[0] || null;
    },
  });

  const { data: playerStatuses = [] } = useQuery({
    queryKey: ["playerStatuses", screens.map(s => s.id).join(",")],
    queryFn: async () => {
      if (!screens.length) return [];
      try {
        const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, "") || "https://player.screenfleet.io";
        const res = await fetch(`${playerOrigin}/functions/getCmsScreenStatuses`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ cms_screen_ids: screens.map(s => s.id) }),
        });
        if (!res.ok) return [];
        const data = await res.json();
        return Array.isArray(data) ? data : [];
      } catch (err) {
        console.warn("[Dashboard] getCmsScreenStatuses fetch failed:", err.message);
        return [];
      }
    },
    enabled: screens.length > 0,
    refetchInterval: 30000,
  });

  // Returns 'online' | 'warning' | 'offline' | 'never'
  const getHeartbeatStatus = (screenId) => {
    const ps = playerStatuses.find(p => p.cms_screen_id === screenId);
    if (!ps?.last_ping) return 'never';
    const age = Date.now() - new Date(ps.last_ping).getTime();
    if (age <= 90000)  return 'online';
    if (age <= 300000) return 'warning';
    return 'offline';
  };

  const getLastSeen = (screenId) => {
    const ps = playerStatuses.find(p => p.cms_screen_id === screenId);
    if (!ps?.last_ping) return null;
    const age = Date.now() - new Date(ps.last_ping).getTime();
    if (age < 60000)   return `${Math.round(age / 1000)}s ago`;
    if (age < 3600000) return `${Math.round(age / 60000)}m ago`;
    return new Date(ps.last_ping).toLocaleTimeString();
  };

  const isOnline = (screenId) => getHeartbeatStatus(screenId) === 'online';

  // V2: Published screens
  const { data: publishedScreens = [] } = useQuery({
    queryKey: ["publishedScreens", activeOrgId],
    queryFn: async () => {
      if (!screens.length) return [];
      const all = await Promise.all(screens.map(s => base44.entities.PublishedScreen.filter({ screen_id: s.id })));
      return all.flat();
    },
    enabled: screens.length > 0,
    refetchInterval: 30000,
  });

  const { data: media = [] } = useQuery({
    queryKey: ["media", activeOrgId],
    queryFn: () => activeOrgId ? base44.entities.MediaAsset.filter({ org_id: activeOrgId }) : Promise.resolve([]),
    enabled: !!activeOrgId,
  });

  const { data: playlists = [] } = useQuery({
    queryKey: ["playlists", activeOrgId],
    queryFn: () => base44.entities.Playlist.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId && activeOrgId !== "PLATFORM_ADMIN",
  });

  const { data: allControls = [] } = useQuery({
    queryKey: ["screenControls", activeOrgId],
    queryFn: async () => {
      if (!screens.length) return [];
      const results = await Promise.all(screens.map(s => base44.entities.ScreenControl.filter({ screen_id: s.id })));
      return results.flat();
    },
    enabled: screens.length > 0,
  });

  const queryClient = useQueryClient();
  const updateControlMutation = useMutation({
    mutationFn: async ({ screenId, data }) => {
      const existing = allControls.find(c => c.screen_id === screenId);
      if (existing) return base44.entities.ScreenControl.update(existing.id, data);
      return base44.entities.ScreenControl.create({ screen_id: screenId, ...data });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["screenControls"] }),
  });

  const getControl = (screenId) => allControls.find(c => c.screen_id === screenId);

  const onlineScreens  = screens.filter(s => getHeartbeatStatus(s.id) === 'online');
  const warningScreens = screens.filter(s => getHeartbeatStatus(s.id) === 'warning');
  const offlineScreens = screens.filter(s => getHeartbeatStatus(s.id) === 'offline');
  const neverScreens   = screens.filter(s => getHeartbeatStatus(s.id) === 'never');

  // Published count
  const publishedCount = publishedScreens.filter(p => !p.is_stale).length;

  if (isPlatformAdmin && activeOrgId === 'PLATFORM_ADMIN') {
    return (
      <div className="p-8 text-center text-slate-500">
        <p className="mb-3">Select an organization to view its dashboard.</p>
        <a href="/Organizations" className="text-blue-600 underline text-sm">Go to Organizations</a>
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-6 lg:p-8 max-w-6xl mx-auto space-y-4 sm:space-y-6 bg-slate-50 min-h-full">

      {/* 1. Network Status */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
        <h2 className="text-sm font-semibold text-slate-700 mb-3">Network Status</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className={`flex items-center gap-2.5 rounded-lg px-4 py-3 border ${onlineScreens.length > 0 ? "bg-green-50 border-green-200" : "bg-slate-50 border-slate-200"}`}>
            <CheckCircle2 className={`w-5 h-5 flex-shrink-0 ${onlineScreens.length > 0 ? "text-green-600" : "text-slate-300"}`} />
            <div>
              <div className="text-base font-bold text-slate-800">{onlineScreens.length}</div>
              <div className="text-[10px] text-slate-500">Online</div>
            </div>
          </div>
          <div className={`flex items-center gap-2.5 rounded-lg px-4 py-3 border ${warningScreens.length > 0 ? "bg-amber-50 border-amber-200" : "bg-slate-50 border-slate-200"}`}>
            <AlertCircle className={`w-5 h-5 flex-shrink-0 ${warningScreens.length > 0 ? "text-amber-500" : "text-slate-300"}`} />
            <div>
              <div className="text-base font-bold text-slate-800">{warningScreens.length}</div>
              <div className="text-[10px] text-slate-500">Warning</div>
            </div>
          </div>
          <div className={`flex items-center gap-2.5 rounded-lg px-4 py-3 border ${offlineScreens.length > 0 ? "bg-red-50 border-red-200" : "bg-slate-50 border-slate-200"}`}>
            <XCircle className={`w-5 h-5 flex-shrink-0 ${offlineScreens.length > 0 ? "text-red-500" : "text-slate-300"}`} />
            <div>
              <div className="text-base font-bold text-slate-800">{offlineScreens.length}</div>
              <div className="text-[10px] text-slate-500">Offline</div>
            </div>
          </div>
          <div className={`flex items-center gap-2.5 rounded-lg px-4 py-3 border ${neverScreens.length > 0 ? "bg-slate-100 border-slate-300" : "bg-slate-50 border-slate-200"}`}>
            <Clock className={`w-5 h-5 flex-shrink-0 ${neverScreens.length > 0 ? "text-slate-500" : "text-slate-300"}`} />
            <div>
              <div className="text-base font-bold text-slate-800">{neverScreens.length}</div>
              <div className="text-[10px] text-slate-500">Never connected</div>
            </div>
          </div>
        </div>
        {screens.length > 0 && (
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {screens.map(screen => {
              const status = getHeartbeatStatus(screen.id);
              const lastSeen = getLastSeen(screen.id);
              const statusConfig = {
                online:  { dot: "bg-green-500",  label: "Online",          text: "text-green-700" },
                warning: { dot: "bg-amber-400",  label: "Warning",         text: "text-amber-700" },
                offline: { dot: "bg-red-500",    label: "Offline",         text: "text-red-600"   },
                never:   { dot: "bg-slate-400",  label: "Never connected", text: "text-slate-500" },
              }[status];
              return (
                <div key={screen.id} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${statusConfig.dot}`} />
                    <span className="text-xs font-medium text-slate-700 truncate">{screen.name}</span>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                    <span className={`text-[10px] font-semibold ${statusConfig.text}`}>{statusConfig.label}</span>
                    {lastSeen && <span className="text-[10px] text-slate-400">{lastSeen}</span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 2. Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <QuickAction title="Manage Assets" description="Configure your V2 asset fleet" icon={Layers} page="Assets" />
        <QuickAction title="Media Library" description="Manage your presentation assets" icon={Image} page="MediaLibrary" />
        <QuickAction title="Layout Templates" description="Design multi-zone screen layouts" icon={LayoutGrid} page="LayoutTemplates" />
        <QuickAction title="Playlists" description="Build and edit content playlists" icon={ListVideo} page="Playlists" />
        <QuickAction title="Route Presentations" description="Configure ad rotation cycles" icon={RefreshCw} page="Rotations" />
        <QuickAction title="Scheduling" description="Schedule content by time and day" icon={CalendarClock} page="Scheduling" />
        <QuickAction title="Screen Controls" description="Brightness, audio and power" icon={SlidersHorizontal} page="Controls" />
        <QuickAction title="Live Output" description="View live V2 screen output" icon={Monitor} page="LiveOutput" />
      </div>

      {/* 3. Live Previews */}
      <LivePreviewGrid />

      {/* 4. Screen Controls */}
      {screens.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Sun className="w-4 h-4 text-amber-500" /> Screen Controls
            </h2>
            <Link to={createPageUrl("Controls")} className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1">
              Full controls <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {screens.map(screen => {
              const ctrl = getControl(screen.id);
              const brightness = ctrl?.brightness ?? 100;
              const auto = ctrl?.auto_brightness ?? false;
              const asset = assets.find(a => a.id === screen.asset_id);
              return (
                <div key={screen.id} className="bg-slate-50 rounded-lg p-3 space-y-3">
                  <div className="flex flex-col gap-1.5">
                    <div className="text-[10px] text-slate-500 font-medium">{asset?.name || "Unknown Asset"}</div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700 truncate">{screen.name}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${isOnline(screen.id) ? "bg-green-100 text-green-700" : "bg-slate-200 text-slate-500"}`}>
                        {isOnline(screen.id) ? "online" : "offline"}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-slate-500">Brightness</span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] font-medium text-slate-700">{auto ? "Auto" : `${brightness}%`}</span>
                        <div className="flex items-center gap-1" title="Auto brightness">
                          <Switch
                            checked={auto}
                            onCheckedChange={v => updateControlMutation.mutate({ screenId: screen.id, data: { auto_brightness: v } })}
                            className="scale-75"
                          />
                          <Zap className={`w-3 h-3 ${auto ? "text-amber-500" : "text-slate-300"}`} />
                        </div>
                      </div>
                    </div>
                    <Slider
                      value={[brightness]}
                      onValueChange={([v]) => updateControlMutation.mutate({ screenId: screen.id, data: { brightness: v } })}
                      min={0} max={100} step={5}
                      disabled={auto}
                      className={auto ? "opacity-40" : ""}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. Fleet Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <h2 className="text-sm font-semibold text-slate-700 mb-1">Fleet Status</h2>
          <p className="text-xs text-slate-400 mb-4">Overview of your V2 assets</p>
          <div className="space-y-2 mb-4">
            {assets.slice(0, 5).map(asset => {
              const assetScreens = screens.filter(s => s.asset_id === asset.id);
              return (
                <div key={asset.id} className="flex items-center gap-2.5 py-2 border-b border-slate-100 last:border-0">
                  <Layers className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span className="flex-1 text-sm text-slate-700 truncate">{asset.name}</span>
                  <span className="text-xs text-slate-400">{assetScreens.length} screens</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${asset.status === "active" ? "bg-green-100 text-green-700" : asset.status === "maintenance" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-500"}`}>
                    {asset.status}
                  </span>
                </div>
              );
            })}
            {assets.length === 0 && (
              <p className="text-xs text-slate-400 py-4 text-center">No assets configured</p>
            )}
          </div>
          <Link to="/Assets" className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1">
            Manage Assets <ArrowRight className="w-3.5 h-3.5" />
          </Link>
          <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 gap-3">
            {[
              { label: "Assets",    value: assets.length,       sub: `${assets.filter(a => a.status === "active").length} active` },
              { label: "Screens",   value: screens.length,      sub: `${onlineScreens.length} online` },
              { label: "Published", value: publishedCount,      sub: "screens live" },
              { label: "Media",     value: media.length,        sub: "assets" },
            ].map(({ label, value, sub }) => (
              <div key={label} className="bg-slate-50 rounded-lg p-3">
                <div className="text-xl font-bold text-slate-800">{value}</div>
                <div className="text-xs font-medium text-slate-600">{label}</div>
                <div className="text-[10px] text-slate-400">{sub}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}