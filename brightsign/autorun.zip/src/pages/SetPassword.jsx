import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { CheckCircle2, AlertCircle, Clock, Loader2, Mail, Shield } from "lucide-react";

export default function SetPassword() {
  const params = new URLSearchParams(window.location.search);
  const token = params.get("token");

  const [status, setStatus] = useState("validating");
  const [tokenData, setTokenData] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [errorCode, setErrorCode] = useState("");

  useEffect(() => {
    if (!token) {
      setStatus("error");
      setErrorCode("INVALID_TOKEN");
      setErrorMsg("No setup token found in this link. Please use the link from your invitation email.");
      return;
    }
    validateToken();
  }, []);

  const validateToken = async () => {
    setStatus("validating");
    try {
      const res = await base44.functions.invoke("validateSetupToken", { token });
      const data = res.data;
      if (data.valid) {
        setTokenData(data);
        setStatus("valid");
      } else {
        setErrorCode(data.code || "INVALID_TOKEN");
        setErrorMsg(data.error || "This link is not valid.");
        setStatus("error");
      }
    } catch (err) {
      setErrorCode("INVALID_TOKEN");
      setErrorMsg("Unable to validate this link. Please try again or contact support.");
      setStatus("error");
    }
  };

  const handleActivate = async () => {
    setStatus("submitting");
    try {
      // Step 1: Register the user in the platform (frontend-only SDK method)
      try {
        await base44.users.inviteUser(tokenData.user_email, 'user');
      } catch (e) {
        // Already registered — that's fine
      }
      // Step 2: Mark the setup token as redeemed
      const res = await base44.functions.invoke("redeemSetupToken", { token });
      const data = res.data;
      if (data.success) {
        setTokenData(prev => ({ ...prev, ...data }));
        setStatus("success");
      } else {
        setErrorCode(data.code || "ERROR");
        setErrorMsg(data.error || "Failed to activate account.");
        setStatus("error");
      }
    } catch (err) {
      setErrorCode("ERROR");
      setErrorMsg(err?.message || "Something went wrong. Please try again.");
      setStatus("error");
    }
  };

  const loginUrl = `${window.location.origin}/login`;

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl overflow-hidden mx-auto mb-4">
            <img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699e82a2479ad26532b0b448/19f40cc91_ScreenFleetIcon.png"
              alt="ScreenFleet"
              className="w-full h-full object-cover"
            />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">ScreenFleet</h1>
          <p className="text-sm text-slate-500 mt-1">Account Setup</p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
          {status === "validating" && (
            <div className="text-center py-6">
              <Loader2 className="w-10 h-10 text-blue-500 mx-auto mb-4 animate-spin" />
              <p className="text-slate-700 font-medium">Validating your invitation link...</p>
              <p className="text-sm text-slate-400 mt-1">Just a moment</p>
            </div>
          )}

          {(status === "valid" || status === "submitting") && tokenData && (
            <div className="text-center">
              <div className="w-14 h-14 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-5">
                <Mail className="w-7 h-7 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-1">Welcome to ScreenFleet!</h2>
              {tokenData.org_name && (
                <p className="text-sm text-slate-500 mb-4">
                  You have been invited to <strong className="text-slate-700">{tokenData.org_name}</strong>
                </p>
              )}
              <p className="text-sm text-slate-600 mb-6 leading-relaxed">
                Click below to activate <strong>{tokenData.user_email}</strong>. You'll receive a one-time sign-in link by email — click it to access ScreenFleet.
              </p>
              <Button
                onClick={handleActivate}
                disabled={status === "submitting"}
                className="w-full bg-blue-600 hover:bg-blue-700 h-11 text-sm font-semibold"
              >
                {status === "submitting" ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" /> Activating...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <Shield className="w-4 h-4" /> Activate My Account
                  </span>
                )}
              </Button>
            </div>
          )}

          {status === "success" && (
            <div className="text-center">
              <div className="w-14 h-14 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-5">
                <CheckCircle2 className="w-8 h-8 text-green-500" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">Account Activated!</h2>
              <p className="text-sm text-slate-600 mb-5 leading-relaxed">
                Your account for <strong>{tokenData?.user_email}</strong> is ready.
              </p>
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-left text-sm text-amber-800 mb-5">
                <p className="font-semibold mb-2">⚠️ You don't have a password yet — here's how to sign in:</p>
                <ol className="list-decimal ml-4 space-y-1.5 text-amber-700">
                  <li>Click <strong>"Go to Sign In"</strong> below</li>
                  <li>Click <strong>"Forgot Password"</strong> on the login page</li>
                  <li>Enter your email: <strong>{tokenData?.user_email}</strong></li>
                  <li>Check your inbox for a password reset link</li>
                  <li>Set your password and you're in!</li>
                </ol>
              </div>
              <Button
                onClick={() => window.location.href = loginUrl}
                className="w-full bg-blue-600 hover:bg-blue-700 h-11 text-sm font-semibold"
              >
                Go to Sign In →
              </Button>
            </div>
          )}

          {status === "error" && (
            <div className="text-center">
              <div className={`w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-5 ${errorCode === "TOKEN_EXPIRED" ? "bg-amber-50" : "bg-red-50"}`}>
                {errorCode === "TOKEN_EXPIRED"
                  ? <Clock className="w-7 h-7 text-amber-500" />
                  : <AlertCircle className="w-7 h-7 text-red-500" />
                }
              </div>
              <h2 className="text-lg font-bold text-slate-900 mb-2">
                {errorCode === "TOKEN_EXPIRED" && "Link Expired"}
                {errorCode === "TOKEN_USED" && "Link Already Used"}
                {errorCode === "INVALID_TOKEN" && "Invalid Link"}
                {!["TOKEN_EXPIRED", "TOKEN_USED", "INVALID_TOKEN"].includes(errorCode) && "Something Went Wrong"}
              </h2>
              <p className="text-sm text-slate-500 leading-relaxed">{errorMsg}</p>
              <p className="text-xs text-slate-400 mt-4">
                Need help? Contact your ScreenFleet administrator.
              </p>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-slate-400 mt-6">
          ScreenFleet - LED Truck Management Platform
        </p>
      </div>
    </div>
  );
}