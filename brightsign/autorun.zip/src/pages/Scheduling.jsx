import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Layers, CalendarDays, Send, CheckCircle2, HardDrive, Loader2 } from "lucide-react";
import { toast } from "sonner";
import WeekCalendar from "@/components/scheduling/WeekCalendar";
import ScheduleEditPanel from "@/components/scheduling/ScheduleEditPanel";
import RecentPresentations from "@/components/scheduling/RecentPresentations";

export default function Scheduling() {
  const queryClient = useQueryClient();
  const { activeOrgId } = useOrg();
  const validOrgId = activeOrgId && activeOrgId !== "PLATFORM_ADMIN" ? activeOrgId : null;
  const { canAccessModule } = useAuthority();
  const [selectedAssetId, setSelectedAssetId] = useState(null);
  const [weekStart, setWeekStart] = useState(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [selectedScheduleId, setSelectedScheduleId] = useState(null);
  const [use24h, setUse24h] = useState(true);
  const [publishedAt, setPublishedAt] = useState(null);
  const [downloadingBackup, setDownloadingBackup] = useState(false);
  const [showPlaylists, setShowPlaylists] = useState(false);

  const { data: assets = [] } = useQuery({
    queryKey: ["assets", validOrgId],
    queryFn: () => base44.entities.Asset.filter({ org_id: validOrgId }),
    enabled: !!validOrgId,
  });
  const { data: playlists = [] } = useQuery({
    queryKey: ["playlists", validOrgId],
    queryFn: () => base44.entities.Playlist.filter({ org_id: validOrgId }),
    enabled: !!validOrgId,
  });
  const { data: routePresentations = [] } = useQuery({
    queryKey: ["routePresentations", validOrgId],
    queryFn: () => base44.entities.RoutePresentation.filter({ org_id: validOrgId }),
    enabled: !!validOrgId,
  });
  const { data: sequences = [] } = useQuery({
    queryKey: ["sequences", validOrgId],
    queryFn: () => base44.entities.Sequence.filter({ org_id: validOrgId }),
    enabled: !!validOrgId,
  });
  const { data: schedules = [] } = useQuery({
    queryKey: ["schedules", selectedAssetId],
    queryFn: () => base44.entities.Schedule.filter({ truck_id: selectedAssetId }),
    enabled: !!selectedAssetId,
  });

  const createMutation = useMutation({
    mutationFn: ({ content_type, id, name } = {}) => base44.entities.Schedule.create({
      truck_id: selectedAssetId,
      name: name || "New Schedule",
      content_type: content_type || "playlist",
      playlist_id: content_type === "playlist" ? id : undefined,
      rotation_id: content_type === "rotation" ? id : undefined,
      sequence_id: content_type === "sequence" ? id : undefined,
      days_of_week: [0, 1, 2, 3, 4, 5, 6],
      start_time: "08:00",
      end_time: "20:00",
      is_active: true,
      priority: 1,
      play_all_day: false,
      interrupt_others: false,
    }),
    onSuccess: (newSchedule) => {
      queryClient.invalidateQueries({ queryKey: ["schedules"] });
      setSelectedScheduleId(newSchedule.id);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Schedule.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["schedules"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Schedule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["schedules"] });
      setSelectedScheduleId(null);
    },
  });

  const publishMutation = useMutation({
    mutationFn: () => base44.functions.invoke('publishAsset', { asset_id: selectedAssetId }),
    onSuccess: (res) => {
      queryClient.invalidateQueries({ queryKey: ["schedules"] });
      queryClient.invalidateQueries({ queryKey: ["publishedScreens"] });
      queryClient.invalidateQueries({ queryKey: ["publishedScreens", activeOrgId] });
      queryClient.invalidateQueries({ queryKey: ["liveOutputDashboard"] });
      queryClient.invalidateQueries({ queryKey: ["liveOutputDashboard", activeOrgId] });
      const now = res.data?.content_version || new Date().toISOString();
      setPublishedAt(now);
      setTimeout(() => setPublishedAt(null), 4000);
      toast.success(`Published ${res.data?.results?.length ?? 0} screen(s)!`);
    },
    onError: (e) => toast.error('Publish failed: ' + e.message),
  });

  const handleDownloadBackup = async () => {
    if (!selectedAssetId) return;
    setDownloadingBackup(true);
    try {
      const response = await base44.functions.invoke("generateOfflineBackup", { truckId: selectedAssetId });
      const { base64, filename } = response.data;
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Offline backup downloaded!");
    } catch (e) {
      toast.error("Failed to generate backup: " + e.message);
    } finally {
      setDownloadingBackup(false);
    }
  };

  const goToToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); setWeekStart(d); };
  const prevWeek = () => { const d = new Date(weekStart); d.setDate(d.getDate() - 7); setWeekStart(d); };
  const nextWeek = () => { const d = new Date(weekStart); d.setDate(d.getDate() + 7); setWeekStart(d); };

  const now = new Date();
  const currentDay = now.getDay();
  const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const activeNow = schedules
    .filter((s) => {
      if (!s.is_active) return false;
      if (s.play_all_day) return true;
      return (s.days_of_week || []).includes(currentDay) && s.start_time <= currentTime && s.end_time >= currentTime;
    })
    .sort((a, b) => {
      if (b.interrupt_others !== a.interrupt_others) return b.interrupt_others ? 1 : -1;
      return (b.priority || 1) - (a.priority || 1);
    })[0];

  const getScheduleDisplayName = (s) => {
    if (!s) return "";
    if (s.content_type === "playlist") return playlists.find((p) => p.id === s.playlist_id)?.name || s.name;
    if (s.content_type === "rotation") return routePresentations.find((r) => r.id === s.rotation_id)?.name || s.name;
    if (s.content_type === "sequence") return sequences.find((seq) => seq.id === s.sequence_id)?.name || s.name;
    return s.name;
  };

  const selectedSchedule = schedules.find((s) => s.id === selectedScheduleId);

  const weekDates = (() => {
    const d = new Date(weekStart);
    const day = d.getDay();
    const sun = new Date(d);
    sun.setDate(d.getDate() - day);
    const sat = new Date(sun);
    sat.setDate(sun.getDate() + 6);
    return { sun, sat };
  })();
  const weekLabel = `${weekDates.sun.toLocaleDateString("en-US", { month: "short", day: "numeric" })} – ${weekDates.sat.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`;

  if (!canAccessModule('module_scheduling')) return <AccessDenied reason="module" />;

  return (
    <div className="h-[calc(100dvh-64px)] flex flex-col overflow-hidden">
      {/* Toolbar */}
      <div className="bg-white border-b border-slate-200 flex flex-col md:flex-row md:items-center md:justify-between px-3 md:px-4 gap-2 py-2 flex-shrink-0">
        {/* Row 1: Asset selector + date nav */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <Select value={selectedAssetId || ""} onValueChange={(v) => { setSelectedAssetId(v); setSelectedScheduleId(null); }}>
              <SelectTrigger className="h-8 w-44 text-sm"><SelectValue placeholder="Select asset…" /></SelectTrigger>
              <SelectContent>
                {assets.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="hidden md:block w-px h-6 bg-slate-200" />

          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={prevWeek}><ChevronLeft className="w-4 h-4" /></Button>
            <Button variant="ghost" size="sm" className="h-8 text-xs px-3" onClick={goToToday}>Today</Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={nextWeek}><ChevronRight className="w-4 h-4" /></Button>
          </div>

          <div className="hidden md:flex items-center gap-1.5 text-sm text-slate-600 font-medium">
            <CalendarDays className="w-4 h-4 text-slate-400" />
            {weekLabel}
          </div>
        </div>

        {/* Row 2: Time format toggle + actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex border border-slate-200 rounded-lg overflow-hidden text-xs">
            <button onClick={() => setUse24h(true)} className={`px-3 py-1.5 font-medium transition-colors ${use24h ? "bg-slate-900 text-white" : "bg-white text-slate-500 hover:bg-slate-50"}`}>24h</button>
            <button onClick={() => setUse24h(false)} className={`px-3 py-1.5 font-medium transition-colors ${!use24h ? "bg-slate-900 text-white" : "bg-white text-slate-500 hover:bg-slate-50"}`}>AM/PM</button>
          </div>

          {activeNow && (
            <Badge className="bg-green-100 text-green-700 border-green-200 gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              <span className="hidden sm:inline">Live: </span>{getScheduleDisplayName(activeNow)}
            </Badge>
          )}

          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs gap-1.5 px-3"
            onClick={handleDownloadBackup}
            disabled={downloadingBackup || !selectedAssetId}
            title="Download offline SD card backup"
          >
            {downloadingBackup ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <HardDrive className="w-3.5 h-3.5" />}
            SD Backup
          </Button>

          {publishedAt ? (
            <Badge className="bg-green-100 text-green-700 border-green-200 gap-1.5 px-3 py-1.5 text-xs font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" /> Published!
            </Badge>
          ) : (
            <Button
              size="sm"
              className="h-8 bg-blue-600 hover:bg-blue-700 text-xs gap-1.5 px-4 font-semibold"
              onClick={() => publishMutation.mutate()}
              disabled={publishMutation.isPending || schedules.length === 0}
            >
              <Send className="w-3.5 h-3.5" />
              Publish
            </Button>
          )}
        </div>
      </div>

      {/* Mobile playlists toggle */}
      <div className="md:hidden bg-white border-b border-slate-100 px-3 py-1.5 flex-shrink-0">
        <button
          className="flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors"
          onClick={() => setShowPlaylists(p => !p)}
        >
          <span>📋</span>
          {showPlaylists ? "Hide Playlists" : "Show Playlists"}
          <ChevronRight className={`w-3.5 h-3.5 transition-transform ${showPlaylists ? "rotate-90" : ""}`} />
        </button>
      </div>

      {/* Main area */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        <div className={`${showPlaylists ? "flex" : "hidden"} md:flex flex-shrink-0`}>
          <RecentPresentations
            playlists={playlists}
            routePresentations={routePresentations}
            sequences={sequences}
            onSelect={(item) => { selectedAssetId ? createMutation.mutate(item) : null; setShowPlaylists(false); }}
            disabled={!selectedAssetId}
          />
        </div>
        <WeekCalendar
          schedules={schedules}
          layouts={[]}
          weekStart={weekStart}
          selectedScheduleId={selectedScheduleId}
          onSelectSchedule={(s) => setSelectedScheduleId(s.id === selectedScheduleId ? null : s.id)}
          onDeleteSchedule={(id) => deleteMutation.mutate(id)}
          use24h={use24h}
          getScheduleDisplayName={getScheduleDisplayName}
        />
        <ScheduleEditPanel
          schedule={selectedSchedule}
          playlists={playlists}
          routePresentations={routePresentations}
          sequences={sequences}
          onUpdate={(data) => updateMutation.mutate({ id: selectedScheduleId, data })}
          onDelete={() => deleteMutation.mutate(selectedScheduleId)}
          onAdd={() => createMutation.mutate({})}
        />
      </div>
    </div>
  );
}