import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Building2, Search, Users, Zap, ArrowLeft, ExternalLink, ToggleLeft, ScrollText, BarChart3 } from "lucide-react";
import { toast } from "sonner";
import OrgMemberList from "@/components/organizations/OrgMemberList";
import OrgFeaturesEditor from "@/components/organizations/OrgFeaturesEditor";
import OrgAuditLog from "@/components/organizations/OrgAuditLog";
import OrgUsageDashboard from "@/components/organizations/OrgUsageDashboard";

const PLAN_BADGE = {
  starter: "bg-blue-100 text-blue-700",
  growth: "bg-violet-100 text-violet-700",
  total360: "bg-amber-100 text-amber-700",
};

function OrgForm({ org, onSave, onClose }) {
  const [form, setForm] = useState(org || {
    name: "", owner_email: "", billing_email: "",
    plan_slug: "starter", max_trucks: 1, max_users: 5, notes: "",
    is_active: true, plan_source: "screenfleet_direct",
  });

  const isHubSource = form.plan_source === "legion_hub";

  const { data: plans = [] } = useQuery({ queryKey: ["plans"], queryFn: () => base44.entities.Plan.list() });

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="col-span-2">
          <Label className="text-xs">Organization Name *</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="h-8 mt-1" placeholder="Acme Outdoor Advertising" />
        </div>
        <div>
          <Label className="text-xs">Owner Email *</Label>
          <Input type="email" value={form.owner_email} onChange={(e) => setForm({ ...form, owner_email: e.target.value })} className="h-8 mt-1" />
        </div>
        <div>
          <Label className="text-xs">Billing Email</Label>
          <Input type="email" value={form.billing_email || ""} onChange={(e) => setForm({ ...form, billing_email: e.target.value })} className="h-8 mt-1" />
        </div>
        <div>
          <Label className="text-xs">Plan</Label>
          <Select value={form.plan_slug} onValueChange={(v) => setForm({ ...form, plan_slug: v })}>
            <SelectTrigger className="h-8 mt-1 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              {plans.map((plan) => (
                <SelectItem key={plan.id} value={plan.slug}>{plan.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">Plan Expires At</Label>
          <Input type="datetime-local" value={form.plan_expires_at || ""} onChange={(e) => setForm({ ...form, plan_expires_at: e.target.value })} className="h-8 mt-1" />
        </div>
        <div>
          <Label className="text-xs">Max Trucks</Label>
          <Input type="number" min="1" value={form.max_trucks} onChange={(e) => setForm({ ...form, max_trucks: Number(e.target.value) })} className="h-8 mt-1" />
        </div>
        <div>
          <Label className="text-xs">Max Users</Label>
          <Input type="number" min="1" value={form.max_users} onChange={(e) => setForm({ ...form, max_users: Number(e.target.value) })} className="h-8 mt-1" />
        </div>
        <div className="col-span-2">
          <Label className="text-xs">Plan Source</Label>
          <Select value={form.plan_source || "screenfleet_direct"} onValueChange={(v) => setForm({ ...form, plan_source: v })}>
            <SelectTrigger className="h-8 mt-1 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="screenfleet_direct">ScreenFleet Direct (Stripe billing)</SelectItem>
              <SelectItem value="legion_hub">Legion Hub (hub-authorized)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {isHubSource ? (
          <>
            <div>
              <Label className="text-xs">Legion Hub Org ID</Label>
              <Input value={form.legion_hub_org_id || ""} onChange={(e) => setForm({ ...form, legion_hub_org_id: e.target.value })} className="h-8 mt-1" placeholder="hub_org_…" />
            </div>
            <div>
              <Label className="text-xs">Legion Hub Plan Tier</Label>
              <Input value={form.legion_hub_plan_tier || ""} onChange={(e) => setForm({ ...form, legion_hub_plan_tier: e.target.value })} className="h-8 mt-1" placeholder="hub_starter / hub_pro / hub_enterprise" />
            </div>
          </>
        ) : (
          <>
            <div>
              <Label className="text-xs">Phone</Label>
              <Input value={form.phone || ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="h-8 mt-1" />
            </div>
            <div>
              <Label className="text-xs">Website</Label>
              <Input value={form.website || ""} onChange={(e) => setForm({ ...form, website: e.target.value })} className="h-8 mt-1" placeholder="https://" />
            </div>
          </>
        )}
        <div className="col-span-2">
          <Label className="text-xs">Notes</Label>
          <Input value={form.notes || ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="h-8 mt-1" />
        </div>
        <div className="col-span-2 flex items-center gap-3">
          <Switch checked={!!form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
          <Label className="text-sm">Account Active</Label>
        </div>
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
        <Button size="sm" onClick={() => {
          if (!form.name?.trim()) { toast.error("Organization Name is required"); return; }
          if (!form.owner_email?.trim()) { toast.error("Owner Email is required"); return; }
          onSave(form);
        }} className="bg-blue-600 hover:bg-blue-700">Save</Button>
      </div>
    </div>
  );
}

// CMS is private and invite-only. Public self-signup and trial signup links have been removed.
function OrgDetail({ org, onBack, onEdit }) {
  const { data: members = [] } = useQuery({
    queryKey: ["org-members", org.id],
    queryFn: () => base44.entities.OrgMember.filter({ org_id: org.id }),
  });

  return (
    <div>
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="sm" onClick={onBack} className="text-slate-500 gap-1.5">
          <ArrowLeft className="w-4 h-4" /> All Organizations
        </Button>
      </div>

      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
            {org.logo_url
              ? <img src={org.logo_url} alt="" className="w-full h-full rounded-2xl object-cover" />
              : <Building2 className="w-6 h-6 text-slate-400" />
            }
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">{org.name}</h2>
              <Badge className={`text-[10px] ${PLAN_BADGE[org.plan_slug] || "bg-slate-100 text-slate-600"}`}>{org.plan_slug}</Badge>
              {!org.is_active && <Badge variant="outline" className="text-[10px] text-red-500 border-red-200">Inactive</Badge>}
            </div>
            <p className="text-sm text-slate-500 mt-0.5">{org.owner_email}</p>
            <p className="text-xs text-slate-400 mt-0.5">
              {org.max_trucks} truck{org.max_trucks !== 1 ? "s" : ""} · {org.max_users} user{org.max_users !== 1 ? "s" : ""}
              {org.plan_expires_at && ` · expires ${new Date(org.plan_expires_at).toLocaleDateString()}`}
            </p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={onEdit} className="gap-1.5">
          <Pencil className="w-3.5 h-3.5" /> Edit Account
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "Team Members", value: members.length, sub: `${members.filter((m) => m.status === "active").length} active` },
          { label: "Max Trucks", value: org.max_trucks },
          { label: "Features", value: (org.features_enabled || []).length, sub: "enabled" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-4">
            <p className="text-xs text-slate-500 uppercase tracking-widest">{s.label}</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{s.value}</p>
            {s.sub && <p className="text-xs text-slate-400 mt-0.5">{s.sub}</p>}
          </div>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="members">
        <TabsList className="mb-4">
          <TabsTrigger value="members" className="gap-1.5"><Users className="w-3.5 h-3.5" /> Team Members</TabsTrigger>
          <TabsTrigger value="features" className="gap-1.5"><Zap className="w-3.5 h-3.5" /> Platform Features</TabsTrigger>
          <TabsTrigger value="audit" className="gap-1.5"><ScrollText className="w-3.5 h-3.5" /> Audit Log</TabsTrigger>
          <TabsTrigger value="usage" className="gap-1.5"><BarChart3 className="w-3.5 h-3.5" /> Usage</TabsTrigger>
        </TabsList>

        <TabsContent value="members" className="bg-white rounded-xl border border-slate-200 p-5">
          <OrgMemberList orgId={org.id} />
        </TabsContent>

        <TabsContent value="features" className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="mb-4">
            <h3 className="font-semibold text-slate-900">Platform Features</h3>
            <p className="text-xs text-slate-500 mt-0.5">Control which platform capabilities are available to this organization's users.</p>
          </div>
          <OrgFeaturesEditor org={org} />
        </TabsContent>

        <TabsContent value="audit" className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="mb-4">
            <h3 className="font-semibold text-slate-900">Audit Log</h3>
            <p className="text-xs text-slate-500 mt-0.5">Last 20 events for this organization.</p>
          </div>
          <OrgAuditLog orgId={org.id} />
        </TabsContent>

        <TabsContent value="usage" className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="mb-4">
            <h3 className="font-semibold text-slate-900">Usage</h3>
            <p className="text-xs text-slate-500 mt-0.5">Live resource usage for this organization.</p>
          </div>
          <OrgUsageDashboard org={org} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function Organizations() {
  const { hasPlatformRole } = useAuthority();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [editOrg, setEditOrg] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedOrg, setSelectedOrg] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null); // org to confirm-delete
  const [deleteConfirmText, setDeleteConfirmText] = useState("");
  const [deleteChecking, setDeleteChecking] = useState(false);

  const { data: orgs = [] } = useQuery({ queryKey: ["orgs"], queryFn: () => base44.entities.Organization.list() });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const payload = { ...data };
      if (!payload.plan_expires_at) delete payload.plan_expires_at;
      if (!payload.billing_email) delete payload.billing_email;
      console.log("Submitting org payload:", payload);
      const org = await base44.entities.Organization.create(payload);
      await base44.entities.OrgMember.create({
        org_id: org.id,
        user_email: org.owner_email,
        org_role: "owner",
        status: "active",
      });
      try {
        await base44.functions.invoke('sendOrgOwnerInvite', {
          orgId: org.id,
          ownerEmail: org.owner_email,
          orgName: org.name,
          appUrl: window.location.origin,
        });
      } catch (inviteErr) {
        console.warn("Invite email failed (org was still created):", inviteErr);
      }
      return org;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orgs"] });
      setShowCreate(false);
      toast.success("Organization created successfully");
    },
    onError: (err) => {
      console.error("Create org failed:", err);
      toast.error(err?.message || "Failed to create organization");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Organization.update(id, data),
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ["orgs"] });
      setEditOrg(null);
      if (selectedOrg?.id === vars.id) setSelectedOrg((o) => ({ ...o, ...vars.data }));
      toast.success("Organization updated");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Organization.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["orgs"] }); toast.success("Deleted"); },
  });

  if (!hasPlatformRole(['platform_owner', 'platform_admin', 'platform_support'])) return <AccessDenied reason="platform" />;

  const filtered = orgs.filter((o) =>
    o.name?.toLowerCase().includes(search.toLowerCase()) ||
    o.owner_email?.toLowerCase().includes(search.toLowerCase())
  );

  // --- Drill-in view ---
  if (selectedOrg) {
    const live = orgs.find((o) => o.id === selectedOrg.id) || selectedOrg;
    return (
      <div className="p-6 max-w-5xl">
        <OrgDetail
          org={live}
          onBack={() => setSelectedOrg(null)}
          onEdit={() => setEditOrg(live)}
        />
        <Dialog open={!!editOrg} onOpenChange={() => setEditOrg(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Edit: {editOrg?.name}</DialogTitle></DialogHeader>
            {editOrg && (
              <OrgForm
                org={editOrg}
                onSave={(data) => updateMutation.mutate({ id: editOrg.id, data })}
                onClose={() => setEditOrg(null)}
              />
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // --- List view ---
  return (
    <div className="p-6 max-w-6xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Organizations</h2>
          <p className="text-sm text-slate-500 mt-0.5">Manage sub-accounts — each org has its own team, roles, and feature access</p>
        </div>
        <Button onClick={() => setShowCreate(true)} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
          <Plus className="w-4 h-4" /> New Organization
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: "Total", value: orgs.length, color: "text-slate-700" },
          { label: "Active", value: orgs.filter((o) => o.is_active !== false).length, color: "text-green-600" },
          { label: "Total360", value: orgs.filter((o) => o.plan_slug === "total360").length, color: "text-amber-600" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-4">
            <p className="text-xs text-slate-500 uppercase tracking-widest">{s.label}</p>
            <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-slate-200">
        <div className="p-4 border-b border-slate-100 flex items-center gap-3">
          <Search className="w-4 h-4 text-slate-400" />
          <Input placeholder="Search organizations…" value={search} onChange={(e) => setSearch(e.target.value)} className="h-8 border-0 p-0 focus-visible:ring-0 text-sm flex-1" />
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Organization</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Plan</TableHead>
              <TableHead>Trucks</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Expires</TableHead>
              <TableHead className="w-24" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((org) => (
              <TableRow key={org.id} className="cursor-pointer hover:bg-slate-50" onClick={() => setSelectedOrg(org)}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                    <div>
                      <p className="font-medium text-sm text-slate-900">{org.name}</p>
                      {org.notes && <p className="text-[10px] text-slate-400 truncate max-w-40">{org.notes}</p>}
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-sm text-slate-600">{org.owner_email}</TableCell>
                <TableCell>
                  <Badge className={`text-[10px] ${PLAN_BADGE[org.plan_slug] || "bg-slate-100 text-slate-600"}`}>
                    {org.plan_slug || "starter"}
                  </Badge>
                </TableCell>
                <TableCell className="text-sm text-slate-600">{org.max_trucks}</TableCell>
                <TableCell>
                  <Badge className={`text-[10px] ${org.is_active !== false ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>
                    {org.is_active !== false ? "Active" : "Inactive"}
                  </Badge>
                </TableCell>
                <TableCell className="text-xs text-slate-400">
                  {org.plan_expires_at ? new Date(org.plan_expires_at).toLocaleDateString() : "—"}
                </TableCell>
                <TableCell onClick={(e) => e.stopPropagation()}>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setSelectedOrg(org)} title="Open">
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditOrg(org)}>
                      <Pencil className="w-3.5 h-3.5 text-slate-400" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setDeleteTarget(org); setDeleteConfirmText(""); }}>
                      <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {filtered.length === 0 && (
          <div className="py-12 text-center text-slate-400">
            <Building2 className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No organizations found</p>
          </div>
        )}
      </div>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>New Organization</DialogTitle></DialogHeader>
          <OrgForm onSave={(data) => createMutation.mutate(data)} onClose={() => setShowCreate(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editOrg} onOpenChange={() => setEditOrg(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Edit: {editOrg?.name}</DialogTitle></DialogHeader>
          {editOrg && <OrgForm org={editOrg} onSave={(data) => updateMutation.mutate({ id: editOrg.id, data })} onClose={() => setEditOrg(null)} />}
        </DialogContent>
      </Dialog>

      {/* Delete confirmation dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={() => { setDeleteTarget(null); setDeleteConfirmText(""); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-600 flex items-center gap-2">
              <Trash2 className="w-4 h-4" /> Delete Organization
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              This action is <strong>permanent</strong>. Type the organization name to confirm:
            </p>
            <p className="text-sm font-mono bg-slate-50 border border-slate-200 rounded px-3 py-2 text-slate-800">
              {deleteTarget?.name}
            </p>
            <Input
              placeholder="Type org name to confirm…"
              value={deleteConfirmText}
              onChange={(e) => setDeleteConfirmText(e.target.value)}
              className="h-9"
              autoFocus
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => { setDeleteTarget(null); setDeleteConfirmText(""); }}>
                Cancel
              </Button>
              <Button
                size="sm"
                disabled={deleteConfirmText !== deleteTarget?.name || deleteChecking || deleteMutation.isPending}
                className="bg-red-600 hover:bg-red-700"
                onClick={async () => {
                  setDeleteChecking(true);
                  const assets = await base44.entities.Asset.filter({ org_id: deleteTarget.id });
                  const screens = await base44.entities.Screen.filter({ org_id: deleteTarget.id });
                  setDeleteChecking(false);
                  if (assets.length > 0 || screens.length > 0) {
                    toast.error(`Cannot delete: org has ${assets.length} asset${assets.length !== 1 ? "s" : ""} and ${screens.length} screen${screens.length !== 1 ? "s" : ""}. Archive or transfer them first.`);
                    return;
                  }
                  deleteMutation.mutate(deleteTarget.id, {
                    onSuccess: () => { setDeleteTarget(null); setDeleteConfirmText(""); },
                  });
                }}
              >
                {deleteChecking ? "Checking…" : deleteMutation.isPending ? "Deleting…" : "Delete Permanently"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}