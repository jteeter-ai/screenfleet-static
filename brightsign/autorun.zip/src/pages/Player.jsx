/**
 * V2 Public Player
 * /player?screenId=XXX
 * /player?screenId=XXX&preview=1
 *
 * Public — no login required.
 * Reads ONLY screenVersionCheck + screenPayload V2 functions.
 * Renders RuntimeZone.playback_track.items[] directly.
 * No business logic. No entity API calls. No V1 logic.
 */

import React, { useEffect, useRef, useCallback, useState } from "react";
import ReactDOM from "react-dom";
import { base44 } from "@/api/base44Client";
import {
  syncMediaManifest,
  applyLocalUrls,
  cleanupOrphans,
  persistPayload,
  loadPersistedPayload,
} from "@/lib/deviceCache";
import RuntimeCanvas from "@/components/player/RuntimeCanvas";

const VERSION_POLL_MS  = 60000;
const DEVICE_POLL_MS   = 90000;
const HEARTBEAT_MS     = 30000;

// ─── Pure player portal (exact pixels, no UI) ────────────────────────────────
function PurePlayer({ payload }) {
  const { screen_width, screen_height, zones } = payload;
  return ReactDOM.createPortal(
    <div style={{ position: "fixed", top: 0, left: 0, background: "#000" }}>
      <RuntimeCanvas zones={zones} width={screen_width} height={screen_height} />
    </div>,
    document.body
  );
}

// ─── Preview player (scaled to viewport) ─────────────────────────────────────
function PreviewPlayer({ payload }) {
  const { screen_width, screen_height, zones, screen_name, content_version } = payload;
  const scale = Math.min(window.innerWidth / screen_width, (window.innerHeight - 48) / screen_height);
  // eslint-disable-next-line no-unused-vars

  return ReactDOM.createPortal(
    <div style={{ position: "fixed", inset: 0, background: "#111", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
      <div style={{ marginBottom: 8, color: "#fff8", fontSize: 11, fontFamily: "monospace" }}>
        {screen_name} · {screen_width}×{screen_height} · v{content_version?.slice(0, 16)}
      </div>
      <div style={{
        position: "relative",
        width: screen_width,
        height: screen_height,
        transform: `scale(${scale})`,
        transformOrigin: "top center",
        flexShrink: 0,
        overflow: "hidden",
      }}>
        <RuntimeCanvas zones={zones} width={screen_width} height={screen_height} />
      </div>
    </div>,
    document.body
  );
}

// ─── Main Player ─────────────────────────────────────────────────────────────
export default function Player() {
  const urlParams = new URLSearchParams(window.location.search);
  const screenId = urlParams.get("screenId");
  const previewMode = urlParams.get("preview") === "1";
  const isDevice = urlParams.get("device") === "1";

  const [payload, setPayload] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const knownVersionRef = useRef(null);
  const versionPollRef = useRef(null);

  // ── Fetch + cache payload (device: delta download + atomic swap) ──────────
  const fetchPayload = useCallback(async () => {
    if (!screenId) return;
    try {
      const res = await base44.functions.invoke("screenPayload", { screenId });
      const data = res.data;
      if (data?.status === "error") throw new Error(data.error);

      let activePayload = data;

      if (isDevice && data.media_manifest?.length) {
        // Stage: download only missing files (delta)
        const urlMap = await syncMediaManifest(data.media_manifest);
        // Apply local blob URLs — new payload with local files ready
        const staged = applyLocalUrls(data, urlMap);
        // Atomic swap: only now replace live payload
        activePayload = staged;
        // Cleanup orphans from previous manifest
        cleanupOrphans(data.media_manifest);
      }

      knownVersionRef.current = data.content_version;
      setPayload(activePayload);
      setError(null);
      persistPayload(screenId, data);
    } catch (e) {
      // Offline fallback — keep playing last cached payload
      if (!payload) {
        const cached = loadPersistedPayload(screenId);
        if (cached) { setPayload(cached); return; }
        setError(e.message);
      }
      // If payload already set, silently continue current playback
    } finally {
      setLoading(false);
    }
  }, [screenId, isDevice]); // intentionally exclude payload to avoid stale closure loop

  // ── Version poll (lightweight) ────────────────────────────────────────────
  const pollVersion = useCallback(async () => {
    if (!screenId) return;
    try {
      const res = await base44.functions.invoke("screenVersionCheck", { screenId });
      const data = res.data;
      if (data?.content_version && data.content_version !== knownVersionRef.current) {
        await fetchPayload();
      }
    } catch (_) { /* silent — continue playback on network loss */ }
  }, [screenId, fetchPayload]);

  // Initial load — try offline cache immediately for device mode (no blank screen)
  useEffect(() => {
    if (isDevice) {
      const cached = loadPersistedPayload(screenId);
      if (cached) {
        setPayload(cached);
        setLoading(false);
      }
    }
    fetchPayload();
  }, [screenId]);

  // Version polling
  useEffect(() => {
    if (!screenId) return;
    const interval = isDevice ? DEVICE_POLL_MS : VERSION_POLL_MS;
    versionPollRef.current = setInterval(pollVersion, interval);
    return () => clearInterval(versionPollRef.current);
  }, [pollVersion, screenId, isDevice]);

  // Heartbeat — report online status every 30s so dashboard shows correct status
  useEffect(() => {
    if (!screenId || previewMode) return; // don't heartbeat in preview/dashboard mode
    const sendHeartbeat = async () => {
      try {
        await base44.functions.invoke("reportHeartbeat", {
          screen_id: screenId,
          ...(knownVersionRef.current ? { content_version: knownVersionRef.current } : {}),
        });
        console.log(`[Player] Heartbeat sent for screen ${screenId}`);
      } catch (e) {
        console.warn("[Player] Heartbeat failed:", e.message);
      }
    };
    sendHeartbeat(); // send immediately on load
    const hbInterval = setInterval(sendHeartbeat, HEARTBEAT_MS);
    return () => clearInterval(hbInterval);
  }, [screenId, previewMode]);

  if (!screenId) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#ff4444", fontFamily: "monospace", textAlign: "center" }}>
          <div>Missing screenId parameter</div>
          <div style={{ color: "#fff4", marginTop: 8, fontSize: 12 }}>/player?screenId=XXX</div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#ffffff44", fontFamily: "monospace", fontSize: 12 }}>Loading…</div>
      </div>
    );
  }

  if (error && !payload) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#fff", fontFamily: "monospace", textAlign: "center", padding: 32 }}>
          <div style={{ color: "#ff4444", fontSize: 18, marginBottom: 12 }}>⚠ Screen Unavailable</div>
          <div style={{ color: "#fff8", fontSize: 14 }}>{error}</div>
          <div style={{ color: "#fff3", fontSize: 11, marginTop: 8 }}>Screen ID: {screenId}</div>
        </div>
      </div>
    );
  }

  if (!payload || payload.status === "no_published_state") {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#ffffff33", fontFamily: "monospace", fontSize: 12 }}>No published content</div>
      </div>
    );
  }

  // device=1 and preview=1 both use PurePlayer (full screen, no UI)
  // Only non-device, non-preview uses PreviewPlayer (scaled with overlay)
  if (previewMode && !isDevice) return <PreviewPlayer payload={payload} />;
  return <PurePlayer payload={payload} />;
}