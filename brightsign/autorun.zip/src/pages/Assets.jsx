import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useOrg } from "@/components/OrgContext";
import { useAuthority } from "@/lib/useAuthority";
import AccessDenied from "@/components/AccessDenied";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, ChevronDown, ChevronRight, Monitor, Edit, Trash2, Cpu, Truck, Copy, CheckCircle2, LayoutGrid, X, AlertTriangle, Zap } from "lucide-react";
import BrightSignDeployModal from "@/components/assets/BrightSignDeployModal";
import BrightSignDeployModeToggle from "@/components/assets/BrightSignDeployModeToggle";
import { toast } from "sonner";
import DeviceSafeModeSetting from "@/components/screens/DeviceSafeModeSetting";

function PlayerUrlRow({ url, token }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    toast.success("Player URL copied!");
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="flex items-center gap-2 mt-1">
      <div className="flex-1 min-w-0">
        <div className="text-[10px] text-slate-400 mb-0.5">Player URL</div>
        <span className="text-[10px] font-mono text-slate-600 truncate block">{url}</span>
      </div>
      <button
        onClick={handleCopy}
        className="shrink-0 flex items-center gap-1 text-[10px] text-slate-500 hover:text-blue-600 transition-colors border border-slate-200 rounded px-1.5 py-0.5"
      >
        {copied ? <CheckCircle2 className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
        {copied ? "Copied" : "Copy URL"}
      </button>
    </div>
  );
}

function TokenRow({ token }) {
  return (
    <div className="flex items-center gap-2 mt-1">
      <span className="text-[10px] text-slate-400 w-24 shrink-0">Public Token</span>
      <span className="text-[10px] font-mono text-slate-500 truncate flex-1 select-all">{token}</span>
    </div>
  );
}
import AssetDialog from "@/components/assets/AssetDialog";
import ScreenDialog from "@/components/assets/ScreenDialog";
import ResyncButton from "@/components/assets/ResyncButton";
import AssetLayoutAssigner from "@/components/assets/AssetLayoutAssigner";
import CreateLayoutModal from "@/components/assets/CreateLayoutModal";
import LayoutZoneEditor from "@/components/layouts/LayoutZoneEditor";

const ASSET_TYPE_LABELS = {
  truck: "Truck", trailer: "Trailer", video_wall: "Video Wall",
  poster_panel: "Poster Panel", tv: "TV", custom: "Custom"
};

const STATUS_VARIANTS = { active: "default", inactive: "secondary", maintenance: "outline" };

export default function Assets() {
  const { activeOrgId } = useOrg();
  const { canAccessModule } = useAuthority();
  console.log("[Assets] ACTIVE ORG:", activeOrgId);

  const maxScreens = sessionStorage.getItem("legion_max_screens");
  const screenLimit = maxScreens ? parseInt(maxScreens) : null;


  const qc = useQueryClient();
  const [expanded, setExpanded] = useState({});
  const [assetDialog, setAssetDialog] = useState(null);
  const [screenDialog, setScreenDialog] = useState(null);
  const [deployModal, setDeployModal] = useState(null); // asset to show deploy modal for
  const [layoutAssigner, setLayoutAssigner] = useState(null);
  const [createLayoutFor, setCreateLayoutFor] = useState(null);
  const [inlineEditor, setInlineEditor] = useState(null); // { template, screenId }

  const validOrgId = activeOrgId && activeOrgId !== "PLATFORM_ADMIN" ? activeOrgId : null;

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ["assets_v2", validOrgId],
    queryFn: async () => {
      const result = await base44.functions.invoke('listOrgAssets', { org_id: validOrgId });
      const data = result?.data;
      return Array.isArray(data) ? data : [];
    },
    enabled: !!validOrgId,
  });

  const { data: screens = [] } = useQuery({
    queryKey: ["screens_v2", validOrgId],
    queryFn: async () => {
      const result = await base44.functions.invoke('listScreens', { org_id: validOrgId });
      const data = result?.data;
      return Array.isArray(data) ? data : [];
    },
    enabled: !!validOrgId,
  });

  // Fetch all AssetLayouts for this org's assets in a single call, filter in memory
  const assetIds = assets.map(a => a.id);
  const screenIds = screens.map(s => s.id);
  const { data: assetLayouts = [] } = useQuery({
    queryKey: ["asset_layouts", validOrgId],
    queryFn: async () => {
      if (!assetIds.length) return [];
      const results = await Promise.all(
        assetIds.map(id => base44.entities.AssetLayout.filter({ asset_id: id }))
      );
      return results.flat();
    },
    enabled: !!validOrgId && assetIds.length > 0,
    staleTime: 60000,
  });

  const { data: layoutTemplates = [] } = useQuery({
    queryKey: ["layout_templates", validOrgId],
    queryFn: () => base44.entities.LayoutTemplate.filter({ org_id: validOrgId }),
    enabled: !!validOrgId,
  });

  const { data: publishedScreens = [] } = useQuery({
    queryKey: ["published_screens_assets", validOrgId],
    queryFn: async () => {
      if (!screenIds.length) return [];
      const results = await Promise.all(
        screenIds.map(id => base44.entities.PublishedScreen.filter({ screen_id: id }))
      );
      return results.flat();
    },
    enabled: !!validOrgId && screenIds.length > 0,
    staleTime: 60000,
  });

  const { data: appConfig = null } = useQuery({
    queryKey: ["app_config"],
    queryFn: async () => {
      const result = await base44.functions.invoke('getAppConfig', {});
      return result?.data?.config || result?.data || null;
    },
  });

  const origin = appConfig?.player_app_origin?.replace(/\/$/, "") || null;

  const deleteAsset = useMutation({
    mutationFn: (id) => base44.entities.Asset.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["assets_v2"] }),
  });

  // Safe lifecycle delete: archive → deactivate Player → hard delete
  const [deletingScreenId, setDeletingScreenId] = useState(null);
  const handleDeleteScreen = async (screen) => {
    if (!confirm(`Delete screen "${screen.name}"?\n\nThis will:\n• Deactivate the screen on the Player\n• Remove all published content and layouts\n• Permanently delete the screen record\n\nThis cannot be undone.`)) return;
    setDeletingScreenId(screen.id);
    try {
      // Step 1: Archive (deactivates Player, cleans up AssetLayout + PublishedScreen)
      await base44.functions.invoke('archiveScreen', { screen_id: screen.id });
      // Step 2: Hard delete (requires archived status)
      await base44.functions.invoke('deleteScreen', { screen_id: screen.id });
      qc.invalidateQueries({ queryKey: ["screens_v2"] });
      qc.invalidateQueries({ queryKey: ["asset_layouts"] });
      toast.success(`Screen "${screen.name}" deleted and Player deactivated.`);
    } catch (err) {
      toast.error(`Delete failed: ${err.message}`);
    } finally {
      setDeletingScreenId(null);
    }
  };

  const getScreenLayout = (screenId) => {

    const al = assetLayouts.find(a => a.screen_id === screenId);
    if (!al) return null;
    return layoutTemplates.find(lt => lt.id === al.layout_template_id) || null;
  };

  // Returns true if the AssetLayout template differs from what was last published
  const hasLayoutMismatch = (screenId) => {
    const al = assetLayouts.find(a => a.screen_id === screenId);
    if (!al) return false;
    // Get the most recent published screen for this screen
    const published = publishedScreens
      .filter(p => p.screen_id === screenId)
      .sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0];
    if (!published) return false; // never published — separate "no layout" warning handles this
    return published.layout_template_id !== al.layout_template_id;
  };

  const toggleExpand = (id) => setExpanded(e => ({ ...e, [id]: e[id] === false ? true : false }));
  const isExpanded = (id) => expanded[id] !== false;

  const handleCreateLayout = async ({ name, width, height }) => {
    const template = await base44.entities.LayoutTemplate.create({
      org_id: validOrgId,
      name,
      canvas_width: width,
      canvas_height: height,
    });
    qc.invalidateQueries({ queryKey: ["layout_templates"] });
    const screen = createLayoutFor.screen;
    setCreateLayoutFor(null);
    setInlineEditor({ template, screenId: screen.id });
  };

  const handleEditorBack = async () => {
    // If we have a pending screen to assign to, do it now
    if (inlineEditor?.screenId) {
      const { template, screenId } = inlineEditor;
      // Find the asset for this screen
      const screen = screens.find(s => s.id === screenId);
      if (screen) {
        const asset = assets.find(a => a.id === screen.asset_id);
        if (asset) {
          try {
            await base44.functions.invoke("assignAssetLayout", {
              asset_id: asset.id,
              screen_id: screenId,
              layout_template_id: template.id,
            });
            qc.invalidateQueries({ queryKey: ["asset_layouts"] });
            toast.success(`Layout "${template.name}" assigned to ${screen.name}`);
          } catch (e) {
            toast.error("Layout created but auto-assign failed. Use \"Assign Layout\" to assign manually.");
          }
        }
      }
    }
    setInlineEditor(null);
  };

  const invalidateAll = () => {
    qc.invalidateQueries({ queryKey: ["assets_v2"] });
    qc.invalidateQueries({ queryKey: ["screens_v2"] });
    qc.invalidateQueries({ queryKey: ["asset_layouts"] });
    qc.invalidateQueries({ queryKey: ["published_screens_assets"] });
  };

  if (!canAccessModule('module_assets')) return <AccessDenied reason="module" />;

  if (!validOrgId) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-400">
        No organization selected. Please select an organization to manage.
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Truck className="w-6 h-6 text-blue-600" /> Assets
          </h1>
          <p className="text-slate-500 text-sm mt-1">
            Manage your advertising assets (trucks, trailers, video walls, TVs) and their screens
          </p>
        </div>
        <Button onClick={() => setAssetDialog({ mode: "create" })}>
          <Plus className="w-4 h-4" /> New Asset
        </Button>
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-slate-300 border-t-blue-600 rounded-full animate-spin" />
        </div>
      )}

      <div className="space-y-3">
        {assets.map(asset => {
          const assetScreens = screens.filter(s => s.asset_id === asset.id);
          const open = isExpanded(asset.id);
          const allHaveLayouts = assetScreens.length > 0 && assetScreens.every(s => getScreenLayout(s.id));

          return (
            <div key={asset.id} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
              {/* Asset header */}
              <div className="flex items-center justify-between px-3 sm:px-5 py-4">
                <button
                  className="flex items-center gap-3 flex-1 text-left"
                  onClick={() => toggleExpand(asset.id)}
                >
                  {open
                    ? <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    : <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />}
                  <div>
                    <div className="font-semibold text-slate-900">{asset.name}</div>
                    <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                      <span>{ASSET_TYPE_LABELS[asset.asset_type] || asset.asset_type}</span>
                      <span>·</span>
                      <span>{assetScreens.length} screen{assetScreens.length !== 1 ? "s" : ""}</span>
                      {asset.player_type && asset.player_type !== "none" && (
                        <><span>·</span><span className="font-mono">{asset.player_type}</span></>
                      )}
                    </div>
                  </div>
                </button>
                <div className="flex items-center gap-2">
                  {!allHaveLayouts && assetScreens.length > 0 && (
                    <Badge variant="outline" className="text-amber-600 border-amber-300 text-xs">Layout needed</Badge>
                  )}
                  <Badge variant={STATUS_VARIANTS[asset.status] || "secondary"}>{asset.status}</Badge>
                  <Button size="icon" variant="ghost" onClick={() => setAssetDialog({ mode: "edit", asset })}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="text-red-400 hover:text-red-600" onClick={() => deleteAsset.mutate(asset.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Screens list */}
              {open && (
                <div className="border-t border-slate-100 px-5 py-4">

                  {/* BrightSign Deployment Mode Toggle */}
                  {asset.player_type === "brightsign" && (
                    <BrightSignDeployModeToggle
                      asset={asset}
                      screens={assetScreens}
                      onModeChange={(updatedAsset) => {
                        qc.invalidateQueries({ queryKey: ["assets_v2"] });
                      }}
                      onOpenDeployModal={() => setDeployModal(asset)}
                    />
                  )}

                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Screens</span>
                    <div className="flex flex-col items-end gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setScreenDialog({ mode: "create", assetId: asset.id, orgId: validOrgId })}
                        disabled={screenLimit !== null && screens.length >= screenLimit}
                        title={screenLimit !== null && screens.length >= screenLimit ? `Upgrade your plan to add more than ${screenLimit} screens` : ""}
                      >
                        <Plus className="w-3 h-3" /> Add Screen
                      </Button>
                      {screenLimit !== null && screens.length >= screenLimit && (
                        <p className="text-xs text-amber-600">
                          You've reached your {screenLimit}-screen limit. Contact your account manager to upgrade.
                        </p>
                      )}
                    </div>
                  </div>

                  {assetScreens.length === 0 ? (
                    <p className="text-sm text-slate-400 italic">No screens configured. Add a screen to get started.</p>
                  ) : (
                    <div className="space-y-2">
                      {assetScreens.map(screen => {
                        const layout = getScreenLayout(screen.id);
                        const mismatch = hasLayoutMismatch(screen.id);
                        return (
                          <div key={screen.id} className={`flex flex-col bg-slate-50 rounded-lg px-3 py-3 border gap-2 ${mismatch ? "border-amber-300 bg-amber-50" : "border-slate-100"}`}>
                            <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <Monitor className={`w-4 h-4 flex-shrink-0 ${mismatch ? "text-amber-500" : "text-slate-400"}`} />
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-medium text-slate-800">{screen.name}</span>
                                  {mismatch && (
                                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-amber-100 text-amber-700 border border-amber-300 rounded px-1.5 py-0.5">
                                      <AlertTriangle className="w-2.5 h-2.5" />
                                      Layout mismatch — republish needed
                                    </span>
                                  )}
                                </div>
                                <div className="text-xs text-slate-400 font-mono mt-0.5">{screen.width}×{screen.height}px · {screen.position?.replace(/_/g, " ")}</div>
                              </div>
                            </div>
                             <div className="flex items-center gap-2 flex-wrap">
                              {layout ? (
                                <Badge variant="outline" className="text-xs text-blue-700 border-blue-200">
                                  {layout.name}
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="text-xs text-amber-600 border-amber-300">
                                  No layout assigned
                                </Badge>
                              )}
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-slate-600 h-7 text-xs"
                                onClick={() => setLayoutAssigner({ screen, asset })}
                              >
                                <Cpu className="w-3 h-3 mr-1" />
                                {layout ? "Change" : "Assign"} Layout
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-slate-600 h-7 text-xs"
                                onClick={() => setCreateLayoutFor({ screen, asset })}
                              >
                                <LayoutGrid className="w-3 h-3 mr-1" />
                                Create Layout
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7"
                                onClick={() => setScreenDialog({ mode: "edit", screen, assetId: asset.id, orgId: validOrgId })}
                              >
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-red-400 hover:text-red-600"
                                onClick={() => handleDeleteScreen(screen)}
                                disabled={deletingScreenId === screen.id}
                                title="Delete screen (archive + Player deactivate + hard delete)"
                              >
                                {deletingScreenId === screen.id
                                  ? <div className="w-3 h-3 border border-red-400 border-t-transparent rounded-full animate-spin" />
                                  : <Trash2 className="w-3 h-3" />}
                              </Button>
                              </div>
                              </div>
                              {/* Player URL + Token — hidden in native_install mode */}
                              {asset.player_deployment_mode !== "native_install" && (
                              <div className="border-t border-slate-200 pt-2">
                                {!origin ? (
                                  <div className="flex items-center gap-1.5 text-[10px] text-amber-600">
                                    <AlertTriangle className="w-3 h-3 shrink-0" />
                                    Player app not configured — set player_app_origin in AppConfig
                                  </div>
                                ) : !screen.public_token ? (
                                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                                    <AlertTriangle className="w-3 h-3 shrink-0" />
                                    No public token — re-save this screen to generate one
                                  </div>
                                ) : (
                                  <>
                                    <TokenRow token={screen.public_token} />
                                    <PlayerUrlRow url={`${origin}/screen/${screen.public_token}`} token={screen.public_token} />
                                  </>
                                )}
                                <div className="mt-2">
                                  <ResyncButton screenId={screen.id} />
                                </div>
                              </div>
                              )}
                                {/* Device Safe Mode */}
                                <div className="border-t border-slate-200 mt-2 pt-2">
                                <DeviceSafeModeSetting screen={screen} appConfig={appConfig} onUpdate={() => qc.invalidateQueries({ queryKey: ["screens_v2"] })} />
                                </div>
                                </div>
                                );
                              })}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {!isLoading && assets.length === 0 && (
          <div className="text-center py-20 text-slate-400">
            <Truck className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No assets yet</p>
            <p className="text-sm mt-1">Create your first asset to get started</p>
          </div>
        )}
      </div>

      {assetDialog && (
        <AssetDialog
          mode={assetDialog.mode}
          asset={assetDialog.asset}
          orgId={validOrgId}
          onClose={() => setAssetDialog(null)}
          onSaved={() => { setAssetDialog(null); qc.invalidateQueries({ queryKey: ["assets_v2"] }); }}
        />
      )}
      {screenDialog && (
        <ScreenDialog
          mode={screenDialog.mode}
          screen={screenDialog.screen}
          assetId={screenDialog.assetId}
          orgId={screenDialog.orgId}
          onClose={() => setScreenDialog(null)}
          onSaved={() => { setScreenDialog(null); qc.invalidateQueries({ queryKey: ["screens_v2"] }); }}
        />
      )}
      {layoutAssigner && (
        <AssetLayoutAssigner
          screen={layoutAssigner.screen}
          asset={layoutAssigner.asset}
          orgId={validOrgId}
          onClose={() => setLayoutAssigner(null)}
          onSaved={() => { setLayoutAssigner(null); qc.invalidateQueries({ queryKey: ["asset_layouts"] }); }}
        />
      )}
      {createLayoutFor && (
        <CreateLayoutModal
          screen={createLayoutFor.screen}
          onClose={() => setCreateLayoutFor(null)}
          onCreate={handleCreateLayout}
        />
      )}
      {inlineEditor && (
        <div className="fixed inset-0 z-50 bg-slate-900">
          <LayoutZoneEditor
            template={inlineEditor.template}
            onBack={handleEditorBack}
          />
        </div>
      )}
      {deployModal && (
        <BrightSignDeployModal
          asset={deployModal}
          onClose={() => setDeployModal(null)}
        />
      )}
    </div>
  );
}