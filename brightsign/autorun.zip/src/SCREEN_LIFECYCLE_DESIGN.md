# Screen Lifecycle & Data Integrity Hardening

## Overview
Prevents orphaned screen/token/player data by enforcing lifecycle states, stable tokens, transactional cleanup, and uniqueness constraints.

---

## PART 1: Screen Lifecycle States

### New `status` Field on Screen Entity
```
status: enum [
  "active",           // Normal, device-capable
  "archived",         // Soft delete: hidden from UI, token deactivated on Player
  "deleted_internal"  // Hard delete candidate (cleanup phase)
]
```

**Workflow Changes:**
- **Edit instead of recreate**: When screen configuration changes, update the existing Screen record. Do NOT recreate.
- **Archive instead of delete**: Change `status` to `archived` (soft delete). Triggers transactional cleanup.
- **Hard delete only after archive**: After archive is confirmed clean on Player side, mark as `deleted_internal` or hard delete.

---

## PART 2: Stable Public Token

### Current Problem
- Every screen recreation generates a new `public_token`, orphaning the old one on devices and leaving stale Player rows.

### Solution
1. **`public_token` is immutable by default**: Once set at screen creation, it never changes on edit/update.
2. **Add new field: `token_regenerated_at`**: Tracks when token was admin-regenerated (null = original).
3. **Admin-only action: "Regenerate Player URL"**: 
   - Generates new token
   - Updates Player with new token
   - Deactivates old token on Player
   - Logs action

### Implementation
- When `status` is updated (archive/delete), token remains stable but is marked `inactive` on Player side.
- Only explicit admin action `regenerateScreenToken()` creates a new token.

---

## PART 3: Transactional Delete/Archive Cleanup

### Archive Flow (Normal User)
```
User clicks "Archive Screen" →
  1. Change Screen.status to "archived"
  2. Fetch all AssetLayout records for this screen_id
  3. Delete all AssetLayout records
  4. Fetch all PublishedScreen records for this screen_id
  5. Delete all PublishedScreen records
  6. Call Player: syncScreenData { action: "deactivate", public_token, cms_screen_id }
  7. Log audit entry
  8. Return success / list of deleted records
```

### Hard Delete Flow (Admin Only)
```
Admin clicks "Permanently Delete" on archived screen →
  1. Verify Screen.status == "archived"
  2. Call Player: syncScreenData { action: "delete", public_token, cms_screen_id }
  3. Hard delete Screen record
  4. Log audit entry
```

### Player API: `/syncScreenData` Changes
```js
POST /syncScreenData
Body: {
  action: "create|update|deactivate|delete",
  public_token: string,
  cms_screen_id: string,
  // ... payload for create/update
}

Responses:
- action:"create" or "update" → standard sync response
- action:"deactivate" → { ok: true, deactivated_token }
- action:"delete" → { ok: true, deleted_token, deleted_rows: N }
```

---

## PART 4: Data Integrity Constraints

### Uniqueness Rules (Database Level)
1. **public_token uniqueness**: Only 1 active (status != "deleted_internal") Screen per token.
2. **screen_id per asset**: No two active Screens for same asset (exception: explicit multi-screen layouts, but AssetLayout must be 1:1 or N:1 with explicit relationship).
3. **AssetLayout 1:1 mapping**: One AssetLayout per Screen. Delete AssetLayout when Screen is archived.
4. **PublishedScreen cleanup**: Delete all PublishedScreen records when Screen is archived.

### Code-Level Protections
- **No unordered list reads**: Don't use `filter(...)[0]`. Always query by primary key or explicit sort.
- **Validation on Screen update**: Reject updates that would create duplicate asset_id + active_screen combinations.
- **Audit logging**: Every delete/archive action logged with user, timestamp, affected record IDs.

---

## PART 5: Orphan Detection & Repair

### Detection Queries
```
1. AssetLayout.screen_id not in active Screens
2. PublishedScreen.screen_id not in active Screens
3. RuntimeZone.published_screen_id not in PublishedScreens
4. Player: multiple rows for same public_token (if token_count > 1)
5. Player: cms_screen_id not in CMS Screens
```

### Repair Tool: `repairScreenIntegrity()`
- Finds all orphaned records
- Offers safe deletion with dry-run option
- Logs each deletion
- Returns summary

---

## PART 6: Delete/Archive UX Warnings

### Pre-Delete Modal
```
Icon: ⚠️
Title: Archive Screen "{name}"?

Details:
- Token: {public_token}
- Player URL: {player_url}
- Last Ping: {last_seen_at or "Never"}
- Asset: {asset_name}
- Impact:
  ✓ AssetLayout ({count} rows) will be deleted
  ✓ PublishedScreen ({count} rows) will be deleted
  ✓ Player token will be deactivated
  ✓ Devices still using this URL will show blank/offline
  
If device is active:
  ⚠️ Device {device_hostname} last seen {minutes_ago}
  → Reprovisioning required after archive

Buttons:
  [Cancel] [Archive & Cleanup]
```

---

## PART 7: Deliverables Checklist

| # | Deliverable | File | Status |
|---|---|---|---|
| 1 | Screen entity: `status` field, `token_regenerated_at` | `entities/Screen.json` | ✓ Write |
| 2 | Archive flow function | `functions/archiveScreen.js` | ✓ Write |
| 3 | Delete flow function | `functions/deleteScreen.js` | ✓ Write |
| 4 | Regenerate token function | `functions/regenerateScreenToken.js` | ✓ Write |
| 5 | Player API: syncScreenData deactivate/delete | Spec only (Player impl) | 📋 |
| 6 | Orphan repair function | `functions/repairScreenIntegrity.js` | ✓ Write (enhanced) |
| 7 | Pre-delete warning component | `components/ScreenDeleteWarning.jsx` | ✓ Write |
| 8 | Integrity constraint validators | `functions/validateScreenIntegrity.js` | ✓ Write |
| 9 | Audit logging on delete/archive | Inline in delete/archive functions | ✓ Write |

---

## Verification Checklist

After implementation:
- [ ] Deleting a screen no longer hard deletes orphaned references
- [ ] Archiving a screen cleans up AssetLayout + PublishedScreen + Player rows
- [ ] public_token remains stable across screen edits
- [ ] public_token only changes on explicit admin regeneration
- [ ] No duplicate active screens per asset
- [ ] Player no longer has multiple rows for same token
- [ ] All delete/archive actions are audited and logged
- [ ] Orphan detection finds and can safely repair all edge cases
- [ ] UI warns users of impact before archiving