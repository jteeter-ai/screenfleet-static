# Player API Changes for Data Integrity

## `/syncScreenData` Endpoint — New Actions

### Current Behavior
```
POST /syncScreenData
Body: { screen_id, org_id, zones[], ...playback data }
Response: { ok: true, synced_at, ... }
```

### New Extended Behavior

The endpoint must now support additional `action` values for lifecycle management:

#### 1. `action: "deactivate"` — Soft Delete
Marks a screen/token as inactive on the Player side without removing the row.

```js
POST /syncScreenData
Body: {
  action: "deactivate",
  public_token: "1c2ac7e4-f3b6-4676-b3ef-a0859dafcc19",
  cms_screen_id: "69d7f8e28f14f9bc7d62c922"
}

Response: {
  ok: true,
  action: "deactivate",
  deactivated_token: "1c2ac7e4-...",
  deactivated_at: "2026-04-09T19:45:00Z"
}
```

**Player-side behavior:**
- Fetch the PlayerScreen row with matching `public_token`
- Set `is_active: false`
- Keep row in database for audit trail
- When device pings with this token, return `{ status: "inactive", message: "This screen is no longer in use" }`

---

#### 2. `action: "delete"` — Hard Delete
Permanently removes the screen/token row from Player.

```js
POST /syncScreenData
Body: {
  action: "delete",
  public_token: "1c2ac7e4-f3b6-4676-b3ef-a0859dafcc19",
  cms_screen_id: "69d7f8e28f14f9bc7d62c922"
}

Response: {
  ok: true,
  action: "delete",
  deleted_token: "1c2ac7e4-...",
  deleted_rows: 1,
  deleted_at: "2026-04-09T19:45:00Z"
}
```

**Player-side behavior:**
- Fetch all PlayerScreen rows with matching `public_token` or `cms_screen_id`
- Hard delete them
- Log audit entry for forensics
- Return count of deleted rows

---

#### 3. `action: "create"` or `action: "update"` — Standard Sync (Existing)
```js
POST /syncScreenData
Body: {
  action: "create",  // or "update" (auto-detected)
  screen_id: "69d7f8e28f14f9bc7d62c922",
  public_token: "1c2ac7e4-f3b6-4676-b3ef-a0859dafcc19",
  org_id: "69a70f9b...",
  zones: [ ... ],
  ...playback_data
}

Response: {
  ok: true,
  screen_id: "69d7f8e28f14f9bc7d62c922",
  public_token: "1c2ac7e4-...",
  synced_at: "2026-04-09T19:45:00Z",
  zones_count: 2
}
```

---

## PlayerScreen Table Schema (Player-side)

Add these columns for lifecycle management:

```sql
CREATE TABLE PlayerScreen (
  id UUID PRIMARY KEY,
  public_token UUID NOT NULL UNIQUE,  -- CMS Screen.public_token
  cms_screen_id UUID,                  -- CMS Screen.id
  org_id UUID,                         -- CMS Organization.id
  is_active BOOLEAN DEFAULT true,     -- NEW: deactivate marker
  zones JSONB,                         -- Existing: RuntimeZone payloads
  last_synced_at TIMESTAMP,
  deactivated_at TIMESTAMP,            -- NEW: When deactivated
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

CREATE UNIQUE INDEX idx_public_token_active ON PlayerScreen(public_token) WHERE is_active = true;
CREATE UNIQUE INDEX idx_cms_screen_id_active ON PlayerScreen(cms_screen_id) WHERE is_active = true;
```

---

## Constraints Enforced by Player

1. **No duplicate active tokens**: Only one `PlayerScreen` row with `is_active=true` and same `public_token`
2. **No duplicate active cms_screen_id**: Only one `PlayerScreen` row with `is_active=true` and same `cms_screen_id`
3. **Deactivate before delete**: If a token needs cleanup, deactivate first, then delete after device goes offline

---

## CMS Integration

### When Screen is Archived (soft delete):
```js
// archiveScreen.js calls:
await fetch(`${playerOrigin}/functions/syncScreenData`, {
  method: 'POST',
  headers: { 'x-sync-secret': PLAYER_SYNC_SECRET },
  body: JSON.stringify({
    action: 'deactivate',
    public_token: screen.public_token,
    cms_screen_id: screen.id
  })
});
```

### When Screen is Permanently Deleted:
```js
// deleteScreen.js calls:
await fetch(`${playerOrigin}/functions/syncScreenData`, {
  method: 'POST',
  headers: { 'x-sync-secret': PLAYER_SYNC_SECRET },
  body: JSON.stringify({
    action: 'delete',
    public_token: screen.public_token,
    cms_screen_id: screen.id
  })
});
```

### When Screen Token is Regenerated:
```js
// regenerateScreenToken.js:
// 1. Deactivate old token
await fetch(`${playerOrigin}/functions/syncScreenData`, {
  method: 'POST',
  body: JSON.stringify({
    action: 'deactivate',
    public_token: oldToken,
    cms_screen_id: screen.id
  })
});

// 2. Create/update new token (standard sync on next publish)
// New token syncs via normal screenPayload → syncScreenData create/update flow
```

---

## Error Handling

All actions must return error responses for edge cases:

```js
// Token not found
{ ok: false, error: "token_not_found", message: "No PlayerScreen with this token" }

// CMS ID mismatch
{ ok: false, error: "cms_id_mismatch", message: "Token exists but cms_screen_id does not match" }

// Duplicate detection
{ ok: false, error: "duplicate_active_tokens", message: "Multiple active rows for same token detected" }
```

---

## Deployment Notes

1. **Backward compatible**: Existing `action: "create"` and `action: "update"` behavior unchanged
2. **Optional initially**: Can add deactivate/delete support incrementally
3. **Audit logging**: Log all deactivate/delete actions on Player side for forensics
4. **Device behavior**: When device pings with an inactive token, return status 410 (Gone) + message