import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Check, Zap } from "lucide-react";
import { toast } from "sonner";

export default function PlanUpgradeDialog({ org, open, onOpenChange }) {
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [billingFrequency, setBillingFrequency] = useState("monthly");
  const [loading, setLoading] = useState(false);

  const { data: plans = [] } = useQuery({
    queryKey: ["plans"],
    queryFn: () => base44.entities.Plan.list(),
  });

  const availablePlans = plans.filter(p => p.is_active && p.slug !== org?.plan_slug);

  const handleUpgrade = async () => {
    if (!selectedPlan) {
      toast.error("Please select a plan");
      return;
    }

    setLoading(true);
    try {
      const result = await base44.functions.invoke('processPlanUpgrade', {
        orgId: org.id,
        newPlanSlug: selectedPlan.slug,
        billingFrequency,
      });

      if (result.data.checkoutUrl) {
        window.location.href = result.data.checkoutUrl;
      }
    } catch (error) {
      toast.error(error.message || "Failed to process upgrade");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Upgrade Plan</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Current Plan: <Badge variant="outline" className="ml-2">{org?.plan_slug}</Badge>
          </p>

          <div className="space-y-3">
            {availablePlans.map((plan) => {
              const isSelected = selectedPlan?.id === plan.id;
              const monthlyCycle = plan.billing_cycles?.find(bc => bc.frequency === 'monthly');

              return (
                <Card
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan)}
                  className={`p-4 cursor-pointer transition-all border-2 ${
                    isSelected ? "border-blue-600 bg-blue-50" : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                        {plan.name}
                        {plan.is_highlighted && <Zap className="w-4 h-4 text-amber-500" />}
                      </h3>
                      {plan.description && (
                        <p className="text-xs text-slate-500 mt-0.5">{plan.description}</p>
                      )}
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center">
                        <Check className="w-3 h-3 text-white" />
                      </div>
                    )}
                  </div>

                  <div className="flex items-baseline gap-1 my-2">
                    <span className="text-2xl font-bold text-slate-900">${monthlyCycle?.price || 0}</span>
                    <span className="text-slate-500 text-sm">/month</span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1">
                    <p>{plan.max_trucks === 999 ? "Unlimited" : plan.max_trucks} trucks</p>
                    <p>{plan.max_users === 999 ? "Unlimited" : plan.max_users} users</p>
                    {plan.features && plan.features.length > 0 && (
                      <p>{plan.features.length} features included</p>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>

          {selectedPlan && (
            <div className="border-t border-slate-200 pt-4 space-y-3">
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Billing Frequency</label>
                <Select value={billingFrequency} onValueChange={setBillingFrequency}>
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedPlan.billing_cycles?.map((cycle) => (
                      <SelectItem key={cycle.frequency} value={cycle.frequency} className="capitalize">
                        ${cycle.price} / {cycle.frequency}
                        {cycle.discount_percent > 0 && ` (${cycle.discount_percent}% off)`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-xs text-blue-900">
                  <strong>Pro-rated pricing:</strong> If upgrading mid-cycle, you'll only pay for the remaining days at the new plan price.
                </p>
              </div>

              <Button
                onClick={handleUpgrade}
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {loading ? "Processing..." : `Upgrade to ${selectedPlan.name}`}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}