import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { ScrollText } from "lucide-react";

const ACTION_LABELS = {
  content_published: { label: "Content Published", color: "bg-blue-50 text-blue-700" },
  admin_impersonation: { label: "Admin Impersonation", color: "bg-amber-50 text-amber-700" },
  platform_user_modified: { label: "Platform User Modified", color: "bg-violet-50 text-violet-700" },
};

export default function OrgAuditLog({ orgId }) {
  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["audit-log", orgId],
    queryFn: async () => {
      const all = await base44.entities.AuditLog.filter({ org_id: orgId });
      return all
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
        .slice(0, 20);
    },
    enabled: !!orgId,
  });

  if (isLoading) {
    return <div className="py-8 text-center text-sm text-slate-400">Loading audit log…</div>;
  }

  if (logs.length === 0) {
    return (
      <div className="py-12 text-center">
        <ScrollText className="w-7 h-7 mx-auto mb-2 text-slate-300" />
        <p className="text-sm text-slate-400">No audit events recorded yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-1">
      {logs.map((log) => {
        const meta = ACTION_LABELS[log.action] || { label: log.action, color: "bg-slate-100 text-slate-600" };
        return (
          <div key={log.id} className="flex items-start gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-50 transition-colors">
            <div className="flex-shrink-0 mt-0.5">
              <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full ${meta.color}`}>
                {meta.label}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-slate-700 truncate">{log.details || "—"}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{log.actor_email || "system"}</p>
            </div>
            <div className="flex-shrink-0 text-[10px] text-slate-400 whitespace-nowrap">
              {log.created_date ? new Date(log.created_date).toLocaleString() : "—"}
            </div>
          </div>
        );
      })}
    </div>
  );
}