import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, MoreVertical, UserX, ShieldCheck, Mail, Check, Eye, Copy, CheckCircle2, ExternalLink } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { ORG_ROLES, ORG_PERMISSIONS, ROLE_DEFAULT_PERMISSIONS } from "./permissionsConfig";

function SetupLinkDialog({ data, onClose }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(data.setupUrl || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
        <p className="font-medium mb-1">
          {data.emailStatus === 'sent'
            ? <>Invitation sent to <strong>{data.email}</strong></>
            : <>Account created for <strong>{data.email}</strong> — email failed</>}
        </p>
        <p className="text-xs text-blue-600 mt-1">
          {data.emailStatus === 'sent'
            ? "They will receive a setup email. Share the link below as a backup."
            : "Copy the setup link below and send it manually."}
        </p>
      </div>
      <div>
        <p className="text-xs text-slate-500 mb-1.5 font-medium">Setup link for {data.email}</p>
        <div className="flex gap-2">
          <input
            readOnly
            value={data.setupUrl || ''}
            className="flex-1 text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1.5 font-mono"
          />
          <Button size="sm" variant="outline" onClick={copy} className="gap-1.5">
            {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </Button>
          <Button size="sm" variant="outline" onClick={() => window.open(data.setupUrl, '_blank')}>
            <ExternalLink className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
      <p className="text-xs text-slate-400">This link expires in 48 hours.</p>
      <div className="flex justify-end">
        <Button size="sm" variant="outline" onClick={onClose}>Close</Button>
      </div>
    </div>
  );
}

const ROLE_COLORS = {
  owner: "bg-amber-50 text-amber-700 border-amber-200",
  admin: "bg-blue-50 text-blue-700 border-blue-200",
  manager: "bg-violet-50 text-violet-700 border-violet-200",
  operator: "bg-green-50 text-green-700 border-green-200",
  viewer: "bg-slate-100 text-slate-600 border-slate-200",
};

const STATUS_COLORS = {
  active: "bg-green-50 text-green-700",
  invited: "bg-amber-50 text-amber-700",
  suspended: "bg-red-50 text-red-600",
};

function InviteDialog({ orgId, orgName, onClose, onSetupLink }) {
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ user_email: "", org_role: "operator" });

  const mutation = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createOrgUser', {
        userEmail: data.user_email,
        orgId,
        orgName: orgName || '',
        orgRole: data.org_role,
        appUrl: window.location.hostname.includes('base44.app')
          ? 'https://app.screenfleet.io'
          : window.location.origin,
      });
      if (!res.data?.success) throw new Error(res.data?.error || 'Failed to create user.');
      return res.data;
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["org-members", orgId] });
      onClose();
      onSetupLink({ email: result.user_email, setupUrl: result.setupUrl, emailStatus: result.emailStatus });
      if (result.emailStatus === 'sent') {
        toast.success(`Invitation sent to ${result.user_email}`);
      } else {
        toast.warning(`Account created but email failed. Copy the setup link manually.`);
      }
    },
    onError: (err) => toast.error(err.message || "Failed to send invitation"),
  });

  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <Label className="text-xs">Email Address</Label>
        <Input
          type="email"
          placeholder="user@example.com"
          value={form.user_email}
          onChange={(e) => setForm({ ...form, user_email: e.target.value })}
          className="h-9"
        />
      </div>
      <div className="space-y-1.5">
        <Label className="text-xs">Role</Label>
        <Select value={form.org_role} onValueChange={(v) => setForm({ ...form, org_role: v })}>
          <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            {ORG_ROLES.filter((r) => r.value !== "owner").map((r) => (
              <SelectItem key={r.value} value={r.value}>
                <span className="font-medium">{r.label}</span>
                <span className="text-slate-400 text-xs ml-2">{r.description}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <p className="text-xs text-slate-500">Default permissions for this role will be applied. You can customize them after inviting.</p>
      <div className="flex justify-end gap-2 pt-1">
        <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
        <Button size="sm" onClick={() => mutation.mutate(form)} disabled={!form.user_email || mutation.isPending} className="bg-blue-600 hover:bg-blue-700">
          <Mail className="w-3.5 h-3.5 mr-1.5" /> Send Invite
        </Button>
      </div>
    </div>
  );
}

function PermissionsEditor({ member, onClose }) {
  const queryClient = useQueryClient();
  const [perms, setPerms] = useState(member.permissions || []);

  const grouped = ORG_PERMISSIONS.reduce((acc, p) => {
    if (!acc[p.category]) acc[p.category] = [];
    acc[p.category].push(p);
    return acc;
  }, {});

  const toggle = (key) => setPerms((prev) =>
    prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
  );

  const mutation = useMutation({
    mutationFn: () => base44.entities.OrgMember.update(member.id, { permissions: perms }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["org-members", member.org_id] });
      toast.success("Permissions saved");
      onClose();
    },
  });

  return (
    <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
      {Object.entries(grouped).map(([cat, items]) => (
        <div key={cat}>
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">{cat}</p>
          <div className="grid grid-cols-1 gap-1">
            {items.map((p) => (
              <label key={p.key} className={`flex items-center gap-2.5 px-3 py-2 rounded-lg border cursor-pointer text-sm transition-colors ${
                perms.includes(p.key) ? "bg-blue-50 border-blue-200 text-blue-800" : "border-slate-200 text-slate-600 hover:border-slate-300"
              }`}>
                <input type="checkbox" checked={perms.includes(p.key)} onChange={() => toggle(p.key)} className="hidden" />
                <div className={`w-4 h-4 rounded flex-shrink-0 flex items-center justify-center ${perms.includes(p.key) ? "bg-blue-600" : "border border-slate-300"}`}>
                  {perms.includes(p.key) && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                {p.label}
              </label>
            ))}
          </div>
        </div>
      ))}
      <div className="flex justify-between items-center pt-2 border-t border-slate-100 sticky bottom-0 bg-white pb-1">
        <Button variant="ghost" size="sm" onClick={() => setPerms(ROLE_DEFAULT_PERMISSIONS[member.org_role] || [])} className="text-xs text-slate-500">
          Reset to role defaults
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" onClick={() => mutation.mutate()} className="bg-blue-600 hover:bg-blue-700">Save</Button>
        </div>
      </div>
    </div>
  );
}

export default function OrgMemberList({ orgId }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [showInvite, setShowInvite] = useState(false);
  const [editingPerms, setEditingPerms] = useState(null);
  const [impersonating, setImpersonating] = useState(null);
  const [setupLinkData, setSetupLinkData] = useState(null);

  const handleViewAsUser = async (member) => {
    setImpersonating(member.id);
    try {
      const res = await base44.functions.invoke('impersonateUser', {
        memberId: member.id,
        appOrigin: window.location.origin,
      });
      const { impersonationUrl } = res.data;
      // Navigate within the CMS app — no raw external URL
      const url = new URL(impersonationUrl);
      navigate(url.pathname + url.search);
    } catch (err) {
      toast.error('Failed to load user view');
    } finally {
      setImpersonating(null);
    }
  };

  const { data: members = [] } = useQuery({
    queryKey: ["org-members", orgId],
    queryFn: () => base44.entities.OrgMember.filter({ org_id: orgId }),
    enabled: !!orgId,
  });

  const { data: org = null } = useQuery({
    queryKey: ["org", orgId],
    queryFn: async () => {
      const results = await base44.entities.Organization.filter({ id: orgId });
      return results[0] || null;
    },
    enabled: !!orgId,
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.OrgMember.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["org-members", orgId] }); toast.success("Updated"); },
  });

  const removeMutation = useMutation({
    mutationFn: (id) => base44.entities.OrgMember.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["org-members", orgId] }); toast.success("Member removed"); },
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-slate-900">Team Members</h3>
          <p className="text-xs text-slate-500 mt-0.5">{members.length} / {org?.max_users || '∞'} seats used</p>
        </div>
        <Button size="sm" onClick={() => setShowInvite(true)} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
          <Plus className="w-3.5 h-3.5" /> Invite Member
        </Button>
      </div>

      <div className="space-y-2">
        {members.length === 0 && (
          <p className="text-sm text-slate-400 text-center py-8">No members yet. Invite someone to get started.</p>
        )}
        {members.map((m) => (
          <div key={m.id} className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 bg-white">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-slate-300 to-slate-500 flex items-center justify-center flex-shrink-0">
              <span className="text-white text-xs font-bold">{(m.user_email?.[0] || "?").toUpperCase()}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-900 truncate">{m.user_email}</p>
              <p className="text-xs text-slate-400">{(m.permissions || []).length} permissions</p>
            </div>
            <Badge variant="outline" className={`text-[10px] capitalize ${ROLE_COLORS[m.org_role] || ""}`}>{m.org_role}</Badge>
            <Badge className={`text-[10px] ${STATUS_COLORS[m.status] || ""}`}>{m.status}</Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 flex-shrink-0">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleViewAsUser(m)} disabled={impersonating === m.id}>
                <Eye className="w-4 h-4 mr-2" /> {impersonating === m.id ? 'Loading…' : 'View as user'}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setEditingPerms(m)}>
                  <ShieldCheck className="w-4 h-4 mr-2" /> Edit Permissions
                </DropdownMenuItem>
                {ORG_ROLES
                  .filter((r) => ['admin', 'operator', 'viewer'].includes(r.value) && r.value !== m.org_role)
                  .map((r) => (
                    <DropdownMenuItem key={r.value} onClick={() => updateMutation.mutate({ id: m.id, data: { org_role: r.value, permissions: ROLE_DEFAULT_PERMISSIONS[r.value] || [] } })}>
                      <ShieldCheck className="w-4 h-4 mr-2" /> Set as {r.label}
                    </DropdownMenuItem>
                  ))
                }
                <DropdownMenuSeparator />
                {m.status === 'invited' && (
                  <>
                    <DropdownMenuItem onClick={() => updateMutation.mutate({ id: m.id, data: { status: 'active' } })} className="text-green-600">
                      <ShieldCheck className="w-4 h-4 mr-2" /> Mark as Active
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={async () => {
                      try {
                        await base44.users.inviteUser(m.user_email, 'user');
                        toast.success(`Re-invitation sent to ${m.user_email}`);
                      } catch {
                        toast.error('Failed to re-send invitation');
                      }
                    }}>
                      <Mail className="w-4 h-4 mr-2" /> Re-send Invitation
                    </DropdownMenuItem>
                  </>
                )}
                {m.status !== "suspended" && (
                  <DropdownMenuItem onClick={() => updateMutation.mutate({ id: m.id, data: { status: "suspended" } })} className="text-amber-600">
                    <UserX className="w-4 h-4 mr-2" /> Suspend
                  </DropdownMenuItem>
                )}
                {m.status === "suspended" && (
                  <DropdownMenuItem onClick={() => updateMutation.mutate({ id: m.id, data: { status: "active" } })} className="text-green-600">
                    <ShieldCheck className="w-4 h-4 mr-2" /> Re-activate
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => removeMutation.mutate(m.id)} className="text-red-600">
                  Remove Member
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        ))}
      </div>

      <Dialog open={showInvite} onOpenChange={setShowInvite}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Invite Team Member</DialogTitle></DialogHeader>
          <InviteDialog orgId={orgId} orgName={org?.name} onClose={() => setShowInvite(false)} onSetupLink={setSetupLinkData} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!setupLinkData} onOpenChange={() => setSetupLinkData(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" /> User Invited
            </DialogTitle>
          </DialogHeader>
          {setupLinkData && <SetupLinkDialog data={setupLinkData} onClose={() => setSetupLinkData(null)} />}
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingPerms} onOpenChange={() => setEditingPerms(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Permissions — {editingPerms?.user_email}</DialogTitle>
          </DialogHeader>
          {editingPerms && <PermissionsEditor member={editingPerms} onClose={() => setEditingPerms(null)} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}