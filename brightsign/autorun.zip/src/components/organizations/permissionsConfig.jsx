// ─── Platform-Only Permissions ────────────────────────────────────────────
// These permissions cannot be granted by org admins to regular org users
export const PLATFORM_ONLY_PERMISSIONS = [
  'impersonate_user',
  'access_platform_admin',
  'manage_platform_features',
  'billing_management',
];

// Central feature key registry — single source of truth for all feature checks
export const FEATURE_KEYS = {
  // CORE
  PLAYLISTS:               'playlists',            // replaces legacy 'standard_rotations'
  BASIC_SCHEDULING:        'basic_scheduling',

  // ADVANCED DELIVERY
  ROUTE_PRESENTATIONS:     'route_presentations',  // includes Total360 (no separate toggle)

  // ADVANCED AUTOMATION
  SEQUENCES:               'sequences',

  // CONTENT
  MULTI_ZONE_LAYOUTS:      'multi_zone_layouts',
  SCREEN_EDITOR:           'screen_editor',
  MEDIA_LIBRARY:           'media_library',

  // REPORTING
  ANALYTICS:               'analytics',

  // PLATFORM / ADVANCED
  API_ACCESS:              'api_access',
  PRIORITY_SUPPORT:        'priority_support',

  // OPTIONAL / FUTURE
  LIVE_OUTPUT:             'live_output',
  DEVICE_MONITORING:       'device_monitoring',
  REMOTE_SCREEN_CONTROL:   'remote_screen_control',
  TEAM_MANAGEMENT:         'team_management',
};

// ── OOH Package tiers — maps package_tier to included OOH modules ──────────
// Central source of truth. Add new tiers here only.
export const OOH_PACKAGE_TIERS = {
  none: {
    label: 'None',
    description: 'No OOH operator features',
    modules: [],
  },
  basic: {
    label: 'Basic',
    description: 'Route Presentations + Sequences',
    modules: ['module_route_presentations', 'module_sequences', 'module_ooh_operator'],
  },
  pro: {
    label: 'Pro',
    description: 'Route Presentations + Sequences + Reporting + Advertisers',
    modules: ['module_route_presentations', 'module_sequences', 'module_ooh_operator', 'module_ooh_reporting', 'module_ooh_advertisers'],
  },
  enterprise: {
    label: 'Enterprise',
    description: 'Full OOH operator feature set',
    modules: ['module_route_presentations', 'module_sequences', 'module_ooh_operator', 'module_ooh_reporting', 'module_ooh_advertisers', 'module_ooh_campaigns'],
  },
};

// Platform feature options — assigned at the Organization level by superadmin/admin
export const FEATURE_OPTIONS = [
  { key: FEATURE_KEYS.PLAYLISTS,              label: "Playlists",               category: "Core" },
  { key: FEATURE_KEYS.BASIC_SCHEDULING,       label: "Basic Scheduling",        category: "Core" },
  { key: FEATURE_KEYS.ROUTE_PRESENTATIONS,    label: "Route Presentations",     category: "Advanced Delivery" },
  { key: FEATURE_KEYS.SEQUENCES,              label: "Sequences",               category: "Automation" },
  { key: FEATURE_KEYS.MULTI_ZONE_LAYOUTS,     label: "Multi-Zone Layouts",      category: "Content" },
  { key: FEATURE_KEYS.SCREEN_EDITOR,          label: "Screen Editor",           category: "Content" },
  { key: FEATURE_KEYS.MEDIA_LIBRARY,          label: "Media Library",           category: "Content" },
  { key: FEATURE_KEYS.ANALYTICS,              label: "Analytics & Reports",     category: "Reporting" },
  { key: FEATURE_KEYS.API_ACCESS,             label: "API Access",              category: "Advanced" },
  { key: FEATURE_KEYS.PRIORITY_SUPPORT,       label: "Priority Support",        category: "Advanced" },
  { key: FEATURE_KEYS.LIVE_OUTPUT,            label: "Live Output",             category: "Advanced" },
  { key: FEATURE_KEYS.REMOTE_SCREEN_CONTROL,  label: "Remote Screen Control",   category: "Advanced" },
  { key: FEATURE_KEYS.DEVICE_MONITORING,      label: "Device Monitoring",       category: "Advanced" },
  { key: FEATURE_KEYS.TEAM_MANAGEMENT,        label: "Team Management",         category: "Advanced" },
];

// Granular per-user permissions within an org
export const ORG_PERMISSIONS = [
  { key: "view_assets", label: "View Assets", category: "Assets" },
  { key: "manage_assets", label: "Manage Assets (add/edit/delete)", category: "Assets" },
  { key: "view_screens", label: "View Screens", category: "Assets" },
  { key: "manage_screens", label: "Manage Screens", category: "Assets" },
  { key: "view_media", label: "View Media Library", category: "Content" },
  { key: "upload_media", label: "Upload Media", category: "Content" },
  { key: "manage_media", label: "Manage Media (delete/organize)", category: "Content" },
  { key: "view_playlists", label: "View Playlists", category: "Content" },
  { key: "manage_playlists", label: "Manage Playlists", category: "Content" },
  { key: "view_rotations", label: "View Rotations", category: "Content" },
  { key: "manage_rotations", label: "Manage Rotations", category: "Content" },
  { key: "view_schedules", label: "View Schedules", category: "Scheduling" },
  { key: "manage_schedules", label: "Manage Schedules", category: "Scheduling" },
  { key: "view_sequences", label: "View Sequences", category: "Scheduling" },
  { key: "manage_sequences", label: "Manage Sequences", category: "Scheduling" },
  { key: "screen_editor", label: "Use Screen Editor", category: "Content" },
  { key: "screen_controls", label: "Screen Controls (brightness/power)", category: "Controls" },
  { key: "live_output", label: "View Live Output", category: "Controls" },
  { key: "manage_members", label: "Manage Team Members", category: "Account" },
  { key: "view_billing", label: "View Billing & Plan", category: "Account" },
  // ── OOH Operator permissions ─────────────────────────────────────────────
  { key: "view_reporting",       label: "View Reporting",           category: "OOH Operator" },
  { key: "export_reporting",     label: "Export Reports (CSV/PDF)",  category: "OOH Operator" },
  { key: "view_advertisers",     label: "View Advertisers",          category: "OOH Operator" },
  { key: "manage_advertisers",   label: "Manage Advertisers",        category: "OOH Operator" },
  { key: "view_campaigns",       label: "View Campaigns",            category: "OOH Operator" },
  { key: "manage_campaigns",     label: "Manage Campaigns",          category: "OOH Operator" },
];

// ─── Module Keys ────────────────────────────────────────────────────────────
// Used for plan entitlement gating and route/nav access checks.
// These are coarser than action permissions and map 1:1 to app modules/pages.
export const MODULE_KEYS = {
  ASSETS:              'module_assets',
  LAYOUTS:             'module_layouts',
  MEDIA_LIBRARY:       'module_media_library',
  PLAYLISTS:           'module_playlists',
  ROUTE_PRESENTATIONS: 'module_route_presentations',
  SEQUENCES:           'module_sequences',
  SCHEDULING:          'module_scheduling',
  LIVE_OUTPUT:         'module_live_output',
  SCREEN_CONTROLS:     'module_screen_controls',
  STUDIO:              'module_studio',
  ANALYTICS:           'module_analytics',
  TEAM_MANAGEMENT:     'module_team_management',
  PLAYER_MONITORING:   'module_player_monitoring',
  BILLING:             'module_billing',
  PLATFORM_ADMIN:      'module_platform_admin',  // platform-only, never granted to org users
  // ── OOH Operator group ───────────────────────────────────────────────────
  OOH_OPERATOR:        'module_ooh_operator',     // group gate: any OOH feature
  OOH_REPORTING:       'module_ooh_reporting',
  OOH_ADVERTISERS:     'module_ooh_advertisers',
  OOH_CAMPAIGNS:       'module_ooh_campaigns',
};

// Default permissions by org role
export const ROLE_DEFAULT_PERMISSIONS = {
  // ── Existing roles (unchanged) ──────────────────────────────────────────
  owner:   ORG_PERMISSIONS.map((p) => p.key),
  admin:   ORG_PERMISSIONS.map((p) => p.key),
  manager: [
    "view_assets", "manage_assets", "view_screens", "manage_screens",
    "view_media", "upload_media", "manage_media",
    "view_playlists", "manage_playlists", "view_rotations", "manage_rotations",
    "view_schedules", "manage_schedules", "view_sequences", "manage_sequences",
    "screen_editor", "screen_controls", "live_output", "manage_members",
    "view_reporting", "export_reporting", "view_advertisers", "manage_advertisers",
    "view_campaigns", "manage_campaigns",
  ],
  operator: [
    "view_assets", "view_screens",
    "view_media", "upload_media",
    "view_playlists", "manage_playlists",
    "view_rotations", "view_schedules", "view_sequences",
    "screen_controls", "live_output",
    "view_reporting",
  ],
  viewer: [
    "view_assets", "view_screens", "view_media",
    "view_playlists", "view_rotations", "view_schedules", "view_sequences",
    "live_output", "view_reporting",
  ],
  ops_manager: [
    "view_assets", "manage_assets", "view_screens", "manage_screens",
    "view_media", "upload_media", "manage_media",
    "view_playlists", "manage_playlists", "view_rotations", "manage_rotations",
    "view_schedules", "manage_schedules", "view_sequences", "manage_sequences",
    "screen_editor", "screen_controls", "live_output",
    "view_reporting", "export_reporting", "view_advertisers", "manage_advertisers",
    "view_campaigns", "manage_campaigns",
  ],
  content_manager: [
    "view_assets", "view_screens",
    "view_media", "upload_media", "manage_media",
    "view_playlists", "manage_playlists", "view_rotations", "manage_rotations",
    "view_sequences", "screen_editor", "live_output",
  ],
  scheduler: [
    "view_assets", "view_screens", "view_media",
    "view_playlists", "view_rotations", "view_sequences",
    "view_schedules", "manage_schedules", "live_output",
  ],
  screen_operator: [
    "view_assets", "view_screens",
    "view_playlists", "view_schedules",
    "screen_controls", "live_output",
  ],
  analyst: [
    "view_assets", "view_screens", "view_media",
    "view_playlists", "view_rotations", "view_schedules", "view_sequences",
    "live_output", "view_billing",
    "view_reporting", "export_reporting", "view_advertisers", "view_campaigns",
  ],
};

export const ORG_ROLES = [
  { value: "owner",           label: "Owner",           description: "Full control, billing access" },
  { value: "admin",           label: "Admin",           description: "All access except billing ownership" },
  { value: "manager",         label: "Manager",         description: "Manage content and team members" },
  { value: "ops_manager",     label: "Ops Manager",     description: "Full content + scheduling, no team management" },
  { value: "content_manager", label: "Content Manager", description: "Manage playlists, media, and layouts" },
  { value: "scheduler",       label: "Scheduler",       description: "Create and manage schedules only" },
  { value: "screen_operator", label: "Screen Operator", description: "Operate screens and view live output" },
  { value: "analyst",         label: "Analyst",         description: "Read-only access to analytics and reports" },
  { value: "operator",        label: "Operator",        description: "Day-to-day operations" },
  { value: "viewer",          label: "Viewer",          description: "Read-only access" },
];