import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { toast } from "sonner";
import { FEATURE_OPTIONS } from "./permissionsConfig";

export default function OrgFeaturesEditor({ org }) {
  const queryClient = useQueryClient();
  const [enabled, setEnabled] = useState(org.features_enabled || []);

  const grouped = FEATURE_OPTIONS.reduce((acc, f) => {
    if (!acc[f.category]) acc[f.category] = [];
    acc[f.category].push(f);
    return acc;
  }, {});

  const toggle = (key) => setEnabled((prev) =>
    prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
  );

  const mutation = useMutation({
    mutationFn: () => base44.entities.Organization.update(org.id, { features_enabled: enabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orgs"] });
      queryClient.invalidateQueries({ queryKey: ["org", org.id] });
      toast.success("Features saved");
    },
  });

  return (
    <div className="space-y-5">
      {Object.entries(grouped).map(([cat, items]) => (
        <div key={cat}>
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">{cat}</p>
          <div className="grid grid-cols-2 gap-1.5">
            {items.map((f) => (
              <label key={f.key} className={`flex items-center gap-2.5 px-3 py-2 rounded-lg border cursor-pointer text-sm transition-colors ${
                enabled.includes(f.key) ? "bg-indigo-50 border-indigo-300 text-indigo-800" : "border-slate-200 text-slate-600 hover:border-slate-300"
              }`}>
                <input type="checkbox" checked={enabled.includes(f.key)} onChange={() => toggle(f.key)} className="hidden" />
                <div className={`w-4 h-4 rounded flex-shrink-0 flex items-center justify-center ${enabled.includes(f.key) ? "bg-indigo-600" : "border border-slate-300"}`}>
                  {enabled.includes(f.key) && <Check className="w-2.5 h-2.5 text-white" />}
                </div>
                {f.label}
              </label>
            ))}
          </div>
        </div>
      ))}
      <div className="flex justify-end pt-2 border-t border-slate-100">
        <Button size="sm" onClick={() => mutation.mutate()} disabled={mutation.isPending} className="bg-blue-600 hover:bg-blue-700">
          Save Features
        </Button>
      </div>
    </div>
  );
}