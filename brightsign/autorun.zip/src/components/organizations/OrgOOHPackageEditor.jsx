/**
 * OrgOOHPackageEditor
 * Admin UI to view and configure OOH package tier + feature overrides for an org.
 *
 * Shows per-feature state with clear source labels:
 *   - "Enabled by package"
 *   - "Disabled by package"
 *   - "Enabled by override"
 *   - "Disabled by override"
 *
 * Used in the Organizations page (platform admin) and AppSettings (org admin).
 */
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { OOH_PACKAGE_TIERS, MODULE_KEYS } from "@/components/organizations/permissionsConfig";
import { CheckCircle2, XCircle, ToggleLeft, Package, AlertCircle } from "lucide-react";
import { toast } from "sonner";

// All OOH features available for override
const OOH_FEATURE_LIST = [
  { key: MODULE_KEYS.OOH_OPERATOR,    label: "OOH Operator Group",     description: "Master gate — enables the OOH nav section" },
  { key: MODULE_KEYS.ROUTE_PRESENTATIONS, label: "Route Presentations", description: "Ad rotation / route scheduling" },
  { key: MODULE_KEYS.SEQUENCES,       label: "Sequences",              description: "Ordered content scheduling" },
  { key: MODULE_KEYS.OOH_REPORTING,   label: "Reporting",              description: "Proof of Play and delivery reports" },
  { key: MODULE_KEYS.OOH_ADVERTISERS, label: "Advertisers",            description: "Advertiser/customer management" },
  { key: MODULE_KEYS.OOH_CAMPAIGNS,   label: "Campaigns",              description: "Campaign management and pacing" },
];

/**
 * Get status for a feature given package tier + org overrides.
 * Returns: 'pkg_on' | 'pkg_off' | 'override_on' | 'override_off'
 */
function featureStatus(featureKey, packageTier, overrides = {}) {
  const tierConfig = OOH_PACKAGE_TIERS[packageTier] || OOH_PACKAGE_TIERS.none;
  const inPackage = tierConfig.modules.includes(featureKey);

  if (featureKey in overrides) {
    return overrides[featureKey] ? 'override_on' : 'override_off';
  }
  return inPackage ? 'pkg_on' : 'pkg_off';
}

function isFeatureEffectivelyEnabled(featureKey, packageTier, overrides = {}) {
  const status = featureStatus(featureKey, packageTier, overrides);
  return status === 'pkg_on' || status === 'override_on';
}

const STATUS_CONFIG = {
  pkg_on:      { label: "Enabled by package",  color: "bg-green-100 text-green-700 border-green-200",  icon: CheckCircle2, iconClass: "text-green-600" },
  pkg_off:     { label: "Disabled by package", color: "bg-slate-100 text-slate-500 border-slate-200",  icon: XCircle,      iconClass: "text-slate-400" },
  override_on: { label: "Override: enabled",   color: "bg-blue-100 text-blue-700 border-blue-200",     icon: ToggleLeft,   iconClass: "text-blue-600" },
  override_off:{ label: "Override: disabled",  color: "bg-amber-100 text-amber-700 border-amber-200",  icon: ToggleLeft,   iconClass: "text-amber-600" },
};

export default function OrgOOHPackageEditor({ org, readOnly = false }) {
  const queryClient = useQueryClient();

  // ooh_package_tier and ooh_feature_overrides stored in org.features_enabled / plan_modules_resolved
  // We use two dedicated fields via org record update.
  // ooh_package_tier:       string (stored in a JSON field we add to org notes as metadata, OR we use plan_modules_resolved)
  // ooh_feature_overrides:  object {[moduleKey]: boolean}
  // For clean storage we use org.hardware_config-style blob. We store in org record as:
  //   org.ooh_package = { tier: 'pro', overrides: { ... } }
  // Since Organization entity doesn't have ooh_package, we'll use the existing plan_modules_resolved
  // array as additive, plus a metadata JSON field by updating features_enabled.
  // Pragmatic approach: store in org.notes as JSON (no schema change needed) - but that's dirty.
  // Better: the org entity has features_enabled (array) and plan_modules_resolved (array).
  // We'll add/remove OOH module keys from plan_modules_resolved as the override mechanism,
  // and store the package tier in a new field ooh_package_tier via org update.
  // The org entity has no strict schema enforcement on extra fields — they pass through.

  const currentTier = org?.ooh_package_tier || 'none';
  const currentOverrides = org?.ooh_feature_overrides || {};

  const [tier, setTier] = useState(currentTier);
  const [overrides, setOverrides] = useState(currentOverrides);
  const [dirty, setDirty] = useState(false);

  const saveMutation = useMutation({
    mutationFn: async () => {
      // Compute effective modules from tier + overrides
      const tierModules = new Set(OOH_PACKAGE_TIERS[tier]?.modules || []);
      Object.entries(overrides).forEach(([key, val]) => {
        if (val) tierModules.add(key);
        else tierModules.delete(key);
      });

      // Merge with existing plan_modules_resolved (non-OOH modules untouched)
      const existingModules = (org.plan_modules_resolved || []).filter(
        m => !m.startsWith('module_ooh_') && m !== MODULE_KEYS.ROUTE_PRESENTATIONS && m !== MODULE_KEYS.SEQUENCES
      );
      // Re-add route_presentations / sequences if they were previously in plan_modules_resolved
      // (they're controlled by OOH tier, but also by main plan — keep union)
      const resolvedModules = [...new Set([...existingModules, ...tierModules])];

      await base44.entities.Organization.update(org.id, {
        ooh_package_tier: tier,
        ooh_feature_overrides: overrides,
        plan_modules_resolved: resolvedModules,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations"] });
      queryClient.invalidateQueries({ queryKey: ["my-org"] });
      setDirty(false);
      toast.success("OOH package settings saved");
    },
    onError: (err) => toast.error(`Save failed: ${err.message}`),
  });

  const handleTierChange = (newTier) => {
    setTier(newTier);
    setOverrides({});  // clear overrides when changing tier
    setDirty(true);
  };

  const handleOverrideToggle = (featureKey, currentlyEnabled) => {
    const tierConfig = OOH_PACKAGE_TIERS[tier] || OOH_PACKAGE_TIERS.none;
    const inPackage = tierConfig.modules.includes(featureKey);
    const newOverrides = { ...overrides };

    if (currentlyEnabled) {
      // Turning off
      if (inPackage) newOverrides[featureKey] = false;  // override off
      else delete newOverrides[featureKey];  // already off by package, nothing to do
    } else {
      // Turning on
      if (!inPackage) newOverrides[featureKey] = true;  // override on
      else delete newOverrides[featureKey];  // back to package default (on)
    }
    setOverrides(newOverrides);
    setDirty(true);
  };

  const clearOverride = (featureKey) => {
    const newOverrides = { ...overrides };
    delete newOverrides[featureKey];
    setOverrides(newOverrides);
    setDirty(true);
  };

  const selectedTierConfig = OOH_PACKAGE_TIERS[tier] || OOH_PACKAGE_TIERS.none;

  return (
    <div className="space-y-5">
      {/* Package tier selector */}
      <div className="flex items-start gap-4">
        <div className="flex-1">
          <label className="text-xs font-semibold text-slate-600 uppercase tracking-wide flex items-center gap-1.5 mb-2">
            <Package className="w-3.5 h-3.5" /> OOH Package Tier
          </label>
          {readOnly ? (
            <Badge className="capitalize bg-purple-100 text-purple-700 border-purple-200">{selectedTierConfig.label}</Badge>
          ) : (
            <Select value={tier} onValueChange={handleTierChange}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(OOH_PACKAGE_TIERS).map(([key, cfg]) => (
                  <SelectItem key={key} value={key}>
                    <div>
                      <div className="font-medium">{cfg.label}</div>
                      <div className="text-[10px] text-slate-400">{cfg.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <p className="text-xs text-slate-400 mt-1">{selectedTierConfig.description}</p>
        </div>

        {!readOnly && dirty && (
          <Button
            size="sm"
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending}
            className="mt-6"
          >
            {saveMutation.isPending ? "Saving…" : "Save Changes"}
          </Button>
        )}
      </div>

      {/* Per-feature status + overrides */}
      <div>
        <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-3">Feature Access</div>
        <div className="space-y-2">
          {OOH_FEATURE_LIST.map(feature => {
            const status = featureStatus(feature.key, tier, overrides);
            const cfg = STATUS_CONFIG[status];
            const StatusIcon = cfg.icon;
            const enabled = isFeatureEffectivelyEnabled(feature.key, tier, overrides);
            const hasOverride = feature.key in overrides;

            return (
              <div
                key={feature.key}
                className={`flex items-center justify-between px-3 py-2.5 rounded-lg border ${enabled ? 'bg-white border-slate-200' : 'bg-slate-50 border-slate-150'}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <StatusIcon className={`w-4 h-4 flex-shrink-0 ${cfg.iconClass}`} />
                  <div className="min-w-0">
                    <div className={`text-sm font-medium ${enabled ? 'text-slate-900' : 'text-slate-400'}`}>{feature.label}</div>
                    <div className="text-[10px] text-slate-400">{feature.description}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 ml-3">
                  <Badge variant="outline" className={`text-[10px] ${cfg.color}`}>{cfg.label}</Badge>
                  {!readOnly && (
                    <>
                      <Switch
                        checked={enabled}
                        onCheckedChange={() => handleOverrideToggle(feature.key, enabled)}
                        className="scale-75"
                      />
                      {hasOverride && (
                        <button
                          onClick={() => clearOverride(feature.key)}
                          className="text-[10px] text-slate-400 hover:text-blue-500 underline"
                          title="Reset to package default"
                        >
                          reset
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {!readOnly && (
        <div className="text-[10px] text-slate-400 flex items-start gap-1.5 pt-1 border-t border-slate-100">
          <AlertCircle className="w-3 h-3 flex-shrink-0 mt-0.5" />
          Package tier sets the default. Individual overrides override the package default per-feature.
          Role/permission gating is applied on top of package access at the user level.
        </div>
      )}
    </div>
  );
}