import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Monitor, Truck, Image, Users, Clock, HardDrive, Wifi } from "lucide-react";

function StatCard({ icon: Icon, label, value, sub, iconColor = "text-slate-400" }) {
  return (
    <div className="bg-slate-50 rounded-xl border border-slate-200 p-4">
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`w-4 h-4 ${iconColor}`} />
        <p className="text-xs text-slate-500 uppercase tracking-widest font-medium">{label}</p>
      </div>
      <p className="text-2xl font-bold text-slate-800">{value}</p>
      {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
    </div>
  );
}

function formatBytes(bytes) {
  if (!bytes || bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export default function OrgUsageDashboard({ org }) {
  const orgId = org.id;

  const { data: screens = [], isLoading: loadingScreens } = useQuery({
    queryKey: ["usage-screens", orgId],
    queryFn: () => base44.entities.Screen.filter({ org_id: orgId }),
    enabled: !!orgId,
  });

  const { data: assets = [], isLoading: loadingAssets } = useQuery({
    queryKey: ["usage-assets", orgId],
    queryFn: () => base44.entities.Asset.filter({ org_id: orgId }),
    enabled: !!orgId,
  });

  const { data: mediaAssets = [], isLoading: loadingMedia } = useQuery({
    queryKey: ["usage-media", orgId],
    queryFn: () => base44.entities.MediaAsset.filter({ org_id: orgId }),
    enabled: !!orgId,
  });

  const { data: members = [], isLoading: loadingMembers } = useQuery({
    queryKey: ["org-members", orgId],
    queryFn: () => base44.entities.OrgMember.filter({ org_id: orgId }),
    enabled: !!orgId,
  });

  const { data: auditLogs = [], isLoading: loadingAudit } = useQuery({
    queryKey: ["audit-log", orgId],
    queryFn: () => base44.entities.AuditLog.filter({ org_id: orgId }),
    enabled: !!orgId,
  });

  const isLoading = loadingScreens || loadingAssets || loadingMedia || loadingMembers || loadingAudit;

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="bg-slate-50 rounded-xl border border-slate-200 p-4 animate-pulse h-24" />
        ))}
      </div>
    );
  }

  const onlineScreens = screens.filter(s => s.is_online === true).length;
  const activeMembers = members.filter(m => m.status !== "suspended").length;
  const seatLimit = org.max_users || "∞";

  const totalStorageBytes = mediaAssets.reduce((sum, m) => sum + (m.file_size || 0), 0);

  const lastActivity = auditLogs.length > 0
    ? auditLogs.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0]?.created_date
    : null;

  const lastActivityLabel = lastActivity
    ? new Date(lastActivity).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
    : "No activity yet";

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      <StatCard
        icon={Monitor}
        label="Screens"
        value={screens.length}
        sub={`${onlineScreens} online`}
        iconColor={onlineScreens > 0 ? "text-green-500" : "text-slate-400"}
      />
      <StatCard
        icon={Wifi}
        label="Online Now"
        value={onlineScreens}
        sub={`of ${screens.length} total`}
        iconColor={onlineScreens > 0 ? "text-green-500" : "text-slate-400"}
      />
      <StatCard
        icon={Truck}
        label="Assets"
        value={assets.length}
        sub={`limit: ${org.max_trucks}`}
        iconColor="text-blue-500"
      />
      <StatCard
        icon={Image}
        label="Media Files"
        value={mediaAssets.length}
        iconColor="text-violet-500"
      />
      <StatCard
        icon={Users}
        label="Seats Used"
        value={`${activeMembers} / ${seatLimit}`}
        sub={`${members.filter(m => m.status === "invited").length} pending invite`}
        iconColor="text-amber-500"
      />
      <StatCard
        icon={HardDrive}
        label="Storage Used"
        value={formatBytes(totalStorageBytes)}
        sub={`across ${mediaAssets.length} files`}
        iconColor="text-slate-500"
      />
      <div className="col-span-2 md:col-span-3 bg-slate-50 rounded-xl border border-slate-200 p-4 flex items-center gap-3">
        <Clock className="w-4 h-4 text-slate-400 flex-shrink-0" />
        <div>
          <p className="text-xs text-slate-500 uppercase tracking-widest font-medium">Last Activity</p>
          <p className="text-sm font-semibold text-slate-700 mt-0.5">{lastActivityLabel}</p>
        </div>
      </div>
    </div>
  );
}