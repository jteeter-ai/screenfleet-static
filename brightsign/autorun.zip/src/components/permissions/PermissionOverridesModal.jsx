import React, { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { AlertCircle, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import {
  normalizePermissions,
  getRolePermissions,
  validatePermissionOverrides,
  getPermissionMetadata,
  groupPermissionsByCategory,
  getPermissionStatus,
} from "@/lib/permissionHelpers";
import { ORG_PERMISSIONS, PLATFORM_ONLY_PERMISSIONS } from "@/components/organizations/permissionsConfig";
import { PLATFORM_ONLY_PERMISSIONS as BOUNDARY_PLATFORM_PERMS } from "@/lib/orgAdminBoundaries";

export default function PermissionOverridesModal({
  open,
  member,
  orgModules,
  isPlatformAdmin,
  onSave,
  onOpenChange,
}) {
  const [overrides, setOverrides] = useState(() =>
    normalizePermissions(member?.permissions || {})
  );
  const [expandedCategories, setExpandedCategories] = useState({});
  const [isSaving, setIsSaving] = useState(false);

  const roleDefaults = useMemo(() => getRolePermissions(member?.org_role), [member]);
  const metadata = useMemo(() => getPermissionMetadata(), []);
  const grouped = useMemo(() => groupPermissionsByCategory(ORG_PERMISSIONS.map((p) => p.value)), []);

  const handleToggleAllow = (perm) => {
    setOverrides((prev) => {
      const allow = new Set(prev.allow);
      if (allow.has(perm)) {
        allow.delete(perm);
      } else {
        allow.add(perm);
      }
      return { ...prev, allow: Array.from(allow) };
    });
  };

  const handleToggleDeny = (perm) => {
    setOverrides((prev) => {
      const deny = new Set(prev.deny);
      if (deny.has(perm)) {
        deny.delete(perm);
      } else {
        deny.add(perm);
      }
      return { ...prev, deny: Array.from(deny) };
    });
  };

  const handleSave = async () => {
    const validation = validatePermissionOverrides(overrides, member?.org_role, orgModules, isPlatformAdmin);
    if (!validation.valid) {
      validation.errors.forEach((err) => toast.error(err));
      return;
    }

    setIsSaving(true);
    try {
      await onSave(overrides);
      onOpenChange(false);
      toast.success("Permissions updated");
    } catch (error) {
      toast.error(`Failed to save: ${error.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const toggleCategory = (cat) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [cat]: !prev[cat],
    }));
  };

  if (!member) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Advanced Permissions</DialogTitle>
          <DialogDescription>
            Manage permission overrides for <strong>{member.user_email}</strong> ({member.org_role})
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Role Defaults Summary */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-xs font-medium text-blue-900 mb-2">Role Defaults ({member.org_role})</p>
            <div className="flex flex-wrap gap-1">
              {roleDefaults.length > 0 ? (
                roleDefaults.map((perm) => (
                  <span key={perm} className="text-[10px] bg-blue-100 text-blue-700 px-2 py-1 rounded">
                    {metadata[perm]?.label || perm}
                  </span>
                ))
              ) : (
                <p className="text-xs text-blue-700">No default permissions for this role</p>
              )}
            </div>
          </div>

          {/* Platform-Only Warning */}
          {!isPlatformAdmin && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex gap-3">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-amber-800">
                Platform-only permissions (impersonate, support tools, etc.) cannot be granted at the org level.
              </p>
            </div>
          )}

          {/* Permission Groups */}
          <div className="space-y-3">
            {Object.entries(grouped).map(([category, perms]) => (
              <div key={category} className="border border-slate-200 rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleCategory(category)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-slate-50 hover:bg-slate-100 text-sm font-medium text-slate-900"
                >
                  <span>{category}</span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${
                      expandedCategories[category] ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {expandedCategories[category] && (
                  <div className="px-4 py-3 space-y-3 bg-white">
                    {perms.map((perm) => {
                       const status = getPermissionStatus(perm, member.org_role, overrides);
                       const meta = metadata[perm];
                       const isAllowed = overrides.allow.includes(perm);
                       const isDenied = overrides.deny.includes(perm);
                       const isPlatformOnly = BOUNDARY_PLATFORM_PERMS.includes(perm);
                       const canGrantPerm = isPlatformAdmin || !isPlatformOnly;

                       return (
                        <div key={perm} className="space-y-1">
                          <div className="flex items-start gap-3">
                            <div className="flex gap-2 pt-1">
                              <Checkbox
                                id={`allow-${perm}`}
                                checked={isAllowed}
                                onCheckedChange={() => handleToggleAllow(perm)}
                                disabled={isSaving || !canGrantPerm}
                              />
                              <Checkbox
                                id={`deny-${perm}`}
                                checked={isDenied}
                                onCheckedChange={() => handleToggleDeny(perm)}
                                disabled={isSaving}
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <label htmlFor={`allow-${perm}`} className={`text-xs font-medium ${!canGrantPerm ? "text-slate-400 cursor-not-allowed" : "text-slate-900 cursor-pointer"}`}>
                                {meta?.label || perm}
                                {isPlatformOnly && !isPlatformAdmin && <span className="text-[9px] text-red-600 ml-1">(platform-only)</span>}
                              </label>
                              {meta?.description && (
                                <p className={`text-[10px] ${!canGrantPerm ? "text-slate-400" : "text-slate-500"}`}>{meta.description}</p>
                              )}
                              <p className="text-[10px] mt-1">
                                {isPlatformOnly && !isPlatformAdmin ? (
                                  <span className="inline-block px-1.5 py-0.5 rounded bg-red-50 text-red-700">🔒 Platform-only</span>
                                ) : (
                                  <span
                                    className={`inline-block px-1.5 py-0.5 rounded ${
                                      status === "inherited"
                                        ? "bg-blue-50 text-blue-700"
                                        : status === "allowed"
                                        ? "bg-green-50 text-green-700"
                                        : status === "denied"
                                        ? "bg-red-50 text-red-700"
                                        : "bg-slate-50 text-slate-500"
                                    }`}
                                  >
                                    {status === "inherited" ? "✓ Inherited from role" : 
                                     status === "allowed" ? "✓ Explicitly Allowed" : 
                                     status === "denied" ? "✗ Explicitly Denied" : "—"}
                                  </span>
                                )}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Controls */}
          <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSaving}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSaving ? "Saving…" : "Save Overrides"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}