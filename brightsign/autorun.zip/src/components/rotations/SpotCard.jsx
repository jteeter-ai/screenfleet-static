import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Upload, Film, ImageIcon, Clock, ChevronDown, ChevronUp, X } from "lucide-react";

const TIER_STYLES = {
  impact: { badge: "bg-blue-100 text-blue-800 border-blue-200", label: "Impact", border: "border-blue-200" },
  growth: { badge: "bg-emerald-100 text-emerald-800 border-emerald-200", label: "Growth", border: "border-emerald-200" },
  launch: { badge: "bg-amber-100 text-amber-800 border-amber-200", label: "Launch", border: "border-amber-200" },
};

const FREQ_LABELS = {
  1: "Every rotation",
  2: "Every 2nd rotation",
  4: "Every 4th rotation",
};

const ADVERTISER_COLORS = [
  { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-800", dot: "bg-blue-500" },
  { bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-800", dot: "bg-purple-500" },
  { bg: "bg-rose-50", border: "border-rose-200", text: "text-rose-800", dot: "bg-rose-500" },
  { bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-800", dot: "bg-orange-500" },
];

/**
 * Creatives grouped by advertiser_name.
 * Each "advertiser slot" is a list of creatives with the same advertiser_name.
 * We store rotation_offset on the Creative itself (or on the first creative of the group).
 * 
 * SOV logic: if a spot has play_every_n_rotations=2 and 2 advertisers:
 *   Advertiser A: offset=0 → plays on rotations 1, 3, 5, ...
 *   Advertiser B: offset=1 → plays on rotations 2, 4, 6, ...
 */

export default function SpotCard({
  spot,
  creatives,
  defaultDwellTime,
  syncToRear,
  onUpdateSpot,
  onAddCreative,
  onDeleteCreative,
  onUpdateCreative,
}) {
  const [expanded, setExpanded] = useState(true);
  const tier = TIER_STYLES[spot.tier] || TIER_STYLES.impact;
  const effectiveDwell = spot.dwell_time ?? defaultDwellTime;

  // Tier rules
  const maxCreativesPerAdvertiser = spot.tier === "launch" ? 1 : spot.tier === "growth" ? 2 : Infinity;
  const requiredAdvertiserSlots = spot.tier === "growth" ? 2 : spot.tier === "launch" ? 4 : null; // null = Impact (no fixed count)

  // Group creatives by rotation_offset
  const advertiserGroups = [];
  const seen = [];
  creatives.forEach((c) => {
    // Use a unique key per rotation_offset value; null offset creatives get their own bucket
    // so they don't accidentally merge into offset_0 (Advertiser 1)
    const offset = c.rotation_offset ?? 0;
    const key = `offset_${offset}`;
    if (!seen.includes(key)) {
      seen.push(key);
      advertiserGroups.push({
        key,
        advertiser_name: c.advertiser_name || "",
        rotation_offset: offset,
        creatives: [],
      });
    }
    advertiserGroups.find((g) => g.key === key).creatives.push(c);
  });

  advertiserGroups.sort((a, b) => a.rotation_offset - b.rotation_offset);

  // For Growth/Launch: pad with empty placeholder slots up to the required count
  // Match by rotation_offset explicitly (not by array index) so slots stay correctly separated
  const displayGroups = requiredAdvertiserSlots
    ? Array.from({ length: requiredAdvertiserSlots }, (_, i) => {
        const existing = advertiserGroups.find((g) => g.rotation_offset === i);
        return existing || {
          key: `placeholder_${i}`,
          advertiser_name: "",
          rotation_offset: i,
          creatives: [],
          isPlaceholder: true,
        };
      })
    : advertiserGroups;

  return (
    <Card className={`border ${tier.border} shadow-sm`}>
      <CardHeader className="pb-2 pt-3 px-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <span className="text-sm font-bold text-slate-500 w-6">#{spot.spot_number}</span>
            <Badge className={`${tier.badge} border text-xs font-semibold`}>{tier.label}</Badge>
            <span className="text-xs text-slate-400">{FREQ_LABELS[spot.play_every_n_rotations] || "Every rotation"}</span>
            {advertiserGroups.length > 1 && (
              <Badge variant="outline" className="text-[10px] gap-1">
                {advertiserGroups.length} advertisers
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center gap-1 text-xs text-slate-500">
              <Clock className="w-3 h-3" />
              <Input
                type="number"
                min="1"
                value={effectiveDwell}
                onChange={(e) => onUpdateSpot(spot.id, { dwell_time: Number(e.target.value) })}
                className="h-6 w-14 text-xs px-1.5 text-center"
              />
              <span>s</span>
              {syncToRear && <span className="text-slate-400 text-[10px]">(synced)</span>}
            </div>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setExpanded(!expanded)}>
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </Button>
          </div>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="px-4 pb-4 pt-0 space-y-3">
          {/* Spot settings row */}
          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Tier</Label>
              <Select value={spot.tier} onValueChange={(v) => onUpdateSpot(spot.id, { tier: v })}>
                <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="impact">Impact</SelectItem>
                  <SelectItem value="growth">Growth</SelectItem>
                  <SelectItem value="launch">Launch</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Frequency</Label>
              <Select
                value={String(spot.play_every_n_rotations)}
                onValueChange={(v) => onUpdateSpot(spot.id, { play_every_n_rotations: Number(v) })}
              >
                <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Every rotation</SelectItem>
                  <SelectItem value="2">Every 2nd</SelectItem>
                  <SelectItem value="4">Every 4th</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Layout</Label>
              <Select value={spot.layout_type} onValueChange={(v) => onUpdateSpot(spot.id, { layout_type: v })}>
                <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="fullscreen">Full Screen</SelectItem>
                  <SelectItem value="multi_zone">Multi-Zone</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>


          {/* Advertiser SOV Slots */}
          <div>
            <div className="mb-2">
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">
                Share of Voice
                {requiredAdvertiserSlots
                  ? ` (${requiredAdvertiserSlots} advertisers)`
                  : ` (${advertiserGroups.length} advertiser${advertiserGroups.length !== 1 ? "s" : ""})`}
              </Label>
            </div>

            <div className="space-y-3">
              {displayGroups.length === 0 && (
                <div className="border-2 border-dashed border-slate-200 rounded-lg p-3 text-center text-xs text-slate-400">
                  No advertisers yet
                </div>
              )}

              {displayGroups.map((group, groupIdx) => {
                const colors = ADVERTISER_COLORS[groupIdx % ADVERTISER_COLORS.length];
                return (
                  <AdvertiserSlot
                    key={group.key}
                    group={group}
                    groupIdx={groupIdx}
                    totalGroups={displayGroups.length}
                    colors={colors}
                    spotFrequency={spot.play_every_n_rotations || 1}
                    canAddCreative={!group.isPlaceholder && group.creatives.length < maxCreativesPerAdvertiser}
                    onUpdateAdvertiserName={(name) => {
                      group.creatives.forEach((c) => onUpdateCreative(c.id, { advertiser_name: name }));
                    }}
                    onUpdateOffset={(offset) => {
                      group.creatives.forEach((c) => onUpdateCreative(c.id, { rotation_offset: offset }));
                    }}
                    onAddCreative={(extraData = {}) => {
                      // Always use group.rotation_offset (stable value on the group object),
                      // never groupIdx (render-time index that can diverge in async closures)
                      const offset = group.rotation_offset;
                      if (group.isPlaceholder) {
                        onAddCreative(spot.id, { rotation_offset: offset, advertiser_name: "", ...extraData });
                      } else {
                        onAddCreative(spot.id, {
                          rotation_offset: offset,
                          advertiser_name: group.advertiser_name,
                          ...extraData,
                        });
                      }
                    }}
                    onUpdateCreative={onUpdateCreative}
                    onDeleteCreative={onDeleteCreative}
                    isFixedSlot={!!requiredAdvertiserSlots}
                    onDeleteSlot={() => {
                      group.creatives.forEach((c) => onDeleteCreative(c.id));
                    }}
                  />
                );
              })}
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

function AdvertiserSlot({
  group,
  groupIdx,
  totalGroups,
  colors,
  spotFrequency,
  canAddCreative,
  onUpdateAdvertiserName,
  onUpdateOffset,
  onAddCreative,
  onUpdateCreative,
  onDeleteCreative,
  onDeleteSlot,
  isFixedSlot,
}) {
  const [localName, setLocalName] = useState(group.advertiser_name);

  React.useEffect(() => {
    setLocalName(group.advertiser_name);
  }, [group.advertiser_name]);

  // Placeholder slot for fixed tiers: show an editable name + a ghost CreativeRow for uploads
  if (group.isPlaceholder) {
    return (
      <div className={`rounded-lg border ${colors.border} ${colors.bg} p-2.5 space-y-2`}>
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${colors.dot}`} />
          <Input
            value={localName}
            onChange={(e) => setLocalName(e.target.value)}
            onBlur={() => onUpdateAdvertiserName(localName)}
            placeholder={`Advertiser ${groupIdx + 1} name…`}
            className={`h-6 text-xs flex-1 border-0 bg-transparent px-1 font-medium ${colors.text} placeholder:text-slate-400 focus-visible:ring-0`}
          />
        </div>
        <div className="pl-4">
          <GhostCreativeRow onAddCreative={onAddCreative} />
        </div>
      </div>
    );
  }

  return (
    <div className={`rounded-lg border ${colors.border} ${colors.bg} p-2.5 space-y-2`}>
      {/* Slot header */}
      <div className="flex items-center gap-2">
        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${colors.dot}`} />
        <Input
          value={localName}
          onChange={(e) => setLocalName(e.target.value)}
          onBlur={() => onUpdateAdvertiserName(localName)}
          placeholder={`Advertiser ${groupIdx + 1} name…`}
          className={`h-6 text-xs flex-1 border-0 bg-transparent px-1 font-medium ${colors.text} placeholder:text-slate-400 focus-visible:ring-0`}
        />

        {/* Rotation offset selector */}
        {totalGroups > 1 && spotFrequency > 1 && (
          <div className="flex items-center gap-1 flex-shrink-0">
            <span className="text-[10px] text-slate-500">Offset:</span>
            <Select
              value={String(group.rotation_offset ?? groupIdx)}
              onValueChange={(v) => onUpdateOffset(Number(v))}
            >
              <SelectTrigger className="h-6 text-xs w-14 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: spotFrequency }, (_, i) => (
                  <SelectItem key={i} value={String(i)}>+{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Only show delete on Impact (non-fixed) slots */}
        {!isFixedSlot && (
          <Button
            variant="ghost"
            size="sm"
            className="h-5 w-5 p-0 text-slate-400 hover:text-red-500 flex-shrink-0"
            onClick={onDeleteSlot}
            title="Remove advertiser"
          >
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>

      {/* Creatives for this advertiser */}
      <div className="space-y-1.5 pl-4">
        {group.creatives.map((creative, idx) => (
          <CreativeRow
            key={creative.id}
            creative={creative}
            index={idx}
            onUpdate={(data) => onUpdateCreative(creative.id, data)}
            onDelete={() => onDeleteCreative(creative.id)}
          />
        ))}
        {/* For fixed slots (Growth/Launch): if no creatives yet, show ghost row */}
        {isFixedSlot && group.creatives.length === 0 && !group.isPlaceholder && (
          <GhostCreativeRow key={`ghost-${group.rotation_offset}`} onAddCreative={onAddCreative} />
        )}
        {/* For Impact (non-fixed): show add creative link */}
        {!isFixedSlot && canAddCreative && (
          <button
            className="text-[10px] text-slate-400 hover:text-blue-500 flex items-center gap-1 transition-colors"
            onClick={onAddCreative}
          >
            <Plus className="w-3 h-3" /> Add creative
          </button>
        )}
      </div>
    </div>
  );
}

// A ghost upload row shown for fixed-tier slots that have no creative yet
function GhostCreativeRow({ onAddCreative }) {
  const [uploading, setUploading] = useState({ side: false, rear: false });
  // Use a ref so the upload handler always calls the latest onAddCreative (avoids stale closure)
  const onAddCreativeRef = React.useRef(onAddCreative);
  React.useEffect(() => { onAddCreativeRef.current = onAddCreative; }, [onAddCreative]);

  const handleFileUpload = async (e, screenType) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading((u) => ({ ...u, [screenType]: true }));
    const { base44 } = await import("@/api/base44Client");
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const fileType = file.type.startsWith("video") ? "video" : "image";
    onAddCreativeRef.current({ [`${screenType}_file_url`]: file_url, [`${screenType}_file_type`]: fileType });
    setUploading((u) => ({ ...u, [screenType]: false }));
  };

  return (
    <div className="bg-white rounded p-1.5 border border-slate-100">
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-bold text-slate-400 w-3">1</span>

        {/* Side upload */}
        <div className="flex-1">
          <label className="block">
            <div className="flex items-center gap-1.5 rounded px-2 py-1 border cursor-pointer text-xs border-slate-200 bg-white text-slate-500 hover:border-blue-300 transition-colors">
              {uploading.side ? <span className="text-[10px]">Uploading…</span> : <><Upload className="w-3 h-3" /><span>Side</span></>}
            </div>
            <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => handleFileUpload(e, "side")} />
          </label>
        </div>

        {/* Rear upload */}
        <div className="flex-1">
          <label className="block">
            <div className="flex items-center gap-1.5 rounded px-2 py-1 border cursor-pointer text-xs border-slate-200 bg-white text-slate-500 hover:border-emerald-300 transition-colors">
              {uploading.rear ? <span className="text-[10px]">Uploading…</span> : <><Upload className="w-3 h-3" /><span>Rear</span></>}
            </div>
            <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => handleFileUpload(e, "rear")} />
          </label>
        </div>

        <div className="flex items-center gap-0.5">
          <span className="h-6 w-10 text-xs text-center text-slate-300">—</span>
          <span className="text-[10px] text-slate-400">s</span>
        </div>
        <div className="h-5 w-5" />
      </div>
    </div>
  );
}

function CreativeRow({ creative, index, onUpdate, onDelete }) {
  const [uploading, setUploading] = useState({ side: false, rear: false, front: false });
  const onUpdateRef = React.useRef(onUpdate);
  React.useEffect(() => { onUpdateRef.current = onUpdate; }, [onUpdate]);

  const handleFileUpload = async (e, screenType) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading((u) => ({ ...u, [screenType]: true }));
    const { base44 } = await import("@/api/base44Client");
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const fileType = file.type.startsWith("video") ? "video" : "image";
    if (screenType === "side") {
      onUpdateRef.current({ side_file_url: file_url, side_file_type: fileType });
    } else if (screenType === "rear") {
      onUpdateRef.current({ rear_file_url: file_url, rear_file_type: fileType });
    } else {
      onUpdateRef.current({ front_file_url: file_url, front_file_type: fileType });
    }
    setUploading((u) => ({ ...u, [screenType]: false }));
  };

  const UploadButton = ({ screenType, fileUrl, fileType, uploadingNow, label, colors }) => (
    <div className="flex-1">
      <label className="block">
        <div className={`flex items-center gap-1.5 rounded px-2 py-1 border cursor-pointer text-xs transition-colors ${fileUrl ? colors.active : colors.inactive}`}>
          {uploadingNow ? (
            <span className="text-[10px]">Uploading…</span>
          ) : fileUrl ? (
            <>
              {fileType === "video" ? <Film className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
              <span className="truncate max-w-[80px]" title={fileUrl.split("/").pop()}>
                {fileUrl.split("/").pop().split("_").slice(1).join("_") || fileUrl.split("/").pop()}
              </span>
            </>
          ) : (
            <>
              <Upload className="w-3 h-3" />
              <span>{label}</span>
            </>
          )}
        </div>
        <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => handleFileUpload(e, screenType)} />
      </label>
    </div>
  );

  return (
    <div className="bg-white rounded p-1.5 border border-slate-100 space-y-1.5">
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-bold text-slate-400 w-3">{index + 1}</span>

        <UploadButton
          screenType="side"
          fileUrl={creative.side_file_url}
          fileType={creative.side_file_type}
          uploadingNow={uploading.side}
          label="Side"
          colors={{ active: "border-blue-200 bg-blue-50 text-blue-700", inactive: "border-slate-200 bg-white text-slate-500 hover:border-blue-300" }}
        />
        <UploadButton
          screenType="rear"
          fileUrl={creative.rear_file_url}
          fileType={creative.rear_file_type}
          uploadingNow={uploading.rear}
          label="Rear"
          colors={{ active: "border-emerald-200 bg-emerald-50 text-emerald-700", inactive: "border-slate-200 bg-white text-slate-500 hover:border-emerald-300" }}
        />

        <div className="flex items-center gap-0.5">
          <Input
            type="number"
            min="1"
            placeholder="—"
            value={creative.dwell_time_override || ""}
            onChange={(e) => onUpdate({ dwell_time_override: e.target.value ? Number(e.target.value) : null })}
            className="h-6 w-10 text-xs px-1 text-center"
            title="Dwell override (seconds)"
          />
          <span className="text-[10px] text-slate-400">s</span>
        </div>

        <Button variant="ghost" size="sm" className="h-5 w-5 p-0 text-red-400 hover:text-red-600" onClick={onDelete}>
          <Trash2 className="w-3 h-3" />
        </Button>
      </div>


    </div>
  );
}