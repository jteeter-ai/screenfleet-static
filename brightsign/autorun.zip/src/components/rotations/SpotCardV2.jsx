import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Clock, ChevronDown, ChevronUp, X, Building2, Megaphone } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { useOrg } from "@/components/OrgContext";
import RouteCreativeRow from "./RouteCreativeRow";

const TIER_STYLES = {
  impact: { badge: "bg-blue-100 text-blue-800 border-blue-200", label: "Impact", border: "border-blue-200" },
  growth: { badge: "bg-emerald-100 text-emerald-800 border-emerald-200", label: "Growth", border: "border-emerald-200" },
  launch: { badge: "bg-amber-100 text-amber-800 border-amber-200", label: "Launch", border: "border-amber-200" },
};

const FREQ_LABELS = {
  1: "Every rotation",
  2: "Every 2nd rotation",
  4: "Every 4th rotation",
};

const ADVERTISER_COLORS = [
  { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-800", dot: "bg-blue-500" },
  { bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-800", dot: "bg-purple-500" },
  { bg: "bg-rose-50", border: "border-rose-200", text: "text-rose-800", dot: "bg-rose-500" },
  { bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-800", dot: "bg-orange-500" },
];

/**
 * SpotCardV2: RouteSpot with RouteCreatives using zone_assignments
 */
export default function SpotCardV2({
  spot,
  creatives,
  layoutZones,
  defaultDwellTime,
  onUpdateSpot,
  onAddCreative,
  onDeleteCreative,
  onUpdateCreative,
}) {
  const { activeOrgId } = useOrg();
  const [expanded, setExpanded] = useState(true);

  // Load advertisers + campaigns for assignment UI
  const { data: advertisers = [] } = useQuery({
    queryKey: ["advertisers", activeOrgId],
    queryFn: () => base44.entities.Advertiser.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
    staleTime: 60000,
  });
  const { data: campaigns = [] } = useQuery({
    queryKey: ["campaigns", activeOrgId],
    queryFn: () => base44.entities.Campaign.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId,
    staleTime: 60000,
  });

  const selectedAdvertiser = advertisers.find(a => a.id === spot.advertiser_id);
  const advertiserCampaigns = campaigns.filter(c => c.advertiser_id === spot.advertiser_id && c.is_active !== false);
  const tier = TIER_STYLES[spot.tier] || TIER_STYLES.impact;
  const effectiveDwell = spot.dwell_time ?? defaultDwellTime;

  // Tier rules
  const maxCreativesPerAdvertiser = spot.tier === "launch" ? 1 : spot.tier === "growth" ? 2 : spot.tier === "impact" ? 4 : Infinity;
  const requiredAdvertiserSlots = spot.tier === "growth" ? 2 : spot.tier === "launch" ? 4 : spot.tier === "impact" ? 1 : null;

  // Group creatives by rotation_offset (stable slot identifier)
  // advertiser_name is mutable metadata, rotation_offset is the persistent group key
  const advertiserGroups = [];
  const seen = [];
  creatives.forEach((c) => {
    const offset = c.rotation_offset ?? 0;
    const key = `offset_${offset}`;
    if (!seen.includes(key)) {
      seen.push(key);
      advertiserGroups.push({
        key,
        advertiser_name: c.advertiser_name || "",
        rotation_offset: offset,
        creatives: [],
      });
    }
    advertiserGroups.find((g) => g.key === key).creatives.push(c);
  });

  advertiserGroups.sort((a, b) => a.rotation_offset - b.rotation_offset);

  const displayGroups = requiredAdvertiserSlots
    ? Array.from({ length: requiredAdvertiserSlots }, (_, i) => {
        const existing = advertiserGroups.find((g) => g.rotation_offset === i);
        return existing || {
          key: `placeholder_${i}`,
          advertiser_name: "",
          rotation_offset: i,
          creatives: [],
          isPlaceholder: true,
        };
      })
    : advertiserGroups;

  return (
    <Card className={`border ${tier.border} shadow-sm`}>
      <CardHeader className="pb-2 pt-3 px-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <span className="text-sm font-bold text-slate-500 w-6">#{spot.spot_number}</span>
            <Badge className={`${tier.badge} border text-xs font-semibold`}>{tier.label}</Badge>
            <span className="text-xs text-slate-400">{FREQ_LABELS[spot.play_every_n_rotations] || "Every rotation"}</span>
            {advertiserGroups.length > 1 && (
              <Badge variant="outline" className="text-[10px] gap-1">
                {advertiserGroups.length} advertisers
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center gap-1 text-xs text-slate-500">
              <Clock className="w-3 h-3" />
              <Input
                type="number"
                min="1"
                value={effectiveDwell}
                onChange={(e) => onUpdateSpot(spot.id, { dwell_time: Number(e.target.value) })}
                className="h-6 w-14 text-xs px-1.5 text-center"
              />
              <span>s</span>
            </div>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setExpanded(!expanded)}>
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </Button>
          </div>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="px-4 pb-4 pt-0 space-y-3">
          {/* Spot settings row */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Tier</Label>
              <Select value={spot.tier} onValueChange={(v) => onUpdateSpot(spot.id, { tier: v })}>
                <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="impact">Impact</SelectItem>
                  <SelectItem value="growth">Growth</SelectItem>
                  <SelectItem value="launch">Launch</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">Frequency</Label>
              <Select
                value={String(spot.play_every_n_rotations)}
                onValueChange={(v) => onUpdateSpot(spot.id, { play_every_n_rotations: Number(v) })}
              >
                <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Every rotation</SelectItem>
                  <SelectItem value="2">Every 2nd</SelectItem>
                  <SelectItem value="4">Every 4th</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Advertiser + Campaign assignment for reporting */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div>
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide flex items-center gap-1">
                <Building2 className="w-2.5 h-2.5" /> Advertiser
              </Label>
              <Select
                value={spot.advertiser_id || "_none"}
                onValueChange={v => onUpdateSpot(spot.id, { advertiser_id: v === "_none" ? null : v, campaign_id: null })}
              >
                <SelectTrigger className="h-7 text-xs mt-0.5">
                  <SelectValue placeholder="Unassigned" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">— Unassigned —</SelectItem>
                  {advertisers.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide flex items-center gap-1">
                <Megaphone className="w-2.5 h-2.5" /> Campaign
              </Label>
              <Select
                value={spot.campaign_id || "_none"}
                onValueChange={v => onUpdateSpot(spot.id, { campaign_id: v === "_none" ? null : v })}
                disabled={!spot.advertiser_id || advertiserCampaigns.length === 0}
              >
                <SelectTrigger className="h-7 text-xs mt-0.5">
                  <SelectValue placeholder={!spot.advertiser_id ? "Select advertiser first" : "No campaigns"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">— None —</SelectItem>
                  {advertiserCampaigns.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Advertiser SOV Slots */}
          <div>
            <div className="mb-2">
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">
                Share of Voice
                {requiredAdvertiserSlots
                  ? ` (${requiredAdvertiserSlots} advertisers)`
                  : ` (${advertiserGroups.length} advertiser${advertiserGroups.length !== 1 ? "s" : ""})`}
              </Label>
            </div>

            <div className="space-y-3">
              {displayGroups.length === 0 && (
                <div className="border-2 border-dashed border-slate-200 rounded-lg p-3 text-center text-xs text-slate-400">
                  No advertisers yet
                </div>
              )}

              {displayGroups.map((group, groupIdx) => {
                const colors = ADVERTISER_COLORS[groupIdx % ADVERTISER_COLORS.length];
                return (
                  <AdvertiserSlotV2
                    key={group.key}
                    group={group}
                    groupIdx={groupIdx}
                    totalGroups={displayGroups.length}
                    colors={colors}
                    spotFrequency={spot.play_every_n_rotations || 1}
                    layoutZones={layoutZones}
                    spotId={spot.id}
                    canAddCreative={!group.isPlaceholder && group.creatives.length < maxCreativesPerAdvertiser}
                    onUpdateAdvertiserName={(name) => {
                      group.creatives.forEach((c) => onUpdateCreative(c.id, { advertiser_name: name }));
                    }}
                    onUpdateOffset={(offset) => {
                      group.creatives.forEach((c) => onUpdateCreative(c.id, { rotation_offset: offset }));
                    }}
                    onAddCreativeHandler={onAddCreative}
                    onUpdateCreative={onUpdateCreative}
                    onDeleteCreative={onDeleteCreative}
                    isFixedSlot={!!requiredAdvertiserSlots}
                    onDeleteSlot={() => {
                      group.creatives.forEach((c) => onDeleteCreative(c.id));
                    }}
                  />
                );
              })}
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

function AdvertiserSlotV2({
  group,
  groupIdx,
  totalGroups,
  colors,
  spotFrequency,
  layoutZones,
  spotId,
  canAddCreative,
  onUpdateAdvertiserName,
  onUpdateOffset,
  onAddCreativeHandler,
  onUpdateCreative,
  onDeleteCreative,
  onDeleteSlot,
  isFixedSlot,
}) {
  const [localName, setLocalName] = React.useState(group.advertiser_name);

  React.useEffect(() => {
    setLocalName(group.advertiser_name);
  }, [group.advertiser_name]);

  if (group.isPlaceholder) {
    return (
      <div className={`rounded-lg border ${colors.border} ${colors.bg} p-2.5 space-y-2`}>
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${colors.dot}`} />
          <Input
            value={localName}
            onChange={(e) => setLocalName(e.target.value)}
            onBlur={() => onUpdateAdvertiserName(localName)}
            placeholder={`Advertiser ${groupIdx + 1} name…`}
            className={`h-6 text-xs flex-1 border-0 bg-transparent px-1 font-medium ${colors.text} placeholder:text-slate-400 focus-visible:ring-0`}
          />
        </div>
        <div className="pl-4">
          <GhostCreativeRowV2 layoutZones={layoutZones} spotId={spotId} advertiserName={localName || ""} rotationOffset={group.rotation_offset} onAddCreative={onAddCreativeHandler} />
        </div>
      </div>
    );
  }

  return (
    <div className={`rounded-lg border ${colors.border} ${colors.bg} p-2.5 space-y-2`}>
      {/* Slot header */}
      <div className="flex items-center gap-2">
        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${colors.dot}`} />
        <Input
          value={localName}
          onChange={(e) => setLocalName(e.target.value)}
          onBlur={() => onUpdateAdvertiserName(localName)}
          placeholder={`Advertiser ${groupIdx + 1} name…`}
          className={`h-6 text-xs flex-1 border-0 bg-transparent px-1 font-medium ${colors.text} placeholder:text-slate-400 focus-visible:ring-0`}
        />

        {totalGroups > 1 && spotFrequency > 1 && (
          <div className="flex items-center gap-1 flex-shrink-0">
            <span className="text-[10px] text-slate-500">Offset:</span>
            <Select
              value={String(group.rotation_offset ?? groupIdx)}
              onValueChange={(v) => onUpdateOffset(Number(v))}
            >
              <SelectTrigger className="h-6 text-xs w-14 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: spotFrequency }, (_, i) => (
                  <SelectItem key={i} value={String(i)}>+{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {!isFixedSlot && (
          <Button
            variant="ghost"
            size="sm"
            className="h-5 w-5 p-0 text-slate-400 hover:text-red-500 flex-shrink-0"
            onClick={onDeleteSlot}
            title="Remove advertiser"
          >
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>

      {/* Creatives for this advertiser */}
      <div className="space-y-1.5 pl-4">
        {group.creatives.map((creative, idx) => (
          <RouteCreativeRow
            key={creative.id}
            creative={creative}
            index={idx}
            layoutZones={layoutZones}
            onUpdate={(data) => onUpdateCreative(creative.id, data)}
            onDelete={() => onDeleteCreative(creative.id)}
          />
        ))}
        {isFixedSlot && group.creatives.length === 0 && !group.isPlaceholder && (
          <GhostCreativeRowV2 key={`ghost-${group.rotation_offset}`} layoutZones={layoutZones} spotId={spotId} advertiserName={group.advertiser_name} rotationOffset={group.rotation_offset} onAddCreative={onAddCreativeHandler} />
        )}
        {canAddCreative && (
          <button
            className="text-[10px] text-slate-400 hover:text-blue-500 flex items-center gap-1 transition-colors"
            onClick={() => onAddCreativeHandler(spotId, { 
              rotation_offset: group.rotation_offset,
              advertiser_name: group.advertiser_name
            })}
          >
            <Plus className="w-3 h-3" /> Add creative
          </button>
        )}
      </div>
    </div>
  );
}

function GhostCreativeRowV2({ layoutZones, spotId, advertiserName, rotationOffset, onAddCreative }) {
  const handleAddCreative = () => {
    onAddCreative(spotId, { rotation_offset: rotationOffset, advertiser_name: advertiserName });
  };

  return (
    <div className="bg-white rounded p-1.5 border border-slate-100">
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-bold text-slate-400 w-3">1</span>
        <button
          onClick={handleAddCreative}
          className="flex-1 flex items-center gap-1.5 rounded px-2 py-1 border cursor-pointer text-xs border-slate-200 bg-white text-slate-500 hover:border-blue-300 transition-colors"
        >
          <Plus className="w-3 h-3" />
          <span>Add Creative</span>
        </button>
      </div>
    </div>
  );
}