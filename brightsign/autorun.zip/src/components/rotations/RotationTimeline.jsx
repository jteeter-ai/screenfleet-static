import React from "react";

const TIER_COLORS = {
  impact: "bg-blue-500",
  growth: "bg-emerald-500",
  launch: "bg-amber-500",
};

const TIER_LIGHT = {
  impact: "bg-blue-100 text-blue-700",
  growth: "bg-emerald-100 text-emerald-700",
  launch: "bg-amber-100 text-amber-700",
};

const TIER_SLOT_LIMITS = { impact: 1, growth: 2, launch: 4 };

// Shows 4 rotations visually so user can see the cycling pattern
export default function RotationTimeline({ spots, creatives }) {
  const rotations = [1, 2, 3, 4];

  const getCreativeForRotation = (spot, rotationNum) => {
    const rotIdx = rotationNum - 1; // 0-indexed

    const spotCreatives = creatives
      .filter((c) => c.route_spot_id === spot.id && c.is_active !== false)
      .sort((a, b) => a.order - b.order);

    if (spotCreatives.length === 0) return { empty: true };

    // Group by rotation_offset (stable advertiser slot identity)
    const slotMap = {};
    for (const c of spotCreatives) {
      const slot = c.rotation_offset ?? 0;
      if (!slotMap[slot]) slotMap[slot] = [];
      slotMap[slot].push(c);
    }

    // Sort slots numerically and enforce tier limit
    const maxSlots = TIER_SLOT_LIMITS[spot.tier] ?? 1;
    const slots = Object.keys(slotMap)
      .map(Number)
      .sort((a, b) => a - b)
      .slice(0, maxSlots);

    if (slots.length === 0) return null;

    // Interleave: slot = rotIdx % numSlots, depth = Math.floor(rotIdx / numSlots)
    const numSlots = slots.length;
    const slotKey = slots[rotIdx % numSlots];
    const slotCreatives = slotMap[slotKey];
    const depth = Math.floor(rotIdx / numSlots);
    return slotCreatives[depth % slotCreatives.length];
  };

  return (
    <div className="bg-slate-900 rounded-xl p-4 overflow-x-auto">
      <div className="text-xs text-slate-400 font-semibold uppercase tracking-widest mb-3">Rotation Preview (4 cycles)</div>
      <div className="min-w-[600px]">
        {/* Header */}
        <div className="grid grid-cols-5 gap-1 mb-2">
          <div className="text-[10px] text-slate-500 font-medium">Spot</div>
          {rotations.map((r) => (
            <div key={r} className="text-[10px] text-slate-400 font-medium text-center">
              Rotation {r}
            </div>
          ))}
        </div>

        {/* Rows */}
        {spots.map((spot) => (
          <div key={spot.id} className="grid grid-cols-5 gap-1 mb-1 items-center">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-500">#{spot.spot_number}</span>
              <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-semibold ${TIER_LIGHT[spot.tier]}`}>
                {spot.tier}
              </span>
            </div>
            {rotations.map((r) => {
              const creative = getCreativeForRotation(spot, r);
              if (!creative) {
                return (
                  <div key={r} className="h-8 rounded bg-slate-800 border border-slate-700 flex items-center justify-center">
                    <span className="text-[9px] text-slate-600">—</span>
                  </div>
                );
              }
              if (creative.empty) {
                return (
                  <div key={r} className={`h-8 rounded border border-dashed flex items-center justify-center ${TIER_COLORS[spot.tier]} opacity-30`}>
                    <span className="text-[9px] text-white">empty</span>
                  </div>
                );
              }
              return (
                <div
                  key={r}
                  className={`h-8 rounded flex items-center justify-center px-1 ${TIER_COLORS[spot.tier]} opacity-80`}
                  title={creative.advertiser_name || `Creative ${creative.order}`}
                >
                  <span className="text-[9px] text-white font-medium truncate">
                    {creative.advertiser_name || `C${creative.order}`}
                  </span>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}