import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, X, Film, ImageIcon, Trash2, Lock, Zap, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useOrg } from "@/components/OrgContext";

/**
 * RouteCreativeRow: Single creative within an advertiser slot in a RouteSpot
 * 
 * Props:
 * - creative: RouteCreative object
 * - index: order within advertiser group
 * - layoutZones: LayoutZone[] for zone structure + constraints
 * - onUpdate: (data) => void
 * - onDelete: () => void
 */
export default function RouteCreativeRow({
  creative,
  index,
  layoutZones = [],
  onUpdate,
  onDelete,
}) {
  const { activeOrgId } = useOrg();
  const [uploadingZoneId, setUploadingZoneId] = useState(null);
  const [uploadError, setUploadError] = useState(null); // { zoneId, message }
  const [studioPickerOpen, setStudioPickerOpen] = useState(false);
  const [studioPickerZoneId, setStudioPickerZoneId] = useState(null);
  const [studioCreatives, setStudioCreatives] = useState([]);
  const zoneAssignments = creative.zone_assignments || {};

  useEffect(() => {
    if (activeOrgId) {
      base44.entities.CanvasCreative.filter({ org_id: activeOrgId })
        .then(setStudioCreatives)
        .catch(() => setStudioCreatives([]));
    }
  }, [activeOrgId]);

  const handleFileUpload = async (e, zoneId) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingZoneId(zoneId);
    setUploadError(null);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const fileType = file.type.startsWith("video") ? "video" : "image";

      // Compute checksum for deduplication
      const checksumResult = await base44.functions.invoke("computeMediaAssetChecksum", { file_url });
      const { checksum, duplicate_of_asset_id } = checksumResult.data;

      // Use existing asset if duplicate, otherwise create new
      let mediaAssetId;
      if (duplicate_of_asset_id) {
        mediaAssetId = duplicate_of_asset_id;
        toast.info("Using existing media asset (duplicate)");
      } else {
        const asset = await base44.entities.MediaAsset.create({
          org_id: activeOrgId,
          name: file.name,
          file_url,
          file_type: fileType,
          checksum,
        });
        mediaAssetId = asset.id;
      }

      // Fetch latest creative from server before merging to prevent stale zone_assignments
      // overwriting assignments made by concurrent uploads to other zones
      const latestCreatives = await base44.entities.RouteCreative.filter({ route_spot_id: creative.route_spot_id });
      const latest = latestCreatives.find(c => c.id === creative.id);
      const merged = {
        ...(latest?.zone_assignments || {}),
        [zoneId]: { media_asset_id: mediaAssetId, file_url, file_type: fileType },
      };

      onUpdate({ zone_assignments: merged });
    } catch (err) {
      toast.error(`Upload failed: ${err.message}`);
      setUploadError({ zoneId, message: "Upload failed. Try again." });
    } finally {
      setUploadingZoneId(null);
    }
  };

  const handleRemoveZoneMedia = async (zoneId) => {
    // Always fetch latest from server to avoid stale merge overwriting other zones
    const latestCreatives = await base44.entities.RouteCreative.filter({ route_spot_id: creative.route_spot_id });
    const latest = latestCreatives.find(c => c.id === creative.id);
    const merged = { ...(latest?.zone_assignments || {}) };
    delete merged[zoneId];
    onUpdate({ zone_assignments: merged });
  };

  const handleSelectStudioCreative = (zoneId) => {
    setStudioPickerZoneId(zoneId);
    setStudioPickerOpen(true);
  };

  const handleApplyStudioCreative = async (selectedCreative) => {
    if (!studioPickerZoneId || !selectedCreative) return;
    const latestCreatives = await base44.entities.RouteCreative.filter({ route_spot_id: creative.route_spot_id });
    const latest = latestCreatives.find(c => c.id === creative.id);
    const merged = {
      ...(latest?.zone_assignments || {}),
      [studioPickerZoneId]: { content_type: 'canvas_creative', canvas_creative_id: selectedCreative.id },
    };
    onUpdate({ zone_assignments: merged });
    setStudioPickerOpen(false);
    setStudioPickerZoneId(null);
    toast.success('Studio creative assigned');
  };

  const getZoneUploadStatus = (zone) => {
    // ONLY lock uploads if zone is duplicated from another zone
    if (zone.duplicated_from_zone_id) {
      return {
        canUpload: false,
        label: "Inherits from another zone",
        icon: Lock,
      };
    }

    // All other zones allow upload
    return {
      canUpload: true,
      label: "Upload Media",
      icon: Upload,
    };
  };

  return (
    <div className="bg-white rounded p-1.5 border border-slate-100 space-y-1.5">
      {/* Creative header */}
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-bold text-slate-400 w-3">{index + 1}</span>

        <div className="flex items-center gap-1 text-xs text-slate-500">
          <Input
            type="number"
            min="1"
            placeholder="—"
            value={creative.dwell_time_override || ""}
            onChange={(e) => onUpdate({ dwell_time_override: e.target.value ? Number(e.target.value) : null })}
            className="h-6 w-10 text-xs px-1 text-center"
            title="Dwell override (seconds)"
          />
          <span>s</span>
        </div>

        <Button variant="ghost" size="sm" className="h-5 w-5 p-0 text-red-400 hover:text-red-600 flex-shrink-0" onClick={onDelete}>
          <Trash2 className="w-3 h-3" />
        </Button>
      </div>

      {/* Zone assignments */}
      {layoutZones.length > 0 && (
        <div className="pl-1.5 space-y-1">
          <Label className="text-[10px] text-slate-500 uppercase tracking-wide block mt-1">Assign to Zones</Label>
          {layoutZones.map((zone) => {
            const assignment = zoneAssignments[zone.id];
            const status = getZoneUploadStatus(zone);
            const StatusIcon = status.icon;
            const isUploadingThis = uploadingZoneId === zone.id;

            return (
              <div key={zone.id} className={`flex items-center gap-1.5 p-1 border border-slate-200 rounded bg-slate-50 text-xs ${isUploadingThis ? "opacity-60 pointer-events-none" : ""}`}>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-slate-700 truncate">{zone.name}</div>
                  <div className="text-[10px] text-slate-400">{zone.width}×{zone.height}px</div>
                  {uploadError?.zoneId === zone.id && (
                    <div className="text-[10px] text-red-500 mt-0.5">{uploadError.message}</div>
                  )}
                </div>

                {isUploadingThis ? (
                  <div className="flex items-center gap-1 px-1.5 py-0.5 border border-blue-200 rounded bg-blue-50 text-[10px] text-blue-600 flex-shrink-0">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    <span>Uploading…</span>
                  </div>
                ) : status.canUpload ? (
                  <>
                    <label className="flex items-center gap-1 px-1.5 py-0.5 border border-slate-300 rounded bg-white text-[10px] cursor-pointer hover:bg-slate-50 transition-colors flex-shrink-0">
                      {assignment?.content_type === 'canvas_creative' ? (
                        <>
                          <Zap className="w-3 h-3 flex-shrink-0 text-blue-500" />
                          <span className="truncate max-w-[60px]">Studio</span>
                          <button type="button" onClick={(e) => { e.preventDefault(); handleRemoveZoneMedia(zone.id); }} className="ml-auto -mr-0.5 hover:bg-red-100 rounded p-0.5">
                            <X className="w-2 h-2 text-red-500" />
                          </button>
                        </>
                      ) : assignment?.file_url ? (
                        <>
                          {assignment.file_type === "video" ? <Film className="w-3 h-3 flex-shrink-0" /> : <ImageIcon className="w-3 h-3 flex-shrink-0" />}
                          <span className="truncate max-w-[60px]" title={assignment.file_url?.split("/").pop()}>
                            {assignment.file_url?.split("/").pop()?.split("_").slice(1).join("_") || assignment.file_url?.split("/").pop()}
                          </span>
                          <button type="button" onClick={(e) => { e.preventDefault(); handleRemoveZoneMedia(zone.id); }} className="ml-auto -mr-0.5 hover:bg-red-100 rounded p-0.5">
                            <X className="w-2 h-2 text-red-500" />
                          </button>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3 h-3 flex-shrink-0" />
                          <span>Upload</span>
                        </>
                      )}
                      {!assignment && (
                        <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => handleFileUpload(e, zone.id)} disabled={!!uploadingZoneId} />
                      )}
                    </label>
                    {!assignment && (
                      <button onClick={() => handleSelectStudioCreative(zone.id)} className="flex items-center gap-1 px-1.5 py-0.5 border border-slate-300 rounded bg-white text-[10px] cursor-pointer hover:bg-blue-50 transition-colors text-blue-600 flex-shrink-0">
                        <Zap className="w-3 h-3" />
                        <span>Studio</span>
                      </button>
                    )}
                  </>
                ) : (
                  <div className="flex items-center gap-1 px-1.5 py-0.5 border border-slate-300 rounded bg-slate-100 text-[10px] text-slate-500 flex-shrink-0">
                    <StatusIcon className="w-3 h-3" />
                    <span>{status.label}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        )}

        {studioPickerOpen && (
        <Dialog open={studioPickerOpen} onOpenChange={setStudioPickerOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Select Studio Creative</DialogTitle></DialogHeader>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {studioCreatives.length === 0 && (
                <p className="text-sm text-slate-500 text-center py-4">No studio creatives found</p>
              )}
              {studioCreatives.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleApplyStudioCreative(c)}
                  className="w-full flex items-center gap-3 p-2 border border-slate-200 rounded hover:bg-blue-50 transition-colors text-left"
                >
                  <Zap className="w-4 h-4 text-blue-500 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-slate-700 truncate">{c.name}</div>
                    <div className="text-[10px] text-slate-400">{c.width}×{c.height}px</div>
                  </div>
                </button>
              ))}
            </div>
          </DialogContent>
        </Dialog>
        )}
        </div>
        );
        }