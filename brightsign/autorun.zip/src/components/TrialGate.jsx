import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { AlertTriangle, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TrialGate({ org }) {
  const endDate = org?.trial_ends_at ? new Date(org.trial_ends_at) : null;
  const formatted = endDate ? endDate.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 p-8 text-center">
        <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-5">
          <AlertTriangle className="w-8 h-8 text-amber-600" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 mb-2">Your Trial Has Expired</h2>
        {formatted && (
          <p className="text-sm text-slate-500 mb-1">Trial ended on {formatted}</p>
        )}
        <p className="text-sm text-slate-600 mt-3 mb-6">
          To continue using <strong>{org?.name || "your account"}</strong>, please select a plan and activate your subscription.
        </p>
        <Link to={createPageUrl("AppSettings")}>
          <Button className="bg-blue-600 hover:bg-blue-700 gap-2 w-full">
            <CreditCard className="w-4 h-4" />
            Select a Plan
          </Button>
        </Link>
        <p className="text-xs text-slate-400 mt-4">
          Questions? Contact support for assistance.
        </p>
      </div>
    </div>
  );
}