import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Check, Copy } from "lucide-react";
import { toast } from "sonner";

export default function WindowsPCSetupDialog({ open, onOpenChange }) {
  const [copied, setCopied] = useState(false);

  const downloadElectronFiles = () => {
    const files = {
      "electron-main.js": `const { app, BrowserWindow, screen } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');

let mainWindow;
let outputWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, 'electron-preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  const startUrl = isDev ? 'http://localhost:3000' : \`file://\${path.join(__dirname, '../build/index.html')}\`;
  mainWindow.loadURL(startUrl);
  if (isDev) mainWindow.webDevTools.openDevTools();
}

function createOutputWindow() {
  const displays = screen.getAllDisplays();
  const primaryDisplay = screen.getPrimaryDisplay();
  const secondaryDisplay = displays.find(d => d.id !== primaryDisplay.id);

  const targetDisplay = secondaryDisplay || primaryDisplay;
  const { x, y, width, height } = targetDisplay.bounds;

  outputWindow = new BrowserWindow({
    x, y, width, height,
    fullscreen: true,
    webPreferences: {
      preload: path.join(__dirname, 'electron-preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  const startUrl = isDev 
    ? \`http://localhost:3000?displayX=\${x}&displayY=\${y}&displayWidth=\${width}&displayHeight=\${height}\` 
    : \`file://\${path.join(__dirname, '../build/index.html')}?displayX=\${x}&displayY=\${y}&displayWidth=\${width}&displayHeight=\${height}\`;
  
  outputWindow.loadURL(startUrl);
  outputWindow.setFullScreen(true);
}

app.on('ready', () => {
  createWindow();
  setTimeout(() => createOutputWindow(), 1500);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (mainWindow === null) createWindow();
});`,

      "electron-preload.js": `const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getDisplayInfo: () => {
    const params = new URLSearchParams(window.location.search);
    return {
      displayX: parseInt(params.get('displayX')) || 0,
      displayY: parseInt(params.get('displayY')) || 0,
      displayWidth: parseInt(params.get('displayWidth')) || window.innerWidth,
      displayHeight: parseInt(params.get('displayHeight')) || window.innerHeight,
    };
  },
});`,

      "package.json-snippet": `{
  "main": "electron-main.js",
  "homepage": "./",
  "scripts": {
    "electron": "electron .",
    "electron-dev": "concurrently \\"npm start\\" \\"wait-on http://localhost:3000 && electron .\\""
  },
  "devDependencies": {
    "electron": "^latest",
    "electron-is-dev": "^latest",
    "concurrently": "^latest",
    "wait-on": "^latest"
  }
}`
    };

    // Create and download a text file with all contents
    const content = Object.entries(files)
      .map(([name, code]) => `\n${'='.repeat(60)}\n${name}\n${'='.repeat(60)}\n${code}`)
      .join('\n\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'windows-pc-electron-setup.txt';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    toast.success("Setup file downloaded - open and copy contents to your project");
  };

  const copyCommand = () => {
    navigator.clipboard.writeText('npm install electron electron-is-dev concurrently wait-on --save-dev');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Windows PC Setup - Electron Desktop App</DialogTitle>
          <DialogDescription>
            Follow these simple steps to set up automatic display detection on your PC
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Step 1 */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Badge className="bg-blue-600">1</Badge>
              <h3 className="font-semibold">Download Setup Files</h3>
            </div>
            <p className="text-sm text-slate-600 ml-10">Click below to download the configuration files you'll need:</p>
            <div className="ml-10">
              <Button onClick={downloadElectronFiles} className="gap-2 bg-blue-600 hover:bg-blue-700">
                <Download className="w-4 h-4" /> Download Setup File
              </Button>
            </div>
          </div>

          {/* Step 2 */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Badge className="bg-blue-600">2</Badge>
              <h3 className="font-semibold">Install Dependencies</h3>
            </div>
            <p className="text-sm text-slate-600 ml-10">Open PowerShell in your project folder and run:</p>
            <div className="ml-10 flex gap-2">
              <code className="flex-1 bg-slate-900 text-slate-100 p-3 rounded text-xs overflow-x-auto">
                npm install electron electron-is-dev concurrently wait-on --save-dev
              </code>
              <Button
                variant="outline"
                size="icon"
                onClick={copyCommand}
                className="flex-shrink-0"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Step 3 */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Badge className="bg-blue-600">3</Badge>
              <h3 className="font-semibold">Copy Files</h3>
            </div>
            <p className="text-sm text-slate-600 ml-10">Extract the downloaded file and copy these 2 files to your project root:</p>
            <div className="ml-10 space-y-1 text-sm font-mono bg-slate-50 p-3 rounded">
              <div>• electron-main.js</div>
              <div>• electron-preload.js</div>
            </div>
          </div>

          {/* Step 4 */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Badge className="bg-blue-600">4</Badge>
              <h3 className="font-semibold">Update package.json</h3>
            </div>
            <p className="text-sm text-slate-600 ml-10">Add these lines to your package.json:</p>
            <div className="ml-10 bg-slate-50 p-3 rounded text-xs space-y-1">
              <div><span className="text-slate-500">"main": </span><span className="text-green-700">"electron-main.js"</span>,</div>
              <div><span className="text-slate-500">"homepage": </span><span className="text-green-700">"./"</span>,</div>
              <div className="text-slate-500 mt-2">And add to "scripts":</div>
              <div><span className="text-slate-500">"electron": </span><span className="text-green-700">"electron ."</span></div>
            </div>
          </div>

          {/* Step 5 */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Badge className="bg-green-600">5</Badge>
              <h3 className="font-semibold">Run the App</h3>
            </div>
            <div className="ml-10 space-y-2">
              <div>
                <p className="text-xs text-slate-500 mb-1">Development:</p>
                <code className="bg-slate-900 text-slate-100 p-2 rounded text-xs block">npm run electron-dev</code>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Production (after build):</p>
                <code className="bg-slate-900 text-slate-100 p-2 rounded text-xs block">npm run build && electron .</code>
              </div>
            </div>
          </div>

          {/* What happens */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 ml-10 space-y-2">
            <p className="text-sm font-semibold text-green-900">✓ What happens next:</p>
            <ul className="text-xs text-green-800 space-y-1 list-disc list-inside">
              <li>App auto-detects your secondary monitor</li>
              <li>Fullscreen display launches automatically on extended screen</li>
              <li>You can control content from main monitor</li>
              <li>Everything is offline - no setup menus needed!</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}