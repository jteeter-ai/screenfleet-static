import React, { useState } from "react";
import { usePlayerOrigin } from "@/lib/playerUrls";
import { ChevronUp, ChevronDown, Tv2, Grid3x3, Copy, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function ScreenLayoutVisualizer({ screens, onScreenClick }) {
  const [selectedIdx, setSelectedIdx] = useState(null);
  // Player URLs point to the separate ScreenFleet Player app, not this CMS.
  const { origin: playerOrigin } = usePlayerOrigin();

  if (!screens || screens.length === 0) return null;

  // Calculate canvas bounds
  let minX = Infinity, maxX = -Infinity;
  let minY = Infinity, maxY = -Infinity;

  screens.forEach((s) => {
    const x = s.start_x || 0;
    const y = s.start_y || 0;
    const w = s.width || 512;
    const h = s.height || 512;
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x + w);
    maxY = Math.max(maxY, y + h);
  });

  if (minX === Infinity) return null;

  const canvasWidth = maxX - minX;
  const canvasHeight = maxY - minY;
  const scale = Math.min(400 / canvasWidth, 300 / canvasHeight, 1);
  const scaledWidth = canvasWidth * scale;
  const scaledHeight = canvasHeight * scale;

  const handleScreenClick = (idx) => {
    setSelectedIdx(idx);
    onScreenClick(idx);
  };

  const goToPrevious = () => {
    setSelectedIdx(selectedIdx === null || selectedIdx === 0 ? screens.length - 1 : selectedIdx - 1);
  };

  const cycleSelection = () => {
    setSelectedIdx(selectedIdx === null ? 0 : (selectedIdx + 1) % screens.length);
  };

  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 mt-4 space-y-3">
      <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
        Screen Layout Preview
      </p>

      <div className="flex items-start gap-3">
        <div
          className="relative border border-slate-300 bg-white rounded-sm flex-1"
          style={{
            width: `${scaledWidth}px`,
            height: `${scaledHeight}px`,
            overflow: "hidden",
          }}
        >
          {screens.map((screen, idx) => {
            const x = (screen.start_x || 0) - minX;
            const y = (screen.start_y || 0) - minY;
            const w = screen.width || 512;
            const h = screen.height || 512;
            const isSelected = selectedIdx === idx;

            return (
              <div
                key={idx}
                onClick={() => handleScreenClick(idx)}
                className={`absolute flex items-center justify-center text-[9px] font-medium overflow-hidden cursor-pointer transition-all ${
                  isSelected
                    ? "border-2 border-blue-600 bg-blue-100 z-10"
                    : "border border-slate-400 bg-blue-50 opacity-70 hover:opacity-100"
                }`}
                style={{
                  left: `${x * scale}px`,
                  top: `${y * scale}px`,
                  width: `${w * scale}px`,
                  height: `${h * scale}px`,
                  minWidth: "40px",
                  minHeight: "40px",
                }}
                title={`${screen.name || `Screen ${idx + 1}`}`}
              >
                {w * scale > 30 && h * scale > 30 && (
                  <span className={`text-center px-1 flex flex-col items-center gap-0.5 ${isSelected ? "text-blue-900" : "text-slate-600"}`}>
                    {screen.screen_mode === "tv"
                      ? <Tv2 className="w-3 h-3 opacity-60" />
                      : <Grid3x3 className="w-3 h-3 opacity-40" />
                    }
                    {screen.name || `Screen ${idx + 1}`}
                  </span>
                )}
              </div>
            );
          })}
        </div>

        <div className="flex flex-col gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6 text-slate-400 hover:text-slate-600"
            onClick={goToPrevious}
            title="Previous"
          >
            <ChevronUp className="w-3 h-3" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6 text-slate-400 hover:text-slate-600"
            onClick={cycleSelection}
            title="Next"
          >
            <ChevronDown className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {selectedIdx !== null && (() => {
        const s = screens[selectedIdx];
        const isTV = s.screen_mode === "tv";
        return (
          <div className="text-xs text-slate-500 px-3 py-2 bg-blue-50 rounded border border-blue-100 flex flex-wrap gap-x-4 gap-y-1">
            <span><span className="font-medium text-slate-700">Selected:</span> {s.name || `Screen ${selectedIdx + 1}`}</span>
            {isTV ? (
              <>
                <span><span className="font-medium text-slate-700">Type:</span> TV / Monitor</span>
                {s.width && s.height && <span><span className="font-medium text-slate-700">Resolution:</span> {s.width}×{s.height}px</span>}
                {s.tv_size && <span><span className="font-medium text-slate-700">Size:</span> {s.tv_size}</span>}
              </>
            ) : (
              <>
                {s.pixel_pitch && <span><span className="font-medium text-slate-700">Pitch:</span> P{s.pixel_pitch}mm</span>}
                {s.width && s.height && <span><span className="font-medium text-slate-700">Resolution:</span> {s.width}×{s.height}px</span>}
              </>
            )}
          </div>
        );
      })()}

      {selectedIdx !== null && screens[selectedIdx]?.id && (() => {
        const screenId = screens[selectedIdx].id;
        const liveUrl = playerOrigin ? `${playerOrigin}/player?screenId=${screenId}&preview=1` : null;
        return (
          <div className="text-xs px-3 py-2 bg-violet-50 rounded border border-violet-100 space-y-1.5">
            <div className="flex items-center gap-1.5 text-violet-700 font-medium">
              <Globe className="w-3 h-3" />
              HTML Live Output URL
            </div>
            {liveUrl ? (
              <div className="flex items-center gap-1.5">
                <input
                  readOnly
                  value={liveUrl}
                  className="flex-1 bg-white border border-violet-200 rounded px-2 py-1 text-[10px] text-slate-600 font-mono select-all"
                />
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-6 w-6 text-violet-500 hover:text-violet-700 flex-shrink-0"
                  onClick={() => { navigator.clipboard.writeText(liveUrl); toast.success("URL copied!"); }}
                  title="Copy URL"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            ) : (
              <p className="text-[10px] text-amber-700">
                ⚠️ Player app not configured. Set <strong>player_app_origin</strong> in AppConfig to generate URLs.
              </p>
            )}
          </div>
        );
      })()}
    </div>
  );
}