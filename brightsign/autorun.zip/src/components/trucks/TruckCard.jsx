import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Truck, Tv2, PanelTop, LayoutGrid, Monitor, Pencil, Trash2, MapPin, Copy, ChevronDown, ChevronUp } from "lucide-react";
import ScreenSpecBadges from "@/components/screens/ScreenSpecBadges";
import ScreenStatusCard from "./ScreenStatusCard";

const statusColors = {
  active: "bg-emerald-50 text-emerald-700 border-emerald-200",
  inactive: "bg-slate-100 text-slate-500 border-slate-200",
  maintenance: "bg-amber-50 text-amber-700 border-amber-200",
};

const ASSET_ICONS = {
  truck: Truck,
  trailer: Tv2,
  poster_panel: PanelTop,
  video_wall: LayoutGrid,
};

const ASSET_LABELS = {
  truck: "TRUCK",
  trailer: "TRAILER",
  poster_panel: "POSTER PANEL",
  video_wall: "VIDEO WALL",
  tv: "TV",
};

export default function TruckCard({ truck, screenCount, screens = [], onEdit, onDelete, onDuplicate, onManageScreens }) {
  const [expanded, setExpanded] = useState(false);
  const Icon = ASSET_ICONS[truck.asset_type] || Truck;
  const assetLabel = ASSET_LABELS[truck.asset_type] || "ASSET";
  const visibleScreens = expanded ? screens : screens.slice(0, 2);

  return (
    <Card className="border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
            <Icon className="w-5 h-5 text-slate-500" />
          </div>
          <div className="min-w-0">
            <h3 className="font-semibold text-slate-900 text-sm truncate">{truck.name}</h3>
            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">{assetLabel}</span>
              {truck.location && (
                <>
                  <span className="text-slate-300">·</span>
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    <span className="text-[11px] text-slate-400 truncate max-w-[120px]">{truck.location}</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
        <Badge variant="outline" className={`text-xs flex-shrink-0 ${statusColors[truck.status] || statusColors.inactive}`}>
          {truck.status}
        </Badge>
      </div>

      {/* Screens */}
      {screens.length > 0 && (
        <div className="px-4 pb-2 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            {visibleScreens.map(s => (
              <ScreenStatusCard key={s.id} screen={s} />
            ))}
          </div>
          {screens.length > 2 && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="w-full flex items-center justify-center gap-1 text-xs text-slate-400 hover:text-slate-600 py-1"
            >
              {expanded ? <><ChevronUp className="w-3 h-3" /> Show less</> : <><ChevronDown className="w-3 h-3" /> +{screens.length - 2} more</>}
            </button>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="mt-auto px-4 py-3 border-t border-slate-100 flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
            <Monitor className="w-3.5 h-3.5 flex-shrink-0" />
            <span>{truck.screen_count} screen{truck.screen_count !== 1 ? "s" : ""}</span>
            <span className="text-slate-300">·</span>
            <span>{screenCount} active</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {screens.slice(0, 2).map(s => (
              <ScreenSpecBadges key={s.id} screen={s} compact />
            ))}
          </div>
        </div>

        <div className="flex gap-0.5 flex-shrink-0">
          <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-blue-600" onClick={() => onManageScreens(truck)} title="Manage Screens">
            <Monitor className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-slate-600" onClick={() => onEdit(truck)} title="Edit">
            <Pencil className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-emerald-600" onClick={() => onDuplicate(truck)} title="Duplicate">
            <Copy className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-500" onClick={() => onDelete(truck)} title="Delete">
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </Card>
  );
}