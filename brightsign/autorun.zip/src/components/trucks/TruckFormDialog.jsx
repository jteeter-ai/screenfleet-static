import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import TruckPlayerSetup from "@/components/trucks/TruckPlayerSetup";

const ASSET_TYPES = [
  { value: "truck", label: "Truck" },
  { value: "trailer", label: "Trailer" },
  { value: "poster_panel", label: "Poster Panel" },
  { value: "video_wall", label: "Video Wall" },
  { value: "tv", label: "TV" },
];

const DEFAULT_SCREEN_COUNTS = {
  truck: 3,
  trailer: 3,
  poster_panel: 1,
  video_wall: 1,
  tv: 1,
};

export default function TruckFormDialog({ open, onOpenChange, truck, onSave }) {
  const [form, setForm] = useState({
    name: "",
    asset_type: "truck",
    description: "",
    screen_count: 3,
    status: "active",
    location: "",
    tv_resolution: "1080p",
    player_type: "none",
    player_ip: "",
    player_serial: "",
    player_hostname: "",
    player_username: "",
    player_password: "",
    player_html_url: "",
    player_notes: "",
    player_model: "",
    novastar_model: "",
    novastar_ip: "",
  });

  useEffect(() => {
    if (truck) {
      setForm({
        name: truck.name || "",
        asset_type: truck.asset_type || "truck",
        description: truck.description || "",
        screen_count: truck.screen_count || 3,
        status: truck.status || "active",
        location: truck.location || "",
        tv_resolution: truck.tv_resolution || "1080p",
        player_type: truck.player_type || "none",
        player_ip: truck.player_ip || "",
        player_serial: truck.player_serial || "",
        player_hostname: truck.player_hostname || "",
        player_username: truck.player_username || "",
        player_password: truck.player_password || "",
        player_html_url: truck.player_html_url || "",
        player_notes: truck.player_notes || "",
        player_model: truck.player_model || "",
        novastar_model: truck.novastar_model || "",
        novastar_ip: truck.novastar_ip || "",
      });
    } else {
      setForm({
        name: "",
        asset_type: "truck",
        description: "",
        screen_count: 3,
        status: "active",
        location: "",
        tv_resolution: "1080p",
        player_type: "none",
        player_ip: "",
        player_serial: "",
        player_hostname: "",
        player_username: "",
        player_password: "",
        player_html_url: "",
        player_notes: "",
        player_model: "",
        novastar_model: "",
        novastar_ip: "",
      });
    }
  }, [truck, open]);

  const handleAssetTypeChange = (v) => {
    setForm({ ...form, asset_type: v, screen_count: DEFAULT_SCREEN_COUNTS[v] ?? 1 });
  };

  const handleSave = () => {
    onSave({ ...form, screen_count: Number(form.screen_count) });
  };

  const isEditing = !!truck;
  const assetLabel = ASSET_TYPES.find((t) => t.value === form.asset_type)?.label || "Asset";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? `Edit ${assetLabel}` : "Add Asset"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div>
            <Label>Asset Type</Label>
            <Select value={form.asset_type} onValueChange={handleAssetTypeChange}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {ASSET_TYPES.map((t) => (
                  <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Name</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={`${assetLabel} 01`} />
          </div>
          <div>
            <Label>Description</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder={`Notes about this ${assetLabel.toLowerCase()}`} rows={2} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Screen Count</Label>
              <Select value={String(form.screen_count)} onValueChange={(v) => setForm({ ...form, screen_count: Number(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Screen</SelectItem>
                  <SelectItem value="2">2 Screens</SelectItem>
                  <SelectItem value="3">3 Screens</SelectItem>
                  <SelectItem value="4">4 Screens</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          {form.asset_type === "tv" && (
            <div>
              <Label>TV Resolution</Label>
              <Select value={form.tv_resolution} onValueChange={(v) => setForm({ ...form, tv_resolution: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1080p">1080p (1920x1080)</SelectItem>
                  <SelectItem value="4k">4K (3840x2160)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
          <div>
            <Label>Location</Label>
            <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="City, venue, or route" />
          </div>

          <TruckPlayerSetup truck={{ ...form, id: truck?.id }} onChange={(field, value) => setForm({ ...form, [field]: value })} />
          </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={!form.name}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}