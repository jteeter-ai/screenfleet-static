import React, { useState } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ScreenLayoutCard({ screens }) {
  const [selectedIdx, setSelectedIdx] = useState(null);

  if (!screens || screens.length === 0) return null;

  // Calculate canvas bounds based on x,y positions and dimensions
  let minX = Infinity, maxX = -Infinity;
  let minY = Infinity, maxY = -Infinity;

  screens.forEach((s) => {
    const x = s.start_x || 0;
    const y = s.start_y || 0;
    const w = s.width || 512;
    const h = s.height || 512;
    
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x + w);
    maxY = Math.max(maxY, y + h);
  });

  if (minX === Infinity) return null;

  const canvasWidth = maxX - minX;
  const canvasHeight = maxY - minY;
  
  // Scale to fit in compact card space (max 240px width)
  const scale = Math.min(240 / canvasWidth, 120 / canvasHeight, 1);
  const scaledWidth = canvasWidth * scale;
  const scaledHeight = canvasHeight * scale;

  const cycleSelection = () => {
    setSelectedIdx(selectedIdx === null ? 0 : (selectedIdx + 1) % screens.length);
  };

  const goToPrevious = () => {
    setSelectedIdx(selectedIdx === null || selectedIdx === 0 ? screens.length - 1 : selectedIdx - 1);
  };

  return (
    <div className="mb-3 space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex justify-center flex-1">
          <div
            className="relative border border-slate-300 bg-white rounded-sm"
            style={{
              width: `${scaledWidth}px`,
              height: `${scaledHeight}px`,
              overflow: "hidden",
            }}
          >
            {screens.map((screen, idx) => {
              const x = (screen.start_x || 0) - minX;
              const y = (screen.start_y || 0) - minY;
              const w = screen.width || 512;
              const h = screen.height || 512;
              const isSelected = selectedIdx === idx;

              return (
                <div
                  key={idx}
                  className={`absolute flex items-center justify-center text-[9px] font-medium overflow-hidden cursor-pointer transition-all ${
                    isSelected
                      ? "border-2 border-blue-600 bg-blue-100 z-10"
                      : "border border-slate-400 bg-blue-50 opacity-70 hover:opacity-100"
                  }`}
                  style={{
                    left: `${x * scale}px`,
                    top: `${y * scale}px`,
                    width: `${w * scale}px`,
                    height: `${h * scale}px`,
                    minWidth: "20px",
                    minHeight: "20px",
                  }}
                  onClick={() => setSelectedIdx(idx)}
                  title={`${screen.name || `Screen ${idx + 1}`}: ${w}×${h}px @ (${screen.start_x || 0}, ${screen.start_y || 0})`}
                >
                  {w * scale > 25 && h * scale > 20 && (
                    <span className={`text-center px-0.5 ${isSelected ? "text-blue-900" : "text-slate-600"}`}>
                      {screen.name || `S${idx + 1}`}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6 text-slate-400 hover:text-slate-600"
            onClick={goToPrevious}
            title="Previous layer"
          >
            <ChevronUp className="w-3 h-3" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6 text-slate-400 hover:text-slate-600"
            onClick={cycleSelection}
            title="Next layer"
          >
            <ChevronDown className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {selectedIdx !== null && (
        <div className="text-xs text-slate-500 px-2 py-1 bg-blue-50 rounded border border-blue-100">
          <span className="font-medium text-slate-700">Selected:</span> {screens[selectedIdx].name || `Screen ${selectedIdx + 1}`}
        </div>
      )}
    </div>
  );
}