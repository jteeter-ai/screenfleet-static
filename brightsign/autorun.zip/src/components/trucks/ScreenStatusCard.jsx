import React from "react";
import { Badge } from "@/components/ui/badge";
import { Dot } from "lucide-react";
import ScreenLivePreview from "@/components/screens/ScreenLivePreview";

export default function ScreenStatusCard({ screen }) {
  const isOnline = screen.status === "online";

  return (
    <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
      {/* Snapshot Preview */}
      <div className="relative h-24 bg-slate-900 flex items-center justify-center overflow-hidden">
        {isOnline ? (
          <div className="w-full h-full">
            <ScreenLivePreview screenId={screen.id} fitToContainer containerHeight={96} />
          </div>
        ) : (
          <span className="text-[10px] text-slate-500">Offline</span>
        )}
      </div>

      {/* Info */}
      <div className="p-3 space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-semibold text-slate-900">{screen.name}</h4>
          <Badge variant="outline" className={`text-[10px] flex items-center gap-1 ${
            isOnline ? "bg-green-50 text-green-700 border-green-200" : "bg-slate-100 text-slate-500 border-slate-200"
          }`}>
            <Dot className={`w-1.5 h-1.5 ${isOnline ? "fill-green-500 text-green-500" : "fill-slate-400 text-slate-400"}`} />
            {isOnline ? "Online" : "Offline"}
          </Badge>
        </div>
        <div className="text-[10px] text-slate-500">
          <div>{screen.width}×{screen.height}px</div>
        </div>
      </div>
    </div>
  );
}