import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Monitor, Copy, ChevronDown, ChevronUp, Ruler, Grid3x3, Cpu, Tv2 } from "lucide-react";
import { toast } from "sonner";
import ScreenLayoutVisualizer from "./ScreenLayoutVisualizer";
import ScreenContentDialog from "./ScreenContentDialog";


const POSITION_LABELS = {
  left_side: "Driver Side",
  right_side: "Passenger Side",
  rear: "Rear",
  front: "Front",
  custom: "Custom",
};

function numF(v) { return v !== undefined && v !== null && v !== "" ? `${v}` : ""; }

// Auto-calculates panel pixel dims and total screen resolution + physical size
function recalcScreen(screen) {
  const s = { ...screen };
  const pitch = parseFloat(s.pixel_pitch);
  const pw = parseFloat(s.panel_width_mm);
  const ph = parseFloat(s.panel_height_mm);
  const cols = parseInt(s.matrix_cols) || 1;
  const rows = parseInt(s.matrix_rows) || 1;

  if (pitch > 0 && pw > 0) s.panel_pixel_width = Math.round(pw / pitch);
  if (pitch > 0 && ph > 0) s.panel_pixel_height = Math.round(ph / pitch);
  if (s.panel_pixel_width) s.width = s.panel_pixel_width * cols;
  if (s.panel_pixel_height) s.height = s.panel_pixel_height * rows;
  if (pw > 0) s.physical_width_mm = pw * cols;
  if (ph > 0) s.physical_height_mm = ph * rows;
  return s;
}

function mmToFeetInches(mm) {
  if (!mm) return null;
  const totalInches = mm / 25.4;
  const feet = Math.floor(totalInches / 12);
  const inches = (totalInches % 12).toFixed(1);
  return feet > 0 ? `${feet}' ${inches}"` : `${inches}"`;
}

const TV_PRESETS = [
  { label: "1080p (1920×1080)", width: 1920, height: 1080 },
  { label: "1080p Portrait (1080×1920)", width: 1080, height: 1920 },
  { label: "1440p (2560×1440)", width: 2560, height: 1440 },
  { label: "4K (3840×2160)", width: 3840, height: 2160 },
  { label: "4K Portrait (2160×3840)", width: 2160, height: 3840 },
  { label: "720p (1280×720)", width: 1280, height: 720 },
];

const TV_SIZES = ["32\"", "40\"", "43\"", "50\"", "55\"", "65\"", "75\"", "85\"", "98\""];

function ScreenCard({ screen, index, cabinetTypes, controllerTypes, onChange, onRemove, canRemove }) {
  const [expanded, setExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState("led");
  const isTV = screen.screen_mode === "tv";

  const resolutionText = screen.width && screen.height ? `${screen.width}×${screen.height}px` : "—";
  const physicalText = screen.physical_width_mm && screen.physical_height_mm
    ? `${(screen.physical_width_mm / 1000).toFixed(2)}m × ${(screen.physical_height_mm / 1000).toFixed(2)}m`
    : null;
  const imperialText = screen.physical_width_mm ? mmToFeetInches(screen.physical_width_mm) + " × " + mmToFeetInches(screen.physical_height_mm) : null;

  const handleChange = (field, value, isNum = false) => {
    let updated = { ...screen, [field]: isNum ? (value === "" ? "" : Number(value)) : value };

    // Trigger recalc on LED spec or matrix changes
    if (["pixel_pitch", "panel_width_mm", "panel_height_mm", "matrix_cols", "matrix_rows"].includes(field)) {
      updated = recalcScreen(updated);
    }
    onChange(index, updated);
  };

  const handleTVPreset = (presetLabel) => {
    const preset = TV_PRESETS.find(p => p.label === presetLabel);
    if (preset) {
      onChange(index, { ...screen, width: preset.width, height: preset.height, tv_preset: presetLabel });
    }
  };

  const handleScreenModeChange = (mode) => {
    onChange(index, { ...screen, screen_mode: mode });
  };

  const TABS = isTV
    ? [{ id: "tv", label: "TV Settings", icon: Tv2 }]
    : [
        { id: "led", label: "LED Specs", icon: Ruler },
        { id: "matrix", label: "Matrix & Size", icon: Grid3x3 },
        { id: "controller", label: "Controller", icon: Cpu },
        { id: "player", label: "Player", icon: Tv2 },
      ];

  return (
    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
      {/* Screen header */}
      <div
        className="flex items-center justify-between px-4 py-3 bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
            <Monitor className="w-4 h-4 text-blue-600" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-800">{screen.name || `Screen ${index + 1}`}</p>
            <div className="flex items-center gap-2 flex-wrap mt-0.5">
              {screen.pixel_pitch && (
                <span className="text-[10px] text-slate-400">P{screen.pixel_pitch}</span>
              )}
              {resolutionText !== "—" && (
                <Badge variant="outline" className="text-[10px] py-0 h-4 text-blue-700 border-blue-200 bg-blue-50">{resolutionText}</Badge>
              )}
              {physicalText && (
                <span className="text-[10px] text-slate-400">{physicalText}</span>
              )}
              {imperialText && (
                <span className="text-[10px] text-slate-400">({imperialText})</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {canRemove && (
            <Button variant="ghost" size="icon" className="h-7 w-7 text-red-400 hover:text-red-600 hover:bg-red-50"
              onClick={(e) => { e.stopPropagation(); onRemove(index); }}>
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          )}
          {expanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </div>
      </div>

      {expanded && (
        <div className="p-4 space-y-4">
          {/* Screen Mode Toggle */}
          <div className="flex gap-2">
            <button
              onClick={() => { handleScreenModeChange("led"); setActiveTab("led"); }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg border text-sm font-medium transition-all ${
                !isTV ? "bg-blue-50 border-blue-300 text-blue-700" : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"
              }`}
            >
              <Grid3x3 className="w-4 h-4" /> LED Screen
            </button>
            <button
              onClick={() => { handleScreenModeChange("tv"); setActiveTab("tv"); }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg border text-sm font-medium transition-all ${
                isTV ? "bg-blue-50 border-blue-300 text-blue-700" : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"
              }`}
            >
              <Tv2 className="w-4 h-4" /> TV / Monitor
            </button>
          </div>

          {/* Name + Position + Status */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-slate-500">Screen Name</Label>
              <Input value={screen.name || ""} onChange={(e) => handleChange("name", e.target.value)} className="h-8 mt-1" placeholder="e.g. Left Side" />
            </div>
            <div>
              <Label className="text-xs text-slate-500">Position</Label>
              <Select value={screen.position || "custom"} onValueChange={(v) => handleChange("position", v)}>
                <SelectTrigger className="h-8 mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="left_side">Driver Side</SelectItem>
                  <SelectItem value="right_side">Passenger Side</SelectItem>
                  <SelectItem value="rear">Rear</SelectItem>
                  <SelectItem value="front">Front</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          {/* Status */}
          <div>
            <Label className="text-xs text-slate-500">Status</Label>
            <Select value={screen.status || "offline"} onValueChange={(v) => handleChange("status", v)}>
              <SelectTrigger className="h-8 mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="online">Online</SelectItem>
                <SelectItem value="offline">Offline</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tab navigation */}
          <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-medium py-1.5 rounded-md transition-all ${
                    activeTab === tab.id ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* TV Settings Tab */}
          {activeTab === "tv" && (
            <div className="space-y-4">
              <div>
                <Label className="text-xs text-slate-500">Resolution Preset</Label>
                <Select value={screen.tv_preset || ""} onValueChange={handleTVPreset}>
                  <SelectTrigger className="h-9 mt-1"><SelectValue placeholder="Select resolution…" /></SelectTrigger>
                  <SelectContent>
                    {TV_PRESETS.map(p => (
                      <SelectItem key={p.label} value={p.label}>{p.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-slate-500">Width (px)</Label>
                  <Input type="number" min="0" value={numF(screen.width)} onChange={(e) => handleChange("width", e.target.value, true)} className="h-8 mt-1" placeholder="1920" />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Height (px)</Label>
                  <Input type="number" min="0" value={numF(screen.height)} onChange={(e) => handleChange("height", e.target.value, true)} className="h-8 mt-1" placeholder="1080" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-slate-500">Screen Size (diagonal)</Label>
                  <Select value={screen.tv_size || ""} onValueChange={(v) => handleChange("tv_size", v)}>
                    <SelectTrigger className="h-8 mt-1"><SelectValue placeholder="Select size…" /></SelectTrigger>
                    <SelectContent>
                      {TV_SIZES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Canvas Start X (px)</Label>
                  <Input type="number" value={numF(screen.start_x)} onChange={(e) => handleChange("start_x", e.target.value, true)} className="h-8 mt-1" placeholder="0" />
                </div>
              </div>
              {screen.width && screen.height && (
                <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 text-xs text-blue-700">
                  <span className="font-medium">Resolution:</span> {screen.width}×{screen.height}px
                  {screen.tv_size && <span className="ml-3"><span className="font-medium">Size:</span> {screen.tv_size}</span>}
                </div>
              )}
              {/* Live Output URL */}
              {screen.id && (
               <div className="rounded-lg border border-slate-200 p-3 space-y-1.5">
                 <p className="text-xs font-semibold text-slate-600 flex items-center gap-1.5">
                   <Monitor className="w-3 h-3" /> Live Output URL
                 </p>
                 <div className="flex items-center gap-2 bg-slate-50 rounded-md px-2 py-1.5">
                  <code className="text-[10px] text-slate-500 flex-1 truncate">
                    {`https://app.screenfleet.io/ScreenPlayer?screenId=${screen.id}`}
                  </code>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-blue-600"
                    onClick={() => { navigator.clipboard.writeText(`https://app.screenfleet.io/ScreenPlayer?screenId=${screen.id}`); toast.success("URL copied"); }}>
                    <Copy className="w-3 h-3" />
                  </Button>
                 </div>
               </div>
              )}
            </div>
          )}

          {/* LED Specs Tab */}
          {activeTab === "led" && (
            <div className="space-y-3">
              <p className="text-[11px] text-slate-400 font-medium uppercase tracking-wide">LED Panel Specifications</p>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-xs text-slate-500">Pixel Pitch (mm)</Label>
                  <Input type="number" step="0.1" min="0" value={numF(screen.pixel_pitch)} onChange={(e) => handleChange("pixel_pitch", e.target.value, true)} className="h-8 mt-1" placeholder="e.g. 3.9" />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Panel Width (mm)</Label>
                  <Input type="number" min="0" value={numF(screen.panel_width_mm)} onChange={(e) => handleChange("panel_width_mm", e.target.value, true)} className="h-8 mt-1" placeholder="e.g. 500" />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Panel Height (mm)</Label>
                  <Input type="number" min="0" value={numF(screen.panel_height_mm)} onChange={(e) => handleChange("panel_height_mm", e.target.value, true)} className="h-8 mt-1" placeholder="e.g. 500" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-slate-500">Module Width (mm)</Label>
                  <Input type="number" min="0" value={numF(screen.module_width_mm)} onChange={(e) => handleChange("module_width_mm", e.target.value, true)} className="h-8 mt-1" placeholder="e.g. 250" />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Module Height (mm)</Label>
                  <Input type="number" min="0" value={numF(screen.module_height_mm)} onChange={(e) => handleChange("module_height_mm", e.target.value, true)} className="h-8 mt-1" placeholder="e.g. 250" />
                </div>
              </div>

              {/* Auto-calc panel pixel dims — editable override */}
              <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 space-y-2">
                <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wide">Panel Pixel Dimensions <span className="normal-case text-slate-400">(auto-calculated — override if needed)</span></p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-slate-500">Pixels per Panel (W)</Label>
                    <Input type="number" min="0" value={numF(screen.panel_pixel_width)} onChange={(e) => handleChange("panel_pixel_width", e.target.value, true)} className="h-8 mt-1" placeholder="auto" />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Pixels per Panel (H)</Label>
                    <Input type="number" min="0" value={numF(screen.panel_pixel_height)} onChange={(e) => handleChange("panel_pixel_height", e.target.value, true)} className="h-8 mt-1" placeholder="auto" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Matrix & Size Tab */}
          {activeTab === "matrix" && (
            <div className="space-y-3">
              <p className="text-[11px] text-slate-400 font-medium uppercase tracking-wide">Panel Matrix Configuration</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-slate-500">Panels Across (Columns)</Label>
                  <Input type="number" min="1" value={numF(screen.matrix_cols)} onChange={(e) => handleChange("matrix_cols", e.target.value, true)} className="h-8 mt-1" placeholder="1" />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Panels Tall (Rows)</Label>
                  <Input type="number" min="1" value={numF(screen.matrix_rows)} onChange={(e) => handleChange("matrix_rows", e.target.value, true)} className="h-8 mt-1" placeholder="1" />
                </div>
              </div>

              {/* Auto-calculated totals — overridable */}
              <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 space-y-2">
                <p className="text-[10px] font-medium text-blue-700 uppercase tracking-wide">Total Screen Size <span className="normal-case text-blue-500">(auto-calculated — override if needed)</span></p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-slate-500">Resolution Width (px)</Label>
                    <Input type="number" min="0" value={numF(screen.width)} onChange={(e) => handleChange("width", e.target.value, true)} className="h-8 mt-1 bg-white" placeholder="auto" />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Resolution Height (px)</Label>
                    <Input type="number" min="0" value={numF(screen.height)} onChange={(e) => handleChange("height", e.target.value, true)} className="h-8 mt-1 bg-white" placeholder="auto" />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Physical Width (mm)</Label>
                    <Input type="number" min="0" value={numF(screen.physical_width_mm)} onChange={(e) => handleChange("physical_width_mm", e.target.value, true)} className="h-8 mt-1 bg-white" placeholder="auto" />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Physical Height (mm)</Label>
                    <Input type="number" min="0" value={numF(screen.physical_height_mm)} onChange={(e) => handleChange("physical_height_mm", e.target.value, true)} className="h-8 mt-1 bg-white" placeholder="auto" />
                  </div>
                </div>
                {screen.physical_width_mm && screen.physical_height_mm && (
                  <div className="pt-2 border-t border-blue-200 grid grid-cols-2 gap-2 text-xs text-blue-700">
                    <div>
                      <span className="text-[10px] text-blue-500">Metric: </span>
                      {(screen.physical_width_mm / 1000).toFixed(3)}m × {(screen.physical_height_mm / 1000).toFixed(3)}m
                    </div>
                    <div>
                      <span className="text-[10px] text-blue-500">Imperial: </span>
                      {mmToFeetInches(screen.physical_width_mm)} × {mmToFeetInches(screen.physical_height_mm)}
                    </div>
                    <div>
                      <span className="text-[10px] text-blue-500">Total area: </span>
                      {((screen.physical_width_mm * screen.physical_height_mm) / 1_000_000).toFixed(2)} m²
                    </div>
                    {screen.pixel_pitch && (
                      <div>
                        <span className="text-[10px] text-blue-500">Pitch: </span>
                        P{screen.pixel_pitch}mm
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Canvas/output positioning */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-slate-500">Canvas Start X (px)</Label>
                  <Input type="number" value={numF(screen.start_x)} onChange={(e) => handleChange("start_x", e.target.value, true)} className="h-8 mt-1" placeholder="0" />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Canvas Start Y (px)</Label>
                  <Input type="number" value={numF(screen.start_y)} onChange={(e) => handleChange("start_y", e.target.value, true)} className="h-8 mt-1" placeholder="0" />
                </div>
              </div>
            </div>
          )}

          {/* Controller Tab */}
          {activeTab === "controller" && (
            <div className="space-y-3">
              <p className="text-[11px] text-slate-400 font-medium uppercase tracking-wide">LED Controller Setup</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-slate-500">Controller Model</Label>
                  <Select value={screen.controller_type_id || ""} onValueChange={(v) => handleChange("controller_type_id", v)}>
                    <SelectTrigger className="h-8 mt-1"><SelectValue placeholder="Select…" /></SelectTrigger>
                    <SelectContent>
                      {controllerTypes.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.model}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                   <Label className="text-xs text-slate-500">Output Port</Label>
                   <Select value={String(screen.controller_port || 1)} onValueChange={(v) => handleChange("controller_port", v, true)}>
                     <SelectTrigger className="h-8 mt-1"><SelectValue /></SelectTrigger>
                     <SelectContent>
                       {(() => {
                         const selectedController = controllerTypes.find(c => c.id === screen.controller_type_id);
                         const maxPorts = selectedController?.output_ports || 4;
                         return Array.from({ length: maxPorts }, (_, i) => i + 1).map(p => (
                           <SelectItem key={p} value={String(p)}>Port {p}</SelectItem>
                         ));
                       })()}
                     </SelectContent>
                   </Select>
                 </div>
              </div>
              <div>
                <Label className="text-xs text-slate-500">Cabinet Type (optional)</Label>
                <Select value={screen.cabinet_type_id || ""} onValueChange={(v) => handleChange("cabinet_type_id", v)}>
                  <SelectTrigger className="h-8 mt-1"><SelectValue placeholder="Select cabinet…" /></SelectTrigger>
                  <SelectContent>
                    {cabinetTypes.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.model}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Live Output URL */}
              {screen.id && (
                <div className="rounded-lg border border-slate-200 p-3 space-y-1.5 mt-2">
                  <p className="text-xs font-semibold text-slate-600 flex items-center gap-1.5">
                    <Monitor className="w-3 h-3" /> Live Output URL
                  </p>
                  <div className="flex items-center gap-2 bg-slate-50 rounded-md px-2 py-1.5">
                    <code className="text-[10px] text-slate-500 flex-1 truncate">
                      {`https://app.screenfleet.io/ScreenPlayer?screenId=${screen.id}`}
                    </code>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-blue-600"
                      onClick={() => { navigator.clipboard.writeText(`https://app.screenfleet.io/ScreenPlayer?screenId=${screen.id}`); toast.success("URL copied"); }}>
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Player Tab — Moved to truck level */}
           {activeTab === "player" && (
             <div className="text-center py-6 text-slate-500 text-sm">
               <p>Player configuration is set at the asset level.</p>
               <p className="text-xs mt-2">Go to Asset settings to configure the BrightSign or Windows PC player.</p>
             </div>
           )}
        </div>
      )}
    </div>
  );
}

export default function ScreenSetupDialog({ open, onOpenChange, truck }) {
  const queryClient = useQueryClient();
  const [screens, setScreens] = useState([]);
  const [saving, setSaving] = useState(false);
  const [contentDialogOpen, setContentDialogOpen] = useState(false);
  const [selectedScreenIdx, setSelectedScreenIdx] = useState(null);

  const { data: existingScreens = [] } = useQuery({
    queryKey: ["screens", truck?.id],
    queryFn: () => base44.entities.Screen.filter({ truck_id: truck?.id }),
    enabled: !!truck?.id && open,
    staleTime: 0,
    refetchOnWindowFocus: false,
    refetchOnMount: true,
  });

  const { data: cabinetTypes = [] } = useQuery({
    queryKey: ["cabinetTypes"],
    queryFn: () => base44.entities.CabinetType.list(),
    enabled: open,
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  const { data: controllerTypes = [] } = useQuery({
    queryKey: ["controllerTypes"],
    queryFn: () => base44.entities.ControllerType.list(),
    enabled: open,
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  const newBlankScreen = (truck, pos = "custom") => ({
    truck_id: truck?.id,
    name: POSITION_LABELS[pos] || "Screen",
    position: pos,
    matrix_cols: 1,
    matrix_rows: 1,
    controller_port: 1,
    start_x: 0,
    start_y: 0,
    status: "offline",
  });

  useEffect(() => {
    if (!open) {
      setScreens([]);
      return;
    }
    // Force a fresh fetch when dialog opens
    queryClient.invalidateQueries({ queryKey: ["screens", truck?.id] });
  }, [open, truck?.id, queryClient]);

  useEffect(() => {
    if (!open || !truck?.id) return;
    if (existingScreens.length > 0) {
      setScreens(existingScreens.map(s => ({ ...s })));
    } else if (truck && screens.length === 0) {
      // Default positions based on asset type and screen count
      const count = truck.screen_count || 1;
      const defaultPositions = {
        truck: ["left_side", "right_side", "rear", "front"],
        trailer: ["left_side", "right_side", "rear", "front"],
        poster_panel: ["front"],
        video_wall: ["front"],
      };
      const positions = (defaultPositions[truck.asset_type] || ["front"]).slice(0, count);
      setScreens(positions.map(pos => newBlankScreen(truck, pos)));
    }
  }, [open, truck?.id, existingScreens]);

  // Auto-save screen changes when they are made
   useEffect(() => {
     if (!open || screens.length === 0) return;

     const saveTimer = setTimeout(async () => {
       try {
         const existingIds = existingScreens.map(s => s.id);
         const savedIds = screens.filter(s => s.id).map(s => s.id);

         // Delete screens that were removed
         for (const s of existingScreens) {
           if (!savedIds.includes(s.id)) {
             console.log("Deleting screen:", s.id);
             await base44.entities.Screen.delete(s.id);
           }
         }

         // Update existing or create new
         for (const s of screens) {
           const { id, created_date, updated_date, created_by, ...data } = s;
           // Ensure content_type is included (default to "none" if not set)
           const screenData = { ...data, truck_id: truck.id, content_type: data.content_type || "none" };
           if (id && existingIds.includes(id)) {
             console.log("Updating screen:", id, screenData);
             await base44.entities.Screen.update(id, screenData);
           } else {
             console.log("Creating new screen:", screenData);
             await base44.entities.Screen.create(screenData);
           }
         }

         console.log("Screen auto-save completed");
         await queryClient.invalidateQueries({ queryKey: ["screens", truck.id] });
       } catch (error) {
         console.error("Auto-save failed:", error);
       }
     }, 2500); // Save 2.5s after last change to allow multiple rapid edits

     return () => clearTimeout(saveTimer);
   }, [screens, open, truck?.id]);

  const handleScreenChange = (index, updatedScreen) => {
    setScreens(prev => prev.map((s, i) => i === index ? updatedScreen : s));
  };

  const handleAddScreen = () => {
    setScreens(prev => [...prev, newBlankScreen(truck)]);
  };

  const handleRemoveScreen = (index) => {
    setScreens(prev => prev.filter((_, i) => i !== index));
  };

  const handleScreenLayoutClick = (index) => {
    setSelectedScreenIdx(index);
    setContentDialogOpen(true);
  };

  const handleContentSave = (index, updatedScreen) => {
    handleScreenChange(index, updatedScreen);
    setContentDialogOpen(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Force immediate save of all screen changes before closing
      const existingIds = existingScreens.map(s => s.id);
      const savedIds = screens.filter(s => s.id).map(s => s.id);

      // Delete screens that were removed
      for (const s of existingScreens) {
        if (!savedIds.includes(s.id)) {
          console.log("Deleting screen:", s.id);
          await base44.entities.Screen.delete(s.id);
        }
      }

      // Update existing or create new
        for (const s of screens) {
          const { id, created_date, updated_date, created_by, ...data } = s;
          // Ensure content_type is included (default to "none" if not set)
          const screenData = { ...data, truck_id: truck.id, content_type: data.content_type || "none" };
          if (id && existingIds.includes(id)) {
            console.log("Saving screen:", id, screenData);
            await base44.entities.Screen.update(id, screenData);
          } else {
            console.log("Creating new screen:", screenData);
            await base44.entities.Screen.create(screenData);
          }
        }

      // Refresh the cache
      await queryClient.invalidateQueries({ queryKey: ["screens", truck.id] });

      toast.success("Screens saved");
      onOpenChange(false);
    } catch (error) {
      console.error("Save failed:", error);
      toast.error("Failed to save screens: " + error.message);
    } finally {
      setSaving(false);
    }
  };

  if (!truck) return null;

  const totalPixels = screens.reduce((acc, s) => acc + (s.width || 0) * (s.height || 0), 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between pr-8">
            <div>
              <DialogTitle className="text-lg">Screen Setup — {truck.name}</DialogTitle>
              <p className="text-xs text-slate-400 mt-0.5">{screens.length} screen{screens.length !== 1 ? "s" : ""} configured
                {totalPixels > 0 && <span className="ml-2 text-blue-500">{(totalPixels / 1_000_000).toFixed(1)}M total pixels</span>}
              </p>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-3 py-2">
          {screens.map((screen, i) => (
            <ScreenCard
              key={i}
              screen={screen}
              index={i}
              cabinetTypes={cabinetTypes}
              controllerTypes={controllerTypes}
              onChange={handleScreenChange}
              onRemove={handleRemoveScreen}
              canRemove={screens.length > 1}
            />
          ))}
        </div>

        <Button onClick={handleAddScreen} variant="outline" className="w-full gap-2 border-dashed border-slate-300 text-slate-500 hover:border-blue-400 hover:text-blue-600">
          <Plus className="w-4 h-4" /> Add Screen
        </Button>

        <ScreenLayoutVisualizer screens={screens} onScreenClick={handleScreenLayoutClick} />

        <ScreenContentDialog
          open={contentDialogOpen}
          onOpenChange={setContentDialogOpen}
          screen={screens[selectedScreenIdx]}
          screenIndex={selectedScreenIdx}
          allScreens={screens}
          onSave={handleContentSave}
        />

        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
            {saving ? "Saving…" : "Save Screens"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}