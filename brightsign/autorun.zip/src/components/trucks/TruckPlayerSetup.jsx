import React, { useState } from "react";
import { usePlayerOrigin } from "@/lib/playerUrls";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Download, Loader2, Tv2, Monitor, Globe, Cpu, Radio, ExternalLink, Info } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import WindowsPCInstallerGuide from "@/components/WindowsPCInstallerGuide";

const PLAYER_TYPES = [
  { value: "none", label: "No Player", icon: null, color: "bg-slate-100 text-slate-500" },
  { value: "brightsign", label: "BrightSign", icon: Tv2, color: "bg-green-50 text-green-700 border-green-200" },
  { value: "windows_pc", label: "Windows PC", icon: Monitor, color: "bg-blue-50 text-blue-700 border-blue-200" },
  { value: "html_link", label: "HTML Link", icon: Globe, color: "bg-violet-50 text-violet-700 border-violet-200" },
  { value: "raspberry_pi", label: "Raspberry Pi", icon: Cpu, color: "bg-red-50 text-red-700 border-red-200" },
  { value: "novastar_taurus", label: "NovaStar Taurus", icon: Radio, color: "bg-amber-50 text-amber-700 border-amber-200" },
  { value: "novastar_vnnox", label: "NovaStar VNNOX (All-in-One)", icon: Radio, color: "bg-orange-50 text-orange-700 border-orange-200" },
];

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-slate-500">{label}</Label>
      {children}
    </div>
  );
}

function CopyableInput({ value, onChange, placeholder, type = "text" }) {
  return (
    <div className="flex gap-1.5">
      <Input value={value} onChange={onChange} placeholder={placeholder} type={type} className="h-8 text-xs flex-1" />
      {value && (
        <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0 text-slate-400 hover:text-blue-600"
          onClick={() => { navigator.clipboard.writeText(value); toast.success("Copied"); }}>
          <Copy className="w-3.5 h-3.5" />
        </Button>
      )}
    </div>
  );
}

const BRIGHTSIGN_MODELS = [
  { value: "XT1144", label: "XT1144 — 4K, HDMI In, SSD", series: "XT" },
  { value: "XT1145", label: "XT1145 — 4K, HDMI In, SSD", series: "XT" },
  { value: "XT5",    label: "XT5 — 8K, HDMI In, SSD",    series: "XT" },
  { value: "LS425",  label: "LS425 — HD, No HDMI In",     series: "LS" },
  { value: "LS445",  label: "LS445 — 4K, No HDMI In",     series: "LS" },
];

const NOVASTAR_MODELS = [
  { value: "VX600",  label: "VX600 — All-in-One Controller" },
  { value: "VX1000", label: "VX1000 — All-in-One Controller" },
  { value: "VX2000", label: "VX2000 — All-in-One Controller" },
];

function BrightSignFields({ truck, onChange }) {
  const [downloading, setDownloading] = React.useState(false);

  const selectedModel = BRIGHTSIGN_MODELS.find(m => m.value === truck.player_model);
  const isXT = selectedModel?.series === "XT";

  const handleDownloadFiles = async () => {
    if (!truck.id) {
      toast.error("Save asset first before downloading files");
      return;
    }
    try {
      setDownloading(true);
      const response = await base44.functions.invoke('generateBrightSignFiles', { truckId: truck.id });
      const { base64, filename } = response.data;

      // Decode base64 → binary → Blob → trigger Save As dialog
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: 'application/zip' });

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      a.remove();
      toast.success("Package downloaded — extract to blank SD card");
    } catch (error) {
      toast.error("Failed to generate files: " + error.message);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-3">
      {/* Player Model */}
      <Field label="Player Model">
        <Select value={truck.player_model || ""} onValueChange={(v) => onChange("player_model", v)}>
          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select model…" /></SelectTrigger>
          <SelectContent>
            <div className="px-2 py-1 text-[10px] text-slate-400 uppercase tracking-wide font-medium">XT Series (HDMI In)</div>
            {BRIGHTSIGN_MODELS.filter(m => m.series === "XT").map(m => (
              <SelectItem key={m.value} value={m.value} className="text-xs">{m.label}</SelectItem>
            ))}
            <div className="px-2 py-1 text-[10px] text-slate-400 uppercase tracking-wide font-medium mt-1">LS Series</div>
            {BRIGHTSIGN_MODELS.filter(m => m.series === "LS").map(m => (
              <SelectItem key={m.value} value={m.value} className="text-xs">{m.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </Field>

      {selectedModel && (
        <div className={`rounded-lg border px-3 py-2 text-[10px] flex gap-3 flex-wrap ${isXT ? "bg-blue-50 border-blue-200 text-blue-700" : "bg-slate-50 border-slate-200 text-slate-600"}`}>
          <span>🖥 HDMI Out</span>
          {isXT && <span>📥 HDMI In</span>}
          {isXT && <span>💾 Internal SSD</span>}
          <span>🔊 3.5mm Aux Out</span>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <Field label="IP Address">
          <CopyableInput value={truck.player_ip || ""} onChange={(e) => onChange("player_ip", e.target.value)} placeholder="192.168.1.x" />
        </Field>
        <Field label="Serial Number">
          <CopyableInput value={truck.player_serial || ""} onChange={(e) => onChange("player_serial", e.target.value)} placeholder="A1B2C3D4" />
        </Field>
        <Field label="DWS Username">
          <Input value={truck.player_username || ""} onChange={(e) => onChange("player_username", e.target.value)} placeholder="admin" className="h-8 text-xs" />
        </Field>
        <Field label="DWS Password">
          <Input value={truck.player_password || ""} onChange={(e) => onChange("player_password", e.target.value)} placeholder="••••••••" type="password" className="h-8 text-xs" />
        </Field>
      </div>

      {/* NovaStar VX Controller */}
      <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 space-y-2">
        <p className="text-xs font-semibold text-amber-800">NovaStar VX Controller</p>
        <Field label="Controller Model">
          <Select value={truck.novastar_model || ""} onValueChange={(v) => onChange("novastar_model", v)}>
            <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select VX model…" /></SelectTrigger>
            <SelectContent>
              {NOVASTAR_MODELS.map(m => (
                <SelectItem key={m.value} value={m.value} className="text-xs">{m.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Controller IP Address">
          <CopyableInput value={truck.novastar_ip || ""} onChange={(e) => onChange("novastar_ip", e.target.value)} placeholder="192.168.1.x" />
        </Field>
        {truck.novastar_ip && (
          <p className="text-[10px] text-amber-700">Player will send brightness commands to this IP via TCP port 5200 (NovaStar Central Control Protocol)</p>
        )}
      </div>

      {truck.id && truck.player_model && (
        <div className="rounded-lg bg-green-50 border border-green-200 p-3 space-y-2">
          <p className="text-xs font-semibold text-green-800">Download Setup Package</p>
          <Button
            onClick={handleDownloadFiles}
            disabled={downloading}
            className="w-full h-8 text-xs bg-green-600 hover:bg-green-700 text-white gap-2"
          >
            {downloading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3" />}
            Download {truck.player_model} Package (.zip)
          </Button>
          <p className="text-[10px] text-green-700">
            Extract to blank SD card → insert in player → auto-boots, caches content locally, polls for updates every 60s
            {truck.novastar_ip && `, controls NovaStar brightness via TCP`}
          </p>
        </div>
      )}

      <Field label="Notes">
        <Input value={truck.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. Mounted in rack, port 2" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

function WindowsPCFields({ truck, onChange }) {
  const [showInstaller, setShowInstaller] = useState(false);

  return (
    <div className="space-y-3">
      <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 space-y-2">
        <p className="text-xs font-semibold text-blue-800">🚀 Quick Setup (Recommended)</p>
        <p className="text-[10px] text-blue-700 mb-2">Set up automatic monitor detection — the app will auto-launch on your LED screen with no config needed.</p>
        <Button onClick={() => setShowInstaller(!showInstaller)} className="w-full h-8 text-xs bg-blue-600 hover:bg-blue-700 gap-2">
          <Download className="w-3 h-3" /> Get Electron Setup
        </Button>
      </div>

      {showInstaller && <WindowsPCInstallerGuide assetId={truck.id} />}

      <div className="grid grid-cols-2 gap-3">
        <Field label="IP Address / Hostname">
          <CopyableInput value={truck.player_ip || ""} onChange={(e) => onChange("player_ip", e.target.value)} placeholder="192.168.1.x or DESKTOP-XYZ" />
        </Field>
        <Field label="Computer Name">
          <Input value={truck.player_hostname || ""} onChange={(e) => onChange("player_hostname", e.target.value)} placeholder="TRUCK-01-PC" className="h-8 text-xs" />
        </Field>
        <Field label="Username">
          <Input value={truck.player_username || ""} onChange={(e) => onChange("player_username", e.target.value)} placeholder="Windows username" className="h-8 text-xs" />
        </Field>
        <Field label="Password">
          <Input value={truck.player_password || ""} onChange={(e) => onChange("player_password", e.target.value)} placeholder="••••••••" type="password" className="h-8 text-xs" />
        </Field>
      </div>

      <Field label="Notes">
        <Input value={truck.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. GPU model, display port" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

function HTMLLinkFields({ truck, onChange }) {
  return (
    <div className="space-y-3">
      <Field label="Custom HTML Output URL (optional)">
        <CopyableInput value={truck.player_html_url || ""} onChange={(e) => onChange("player_html_url", e.target.value)} placeholder="Leave blank for default" />
      </Field>
      <Field label="Notes">
        <Input value={truck.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. Embedded in digital signage platform" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

const VNNOX_TB_MODELS = [
  { value: "TB50", label: "TB50 — Quad-core A55, 4K" },
  { value: "TB60", label: "TB60 — Octa-core A55, 4K" },
  { value: "TB30", label: "TB30 — Quad-core A35, 1080p" },
  { value: "TB8", label: "TB8 — Octa-core, High Perf" },
  { value: "other", label: "Other Taurus All-in-One" },
];

// getPublishedOrigin() removed — player URLs now come from AppConfig.player_app_origin via usePlayerOrigin hook.
// CMS does NOT serve player URLs.

function VNNOXFields({ truck, onChange, playerOrigin }) {
  const { data: screens = [] } = useQuery({
    queryKey: ["screens-vnnox", truck.id],
    queryFn: () => base44.entities.Screen.filter({ truck_id: truck.id }),
    enabled: !!truck.id,
  });

  // Player URLs point to the separate ScreenFleet Player app.
  const getLiveUrl = (screenId) => playerOrigin ? `${playerOrigin}/player?screenId=${screenId}` : null;

  return (
    <div className="space-y-3">
      {/* Model */}
      <Field label="TB Controller Model">
        <Select value={truck.novastar_model || ""} onValueChange={(v) => onChange("novastar_model", v)}>
          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select model…" /></SelectTrigger>
          <SelectContent>
            {VNNOX_TB_MODELS.map(m => (
              <SelectItem key={m.value} value={m.value} className="text-xs">{m.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </Field>

      {/* VNNOX Device ID */}
      <Field label="VNNOX Device ID (optional)">
        <CopyableInput
          value={truck.player_serial || ""}
          onChange={(e) => onChange("player_serial", e.target.value)}
          placeholder="From VNNOX cloud device list"
        />
      </Field>

      {/* Option 1: HTML Feed */}
      <div className="rounded-lg border border-orange-200 bg-orange-50 p-3 space-y-3">
        <div className="flex items-center gap-2">
          <Globe className="w-3.5 h-3.5 text-orange-600" />
          <p className="text-xs font-semibold text-orange-800">Option 1 — HTML Feed (Live, requires internet)</p>
        </div>
        <p className="text-[10px] text-orange-700">
          Add an <strong>HTML widget</strong> in VNNOX and paste the Live Output URL for each screen. The TB50 loads content live from ScreenFleet.
        </p>

        {truck.id && screens.length > 0 ? (
          <div className="space-y-2">
            <p className="text-[10px] font-medium text-orange-800">Screen URLs — paste each into a VNNOX HTML widget:</p>
            {screens.map((screen) => {
              const url = getLiveUrl(screen.id);
              return (
                <div key={screen.id} className="space-y-0.5">
                  <p className="text-[10px] text-orange-700 font-medium">{screen.name}</p>
                  <div className="flex items-center gap-1">
                    <input
                      readOnly
                      value={url}
                      onClick={(e) => e.target.select()}
                      className="flex-1 bg-white border border-orange-200 rounded px-2 py-1 text-[10px] text-slate-600 font-mono cursor-text min-w-0"
                    />
                    <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-orange-600 hover:text-orange-800"
                      onClick={() => { navigator.clipboard.writeText(url); toast.success("Copied!"); }}>
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white/60 rounded border border-orange-200 px-3 py-2 text-[10px] text-orange-700">
            {!truck.id
              ? "Save this asset first, then set up screens to generate Live Output URLs."
              : "Add screens to this asset in the Screen Editor to generate URLs."}
          </div>
        )}

        {/* Setup steps */}
        <div className="space-y-1 pt-1 border-t border-orange-200">
          <p className="text-[10px] font-semibold text-orange-800">VNNOX Setup Steps:</p>
          <ol className="text-[10px] text-orange-700 space-y-0.5 list-decimal list-inside">
            <li>Log into <strong>VNNOX cloud</strong> → Add your TB50 device</li>
            <li>Create a new <strong>Program</strong> for this asset</li>
            <li>Add an <strong>HTML page widget</strong> to the program</li>
            <li>Paste the ScreenFleet URL above into the widget URL field</li>
            <li>Set the widget to <strong>full screen</strong>, publish to device</li>
          </ol>
          <a
            href="https://vnnox.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-[10px] text-orange-600 hover:underline mt-1"
          >
            Open VNNOX Cloud <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* Option 2 placeholder */}
      <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-1">
        <div className="flex items-center gap-2">
          <Info className="w-3.5 h-3.5 text-slate-400" />
          <p className="text-xs font-semibold text-slate-500">Option 2 — VNNOX API Sync (Coming Soon)</p>
        </div>
        <p className="text-[10px] text-slate-400">
          Push playlists and schedules directly to the TB50's local storage for offline playback. Requires NovaStar VNNOX API credentials.
        </p>
      </div>

      <Field label="Notes">
        <Input value={truck.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. Lobby poster panel, floor 2" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

export default function TruckPlayerSetup({ truck, onChange }) {
  const playerType = truck.player_type || "none";
  const typeInfo = PLAYER_TYPES.find((t) => t.value === playerType);
  const Icon = typeInfo?.icon;
  // Player URLs come from the separate ScreenFleet Player app, not this CMS.
  const { origin: playerOrigin } = usePlayerOrigin();

  if (!truck) return null;

  return (
    <div className="pt-3 border-t border-slate-200 space-y-3">
      <div className="flex items-center gap-2">
        <Label className="text-xs font-semibold text-slate-700">Media Player Hardware</Label>
        {playerType !== "none" && typeInfo && (
          <Badge variant="outline" className={`text-[10px] ${typeInfo.color}`}>
            {Icon && <Icon className="w-3 h-3 mr-1" />}{typeInfo.label}
          </Badge>
        )}
      </div>

      {!playerOrigin && playerType !== "none" && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] text-amber-800">
          ⚠️ Player app URL not configured. Set <strong>player_app_origin</strong> in AppConfig to generate device URLs.
        </div>
      )}

      <div>
        <Label className="text-xs text-slate-500 mb-1.5 block">Player Type</Label>
        <Select value={playerType} onValueChange={(v) => onChange("player_type", v)}>
          <SelectTrigger className="h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {PLAYER_TYPES.map((t) => (
              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {playerType === "brightsign" && <BrightSignFields truck={truck} onChange={onChange} />}
      {playerType === "windows_pc" && <WindowsPCFields truck={truck} onChange={onChange} />}
      {playerType === "html_link" && <HTMLLinkFields truck={truck} onChange={onChange} />}
      {playerType === "novastar_vnnox" && <VNNOXFields truck={truck} onChange={onChange} playerOrigin={playerOrigin} />}
    </div>
  );
}