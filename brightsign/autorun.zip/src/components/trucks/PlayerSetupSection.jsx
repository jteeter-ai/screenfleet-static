import React from "react";
import { usePlayerOrigin } from "@/lib/playerUrls";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, ExternalLink, Tv2, Monitor, Globe, Cpu, Radio, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

const PLAYER_TYPES = [
  { value: "none", label: "No Player", icon: null, color: "bg-slate-100 text-slate-500" },
  { value: "brightsign", label: "BrightSign", icon: Tv2, color: "bg-green-50 text-green-700 border-green-200" },
  { value: "windows_pc", label: "Windows PC", icon: Monitor, color: "bg-blue-50 text-blue-700 border-blue-200" },
  { value: "html_link", label: "HTML Link", icon: Globe, color: "bg-violet-50 text-violet-700 border-violet-200" },
  { value: "raspberry_pi", label: "Raspberry Pi", icon: Cpu, color: "bg-red-50 text-red-700 border-red-200" },
  { value: "novastar_taurus", label: "NovaStar Taurus", icon: Radio, color: "bg-amber-50 text-amber-700 border-amber-200" },
  { value: "novastar_vnnox", label: "NovaStar VNNOX (All-in-One)", icon: Radio, color: "bg-orange-50 text-orange-700 border-orange-200" },
];

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-slate-500">{label}</Label>
      {children}
    </div>
  );
}

function CopyableInput({ value, onChange, placeholder, type = "text" }) {
  return (
    <div className="flex gap-1.5">
      <Input value={value} onChange={onChange} placeholder={placeholder} type={type} className="h-8 text-xs flex-1" />
      {value && (
        <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0 text-slate-400 hover:text-blue-600"
          onClick={() => { navigator.clipboard.writeText(value); toast.success("Copied"); }}>
          <Copy className="w-3.5 h-3.5" />
        </Button>
      )}
    </div>
  );
}

// Per-player tailored setup fields
// playerOrigin comes from AppConfig.player_app_origin via usePlayerOrigin() in parent.
// Never falls back to CMS origin.
function BrightSignFields({ screen, onChange, playerOrigin }) {
  const liveUrl = (screen.id && playerOrigin) ? `${playerOrigin}/player?screenId=${screen.id}` : null;
  const [downloading, setDownloading] = React.useState(false);

  const handleDownloadFiles = async () => {
    if (!screen.id) {
      toast.error("Save screen first before downloading files");
      return;
    }
    
    try {
      setDownloading(true);
      const response = await base44.functions.invoke('generateBrightSignFiles', { screenId: screen.id });
      
      if (response.data.files) {
        // Fallback: Files returned as JSON, create a text manifest
        const manifest = response.data.files.map(f => `\n=== ${f.name} ===\n${f.content}`).join('\n\n');
        const blob = new Blob([manifest], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'brightsign-files.txt';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast.success("Files generated - extract each section to SD card");
      } else {
        // Direct ZIP download
        const blob = new Blob([response.data], { type: 'application/zip' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'brightsign-files.zip';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast.success("Files downloaded - extract to blank SD card");
      }
    } catch (error) {
      toast.error("Failed to generate files: " + error.message);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <Field label="IP Address">
          <CopyableInput value={screen.player_ip || ""} onChange={(e) => onChange("player_ip", e.target.value)} placeholder="192.168.1.x" />
        </Field>
        <Field label="Serial Number">
          <CopyableInput value={screen.player_serial || ""} onChange={(e) => onChange("player_serial", e.target.value)} placeholder="A1B2C3D4" />
        </Field>
        <Field label="DWS Username">
          <Input value={screen.player_username || ""} onChange={(e) => onChange("player_username", e.target.value)} placeholder="admin" className="h-8 text-xs" />
        </Field>
        <Field label="DWS Password">
          <Input value={screen.player_password || ""} onChange={(e) => onChange("player_password", e.target.value)} placeholder="••••••••" type="password" className="h-8 text-xs" />
        </Field>
      </div>
      {liveUrl && (
        <div className="rounded-lg bg-green-50 border border-green-200 p-3 space-y-2">
          <p className="text-xs font-semibold text-green-800">Quick Setup</p>
          <Button 
            onClick={handleDownloadFiles} 
            disabled={downloading}
            className="w-full h-8 text-xs bg-green-600 hover:bg-green-700 text-white gap-2"
          >
            {downloading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3" />}
            Download BrightSign Files
          </Button>
          <p className="text-[10px] text-green-700">Extract files to blank SD card → insert in player → auto-boots to live output</p>
        </div>
      )}
      <Field label="Notes">
        <Input value={screen.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. Mounted in cabinet behind panel" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

function WindowsPCFields({ screen, onChange, playerOrigin }) {
  const liveUrl = (screen.id && playerOrigin) ? `${playerOrigin}/player?screenId=${screen.id}` : null;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <Field label="IP Address / Hostname">
          <CopyableInput value={screen.player_ip || ""} onChange={(e) => onChange("player_ip", e.target.value)} placeholder="192.168.1.x or DESKTOP-XYZ" />
        </Field>
        <Field label="Computer Name">
          <Input value={screen.player_hostname || ""} onChange={(e) => onChange("player_hostname", e.target.value)} placeholder="TRUCK-01-PC" className="h-8 text-xs" />
        </Field>
        <Field label="Username">
          <Input value={screen.player_username || ""} onChange={(e) => onChange("player_username", e.target.value)} placeholder="Windows username" className="h-8 text-xs" />
        </Field>
        <Field label="Password">
          <Input value={screen.player_password || ""} onChange={(e) => onChange("player_password", e.target.value)} placeholder="••••••••" type="password" className="h-8 text-xs" />
        </Field>
      </div>
      {liveUrl && (
        <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 space-y-1.5">
          <p className="text-xs font-semibold text-blue-800">Full-Screen Browser URL</p>
          <p className="text-[10px] text-blue-700">Open this URL in Chrome kiosk mode: <code>chrome --kiosk --incognito {liveUrl}</code></p>
          <div className="flex items-center gap-2 bg-white rounded-md border border-blue-200 px-2 py-1.5">
            <code className="text-[10px] text-slate-600 flex-1 truncate">{liveUrl}</code>
            <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-slate-400 hover:text-blue-700"
              onClick={() => { navigator.clipboard.writeText(liveUrl); toast.success("URL copied"); }}>
              <Copy className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )}
      <Field label="Notes">
        <Input value={screen.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. GPU model, display port" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

function HTMLLinkFields({ screen, onChange, playerOrigin }) {
  const defaultUrl = (screen.id && playerOrigin) ? `${playerOrigin}/player?screenId=${screen.id}` : "";
  const activeUrl = screen.player_html_url || defaultUrl;
  return (
    <div className="space-y-3">
      <Field label="Custom HTML Output URL (leave blank for default)">
        <CopyableInput value={screen.player_html_url || ""} onChange={(e) => onChange("player_html_url", e.target.value)} placeholder={defaultUrl} />
      </Field>
      {activeUrl && (
        <div className="rounded-lg bg-violet-50 border border-violet-200 p-3 space-y-1.5">
          <p className="text-xs font-semibold text-violet-800">Active Output URL</p>
          <div className="flex items-center gap-2 bg-white rounded-md border border-violet-200 px-2 py-1.5">
            <code className="text-[10px] text-slate-600 flex-1 truncate">{activeUrl}</code>
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-slate-400 hover:text-violet-700"
                onClick={() => { navigator.clipboard.writeText(activeUrl); toast.success("URL copied"); }}>
                <Copy className="w-3 h-3" />
              </Button>
              <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-slate-400 hover:text-violet-700"
                onClick={() => window.open(activeUrl, "_blank")}>
                <ExternalLink className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>
      )}
      <Field label="Notes">
        <Input value={screen.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. Embedded in digital signage platform" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

function RaspberryPiFields({ screen, onChange, playerOrigin }) {
  const liveUrl = (screen.id && playerOrigin) ? `${playerOrigin}/player?screenId=${screen.id}` : null;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <Field label="IP Address">
          <CopyableInput value={screen.player_ip || ""} onChange={(e) => onChange("player_ip", e.target.value)} placeholder="192.168.1.x" />
        </Field>
        <Field label="Hostname">
          <CopyableInput value={screen.player_hostname || ""} onChange={(e) => onChange("player_hostname", e.target.value)} placeholder="raspberrypi.local" />
        </Field>
        <Field label="SSH Username">
          <Input value={screen.player_username || ""} onChange={(e) => onChange("player_username", e.target.value)} placeholder="pi" className="h-8 text-xs" />
        </Field>
        <Field label="SSH Password">
          <Input value={screen.player_password || ""} onChange={(e) => onChange("player_password", e.target.value)} placeholder="••••••••" type="password" className="h-8 text-xs" />
        </Field>
      </div>
      {liveUrl && (
        <div className="rounded-lg bg-red-50 border border-red-200 p-3 space-y-1.5">
          <p className="text-xs font-semibold text-red-800">Chromium Kiosk URL</p>
          <p className="text-[10px] text-red-700">Add to <code>/etc/xdg/autostart/kiosk.desktop</code> or use <code>@chromium-browser --noerrdialogs --kiosk</code></p>
          <div className="flex items-center gap-2 bg-white rounded-md border border-red-200 px-2 py-1.5">
            <code className="text-[10px] text-slate-600 flex-1 truncate">{liveUrl}</code>
            <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-slate-400 hover:text-red-700"
              onClick={() => { navigator.clipboard.writeText(liveUrl); toast.success("URL copied"); }}>
              <Copy className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )}
      <Field label="Notes">
        <Input value={screen.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. Model 4B 4GB, OS version" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

function NovaStarTaurusFields({ screen, onChange, playerOrigin }) {
  const liveUrl = (screen.id && playerOrigin) ? `${playerOrigin}/player?screenId=${screen.id}` : null;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <Field label="IP Address">
          <CopyableInput value={screen.player_ip || ""} onChange={(e) => onChange("player_ip", e.target.value)} placeholder="192.168.1.x" />
        </Field>
        <Field label="Serial Number">
          <CopyableInput value={screen.player_serial || ""} onChange={(e) => onChange("player_serial", e.target.value)} placeholder="Taurus serial" />
        </Field>
        <Field label="VNNOX Username">
          <Input value={screen.player_username || ""} onChange={(e) => onChange("player_username", e.target.value)} placeholder="VNNOX account" className="h-8 text-xs" />
        </Field>
        <Field label="VNNOX Password">
          <Input value={screen.player_password || ""} onChange={(e) => onChange("player_password", e.target.value)} placeholder="••••••••" type="password" className="h-8 text-xs" />
        </Field>
      </div>
      {liveUrl && (
        <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 space-y-1.5">
          <p className="text-xs font-semibold text-amber-800">Web Page Program URL</p>
          <p className="text-[10px] text-amber-700">Add this as a "Web Page" media item in Async Manager or VNNOX:</p>
          <div className="flex items-center gap-2 bg-white rounded-md border border-amber-200 px-2 py-1.5">
            <code className="text-[10px] text-slate-600 flex-1 truncate">{liveUrl}</code>
            <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-slate-400 hover:text-amber-700"
              onClick={() => { navigator.clipboard.writeText(liveUrl); toast.success("URL copied"); }}>
              <Copy className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )}
      <Field label="Notes">
        <Input value={screen.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. TB30/TB40/TB50 model" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

function NovaStarVNNOXFields({ screen, onChange, playerOrigin }) {
  const liveUrl = (screen.id && playerOrigin) ? `${playerOrigin}/player?screenId=${screen.id}` : null;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Device IP Address">
          <CopyableInput value={screen.player_ip || ""} onChange={(e) => onChange("player_ip", e.target.value)} placeholder="192.168.1.x" />
        </Field>
        <Field label="Serial Number">
          <CopyableInput value={screen.player_serial || ""} onChange={(e) => onChange("player_serial", e.target.value)} placeholder="VNNOX device serial" />
        </Field>
        <Field label="VNNOX Username">
          <Input value={screen.player_username || ""} onChange={(e) => onChange("player_username", e.target.value)} placeholder="VNNOX account email" className="h-8 text-xs" />
        </Field>
        <Field label="VNNOX Password">
          <Input value={screen.player_password || ""} onChange={(e) => onChange("player_password", e.target.value)} placeholder="••••••••" type="password" className="h-8 text-xs" />
        </Field>
      </div>
      {liveUrl && (
        <div className="rounded-lg bg-orange-50 border border-orange-200 p-3 space-y-1.5">
          <p className="text-xs font-semibold text-orange-800">VNNOX Web Page Program URL</p>
          <p className="text-[10px] text-orange-700">In VNNOX, create a "Web Page" media item and enter this URL. Works with pre-installed VNNOX on NovaStar all-in-one poster panels.</p>
          <div className="flex items-center gap-2 bg-white rounded-md border border-orange-200 px-2 py-1.5">
            <code className="text-[10px] text-slate-600 flex-1 truncate">{liveUrl}</code>
            <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 text-slate-400 hover:text-orange-700"
              onClick={() => { navigator.clipboard.writeText(liveUrl); toast.success("URL copied"); }}>
              <Copy className="w-3 h-3" />
            </Button>
          </div>
          <p className="text-[10px] text-orange-600">💡 Tip: Set the web page item to loop and fill the full-screen zone in your VNNOX program.</p>
        </div>
      )}
      <Field label="Notes">
        <Input value={screen.player_notes || ""} onChange={(e) => onChange("player_notes", e.target.value)} placeholder="e.g. 75-inch poster panel, lobby entrance" className="h-8 text-xs" />
      </Field>
    </div>
  );
}

export default function PlayerSetupSection({ screen, onChange }) {
  const playerType = screen.player_type || "none";
  const typeInfo = PLAYER_TYPES.find((t) => t.value === playerType);
  const Icon = typeInfo?.icon;
  // Player URLs come from the separate ScreenFleet Player app, not this CMS.
  // Set AppConfig.player_app_origin to enable URL generation.
  const { origin: playerOrigin } = usePlayerOrigin();

  return (
    <div className="pt-3 border-t border-slate-200 space-y-3">
      <div className="flex items-center gap-2">
        <Label className="text-xs font-semibold text-slate-700">Media Player Hardware</Label>
        {playerType !== "none" && typeInfo && (
          <Badge variant="outline" className={`text-[10px] ${typeInfo.color}`}>
            {Icon && <Icon className="w-3 h-3 mr-1" />}{typeInfo.label}
          </Badge>
        )}
      </div>

      {!playerOrigin && playerType !== "none" && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] text-amber-800">
          ⚠️ Player app URL not configured. Set <strong>player_app_origin</strong> in AppConfig to generate device URLs.
        </div>
      )}

      <div>
        <Label className="text-xs text-slate-500 mb-1.5 block">Player Type</Label>
        <Select value={playerType} onValueChange={(v) => onChange("player_type", v)}>
          <SelectTrigger className="h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {PLAYER_TYPES.map((t) => (
              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {playerType === "brightsign" && <BrightSignFields screen={screen} onChange={onChange} playerOrigin={playerOrigin} />}
      {playerType === "windows_pc" && <WindowsPCFields screen={screen} onChange={onChange} playerOrigin={playerOrigin} />}
      {playerType === "html_link" && <HTMLLinkFields screen={screen} onChange={onChange} playerOrigin={playerOrigin} />}
      {playerType === "raspberry_pi" && <RaspberryPiFields screen={screen} onChange={onChange} playerOrigin={playerOrigin} />}
      {playerType === "novastar_taurus" && <NovaStarTaurusFields screen={screen} onChange={onChange} playerOrigin={playerOrigin} />}
      {playerType === "novastar_vnnox" && <NovaStarVNNOXFields screen={screen} onChange={onChange} playerOrigin={playerOrigin} />}
    </div>
  );
}