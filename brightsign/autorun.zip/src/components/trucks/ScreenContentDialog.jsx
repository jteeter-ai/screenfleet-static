import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Copy, Radio, Link as LinkIcon, Monitor, X } from "lucide-react";

const CONTENT_OPTIONS = [
  { value: "none", label: "None", icon: X, color: "bg-slate-100 text-slate-500" },
  { value: "playlist", label: "Playlist", icon: Monitor, color: "bg-blue-100 text-blue-700" },
  { value: "hdmi_in", label: "HDMI Input (from Player)", icon: Radio, color: "bg-red-100 text-red-700" },
  { value: "link", label: "Web Link", icon: LinkIcon, color: "bg-violet-100 text-violet-700" },
  { value: "duplicate", label: "Duplicate from Another Screen", icon: Copy, color: "bg-amber-100 text-amber-700" },
];

export default function ScreenContentDialog({
  open,
  onOpenChange,
  screen,
  screenIndex,
  allScreens,
  onSave,
}) {
  const [contentType, setContentType] = useState(screen?.content_type || "none");
  const [duplicateFromIdx, setDuplicateFromIdx] = useState(null);

  const handleSave = () => {
    onSave(screenIndex, {
      ...screen,
      content_type: contentType,
      duplicate_from_screen_idx: contentType === "duplicate" ? duplicateFromIdx : null,
    });
    onOpenChange(false);
  };

  if (!screen) return null;

  const currentOption = CONTENT_OPTIONS.find((o) => o.value === contentType);
  const Icon = currentOption?.icon;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {Icon && <Icon className="w-4 h-4" />}
            Configure Content — {screen.name || `Screen ${screenIndex + 1}`}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div>
            <Label className="text-xs text-slate-600 mb-2 block">Content Source</Label>
            <Select value={contentType} onValueChange={setContentType}>
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CONTENT_OPTIONS.map((opt) => {
                  const OptIcon = opt.icon;
                  return (
                    <SelectItem key={opt.value} value={opt.value}>
                      <div className="flex items-center gap-2">
                        <OptIcon className="w-4 h-4" />
                        {opt.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {contentType === "duplicate" && (
            <div>
              <Label className="text-xs text-slate-600 mb-2 block">
                Duplicate From
              </Label>
              <Select value={String(duplicateFromIdx ?? "")} onValueChange={(v) => setDuplicateFromIdx(Number(v))}>
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select screen to duplicate" />
                </SelectTrigger>
                <SelectContent>
                  {allScreens
                    .map((s, idx) => idx)
                    .filter((idx) => idx !== screenIndex)
                    .map((idx) => (
                      <SelectItem key={idx} value={String(idx)}>
                        {allScreens[idx].name || `Screen ${idx + 1}`}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="rounded-lg bg-slate-50 p-3 space-y-2">
            <p className="text-xs font-semibold text-slate-600">Screen Info</p>
            <div className="grid grid-cols-2 gap-2 text-xs text-slate-500">
              <div>
                <span className="text-slate-400">Position:</span> ({screen.start_x || 0}, {screen.start_y || 0})
              </div>
              <div>
                <span className="text-slate-400">Size:</span> {screen.width || 512}×{screen.height || 512}px
              </div>
              <div>
                <span className="text-slate-400">Physical:</span> {screen.physical_width_mm || "—"}mm ×{" "}
                {screen.physical_height_mm || "—"}mm
              </div>
              <div>
                <span className="text-slate-400">Pitch:</span> P{screen.pixel_pitch || "—"}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}