import React from "react";
import { Card } from "@/components/ui/card";

export default function StatCard({ title, value, subtitle, icon: Icon, color = "blue" }) {
  const colors = {
    blue: "from-blue-500 to-blue-600 shadow-blue-500/20",
    green: "from-emerald-500 to-emerald-600 shadow-emerald-500/20",
    purple: "from-violet-500 to-violet-600 shadow-violet-500/20",
    amber: "from-amber-500 to-amber-600 shadow-amber-500/20",
  };

  return (
    <Card className="p-6 border-0 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <p className="text-3xl font-bold text-slate-900 mt-1 tracking-tight">{value}</p>
          {subtitle && (
            <p className="text-xs text-slate-400 mt-1">{subtitle}</p>
          )}
        </div>
        <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${colors[color]} flex items-center justify-center shadow-lg`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>
    </Card>
  );
}