/**
 * AssetStatusList — V2 replacement for TruckStatusList
 * Shows V2 Asset records with their screen count and online/offline status
 * based on PlayerHeartbeat (2-minute threshold).
 */
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Layers, Monitor, CheckCircle2, XCircle } from "lucide-react";

const ONLINE_THRESHOLD_MS = 2 * 60 * 1000; // 2 minutes

export default function AssetStatusList({ assets, screens, heartbeats }) {
  const isOnline = (screenId) => {
    const hb = heartbeats.find(h => h.screen_id === screenId);
    if (!hb?.last_seen_at) return false;
    return (Date.now() - new Date(hb.last_seen_at).getTime()) < ONLINE_THRESHOLD_MS;
  };

  const statusColors = {
    active: "bg-emerald-50 text-emerald-700 border-emerald-200",
    inactive: "bg-slate-50 text-slate-500 border-slate-200",
    maintenance: "bg-amber-50 text-amber-700 border-amber-200",
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold">Fleet Status</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {assets.length === 0 && (
          <p className="text-sm text-slate-400 py-4 text-center">No V2 assets configured yet</p>
        )}
        {assets.map((asset) => {
          const assetScreens = screens.filter(s => s.asset_id === asset.id);
          const onlineCount = assetScreens.filter(s => isOnline(s.id)).length;
          return (
            <div key={asset.id} className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center">
                  <Layers className="w-4 h-4 text-slate-500" />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900">{asset.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Monitor className="w-3 h-3 text-slate-400" />
                    <span className="text-xs text-slate-400">{assetScreens.length} screen{assetScreens.length !== 1 ? "s" : ""}</span>
                    {assetScreens.length > 0 && (
                      <span className={`flex items-center gap-0.5 text-xs font-medium ${onlineCount > 0 ? "text-green-600" : "text-slate-400"}`}>
                        {onlineCount > 0
                          ? <><CheckCircle2 className="w-3 h-3" /> {onlineCount} online</>
                          : <><XCircle className="w-3 h-3" /> offline</>
                        }
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <Badge variant="outline" className={`text-xs ${statusColors[asset.status] || statusColors.inactive}`}>
                {asset.status}
              </Badge>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}