import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Truck, Monitor } from "lucide-react";

const statusColors = {
  active: "bg-emerald-50 text-emerald-700 border-emerald-200",
  inactive: "bg-slate-50 text-slate-500 border-slate-200",
  maintenance: "bg-amber-50 text-amber-700 border-amber-200",
};

export default function TruckStatusList({ trucks, screens }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold">Fleet Status</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {trucks.length === 0 && (
          <p className="text-sm text-slate-400 py-4 text-center">No trucks configured yet</p>
        )}
        {trucks.map((truck) => {
          const truckScreens = screens.filter((s) => s.truck_id === truck.id);
          return (
            <div key={truck.id} className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center">
                  <Truck className="w-4 h-4 text-slate-500" />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900">{truck.name}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Monitor className="w-3 h-3 text-slate-400" />
                    <span className="text-xs text-slate-400">{truckScreens.length} screens</span>
                  </div>
                </div>
              </div>
              <Badge variant="outline" className={`text-xs ${statusColors[truck.status] || statusColors.inactive}`}>
                {truck.status}
              </Badge>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}