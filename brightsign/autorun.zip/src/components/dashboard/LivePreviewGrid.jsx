/**
 * V2 Live Preview Grid
 * Shows published screens with first-frame preview from RuntimeZone playback_track.
 * Data source: Asset → Screen → PublishedScreen → RuntimeZone
 * NO V1 Truck/Zone/Layout/Playlist data.
 */

import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Monitor, ChevronRight, ImageOff } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useOrg } from "@/components/OrgContext";
import { usePlayerOrigin } from "@/lib/playerUrls";

function ScreenPreviewTile({ screen }) {
  const { data: publishedList = [] } = useQuery({
    queryKey: ["publishedScreen", screen.id],
    queryFn: () => base44.entities.PublishedScreen.filter({ screen_id: screen.id }),
    staleTime: 120000,
  });
  const published = publishedList.sort((a, b) => new Date(b.published_at) - new Date(a.published_at))[0];

  const { data: runtimeZones = [] } = useQuery({
    queryKey: ["runtimeZones", published?.id],
    queryFn: () => base44.entities.RuntimeZone.filter({ published_screen_id: published.id }),
    enabled: !!published?.id,
    staleTime: 120000,
  });

  // Find first playable media item across zones (sorted by z_index)
  const firstMedia = (() => {
    const sorted = [...runtimeZones].sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1));
    for (const zone of sorted) {
      const items = zone.playback_track?.items || [];
      const item = items[0];
      if (item?.file_url) return item;
    }
    return null;
  })();

  // previewUrl points to the separate ScreenFleet Player app, not this CMS.
  const { origin: playerOrigin } = usePlayerOrigin();
  const previewUrl = playerOrigin ? `${playerOrigin}/player?screenId=${screen.id}&preview=1` : null;

  const Wrapper = previewUrl
    ? ({ children }) => <a href={previewUrl} className="group cursor-pointer" target="_blank" rel="noopener noreferrer">{children}</a>
    : ({ children }) => <div className="group">{children}</div>;

  return (
    <Wrapper>
      <div className="rounded-lg overflow-hidden border border-slate-200 hover:border-blue-400 transition-all duration-200 hover:shadow-md flex flex-col">
        {/* Fixed-height preview viewport — all cards same outer size regardless of aspect ratio */}
        <div className="bg-black relative overflow-hidden" style={{ height: "180px" }}>
          <div className="absolute inset-0 flex items-center justify-center">
            {!published && (
              <div className="text-center text-white/30 p-3">
                <ImageOff className="w-5 h-5 mx-auto mb-1" />
                <div className="text-[10px]">Not Published</div>
              </div>
            )}
            {published && !firstMedia && (
              <div className="text-center text-white/20 p-3">
                <Monitor className="w-5 h-5 mx-auto mb-1" />
                <div className="text-[10px]">No content</div>
              </div>
            )}
            {firstMedia?.file_type === "image" && (
              <img
                src={firstMedia.file_url}
                alt=""
                className="max-w-full max-h-full w-full h-full"
                style={{ objectFit: "contain" }}
              />
            )}
            {firstMedia?.file_type === "video" && (
              <video
                src={firstMedia.file_url}
                autoPlay muted loop playsInline
                className="max-w-full max-h-full w-full h-full"
                style={{ objectFit: "contain" }}
              />
            )}
          </div>
        </div>
        {/* Card footer — consistent bottom alignment */}
        <div className="p-3 bg-slate-50 group-hover:bg-blue-50 transition-colors">
          <p className="text-xs font-semibold text-slate-900 truncate">{screen.name}</p>
          <p className="text-[10px] text-slate-400">
            {screen.width}×{screen.height} · {published ? "Published" : "Not Published"}
          </p>
        </div>
      </div>
    </Wrapper>
  );
}

export default function LivePreviewGrid() {
  const { activeOrgId, isPlatformAdmin } = useOrg();

  // Only show all assets in true platform-admin mode; specific org always scoped
  const { data: assets = [] } = useQuery({
    queryKey: ["assets", activeOrgId],
    queryFn: () => base44.entities.Asset.filter({ org_id: activeOrgId }),
    enabled: !!activeOrgId && activeOrgId !== "PLATFORM_ADMIN",
  });

  const { data: screens = [] } = useQuery({
    queryKey: ["v2screens", activeOrgId],
    queryFn: async () => {
      if (!assets.length) return [];
      const assetIds = assets.map(a => a.id);
      const all = await Promise.all(assetIds.map(id => base44.entities.Screen.filter({ asset_id: id })));
      return all.flat();
    },
    enabled: assets.length > 0,
  });

  if (!screens.length) return null;

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          <Monitor className="w-4 h-4 text-blue-600" /> Live Previews
        </h2>
        <Link to="/LiveOutput" className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1">
          View all <ChevronRight className="w-3 h-3" />
        </Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {screens.slice(0, 6).map(screen => (
          <ScreenPreviewTile key={screen.id} screen={screen} />
        ))}
      </div>
    </div>
  );
}