import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Plus, Trash2, Sun } from "lucide-react";

const DEFAULT_POINTS = [
  { lux: 1, brightness: 1 },
  { lux: 500, brightness: 30 },
  { lux: 1500, brightness: 60 },
  { lux: 3000, brightness: 80 },
  { lux: 6000, brightness: 100 },
];

export default function AutoBrightnessEditor({ points: externalPoints, onChange }) {
  const [points, setPoints] = useState(externalPoints?.length ? externalPoints : DEFAULT_POINTS);

  const sorted = [...points].sort((a, b) => a.lux - b.lux);

  const update = (newPoints) => {
    setPoints(newPoints);
    onChange?.(newPoints);
  };

  const updatePoint = (index, field, value) => {
    const updated = points.map((p, i) => i === index ? { ...p, [field]: value } : p);
    update(updated);
  };

  const addPoint = () => {
    const maxLux = Math.max(...points.map((p) => p.lux));
    const newLux = Math.min(maxLux + 500, 6000);
    const newBrightness = Math.min(Math.max(...points.map((p) => p.brightness)) + 5, 100);
    update([...points, { lux: newLux, brightness: newBrightness }]);
  };

  const removePoint = (index) => {
    if (points.length <= 2) return;
    update(points.filter((_, i) => i !== index));
  };

  // Interpolate brightness for preview bar
  const getBrightnessAtLux = (lux) => {
    if (sorted.length === 0) return 0;
    if (lux <= sorted[0].lux) return sorted[0].brightness;
    if (lux >= sorted[sorted.length - 1].lux) return sorted[sorted.length - 1].brightness;
    for (let i = 0; i < sorted.length - 1; i++) {
      if (lux >= sorted[i].lux && lux <= sorted[i + 1].lux) {
        const t = (lux - sorted[i].lux) / (sorted[i + 1].lux - sorted[i].lux);
        return Math.round(sorted[i].brightness + t * (sorted[i + 1].brightness - sorted[i].brightness));
      }
    }
    return 0;
  };

  // Build gradient preview
  const gradientStops = Array.from({ length: 20 }, (_, i) => {
    const lux = (i / 19) * 6000;
    const b = getBrightnessAtLux(lux);
    return `hsl(45, 90%, ${20 + b * 0.6}%) ${(i / 19) * 100}%`;
  });
  const gradientStyle = `linear-gradient(to right, ${gradientStops.join(", ")})`;

  return (
    <div className="space-y-4">
      {/* Gradient preview bar */}
      <div className="space-y-1">
        <div className="flex justify-between text-[10px] text-slate-400">
          <span>1 lux → 1%</span>
          <span>6,000 lux → 100%</span>
        </div>
        <div className="h-5 rounded-full overflow-hidden border border-slate-200" style={{ background: gradientStyle }} />
        <div className="flex justify-between text-[10px] text-slate-400">
          <span>Dark</span>
          <span>Bright</span>
        </div>
      </div>

      {/* Curve points */}
      <div className="space-y-2">
        <div className="grid grid-cols-[1fr_1fr_auto] gap-2 text-[10px] font-semibold text-slate-500 uppercase tracking-wide px-1">
          <span>Lux Level</span>
          <span>Brightness %</span>
          <span />
        </div>
        {sorted.map((point, i) => {
          const origIndex = points.indexOf(point);
          return (
            <div key={i} className="grid grid-cols-[1fr_1fr_auto] gap-2 items-center">
              <div className="relative">
                <Input
                  type="number"
                  min={1}
                  max={6000}
                  value={point.lux}
                  onChange={(e) => updatePoint(origIndex, "lux", Math.min(6000, Math.max(1, Number(e.target.value))))}
                  className="h-8 text-sm pr-10"
                />
                <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-400">lux</span>
              </div>
              <div className="flex items-center gap-2">
                <Slider
                  value={[point.brightness]}
                  onValueChange={([v]) => updatePoint(origIndex, "brightness", v)}
                  min={1}
                  max={100}
                  step={1}
                  className="flex-1"
                />
                <span className="text-xs font-medium text-slate-700 w-8 text-right">{point.brightness}%</span>
              </div>
              <button
                onClick={() => removePoint(origIndex)}
                disabled={points.length <= 2}
                className="p-1.5 rounded hover:bg-red-50 hover:text-red-500 text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      <Button variant="outline" size="sm" onClick={addPoint} disabled={points.length >= 8} className="w-full text-xs gap-1.5">
        <Plus className="w-3.5 h-3.5" /> Add Light Level Point
      </Button>

      <p className="text-[10px] text-slate-400">
        Brightness will smoothly interpolate between each lux/brightness point. Minimum: 1 lux / 1%. Maximum: 6,000 lux / 100%.
      </p>
    </div>
  );
}