import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { HelpCircle, Wifi, Cloud } from "lucide-react";
import { Button } from "@/components/ui/button";

export function BrightnessHelpButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setOpen(true)}
        className="text-slate-400 hover:text-blue-600 flex items-center gap-1.5 text-xs"
      >
        <HelpCircle className="w-3.5 h-3.5" />
        How does brightness control work?
      </Button>
      <BrightnessInstructionsModal open={open} onClose={() => setOpen(false)} />
    </>
  );
}

export default function BrightnessInstructionsModal({ open, onClose }) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Brightness Control — Setup Guide
          </DialogTitle>
          <p className="text-sm text-slate-500 mt-1">
            NovaStar controller brightness is controlled via one of two methods below. Choose the one that fits your setup.
          </p>
        </DialogHeader>

        <Tabs defaultValue="local">
          <TabsList className="w-full">
            <TabsTrigger value="local" className="flex-1 flex items-center gap-1.5">
              <Wifi className="w-3.5 h-3.5" /> Option A — Local Network (Recommended)
            </TabsTrigger>
            <TabsTrigger value="cloud" className="flex-1 flex items-center gap-1.5">
              <Cloud className="w-3.5 h-3.5" /> Option B — VNNOX Cloud
            </TabsTrigger>
          </TabsList>

          {/* LOCAL */}
          <TabsContent value="local" className="space-y-4 pt-2">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
              <strong>How it works:</strong> Your BrightSign player and NovaStar controller are on the same local network. This app sends brightness commands directly to the controller's built-in web server — no cloud needed.
            </div>

            <div className="space-y-3">
              <Step number={1} title="Find your controller's IP address">
                <p>On any device on the truck's network, open <strong>NovaLCT</strong> → click <strong>"Find Devices"</strong>. The controller's IP will be listed (e.g. <code className="bg-slate-100 px-1 rounded text-xs">192.168.1.100</code>).</p>
                <p className="mt-1 text-slate-500 text-xs">Alternatively, check your router's DHCP table for a device named "NovaStar" or similar.</p>
              </Step>

              <Step number={2} title="Verify the web interface is accessible">
                <p>Open a browser on the same network and navigate to:</p>
                <code className="block bg-slate-900 text-green-400 rounded px-3 py-2 text-sm mt-1">
                  http://[CONTROLLER_IP]:5200
                </code>
                <p className="mt-1 text-slate-500 text-xs">Default credentials: username <strong>admin</strong>, password <strong>admin</strong> (or <strong>123456</strong>). If you see the NovaStar web UI, you're ready.</p>
              </Step>

              <Step number={3} title="Add the controller IP to each Screen">
                <p>Go to <strong>Trucks → Manage Screens</strong> and enter the controller's IP address for each screen. This app will then send brightness commands directly to that IP.</p>
              </Step>

              <Step number={4} title="Ensure network access from BrightSign">
                <p>The BrightSign player must be on the same subnet as the controller. Verify both devices share the same router/switch on the truck. No internet connection is required for this method.</p>
              </Step>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800">
              <strong>Note:</strong> Some NovaStar firmware versions may use port <strong>8080</strong> instead of 5200. If 5200 doesn't respond, try 8080 or check your firmware version in NovaLCT.
            </div>
          </TabsContent>

          {/* CLOUD */}
          <TabsContent value="cloud" className="space-y-4 pt-2">
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-sm text-purple-800">
              <strong>How it works:</strong> Your NovaStar controllers register with NovaStar's VNNOX cloud platform. This app calls the VNNOX REST API to push brightness changes — works from anywhere, not just the local network.
            </div>

            <div className="space-y-3">
              <Step number={1} title="Create a VNNOX account">
                <p>Go to <a href="https://www.vnnox.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">vnnox.com</a> and register as an <strong>Operator</strong>. Use your company email.</p>
              </Step>

              <Step number={2} title="Connect your controller to VNNOX via NovaLCT">
                <p>On the Windows PC connected to the controller via USB:</p>
                <ol className="list-decimal ml-4 mt-1 space-y-1 text-slate-600">
                  <li>Open <strong>NovaLCT</strong> and connect to the controller</li>
                  <li>Go to <strong>Server → Connect to VNNOX</strong></li>
                  <li>Enter your VNNOX username and password</li>
                  <li>Click <strong>Connect</strong> — the controller will appear in your VNNOX portal</li>
                </ol>
              </Step>

              <Step number={3} title="Get your API token">
                <p>In the VNNOX web portal:</p>
                <ol className="list-decimal ml-4 mt-1 space-y-1 text-slate-600">
                  <li>Go to <strong>System Settings → User Settings → API Management</strong></li>
                  <li>Click <strong>"Generate Token"</strong></li>
                  <li>Copy the token — you'll need it in the next step</li>
                  <li>Also note your <strong>Organization ID</strong> from the account settings page</li>
                </ol>
              </Step>

              <Step number={4} title="Add credentials to this app">
                <p>Go to <strong>App Settings → Integrations</strong> and enter:</p>
                <ul className="list-disc ml-4 mt-1 space-y-1 text-slate-600">
                  <li>VNNOX API Token</li>
                  <li>Organization ID</li>
                  <li>Player/Terminal ID for each screen (found in VNNOX portal under Terminal Control)</li>
                </ul>
              </Step>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-600">
              <strong>VNNOX API endpoint used:</strong><br />
              <code className="bg-slate-200 px-1 rounded">POST https://www.vnnox.com/api/v1/player/brightness</code><br />
              Requires internet access on the server. The initial NovaLCT connection only needs to be done once per controller.
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function Step({ number, title, children }) {
  return (
    <div className="flex gap-3">
      <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
        {number}
      </div>
      <div className="flex-1">
        <p className="font-semibold text-slate-800 text-sm mb-1">{title}</p>
        <div className="text-sm text-slate-600 space-y-1">{children}</div>
      </div>
    </div>
  );
}