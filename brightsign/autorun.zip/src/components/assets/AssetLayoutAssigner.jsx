import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, AlertTriangle, Link } from "lucide-react";

export default function AssetLayoutAssigner({ screen, asset, orgId, onClose, onSaved }) {
  const [selectedId, setSelectedId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const { data: templates = [] } = useQuery({
    queryKey: ["layout_templates", orgId],
    queryFn: () => base44.entities.LayoutTemplate.filter({ org_id: orgId }),
  });

  const { data: existingLayouts = [] } = useQuery({
    queryKey: ["asset_layouts_screen", screen.id],
    queryFn: () => base44.entities.AssetLayout.filter({ screen_id: screen.id }),
  });

  const existing = existingLayouts[0];

  const isCompatible = (t) =>
    Number(t.canvas_width) === Number(screen.width) &&
    Number(t.canvas_height) === Number(screen.height);

  const compatible = templates.filter(t => !t.is_archived && isCompatible(t));
  const incompatible = templates.filter(t => !isCompatible(t));

  const save = async () => {
    if (!selectedId) return;
    const template = templates.find(t => t.id === selectedId);

    // Client-side pre-check (UX guard)
    if (!isCompatible(template)) {
      setError(
        `Dimension mismatch: Screen is ${screen.width}\u00d7${screen.height}px but ` +
        `"${template.name}" is ${template.canvas_width}\u00d7${template.canvas_height}px. ` +
        `They must match exactly.`
      );
      return;
    }

    setSaving(true);
    setError(null);
    try {
      // Route through server-enforced backend function (hard block at data layer)
      const res = await base44.functions.invoke('assignAssetLayout', {
        asset_id: asset.id,
        screen_id: screen.id,
        layout_template_id: selectedId,
      });
      if (res.data?.error) {
        setError(res.data.message || res.data.error);
        setSaving(false);
        return;
      }
      onSaved();
    } catch (e) {
      setError(e.response?.data?.message || e.response?.data?.error || e.message);
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg flex flex-col" style={{ maxHeight: '80vh' }}>
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>
            <span className="flex items-center gap-2">
              <Link className="w-4 h-4" />
              Assign Layout — {screen.name}
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4 pt-2 pr-1">
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm flex items-center justify-between">
            <span className="text-slate-600">Screen dimensions</span>
            <span className="font-mono font-semibold text-slate-900">{screen.width}×{screen.height}px</span>
          </div>

          {error && (
            <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">
              <XCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          {/* Compatible templates */}
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
              Compatible Templates ({compatible.length})
            </p>
            {compatible.length === 0 ? (
              <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-700">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                No compatible templates for {screen.width}×{screen.height}px.
                Create a Layout Template with matching dimensions first.
              </div>
            ) : (
              <div className="space-y-2">
                {compatible.map(t => {
                  const isCurrent = existing?.layout_template_id === t.id;
                  const isSelected = selectedId === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setSelectedId(t.id)}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-lg border text-left transition-colors ${
                        isSelected
                          ? "border-blue-500 bg-blue-50"
                          : isCurrent
                          ? "border-green-400 bg-green-50"
                          : "border-slate-200 hover:border-slate-300 bg-white"
                      }`}
                    >
                      <div>
                        <div className="font-medium text-sm text-slate-900">{t.name}</div>
                        <div className="text-xs text-slate-400">{t.canvas_width}×{t.canvas_height}px</div>
                      </div>
                      <div className="flex items-center gap-2">
                        {isCurrent && <span className="text-xs text-green-600 font-medium">Current</span>}
                        <CheckCircle2 className={`w-4 h-4 ${isSelected ? "text-blue-500" : "text-slate-200"}`} />
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Incompatible templates (shown for awareness) */}
          {incompatible.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">
                Incompatible — dimension mismatch (cannot assign)
              </p>
              <div className="space-y-1">
                {incompatible.map(t => (
                  <div key={t.id} className="flex items-center justify-between px-4 py-2 rounded-lg bg-slate-50 border border-slate-100 opacity-50">
                    <span className="text-sm text-slate-500">{t.name}</span>
                    <span className="text-xs text-slate-400 font-mono">{t.canvas_width}×{t.canvas_height}px</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 flex-shrink-0">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={save} disabled={saving || !selectedId}>
              {saving ? "Assigning..." : "Assign Layout"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}