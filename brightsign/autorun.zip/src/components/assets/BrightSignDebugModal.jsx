import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Copy, CheckCircle2, Loader2, AlertCircle, FlaskConical, ChevronRight, BadgeCheck, AlertTriangle } from "lucide-react";

// NEW CLEAN STAGE PIPELINE — rebuilt from Stage 3 baseline
// Each stage adds exactly ONE line of code
const CLEAN_STAGES = [
  { 
    key: 'stage3_clone_label_only', 
    name: 'Stage 3B: Label-Only Clone', 
    status: 'STABLE', 
    color: 'green', 
    desc: 'Stage 3 + visible label changes only. NO runtime logic changes. Baseline verification.' 
  },
  { 
    key: 'stage3_js_send_only', 
    name: 'Stage 3C: JS Bridge Send (BSMessagePort)', 
    status: 'TESTED', 
    color: 'amber', 
    desc: 'Stage 3B + new BSMessagePort().postBSMessage(). BSMessagePort was undefined — need probe.' 
  },
  { 
    key: 'stage3_bridge_probe', 
    name: 'Stage 3C-P: JS Bridge Probe', 
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: BSMessagePort=undefined, window.postMessage=function. window.postMessage is the only viable bridge path.' 
  },
  {
    key: 'stage3_window_postmessage_send',
    name: 'Stage 3D: window.postMessage Send',
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: window.postMessage sends successfully. JS bridge path confirmed working.'
  },
  {
    key: 'stage3_window_postmessage_receive',
    name: 'Stage 3E: BrightScript Receive-Only',
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: BS receives SF_TEST and logs it. Receive-only confirmed stable. No ACK.'
  },
  {
    key: 'stage3_window_postmessage_ack',
    name: 'Stage 3F: BrightScript ACK',
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: h.PostMessage ACK did not return to HTML (8s timeout). One-way bridge confirmed. Moving forward without roundtrip dependency.'
  },
  {
    key: 'stage3_hdmi_parse_only',
    name: 'Stage 3G: HDMI Payload Parse-Only',
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: BS receives SF_HDMI_ZONES and parses zone geometry. Stable. No object creation.'
  },
  {
    key: 'stage3_hdmi_objects_only',
    name: 'Stage 3H: HDMI Object Creation Only (both)',
    status: 'BLANK SCREEN',
    color: 'amber',
    desc: 'RESULT: Blank screen (no ERR light, no crash). One of the two CreateObject calls is hiding the HTML layer. Split into 3H-A and 3H-B to isolate which one.'
  },
  {
    key: 'stage3_hdmi_videoinput_only',
    name: 'Stage 3H-A: roVideoInput ONLY',
    status: 'TEST NEXT',
    color: 'amber',
    desc: 'SPLIT TEST A — CYAN BORDER. Creates roVideoInput only. No roVideoPlayer. No PlayFile. If HTML panel stays visible → roVideoInput is safe. If blank → roVideoInput causes the black screen.'
  },
  {
    key: 'stage3_hdmi_videoplayer_only',
    name: 'Stage 3H-B: roVideoPlayer ONLY',
    status: 'DONE ✓',
    color: 'green',
    desc: 'Both split tests confirmed stable. Object creation does NOT blank the display. Moving to PlayFile.'
  },
  {
    key: 'stage3_hdmi_playfile_only',
    name: 'Stage 3I: PlayFile(roVideoInput) — RED BORDER',
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: PlayFile does not crash. Runtime alive 3s/10s/20s after call. Feed not visible — missing display-plane setup. Moving to rect/z-order stage.'
  },
  {
    key: 'stage3_hdmi_playfile_with_rect',
    name: 'Stage 3J: PlayFile + SetRectangle + SetVideoZOrder',
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: Confirmed stable — SetRectangle + ZOrder do not crash. Feed still not visible. Moving to port binding.'
  },
  {
    key: 'stage3_hdmi_final_binding_test',
    name: 'Stage 3K: SetHDMIInput(0) — Port Binding Test',
    status: 'DONE ✓',
    color: 'green',
    desc: 'RESULT: Runtime stayed alive. Feed still did not appear. SetHDMIInput(0) alone was not sufficient.'
  },
  {
    key: 'stage3_hdmi_setport_test',
    name: 'Stage 3L: videoPlayer.SetPort(msgPort) — Full Sequence',
    status: 'TEST NEXT',
    color: 'amber',
    desc: 'ADDITION: videoPlayer.SetPort(msgPort) before PlayFile. BrightScript API: roVideoPlayer requires SetPort so its internal state machine can drive the display pipeline. Full sequence: SetHDMIInput(0) + SetPort + SetRectangle + SetVideoZOrder + PlayFile. Blue border on screen.'
  },
  { 
    key: 'stage3_bs_receive_log', 
    name: 'Stage 3E: BrightScript ACK (after postMessage confirmed)', 
    status: 'BLOCKED',
    color: 'slate',
    desc: 'Stage 3D + BrightScript sends minimal ACK back. Only after postMessage receive is confirmed.' 
  },
  { 
    key: 'stage3_bs_ack', 
    name: 'Stage 3E: BrightScript ACK', 
    status: 'BLOCKED', 
    color: 'slate', 
    desc: 'Stage 3D + minimal ACK back to HTML. NO HDMI object creation yet.' 
  },
  { 
    key: 'stage3_hdmi_objects', 
    name: 'Stage 3F: HDMI Object Creation', 
    status: 'BLOCKED', 
    color: 'slate', 
    desc: 'Stage 3E + create roVideoInput + roVideoPlayer. NO PlayFile(...) yet.' 
  },
  { 
    key: 'stage3_hdmi_full', 
    name: 'Stage 3G: Full HDMI Activation', 
    status: 'BLOCKED', 
    color: 'slate', 
    desc: 'Stage 3F + PlayFile(roVideoInput). Complete HDMI bridge.' 
  },
];

// DEPRECATED: Old broken Stage 5/5A pipeline — shown for reference only
const DEPRECATED_STAGES = [
  { key: 'bridge_js_only', name: 'Stage 5A-1: JS Marker Only', status: 'DEPRECATED', desc: 'Old broken pipeline — DO NOT USE' },
  { key: 'bridge_js_send', name: 'Stage 5A-2: JS Send Only', status: 'DEPRECATED', desc: 'Old broken pipeline — DO NOT USE' },
  { key: 'bridge_bs_receive', name: 'Stage 5A-3: BrightScript Receive', status: 'DEPRECATED', desc: 'Old broken pipeline — DO NOT USE' },
  { key: 'bridge_bs_ack', name: 'Stage 5A-4: Receive + ACK', status: 'DEPRECATED', desc: 'Old broken pipeline — DO NOT USE' },
];

export default function BrightSignDebugModal({ asset, onClose }) {
  const [selectedStage, setSelectedStage] = useState('stage3_clone_label_only');
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState(null);

  const handleDownload = async () => {
    setDownloading(true);
    setError(null);
    try {
      // CRITICAL: Uses NEW clean generator only
      const res = await base44.functions.invoke("generateBrightSignCleanStages", { 
        assetId: asset.id, 
        stage: selectedStage 
      });
      const { base64, filename } = res.data;
      if (!base64) throw new Error("Package generation returned no data.");

      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename || `brightsign-v2-CLEAN-${selectedStage}-${asset.name.toLowerCase().replace(/\s+/g, "-")}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e?.message || "Package generation failed.");
    } finally {
      setDownloading(false);
    }
  };

  const stageIndex = CLEAN_STAGES.findIndex(s => s.key === selectedStage);
  const selectedStageData = CLEAN_STAGES.find(s => s.key === selectedStage);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-purple-600" />
            🔬 Clean Stage Debug Generator — Stage 3 Baseline
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 pt-1">
          {/* Generator indicator — CRITICAL for trust */}
          <div className="rounded-lg border-2 border-green-300 bg-green-50 p-3">
            <div className="flex items-center gap-2">
              <BadgeCheck className="w-5 h-5 text-green-600" />
              <div>
                <div className="font-semibold text-green-800 text-sm">Generator: generateBrightSignCleanStages</div>
                <div className="text-xs text-green-700">
                  Rebuilt from Stage 3 baseline. Each stage adds exactly ONE line of code.
                </div>
              </div>
            </div>
          </div>

          {/* Purpose callout */}
          <div className="rounded-lg border border-purple-200 bg-purple-50 p-4">
            <div className="font-semibold text-purple-900 mb-2">🎯 Purpose: Find the Exact Breaking Point</div>
            <p className="text-purple-800 text-sm leading-relaxed">
              <strong>Stage 3 (payload_test)</strong> is proven working on hardware.
              This clean pipeline rebuilds from that baseline, adding one tiny change at a time.
            </p>
            <p className="text-purple-700 text-sm mt-2">
              <strong>Method:</strong> Deploy Stage 3B → verify stable → deploy Stage 3C → repeat.
              The first stage that crashes reveals the exact breaking line.
            </p>
          </div>

          {/* Next recommended stage highlight */}
          <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-100 border-2 border-amber-400 flex items-center justify-center flex-shrink-0">
                <span className="text-amber-700 font-bold text-xs">3D</span>
              </div>
              <div>
                <div className="font-bold text-amber-900">Next Stage to Test: Stage 3D (window.postMessage Send)</div>
                <div className="text-sm text-amber-800 mt-1">
                  Probe confirmed: <code className="bg-amber-100 px-1 rounded">window.postMessage</code> is the only viable JS bridge path (BSMessagePort=undefined).
                  This stage sends <code className="bg-amber-100 px-1 rounded">window.postMessage(&#123; type: 'SF_TEST' &#125;, '*')</code> after boot.
                  BrightScript listens for <code className="bg-amber-100 px-1 rounded">roHtmlWidgetEvent</code> with <code className="bg-amber-100 px-1 rounded">payload.reason = "message"</code> and logs the message type. No ACK yet.
                </div>
              </div>
            </div>
          </div>

          {/* Clean stage selector */}
          <div>
            <div className="text-sm font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <span>Select Clean Stage</span>
              <span className="text-xs font-normal text-slate-500">(New Pipeline)</span>
            </div>
            <div className="grid grid-cols-1 gap-2">
              {CLEAN_STAGES.map((stage, i) => {
                const isSelected = selectedStage === stage.key;
                const isNext = stage.status === 'TEST NEXT';
                const colorMap = {
                  green: 'bg-green-100 text-green-800 border-green-300',
                  amber: 'bg-amber-100 text-amber-800 border-amber-300',
                  slate: 'bg-slate-100 text-slate-800 border-slate-300',
                };
                return (
                  <button
                    key={stage.key}
                    onClick={() => setSelectedStage(stage.key)}
                    className={`flex items-center gap-3 p-3 rounded-lg border text-left transition-all ${
                      isSelected ? 'ring-2 ring-purple-500 border-purple-300 bg-purple-50' : 'hover:bg-slate-50'
                    } ${isNext ? 'border-amber-300' : ''}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border ${colorMap[stage.color]}`}>
                      {i}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-slate-800">{stage.name}</div>
                      <div className="text-xs text-slate-600">{stage.desc}</div>
                    </div>
                    <div className={`text-xs px-2 py-1 rounded font-medium ${colorMap[stage.color]}`}>
                      {stage.status}
                    </div>
                    <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-purple-600' : 'text-slate-400'}`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Deprecated stages warning */}
          <div className="rounded-lg border border-red-200 bg-red-50 p-3">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <div className="font-semibold text-red-800 text-sm">Deprecated: Old Stage 5/5A Pipeline</div>
            </div>
            <div className="text-xs text-red-700 space-y-1">
              <p>The following stages are from the broken generator and should NOT be used:</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {DEPRECATED_STAGES.map(s => (
                  <span key={s.key} className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-xs line-through">
                    {s.name}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Asset info */}
          <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600 font-mono space-y-0.5">
            <div><span className="text-slate-400">Asset:</span> {asset.name}</div>
            <div><span className="text-slate-400">Asset ID:</span> {asset.id}</div>
            <div><span className="text-slate-400">Model:</span> {asset.player_model || "BrightSign"}</div>
            <div><span className="text-slate-400">Selected Stage:</span> <span className="text-purple-600 font-semibold">{selectedStageData?.name}</span></div>
            <div><span className="text-slate-400">Stage Key:</span> <span className="text-slate-500">{selectedStage}</span></div>
            <div><span className="text-slate-400">Generator:</span> <span className="text-green-600 font-semibold">generateBrightSignCleanStages</span></div>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-start gap-2 rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Download button */}
          <Button
            onClick={handleDownload}
            disabled={downloading}
            className="w-full bg-purple-600 hover:bg-purple-700 h-11"
          >
            {downloading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating Clean Stage Package…</>
            ) : (
              <><Download className="w-4 h-4 mr-2" /> Download {selectedStageData?.name} (.zip)</>
            )}
          </Button>

          {/* Testing instructions */}
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
            <div className="font-semibold text-amber-900 mb-2">📋 Testing Instructions (Clean Pipeline)</div>
            <ol className="text-sm text-amber-800 space-y-2">
              <li>1. Download and deploy <strong>Stage 3B (Label-Only Clone)</strong> to SD card</li>
              <li>2. Boot BrightSign, verify it behaves exactly like Stage 3</li>
              <li>3. Check on-screen label shows "Clean Stage 0"</li>
              <li>4. If stable, proceed to Stage 3C (JS Bridge Send)</li>
              <li>5. Continue sequentially until a stage fails</li>
              <li>6. <strong>Report the failing stage</strong> — that's the exact breaking point!</li>
            </ol>
            <div className="mt-3 text-xs text-amber-700">
              <strong>Rule:</strong> Each stage adds exactly ONE line. No template interpolation. No duplicate functions.
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end items-center pt-1 border-t border-slate-100">
            <Button variant="outline" onClick={onClose}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}