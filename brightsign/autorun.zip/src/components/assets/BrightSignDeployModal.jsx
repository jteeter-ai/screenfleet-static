import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Copy, CheckCircle2, Loader2, AlertCircle, Package } from "lucide-react";

const DEPLOY_STEPS = [
  "Download the ScreenFleet BrightSign package zip above.",
  "Extract all files to the root of a blank SD card (FAT32, 16 GB+ recommended).",
  "Insert the SD card into the BrightSign player.",
  "Power cycle or reboot the player — it auto-starts into ScreenFleet native mode.",
  "The player will fetch its latest published content on first boot and cache it locally.",
];

const DEPLOY_TEXT = `BrightSign Native Package Deployment
=====================================
1. Download the ScreenFleet BrightSign package zip.
2. Extract ALL files to the ROOT of a blank SD card (FAT32, 16 GB+ recommended).
3. Insert the SD card into the BrightSign player.
4. Power cycle or reboot the player.
5. The player auto-starts into ScreenFleet native mode and fetches published content.

Notes:
- Native Package Mode is required for advanced BrightSign features (HDMI input, hardware-native control).
- Hosted HTML mode inside BrightAuthor is fallback/content mode only — it does NOT support native HDMI.
- Re-download and redeploy a fresh package after major content structure changes.
- No BrightAuthor Admin is required for native package deployment.`;

export default function BrightSignDeployModal({ asset, onClose }) {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("generateBrightSignFiles", { assetId: asset.id });
      const { base64, filename } = res.data;
      if (!base64) throw new Error("Package generation returned no data. Ensure the asset has screens and published content.");

      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename || `brightsign-${asset.name.toLowerCase().replace(/\s+/g, "-")}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setDownloaded(true);
    } catch (e) {
      setError(e?.message || "Package generation failed. Check that the asset has screens and published content.");
    } finally {
      setDownloading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(DEPLOY_TEXT).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-600" />
            BrightSign Native Package Deployment
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-1">
          {/* Mode callout */}
          <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm">
            <div className="font-semibold text-blue-800 mb-1">⚡ Native Package Mode — Recommended</div>
            <p className="text-blue-700 text-xs leading-relaxed">
              This is the full-feature BrightSign deployment path. ScreenFleet owns the runtime directly — enabling HDMI input, hardware-native playback, and local content caching.
            </p>
            <p className="text-blue-500 text-xs mt-1">
              Hosted HTML mode (BrightAuthor HTML widget) is fallback/content mode only — it does not support native HDMI or hardware features.
            </p>
          </div>

          {/* Asset info */}
          <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600 font-mono space-y-0.5">
            <div><span className="text-slate-400">Asset:</span> {asset.name}</div>
            <div><span className="text-slate-400">Asset ID:</span> {asset.id}</div>
            <div><span className="text-slate-400">Model:</span> {asset.player_model || "BrightSign"}</div>
            <div><span className="text-slate-400">Runtime Mode:</span> <span className="text-green-600">native-package</span></div>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-start gap-2 rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Download button */}
          <Button
            onClick={handleDownload}
            disabled={downloading}
            className="w-full bg-blue-600 hover:bg-blue-700 h-10"
          >
            {downloading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating Package…</>
            ) : downloaded ? (
              <><CheckCircle2 className="w-4 h-4 mr-2" /> Downloaded — Download Again</>
            ) : (
              <><Download className="w-4 h-4 mr-2" /> Download BS Package (.zip)</>
            )}
          </Button>

          {/* Deployment steps */}
          <div>
            <div className="text-sm font-semibold text-slate-800 mb-2">Deployment Steps</div>
            <ol className="space-y-2">
              {DEPLOY_STEPS.map((step, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700">
                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-xs font-bold flex-shrink-0 flex items-center justify-center mt-0.5">
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>

          {/* Notes */}
          <div className="rounded border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 space-y-1 leading-relaxed">
            <div className="font-semibold">Important Notes</div>
            <ul className="list-disc list-inside space-y-0.5">
              <li>Native Package Mode is required for HDMI input and hardware-native features.</li>
              <li>Hosted HTML mode inside BrightAuthor is fallback/content mode — HDMI not supported.</li>
              <li>Re-download and redeploy after major content structure changes.</li>
              <li>No BrightAuthor Admin account required for SD card deployment.</li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex justify-between items-center pt-1 border-t border-slate-100">
            <Button variant="ghost" size="sm" onClick={handleCopy} className="text-slate-500 text-xs gap-1.5">
              {copied
                ? <><CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> Copied!</>
                : <><Copy className="w-3.5 h-3.5" /> Copy Instructions</>
              }
            </Button>
            <Button variant="outline" onClick={onClose}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}