import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Copy, CheckCircle2, Loader2, AlertCircle, TestTube } from "lucide-react";

const DEPLOY_STEPS = [
  "Download the minimal boot test package zip above.",
  "Extract ALL files to the root of a blank SD card (FAT32, any size).",
  "Insert the SD card into the BrightSign player.",
  "Power cycle or reboot the player.",
  "Watch for the blue screen with large white text proving native boot works.",
];

const DEPLOY_TEXT = `ScreenFleet Minimal Boot Test Deployment
==========================================
1. Download the minimal boot test package zip.
2. Extract ALL files to the ROOT of a blank SD card (FAT32, any size).
3. Insert the SD card into the BrightSign player.
4. Power cycle or reboot the player.
5. Watch for the blue screen with "ScreenFleet Native Boot Test".

WHAT YOU SHOULD SEE
-------------------
If native boot works:
  - Blue background (#1e3a5f)
  - Large white text: "ScreenFleet Native Boot Test"
  - Green status box: "✓ autorun.brs started ✓ HTML widget loaded"
  - Gray meta text about "No HDMI • No Network"

If you see this:
  → Native SD boot is working
  → roHtmlWidget is functioning
  → Local HTML rendering works
  → The issue is in the FULL package (HDMI/runtime logic)

If you see blank/black screen:
  → Native SD boot is failing
  → Issue is more fundamental than HDMI
  → Check: SD card format, BrightSign model, autorun.brs syntax

WHAT THIS PACKAGE DOES
----------------------
- Boots from SD card as standalone native package
- Runs autorun.brs
- Opens local index.html
- Displays obvious "boot success" text
- Prints [SF-BOOTTEST] logs

WHAT THIS PACKAGE DOES NOT DO
-----------------------------
- No HDMI input activation
- No network calls (screenPayload, version check)
- No BSMessagePort bridge to BrightScript
- No service worker or caching
- No runtime canvas or zone rendering
- No remote content fetching

NEXT STEPS
----------
If this boots cleanly:
  → The full ScreenFleet package has a bug
  → Incrementally add complexity back to find crash point

If this also fails:
  → Issue is fundamental (SD card, BrightSign model, autorun.brs)
  → Not related to HDMI or runtime complexity`;

export default function BrightSignBootTestModal({ asset, onClose }) {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("generateBrightSignBootTest", { assetId: asset.id });
      const { base64, filename } = res.data;
      if (!base64) throw new Error("Package generation returned no data.");

      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename || `brightsign-boot-test-${asset.name.toLowerCase().replace(/\s+/g, "-")}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setDownloaded(true);
    } catch (e) {
      setError(e?.message || "Package generation failed.");
    } finally {
      setDownloading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(DEPLOY_TEXT).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TestTube className="w-5 h-5 text-amber-600" />
            Minimal BrightSign Boot Test Package
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-1">
          {/* Purpose callout */}
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm">
            <div className="font-semibold text-amber-800 mb-1">🔬 Purpose: Isolate Native Boot</div>
            <p className="text-amber-700 text-xs leading-relaxed">
              This is a STRIPPED-DOWN package to prove whether standalone SD card boot works at all.
              No HDMI, no network, no message bridge, no complexity.
            </p>
            <p className="text-amber-600 text-xs mt-1">
              If this fails → issue is fundamental. If this works → full package has a bug.
            </p>
          </div>

          {/* Asset info */}
          <div className="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600 font-mono space-y-0.5">
            <div><span className="text-slate-400">Asset:</span> {asset.name}</div>
            <div><span className="text-slate-400">Asset ID:</span> {asset.id}</div>
            <div><span className="text-slate-400">Model:</span> {asset.player_model || "BrightSign"}</div>
            <div><span className="text-slate-400">Package Type:</span> <span className="text-amber-600">minimal-boot-test</span></div>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-start gap-2 rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Download button */}
          <Button
            onClick={handleDownload}
            disabled={downloading}
            className="w-full bg-amber-600 hover:bg-amber-700 h-10"
          >
            {downloading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating Test Package…</>
            ) : downloaded ? (
              <><CheckCircle2 className="w-4 h-4 mr-2" /> Downloaded — Download Again</>
            ) : (
              <><Download className="w-4 h-4 mr-2" /> Download Boot Test (.zip)</>
            )}
          </Button>

          {/* Deployment steps */}
          <div>
            <div className="text-sm font-semibold text-slate-800 mb-2">Deployment Steps</div>
            <ol className="space-y-2">
              {DEPLOY_STEPS.map((step, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700">
                  <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-xs font-bold flex-shrink-0 flex items-center justify-center mt-0.5">
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>

          {/* What you should see */}
          <div className="rounded border border-green-200 bg-green-50 p-3 text-xs text-green-800 space-y-2">
            <div className="font-semibold">What You Should See (If Native Boot Works)</div>
            <ul className="list-disc list-inside space-y-0.5">
              <li>Blue background (#1e3a5f)</li>
              <li>Large white text: "ScreenFleet Native Boot Test"</li>
              <li>Green status box with checkmarks</li>
              <li>Gray meta text: "No HDMI • No Network • No Bridge"</li>
            </ul>
          </div>

          {/* What this package does/doesn't do */}
          <div className="rounded border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700 space-y-2">
            <div className="font-semibold">This Package Does</div>
            <ul className="list-disc list-inside space-y-0.5">
              <li>Boots from SD card as standalone native package</li>
              <li>Runs autorun.brs</li>
              <li>Opens local index.html</li>
              <li>Displays obvious "boot success" text</li>
              <li>Prints [SF-BOOTTEST] logs</li>
            </ul>
            <div className="font-semibold mt-3">This Package Does NOT Do</div>
            <ul className="list-disc list-inside space-y-0.5">
              <li>No HDMI input activation</li>
              <li>No network calls (screenPayload, version check)</li>
              <li>No BSMessagePort bridge to BrightScript</li>
              <li>No service worker or caching</li>
              <li>No runtime canvas or zone rendering</li>
              <li>No remote content fetching</li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex justify-between items-center pt-1 border-t border-slate-100">
            <Button variant="ghost" size="sm" onClick={handleCopy} className="text-slate-500 text-xs gap-1.5">
              {copied
                ? <><CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> Copied!</>
                : <><Copy className="w-3.5 h-3.5" /> Copy Instructions</>
              }
            </Button>
            <Button variant="outline" onClick={onClose}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}