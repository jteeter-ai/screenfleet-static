/**
 * ResyncButton — Manual Player Sync Trigger
 * Admin-only button to force-push screen data to the ScreenFleet Player app.
 * Shows sync status and last sync result inline.
 */
import React, { useState } from "react";
import { RefreshCw, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function ResyncButton({ screenId, className = "" }) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null); // { ok, error }

  const handleResync = async () => {
    if (!screenId) { toast.error("No screen ID"); return; }
    setLoading(true);
    setResult(null);
    try {
      const res = await base44.functions.invoke("syncToPlayer", { screenId });
      const data = res.data;
      setResult({ ok: data.ok, error: data.error });
      if (data.ok) {
        toast.success("Screen synced to Player app");
      } else {
        toast.error(data.error || "Sync failed — check logs");
      }
    } catch (err) {
      setResult({ ok: false, error: err.message });
      toast.error("Sync error: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Button
        variant="outline"
        size="sm"
        onClick={handleResync}
        disabled={loading}
        className="h-7 text-xs gap-1.5"
      >
        <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
        {loading ? "Syncing…" : "Sync to Player"}
      </Button>
      {result !== null && (
        result.ok
          ? <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" title="Synced" />
          : <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" title={result.error} />
      )}
    </div>
  );
}