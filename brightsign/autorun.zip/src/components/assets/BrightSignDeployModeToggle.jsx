import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Copy, CheckCircle2, Download, Loader2 } from "lucide-react";
import { format } from "date-fns";

/**
 * BrightSign Deployment Mode Toggle
 * Props:
 *   asset       — Asset record (includes player_deployment_mode, native_token_provisioned_at, native_last_sync_at)
 *   screens     — Screen[] for this asset (from parent)
 *   onModeChange(updatedAsset) — called after successful mode switch
 *   onOpenDeployModal          — called to open HTML-feed deploy modal
 */
export default function BrightSignDeployModeToggle({ asset, screens = [], onModeChange, onOpenDeployModal }) {
  const [saving, setSaving] = useState(false);
  const [tokenCopied, setTokenCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState(null);

  const mode = asset.player_deployment_mode || "html_feed";
  const isNative = mode === "native_install";

  const primaryScreen = screens[0] || null;
  const screenToken = primaryScreen?.public_token || null;

  // ── Mode toggle ────────────────────────────────────────────────────────────
  const handleToggle = async (newMode) => {
    if (newMode === mode || saving) return;
    setSaving(true);
    try {
      await base44.entities.Asset.update(asset.id, { player_deployment_mode: newMode });
      onModeChange?.({ ...asset, player_deployment_mode: newMode });
      toast.success(`Deployment mode set to ${newMode === "native_install" ? "Native Install" : "HTML Feed"}`);
    } catch (e) {
      toast.error("Failed to update deployment mode: " + e.message);
    } finally {
      setSaving(false);
    }
  };

  // ── Copy token ─────────────────────────────────────────────────────────────
  const handleCopyToken = () => {
    if (!screenToken) return;
    navigator.clipboard.writeText(screenToken);
    setTokenCopied(true);
    setTimeout(() => setTokenCopied(false), 2000);
  };

  // ── Download native package ────────────────────────────────────────────────
  const handleDownloadPackage = async () => {
    setDownloading(true);
    setDownloadError(null);
    try {
      const response = await base44.functions.invoke("generateBrightSignFiles", { assetId: asset.id });
      const { base64, filename } = response.data;
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: "application/zip" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename || "autorun.zip";
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setDownloadError(e.message || "Download failed");
    } finally {
      setDownloading(false);
    }
  };

  const fmtDate = (iso) => {
    try { return format(new Date(iso), "MMM d, yyyy h:mm a"); } catch { return iso; }
  };

  return (
    <div className="mb-4 pb-4 border-b border-slate-100">
      {/* Section label */}
      <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
        Player Deployment Mode
      </div>

      {/* Segmented toggle */}
      <div className="inline-flex rounded-lg overflow-hidden border border-slate-200 text-xs font-medium">
        <button
          onClick={() => handleToggle("html_feed")}
          disabled={saving}
          className={`px-4 py-1.5 transition-colors ${
            !isNative ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
          }`}
        >
          HTML Feed
        </button>
        <button
          onClick={() => handleToggle("native_install")}
          disabled={saving}
          className={`px-4 py-1.5 transition-colors border-l border-slate-200 ${
            isNative ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
          }`}
        >
          Native Install
        </button>
      </div>

      {/* ── HTML Feed mode ── */}
      {!isNative && (
        <div className="mt-3">
          <button
            onClick={onOpenDeployModal}
            className="inline-flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-800 border border-blue-200 rounded px-2.5 py-1 bg-white hover:bg-blue-50 transition-colors"
          >
            Download BrightSign Package (.zip)
          </button>
        </div>
      )}

      {/* ── Native Install panel ── */}
      {isNative && (
        <div className="mt-3 space-y-4">

          {/* SECTION 1: Provisioning status */}
          {!asset.native_token_provisioned_at ? (
            <div className="flex flex-col gap-1 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5">
              <span className="text-xs font-semibold text-amber-700">⚠️ Not yet provisioned</span>
              <span className="text-xs text-amber-600">
                Download the native package and install it on your BrightSign player to get started.
              </span>
            </div>
          ) : (
            <div className="flex flex-col gap-0.5 rounded-lg border border-green-200 bg-green-50 px-3 py-2.5">
              <span className="text-xs font-semibold text-green-700">✅ Provisioned</span>
              <span className="text-xs text-green-600">First linked: {fmtDate(asset.native_token_provisioned_at)}</span>
              {asset.native_last_sync_at && (
                <span className="text-xs text-green-600">Last sync: {fmtDate(asset.native_last_sync_at)}</span>
              )}
            </div>
          )}

          {/* SECTION 2: Screen Token */}
          <div>
            <div className="text-xs font-semibold text-slate-500 mb-1">Screen Token</div>
            {!screenToken ? (
              <p className="text-xs text-slate-400 italic">
                No screen configured. Add a screen to this asset first.
              </p>
            ) : (
              <div className="flex items-center gap-2">
                <span className="flex-1 font-mono text-sm text-slate-800 bg-slate-100 rounded px-2.5 py-1.5 select-all break-all">
                  {screenToken}
                </span>
                <button
                  onClick={handleCopyToken}
                  className="shrink-0 flex items-center gap-1 text-xs text-slate-500 hover:text-blue-600 border border-slate-200 bg-white rounded px-2 py-1.5 transition-colors"
                >
                  {tokenCopied
                    ? <><CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Copied!</>
                    : <><Copy className="w-3.5 h-3.5" /> Copy</>
                  }
                </button>
              </div>
            )}
          </div>

          {/* SECTION 3: QR Code */}
          {screenToken && (
            <div className="flex flex-col items-center gap-1">
              <span className="text-xs text-slate-500">Scan on player setup screen</span>
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(primaryScreen.public_token)}`}
                alt="Screen token QR code"
                width={200}
                height={200}
                style={{ borderRadius: '8px' }}
              />
            </div>
          )}

          {/* SECTION 4: Download + Instructions */}
          <div>
            <button
              onClick={handleDownloadPackage}
              disabled={downloading}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-medium rounded-lg px-4 py-2 transition-colors"
            >
              {downloading
                ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating…</>
                : <><Download className="w-4 h-4" /> Download Native Package (autorun.zip)</>
              }
            </button>
            {downloadError && (
              <p className="text-xs text-red-500 mt-1">{downloadError}</p>
            )}

            <div className="mt-3 text-xs text-slate-400 space-y-0.5 leading-relaxed">
              <p>1. Copy <span className="font-mono">autorun.zip</span> to the root of a blank FAT32 SD card</p>
              <p>2. Insert SD card into BrightSign player and power on</p>
              <p>3. Enter the Screen Token above when prompted on the player screen</p>
              <p className="text-slate-300">— or —</p>
              <p>Provision via BSN.cloud: Admin → Setup → Partner App → ScreenFleet</p>
              <p className="text-slate-300">(Use App URL: https://app.screenfleet.io/brightsign/autorun.zip until officially listed)</p>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}