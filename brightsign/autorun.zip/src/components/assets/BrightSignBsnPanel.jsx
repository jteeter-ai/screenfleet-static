import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ExternalLink, Network, Copy } from "lucide-react";

/**
 * BrightSign App URL (BSN Managed) panel.
 * Shown inside AssetDialog when player_type=brightsign AND bsn_deployment_mode=bsn_app_url.
 * This is purely additive — does not touch Native Package or any other flow.
 */
export default function BrightSignBsnPanel({ playerUrl, onCopy, error }) {
  return (
    <div className="rounded-lg border border-indigo-200 bg-indigo-50 p-3 space-y-3">
      <div className="flex items-center gap-2">
        <Network className="w-4 h-4 text-indigo-600 flex-shrink-0" />
        <div className="text-xs font-semibold text-indigo-800">BrightSign App URL (BSN Managed)</div>
      </div>

      <p className="text-xs text-indigo-700 leading-relaxed">
        Provision a BrightSign player through{" "}
        <strong>BrightAuthor:connected / BSN.Cloud</strong> using the App URL below. The player
        fetches and runs the ScreenFleet application — BrightSign network visibility, remote
        monitoring, and BA:C controls remain fully active.
      </p>

      <div className="rounded border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 leading-relaxed">
        <strong>Note:</strong> This is the "App URL" provisioning method in BrightAuthor:connected,
        not a Web Folder or live feed mode.
      </div>

      <div>
        <Label className="text-xs text-indigo-800 mb-1 block">App URL (auto-generated)</Label>
        <div className="flex gap-2">
          <Input
            value={playerUrl || "Save asset first to generate URL"}
            readOnly
            className="text-xs bg-white text-slate-700 cursor-default select-all"
          />
          {playerUrl && (
            <Button type="button" variant="outline" size="icon" onClick={onCopy} title="Copy URL">
              <Copy className="w-4 h-4" />
            </Button>
          )}
          {playerUrl && (
            <a href={playerUrl} target="_blank" rel="noopener noreferrer">
              <Button type="button" variant="outline" size="icon" title="Open in new tab">
                <ExternalLink className="w-4 h-4" />
              </Button>
            </a>
          )}
        </div>
        <p className="text-[10px] text-indigo-500 mt-1">
          Paste this URL into BrightAuthor:connected → App URL field to deploy this screen.
        </p>
      </div>
    </div>
  );
}