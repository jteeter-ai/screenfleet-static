import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const POSITIONS = ["left_side", "right_side", "rear", "front", "custom"];

export default function ScreenDialog({ mode, screen, assetId, orgId, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: screen?.name || "",
    position: screen?.position || "custom",
    screen_mode: screen?.screen_mode || "led",
    width: screen?.width || "",
    height: screen?.height || "",
    start_x: screen?.start_x ?? 0,
    start_y: screen?.start_y ?? 0,
  });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!Number(form.width) || Number(form.width) <= 0) e.width = "Width must be > 0";
    if (!Number(form.height) || Number(form.height) <= 0) e.height = "Height must be > 0";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = async () => {
    if (!validate()) return;
    setSaving(true);
    const data = {
      ...form,
      width: Number(form.width),
      height: Number(form.height),
      start_x: Number(form.start_x) || 0,
      start_y: Number(form.start_y) || 0,
      asset_id: assetId,
      org_id: orgId,
    };
    if (mode === "create") {
      // Generate a public_token for secure, ID-free Player URLs
      data.public_token = crypto.randomUUID();
      await base44.entities.Screen.create(data);
    } else {
      await base44.entities.Screen.update(screen.id, data);
    }
    setSaving(false);
    onSaved();
  };

  const set = (key) => (e) => setForm(f => ({ ...f, [key]: e.target?.value ?? e }));

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add Screen" : "Edit Screen"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div>
            <Label>Screen Name *</Label>
            <Input value={form.name} onChange={set("name")} placeholder="e.g. Left Side" />
            {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Position</Label>
              <Select value={form.position} onValueChange={set("position")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {POSITIONS.map(p => (
                    <SelectItem key={p} value={p}>{p.replace(/_/g, " ")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Screen Mode</Label>
              <Select value={form.screen_mode} onValueChange={set("screen_mode")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="led">LED</SelectItem>
                  <SelectItem value="tv">TV / Monitor</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">
            Enter exact pixel dimensions. These are the source of truth for rendering and layout assignment.
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Width (px) *</Label>
              <Input type="number" value={form.width} onChange={set("width")} placeholder="e.g. 1280" min="1" />
              {errors.width && <p className="text-xs text-red-500 mt-1">{errors.width}</p>}
            </div>
            <div>
              <Label>Height (px) *</Label>
              <Input type="number" value={form.height} onChange={set("height")} placeholder="e.g. 640" min="1" />
              {errors.height && <p className="text-xs text-red-500 mt-1">{errors.height}</p>}
            </div>
            <div>
              <Label>Start X (canvas offset)</Label>
              <Input type="number" value={form.start_x} onChange={set("start_x")} />
            </div>
            <div>
              <Label>Start Y (canvas offset)</Label>
              <Input type="number" value={form.start_y} onChange={set("start_y")} />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={save} disabled={saving}>
              {saving ? "Saving..." : mode === "create" ? "Add Screen" : "Save Changes"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}