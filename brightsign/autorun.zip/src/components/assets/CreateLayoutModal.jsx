import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { LayoutGrid } from "lucide-react";

export default function CreateLayoutModal({ screen, onClose, onCreate }) {
  const [name, setName] = useState(`${screen?.name || "New"} Layout`);
  const [width, setWidth] = useState(screen?.width || 1280);
  const [height, setHeight] = useState(screen?.height || 720);
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!name.trim() || !width || !height) return;
    setLoading(true);
    try {
      await onCreate({ name: name.trim(), width: Number(width), height: Number(height) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LayoutGrid className="w-5 h-5 text-blue-600" />
            Create Layout Template
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          {screen && (
            <p className="text-xs text-slate-500 bg-slate-50 rounded-lg px-3 py-2">
              For screen: <span className="font-medium text-slate-700">{screen.name}</span>
              {screen.width && screen.height && (
                <span className="ml-1 font-mono text-slate-500">({screen.width}×{screen.height}px)</span>
              )}
            </p>
          )}

          <div>
            <Label>Layout Name</Label>
            <Input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Left Side Layout"
              className="mt-1"
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Width (px)</Label>
              <Input
                type="number"
                value={width}
                onChange={e => setWidth(e.target.value)}
                min={1}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Height (px)</Label>
              <Input
                type="number"
                value={height}
                onChange={e => setHeight(e.target.value)}
                min={1}
                className="mt-1"
              />
            </div>
          </div>

          {screen?.width && (Number(width) !== screen.width || Number(height) !== screen.height) && (
            <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded px-3 py-2">
              ⚠ Dimensions don't match screen ({screen.width}×{screen.height}px). The layout must match exactly to be assigned.
            </p>
          )}

          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              disabled={loading || !name.trim() || !width || !height}
              className="flex-1"
            >
              {loading ? "Creating…" : "Create & Open Editor"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}