import React, { useState } from 'react';
import { Zap, AlertCircle } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { base44 } from '@/api/base44Client';

export default function DeviceSafeModeToggle({ screen, onUpdate }) {
  const [saving, setSaving] = useState(false);

  const handleToggle = async (value) => {
    setSaving(true);
    try {
      await base44.entities.Screen.update(screen.id, {
        device_safe_mode: value,
      });
      onUpdate?.({ ...screen, device_safe_mode: value });
    } catch (err) {
      console.error('Failed to update Device Safe Mode:', err);
      alert('Failed to update setting');
    } finally {
      setSaving(false);
    }
  };

  return (
    <TooltipProvider>
      <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3 flex-1">
            <Zap className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="font-semibold text-blue-900">Device Safe Mode</h4>
              <p className="text-sm text-blue-800 mt-1">
                Disables blob URLs and IndexedDB caching. Use this for hardware players
                that don't support offline caching.
              </p>
            </div>
          </div>

          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 ml-4">
                <Switch
                  checked={screen?.device_safe_mode ?? false}
                  onCheckedChange={handleToggle}
                  disabled={saving}
                />
                <AlertCircle className="w-4 h-4 text-blue-600 flex-shrink-0" />
              </div>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p>
                When enabled, the Player will use direct live asset URLs instead of
                cached blobs. This increases bandwidth but fixes compatibility issues
                with BrightSign, ViPlex, and other hardware players.
              </p>
            </TooltipContent>
          </Tooltip>
        </div>

        {screen?.device_safe_mode && (
          <div className="mt-3 p-2 bg-blue-100 rounded text-xs text-blue-900 border-l-2 border-blue-600">
            ✓ Device Safe Mode is <strong>enabled</strong> for this screen. All connected
            players will use live URLs.
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}