import React from "react";
import { Badge } from "@/components/ui/badge";
import { Ruler, Monitor, Maximize2 } from "lucide-react";

function mmToFeetInches(mm) {
  if (!mm) return null;
  const totalInches = mm / 25.4;
  const feet = Math.floor(totalInches / 12);
  const inches = (totalInches % 12).toFixed(1);
  return feet > 0 ? `${feet}' ${inches}"` : `${inches}"`;
}

export default function ScreenSpecBadges({ screen, compact = false }) {
  if (!screen) return null;

  const hasResolution = screen.width && screen.height;
  const hasPhysical = screen.physical_width_mm && screen.physical_height_mm;
  const hasPitch = screen.pixel_pitch;

  if (!hasResolution && !hasPhysical && !hasPitch) return null;

  if (compact) {
    return (
      <div className="flex flex-wrap gap-1">
        {hasPitch && (
          <Badge variant="outline" className="text-[9px] py-0 h-4 border-violet-200 text-violet-700 bg-violet-50">
            P{screen.pixel_pitch}
          </Badge>
        )}
        {hasResolution && (
          <Badge variant="outline" className="text-[9px] py-0 h-4 border-blue-200 text-blue-700 bg-blue-50">
            {screen.width}×{screen.height}
          </Badge>
        )}
        {hasPhysical && (
          <Badge variant="outline" className="text-[9px] py-0 h-4 border-slate-200 text-slate-500">
            {mmToFeetInches(screen.physical_width_mm)} × {mmToFeetInches(screen.physical_height_mm)}
          </Badge>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2 text-xs">
      {hasPitch && (
        <div className="flex items-center gap-1 text-violet-700">
          <Ruler className="w-3 h-3" />
          <span>P{screen.pixel_pitch}mm pitch</span>
        </div>
      )}
      {hasResolution && (
        <div className="flex items-center gap-1 text-blue-700">
          <Monitor className="w-3 h-3" />
          <span>{screen.width}×{screen.height}px</span>
        </div>
      )}
      {hasPhysical && (
        <div className="flex items-center gap-1 text-slate-600">
          <Maximize2 className="w-3 h-3" />
          <span>
            {(screen.physical_width_mm / 1000).toFixed(2)}m × {(screen.physical_height_mm / 1000).toFixed(2)}m
            {" "}({mmToFeetInches(screen.physical_width_mm)} × {mmToFeetInches(screen.physical_height_mm)})
          </span>
        </div>
      )}
    </div>
  );
}