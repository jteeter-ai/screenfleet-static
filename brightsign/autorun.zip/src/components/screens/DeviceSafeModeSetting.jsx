import React, { useState } from 'react';
import { Zap } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { base44 } from '@/api/base44Client';

export default function DeviceSafeModeSetting({ screen, appConfig, onUpdate }) {
  const [saving, setSaving] = useState(false);

  // Resolve effective value: screen-level overrides org default
  const effectiveMode = screen?.device_safe_mode ?? appConfig?.default_device_safe_mode ?? false;

  const handleToggle = async (value) => {
    setSaving(true);
    try {
      await base44.entities.Screen.update(screen.id, {
        device_safe_mode: value,
      });
      onUpdate?.();
    } catch (err) {
      console.error('Failed to update Device Safe Mode:', err);
      alert('Failed to update setting');
    } finally {
      setSaving(false);
    }
  };

  const isOrgDefault = screen?.device_safe_mode === undefined || screen?.device_safe_mode === null;

  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-2 flex-1">
        <Zap className="w-4 h-4 text-blue-600 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="text-xs font-medium text-slate-700">Device Safe Mode</div>
          <div className="text-[10px] text-slate-500">
            {isOrgDefault && appConfig?.default_device_safe_mode
              ? 'Using org default (enabled)'
              : isOrgDefault && !appConfig?.default_device_safe_mode
              ? 'Using org default (disabled)'
              : effectiveMode
              ? 'Enabled for this screen'
              : 'Disabled for this screen'}
          </div>
        </div>
      </div>
      <Switch
        checked={effectiveMode}
        onCheckedChange={handleToggle}
        disabled={saving}
      />
    </div>
  );
}