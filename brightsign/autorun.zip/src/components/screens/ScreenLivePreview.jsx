/**
 * ScreenLivePreview — V2 thumbnail preview using RuntimeCanvas.
 * Data source: liveOutputData function → RuntimeZone.playback_track
 * Replaces V1 ZonePreview logic that queried PlaylistSpot/PlaylistCreative directly.
 */

import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import RuntimeCanvas from "@/components/player/RuntimeCanvas";

export default function ScreenLivePreview({ screenId, scale = 0.2, compact = false, fitToContainer = false, containerHeight = 96 }) {
  const { data: screenData } = useQuery({
    queryKey: ["liveOutput", screenId],
    queryFn: async () => {
      const res = await base44.functions.invoke('liveOutputData', { screenId });
      return res.data;
    },
    enabled: !!screenId,
    refetchInterval: 120000,
  });

  const screen = screenData?.screen;
  const zones = screenData?.zones || [];

  if (!screen) {
    return (
      <div
        className={`bg-slate-900 flex items-center justify-center ${compact ? "rounded text-xs" : "rounded-lg text-sm"} w-full h-full`}
        style={!fitToContainer ? { aspectRatio: "16/9" } : {}}
      >
        <span className="text-slate-400 text-[10px]">Loading...</span>
      </div>
    );
  }

  const screenW = screen.width || 3840;
  const screenH = screen.height || 2160;
  const computedScale = fitToContainer ? containerHeight / screenH : scale;
  const displayW = screenW * computedScale;
  const displayH = screenH * computedScale;

  return (
    <div
      className={compact ? "rounded" : "rounded-lg"}
      style={{ width: displayW, height: displayH, overflow: "hidden", position: "relative", background: "#000" }}
    >
      {/* Scale canvas to thumbnail size using CSS transform */}
      <div style={{ transform: `scale(${computedScale})`, transformOrigin: "top left", position: "absolute", top: 0, left: 0 }}>
        <RuntimeCanvas
          zones={zones}
          width={screenW}
          height={screenH}
          performanceMode="limited"
        />
      </div>
    </div>
  );
}