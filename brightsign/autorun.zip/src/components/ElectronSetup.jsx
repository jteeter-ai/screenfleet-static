import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Code, Download, Monitor } from "lucide-react";

export default function ElectronSetup() {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Electron Desktop Setup</h1>
        <p className="text-slate-600 mt-2">Auto-detect secondary monitor and launch live output on extended display</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="w-5 h-5" /> Step 1: Install Dependencies
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-slate-600">Run in your project root:</p>
          <div className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-sm overflow-x-auto">
            npm install electron electron-is-dev --save-dev
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Monitor className="w-5 h-5" /> Step 2: Create electron-main.js
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600 mb-3">Create this file in your project root:</p>
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg overflow-x-auto text-xs font-mono">
            <pre>{`const { app, BrowserWindow, screen } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');

let mainWindow;
let outputWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, 'electron-preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  const startUrl = isDev ? 'http://localhost:3000' : \`file://\${path.join(__dirname, '../build/index.html')}\`;
  mainWindow.loadURL(startUrl);
  if (isDev) mainWindow.webDevTools.openDevTools();
}

function createOutputWindow() {
  const displays = screen.getAllDisplays();
  const primaryDisplay = screen.getPrimaryDisplay();
  const secondaryDisplay = displays.find(d => d.id !== primaryDisplay.id);

  if (!secondaryDisplay) {
    console.warn('No secondary display found.');
  }

  const targetDisplay = secondaryDisplay || primaryDisplay;
  const { x, y, width, height } = targetDisplay.bounds;

  outputWindow = new BrowserWindow({
    x,
    y,
    width,
    height,
    fullscreen: true,
    webPreferences: {
      preload: path.join(__dirname, 'electron-preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  const startUrl = isDev 
    ? \`http://localhost:3000?displayX=\${x}&displayY=\${y}&displayWidth=\${width}&displayHeight=\${height}\` 
    : \`file://\${path.join(__dirname, '../build/index.html')}?displayX=\${x}&displayY=\${y}&displayWidth=\${width}&displayHeight=\${height}\`;
  
  outputWindow.loadURL(startUrl);
  outputWindow.setFullScreen(true);
}

app.on('ready', () => {
  createWindow();
  setTimeout(() => createOutputWindow(), 1500);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (mainWindow === null) createWindow();
});

const { ipcMain } = require('electron');
ipcMain.on('open-output-window', (event) => {
  if (!outputWindow || outputWindow.isDestroyed()) {
    createOutputWindow();
  } else {
    outputWindow.focus();
  }
});`}</pre>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Monitor className="w-5 h-5" /> Step 3: Create electron-preload.js
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600 mb-3">Create this file in your project root:</p>
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg overflow-x-auto text-xs font-mono">
            <pre>{`const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  openOutputWindow: () => ipcRenderer.send('open-output-window'),
  getDisplayInfo: () => {
    const params = new URLSearchParams(window.location.search);
    return {
      displayX: parseInt(params.get('displayX')) || 0,
      displayY: parseInt(params.get('displayY')) || 0,
      displayWidth: parseInt(params.get('displayWidth')) || window.innerWidth,
      displayHeight: parseInt(params.get('displayHeight')) || window.innerHeight,
    };
  },
});`}</pre>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" /> Step 4: Update package.json
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-slate-600">Add these fields to your package.json:</p>
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg overflow-x-auto text-xs font-mono">
            <pre>{`{
  "main": "electron-main.js",
  "homepage": "./",
  "scripts": {
    "electron": "electron .",
    "electron-dev": "concurrently \\"npm start\\" \\"wait-on http://localhost:3000 && electron .\\""
  }
}`}</pre>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Running the App</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <p className="text-sm font-medium text-slate-700 mb-2">Development:</p>
            <div className="bg-slate-900 text-slate-100 p-3 rounded-lg font-mono text-sm">
              npm run electron-dev
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-slate-700 mb-2">Production (after build):</p>
            <div className="bg-slate-900 text-slate-100 p-3 rounded-lg font-mono text-sm">
              npm run build && electron .
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-green-200 bg-green-50">
        <CardContent className="pt-6">
          <h3 className="font-semibold text-green-900 mb-2">What happens:</h3>
          <ul className="text-sm text-green-800 space-y-1 list-disc list-inside">
            <li>App detects all connected displays on startup</li>
            <li>Automatically launches Live Output window on secondary monitor in fullscreen</li>
            <li>Primary desktop remains clear for CMS controls</li>
            <li>Display position (x,y) automatically passed to LiveOutput page</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}