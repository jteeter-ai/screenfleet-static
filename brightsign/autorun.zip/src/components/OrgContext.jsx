import React, { createContext, useContext, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { resolveOrgModules } from "@/lib/moduleResolution";
import { ROLE_DEFAULT_PERMISSIONS } from "@/components/organizations/permissionsConfig";
import { useQueryClient } from "@tanstack/react-query";

const OrgContext = createContext();

// ── PHASE 7B: Legacy feature migration consolidated into moduleResolution.js ──
// LEGACY_FEATURE_TO_MODULE in moduleResolution.js is now the SINGLE SOURCE OF TRUTH.
// This local map is KEPT for org.features_enabled string remapping only.
// It is NOT used for module resolution (that uses moduleResolution.LEGACY_FEATURE_TO_MODULE).
// Phase 7C: Remove entirely once org.features_enabled migration is complete.
const FEATURE_MIGRATION_MAP = {
  'rotations':          'route_presentations',
  'standard_rotations': 'playlists',
  'total360_rotation':  'route_presentations',
  'multi_zone':         'multi_zone_layouts',
};

async function migrateOrgFeaturesIfNeeded(org) {
  if (!Array.isArray(org.features_enabled)) return org;
  const needsMigration = org.features_enabled.some(f => FEATURE_MIGRATION_MAP[f]);
  if (!needsMigration) return org;
  // Remap legacy org.features_enabled values to new canonical names
  // This is local string normalization only, not module resolution.
  // Module resolution uses moduleResolution.LEGACY_FEATURE_TO_MODULE (single source of truth).
  const migrated = [...new Set(
    org.features_enabled.map(f => FEATURE_MIGRATION_MAP[f] || f)
  )];
  console.log('[OrgContext] Migrating legacy features:', org.features_enabled, '->', migrated);
  await base44.entities.Organization.update(org.id, { features_enabled: migrated });
  return { ...org, features_enabled: migrated };
}

export function OrgProvider({ children }) {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [userOrgs, setUserOrgs] = useState([]);
  const [activeOrgId, setActiveOrgId] = useState(null);
  const [activeOrg, setActiveOrg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentMember, setCurrentMember] = useState(null);
  const [resolvedModules, setResolvedModules] = useState([]);

  useEffect(() => {
    async function loadUserAndOrgs() {
      try {
        // Check for LegionOS hub token
        const params = new URLSearchParams(window.location.search);
        const legionToken = params.get("legion_token");

        if (legionToken) {
          try {
            const decoded = JSON.parse(atob(legionToken));
            const now = Date.now();
            if (decoded.expires_at && decoded.expires_at > now) {
              sessionStorage.setItem("legion_hub_token", JSON.stringify(decoded));
              const cleanUrl = window.location.pathname;
              window.history.replaceState({}, "", cleanUrl);
            }
          } catch (e) {
            console.warn("[OrgContext] Failed to parse legion_token:", e);
          }
        }

        const storedToken = sessionStorage.getItem("legion_hub_token");
        const hubToken = storedToken ? JSON.parse(storedToken) : null;

        // If not on LiveOutput page, require authentication
        const currentPath = window.location.pathname + window.location.search + window.location.hash;
        const isLiveOutput = currentPath.includes("LiveOutput");
        
        const isAuthenticated = await base44.auth.isAuthenticated();
        if (!isAuthenticated && !isLiveOutput) {
          base44.auth.redirectToLogin(currentPath);
          return;
        }

        // Skip user/org loading for unauthenticated LiveOutput player
        if (!isAuthenticated && isLiveOutput) {
          setLoading(false);
          return;
        }

        const currentUser = await base44.auth.me();
        setUser(currentUser);
        console.log("[OrgContext] Logged-in user:", currentUser.email, "role:", currentUser.role);

        let orgs = [];
        
        if (currentUser.role === "admin") {
          // Platform admin check (direct role check at provider bootstrap level is safe here)
          // Sees ALL organizations but defaults to last real org, not sentinel
          orgs = await base44.entities.Organization.list();
          const savedOrgId = localStorage.getItem('sf_activeOrgId');
          const savedOrg = savedOrgId ? orgs.find(o => o.id === savedOrgId) : null;
          const targetOrg = savedOrg || orgs[0] || null;
          if (targetOrg) {
            const migratedOrg = await migrateOrgFeaturesIfNeeded(targetOrg);
            setActiveOrgId(migratedOrg.id);
            setActiveOrg(migratedOrg);
            localStorage.setItem('sf_activeOrgId', migratedOrg.id);
          } else {
            setActiveOrgId(null);
            setActiveOrg(null);
          }
        } else {
          // SECURITY: Non-platform users locked to SINGLE org.
          // Use backend function with asServiceRole to bypass entity permission restrictions.
          let members = [];
          let orgResults = [];

          try {
            const result = await base44.functions.invoke('getMyMembership', {});
            const data = result?.data || result;
            members = data?.members || [];
            orgResults = data?.orgs || [];
          } catch (err) {
            console.warn('[OrgContext] getMyMembership failed:', err?.message);
          }

          const sortedMembers = [...members].sort(
            (a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0)
          );
          const orgIds = [...new Set(sortedMembers.map(m => m.org_id))];

          if (orgIds.length > 1) {
            console.warn(
              `[OrgContext] SECURITY: User ${currentUser.email} has ${orgIds.length} memberships. ` +
              `Single-org constraint enforced. Using: ${orgIds[0]}. Ignored: ${orgIds.slice(1).join(', ')}`
            );
          }

          const primaryOrgId = orgIds[0];
          if (primaryOrgId) {
            const org = orgResults.find(o => o.id === primaryOrgId) || null;
            if (org) {
              const migratedOrg = await migrateOrgFeaturesIfNeeded(org);
              console.log('[OrgContext] Setting active org (locked):', migratedOrg.id, migratedOrg.name);
              setActiveOrgId(migratedOrg.id);
              setActiveOrg(migratedOrg);
              localStorage.setItem('sf_activeOrgId', migratedOrg.id);
              orgs = [migratedOrg];
            }
          }
        }
        
        setUserOrgs(orgs);
      } catch (error) {
        console.error("Failed to load orgs:", error);
      } finally {
        setLoading(false);
      }
    }

    loadUserAndOrgs();
  }, []);

  const switchOrg = async (orgId) => {
    // SECURITY: Only platform admins may switch orgs
    const currentUser = user;
    if (currentUser?.role !== 'admin') {
      console.warn('[OrgContext] SECURITY: switchOrg blocked for non-admin user:', currentUser?.email);
      return;
    }
    console.log("[OrgContext] switchOrg called:", orgId);
    // CRITICAL: clear ALL cached queries when switching orgs to prevent stale cross-tenant data
    queryClient.clear();
    if (orgId === "PLATFORM_ADMIN") {
      setActiveOrgId("PLATFORM_ADMIN");
      setActiveOrg(null);
      localStorage.removeItem('sf_activeOrgId');
    } else {
      // First check userOrgs cache, then fall back to a direct DB fetch for platform admins
      // who have an empty userOrgs array
      let org = userOrgs.find(o => o.id === orgId);
      if (!org) {
        try {
          const fetched = await base44.entities.Organization.filter({ id: orgId });
          org = fetched[0] || null;
        } catch (err) {
          console.warn('[OrgContext] switchOrg: could not fetch org:', err?.message);
        }
      }
      if (org) {
        const migratedOrg = await migrateOrgFeaturesIfNeeded(org);
        console.log("[OrgContext] Switching to org:", orgId, migratedOrg.name);
        setActiveOrgId(migratedOrg.id);
        setActiveOrg(migratedOrg);
        localStorage.setItem('sf_activeOrgId', orgId);
      } else {
        console.warn('[OrgContext] switchOrg: org not found for id:', orgId);
      }
    }
    // Allow React state + queries to settle before navigation
    await new Promise(resolve => setTimeout(resolve, 150));
  };

  const isPlatformAdmin = user?.role === "admin";

  // Hub-authorized orgs are always considered active — Legion Hub manages their subscription.
  // Direct orgs rely on Stripe subscription_status.
  const isSubscriptionActive = (org) => {
    if (!org) return false;
    if (org.plan_source === 'legion_hub') return true;
    const status = org.subscription_status;
    return status === 'active' || status === 'trialing';
  };

  // Phase 3: load current member record + resolve modules when active org changes
  useEffect(() => {
    if (!user || !activeOrgId || activeOrgId === 'PLATFORM_ADMIN') {
      setCurrentMember(null);
      setResolvedModules([]);
      return;
    }
    async function loadMemberAndModules() {
      try {
        // Load current user's OrgMember record for this org
        const members = await base44.entities.OrgMember.filter({
          org_id: activeOrgId,
          user_email: user.email,
        });
        const member = members[0] || null;
        setCurrentMember(member);

        // Auto-activate member if they've successfully logged in but status is still 'invited'
        if (member && member.status === 'invited') {
          const defaultPerms = member.org_role === 'admin' || member.org_role === 'owner'
            ? ['*']
            : (ROLE_DEFAULT_PERMISSIONS[member.org_role] || []);
          try {
            await base44.entities.OrgMember.update(member.id, {
              status: 'active',
              activated_at: new Date().toISOString(),
              permissions: member.permissions?.length ? member.permissions : defaultPerms,
            });
            member = { ...member, status: 'active', permissions: member.permissions?.length ? member.permissions : defaultPerms };
            setCurrentMember(member);
            console.log('[OrgContext] Auto-activated member:', member.user_email);
          } catch (err) {
            console.warn('[OrgContext] Could not auto-activate member:', err?.message);
          }
        }

        // Load the linked plan (if any) for module resolution
        let plan = null;
        if (activeOrg?.plan_slug) {
          const plans = await base44.entities.Plan.filter({ slug: activeOrg.plan_slug });
          plan = plans[0] || null;
        }

        // Resolve modules (non-destructive, additive)
        const modules = resolveOrgModules(activeOrg, plan);

        // Merge LegionOS-granted modules if hub token is present and valid
        const storedHubToken = sessionStorage.getItem("legion_hub_token");
        const hubTokenForModules = storedHubToken ? JSON.parse(storedHubToken) : null;
        if (hubTokenForModules && hubTokenForModules.expires_at > Date.now()) {
          const legionModules = hubTokenForModules.modules_enabled || [];
          const merged = [...new Set([...modules, ...legionModules])];
          setResolvedModules(merged);
          if (hubTokenForModules.max_screens !== null && hubTokenForModules.max_screens !== undefined) {
            sessionStorage.setItem("legion_max_screens", String(hubTokenForModules.max_screens));
          } else {
            sessionStorage.removeItem("legion_max_screens");
          }
        } else {
          setResolvedModules(modules);
        }
      } catch (err) {
        // Non-fatal — legacy behavior continues working without these
        setCurrentMember(null);
        setResolvedModules([]);
      }
    }
    loadMemberAndModules();
  }, [user, activeOrgId, activeOrg]);

  return (
    <OrgContext.Provider value={{ user, userOrgs, activeOrgId, activeOrg, loading, switchOrg, isPlatformAdmin, currentMember, resolvedModules, isSubscriptionActive }}>
      {children}
    </OrgContext.Provider>
  );
}

export function useOrg() {
  const context = useContext(OrgContext);
  if (!context) throw new Error("useOrg must be used within OrgProvider");
  return context;
}