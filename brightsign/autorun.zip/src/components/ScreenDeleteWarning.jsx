import React, { useState, useEffect } from 'react';
import { AlertCircle, Zap, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { base44 } from '@/api/base44Client';

export default function ScreenDeleteWarning({
  screen,
  open,
  onOpenChange,
  onConfirm,
  isArchive = true,
}) {
  const [assetLayouts, setAssetLayouts] = useState([]);
  const [publishedScreens, setPublishedScreens] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open || !screen?.id) return;

    const fetchImpact = async () => {
      try {
        const als = await base44.entities.AssetLayout.filter({
          screen_id: screen.id,
        });
        const pss = await base44.entities.PublishedScreen.filter({
          screen_id: screen.id,
        });
        setAssetLayouts(als);
        setPublishedScreens(pss);
      } catch (err) {
        console.error('Failed to fetch impact:', err);
      } finally {
        setLoading(false);
      }
    };

    setLoading(true);
    fetchImpact();
  }, [open, screen?.id]);

  const playerUrl = screen?.public_token
    ? `https://player.screenfleet.io/player/${screen.public_token}`
    : 'N/A';

  const handleConfirm = async () => {
    onOpenChange(false);
    onConfirm();
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-2xl">
        <AlertDialogHeader>
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-600" />
            <AlertDialogTitle>
              {isArchive ? 'Archive Screen?' : 'Permanently Delete Screen?'}
            </AlertDialogTitle>
          </div>
        </AlertDialogHeader>

        <AlertDialogDescription className="space-y-4 text-sm">
          {/* Screen Details */}
          <div className="bg-slate-50 p-4 rounded-lg space-y-3">
            <div>
              <div className="text-xs font-semibold text-slate-500 uppercase">
                Screen
              </div>
              <div className="text-base font-medium text-slate-900">
                {screen?.name}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs font-semibold text-slate-500 uppercase">
                  Public Token
                </div>
                <div className="text-xs font-mono text-slate-700 truncate">
                  {screen?.public_token || 'N/A'}
                </div>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-500 uppercase">
                  Player URL
                </div>
                <div className="text-xs font-mono text-slate-700 truncate">
                  {playerUrl}
                </div>
              </div>
            </div>

            {screen?.last_published_at && (
              <div>
                <div className="text-xs font-semibold text-slate-500 uppercase">
                  Last Published
                </div>
                <div className="text-xs text-slate-700">
                  {new Date(screen.last_published_at).toLocaleString()}
                </div>
              </div>
            )}
          </div>

          {/* Impact Summary */}
          {!loading && (
            <div className="bg-blue-50 p-4 rounded-lg space-y-2 border border-blue-200">
              <div className="font-semibold text-sm text-blue-900">Impact:</div>
              <ul className="space-y-1 text-sm text-blue-800">
                {assetLayouts.length > 0 && (
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    {assetLayouts.length} AssetLayout record
                    {assetLayouts.length !== 1 ? 's' : ''} will be deleted
                  </li>
                )}
                {publishedScreens.length > 0 && (
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    {publishedScreens.length} PublishedScreen record
                    {publishedScreens.length !== 1 ? 's' : ''} will be deleted
                  </li>
                )}
                <li className="flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  Player token will be {isArchive ? 'deactivated' : 'permanently deleted'}
                </li>
                <li className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Devices using this URL will show blank/offline
                </li>
              </ul>
            </div>
          )}

          {/* Warning */}
          <div className="bg-amber-50 p-3 rounded-lg border border-amber-200 text-xs text-amber-900">
            <strong>⚠️ Action required:</strong> Devices will need to be
            {isArchive ? ' provisioned with the new screen URL' : ' deleted from Player'}
            {isArchive ? ' if this screen is recreated.' : '.'}
          </div>
        </AlertDialogDescription>

        <div className="flex gap-3 justify-end pt-4">
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirm}
            className="bg-red-600 hover:bg-red-700"
          >
            {isArchive ? 'Archive Screen' : 'Delete Screen'}
          </AlertDialogAction>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}