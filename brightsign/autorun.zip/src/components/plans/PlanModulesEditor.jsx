import { Check } from "lucide-react";
import { MODULE_KEYS } from "@/components/organizations/permissionsConfig";
import { PLAN_MODULE_DEFAULTS } from "@/lib/moduleResolution";

// Grouped module registry with labels — source of truth for UI display
const MODULE_GROUPS = [
  {
    label: "Content",
    modules: [
      { key: MODULE_KEYS.ASSETS,              label: "Assets",               description: "Manage trucks, trailers & video walls" },
      { key: MODULE_KEYS.LAYOUTS,             label: "Layout Templates",     description: "Multi-zone screen layout editor" },
      { key: MODULE_KEYS.MEDIA_LIBRARY,       label: "Media Library",        description: "Upload and organize media files" },
      { key: MODULE_KEYS.PLAYLISTS,           label: "Playlists",            description: "Build and manage playlists" },
    ],
  },
  {
    label: "Operations",
    modules: [
      { key: MODULE_KEYS.SCHEDULING,          label: "Scheduling",           description: "Time-based content scheduling" },
      { key: MODULE_KEYS.SCREEN_CONTROLS,     label: "Screen Controls",      description: "Brightness, power, and hardware control" },
      { key: MODULE_KEYS.LIVE_OUTPUT,         label: "Live Output",          description: "View live screen output and status" },
      { key: MODULE_KEYS.PLAYER_MONITORING,   label: "Player Monitoring",    description: "Device heartbeat and online/offline status" },
    ],
  },
  {
    label: "Advanced",
    modules: [
      { key: MODULE_KEYS.ROUTE_PRESENTATIONS, label: "Route Presentations",  description: "Ad rotation across geo-routes" },
      { key: MODULE_KEYS.SEQUENCES,           label: "Sequences",            description: "Multi-step ordered content delivery" },
      { key: MODULE_KEYS.STUDIO,              label: "Studio",               description: "Visual canvas creative builder" },
      { key: MODULE_KEYS.ANALYTICS,           label: "Analytics",            description: "Performance reports and metrics" },
    ],
  },
  {
    label: "Admin",
    modules: [
      { key: MODULE_KEYS.TEAM_MANAGEMENT,     label: "Team Management",      description: "Invite and manage org users" },
      { key: MODULE_KEYS.BILLING,             label: "Billing",              description: "View and manage subscription billing" },
    ],
  },
];

/**
 * PlanModulesEditor
 * @param {string[]} value       — current modules_included array
 * @param {function} onChange    — called with updated array
 * @param {string}   planSlug    — optional, used to show "load defaults" hint
 */
export default function PlanModulesEditor({ value = [], onChange, planSlug }) {
  const included = new Set(value);

  const toggle = (key) => {
    const next = new Set(included);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    onChange([...next]);
  };

  const loadDefaults = () => {
    if (planSlug && PLAN_MODULE_DEFAULTS[planSlug]) {
      onChange([...PLAN_MODULE_DEFAULTS[planSlug]]);
    }
  };

  const hasDefaults = planSlug && PLAN_MODULE_DEFAULTS[planSlug];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold text-slate-700">Module Access</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Select which modules are available on this plan</p>
        </div>
        {hasDefaults && (
          <button
            type="button"
            onClick={loadDefaults}
            className="text-[10px] text-blue-600 hover:text-blue-800 underline"
          >
            Load defaults for "{planSlug}"
          </button>
        )}
      </div>

      {MODULE_GROUPS.map((group) => (
        <div key={group.label}>
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">{group.label}</p>
          <div className="space-y-1">
            {group.modules.map(({ key, label, description }) => {
              const on = included.has(key);
              return (
                <label
                  key={key}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border cursor-pointer transition-colors ${
                    on ? "bg-blue-50 border-blue-300" : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={on}
                    onChange={() => toggle(key)}
                    className="hidden"
                  />
                  <div className={`w-4 h-4 rounded flex-shrink-0 flex items-center justify-center ${
                    on ? "bg-blue-600" : "border border-slate-300"
                  }`}>
                    {on && <Check className="w-2.5 h-2.5 text-white" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm font-medium ${on ? "text-blue-800" : "text-slate-700"}`}>{label}</div>
                    <div className="text-[10px] text-slate-400">{description}</div>
                  </div>
                  <code className="text-[9px] text-slate-300 font-mono hidden sm:block">{key}</code>
                </label>
              );
            })}
          </div>
        </div>
      ))}

      <div className="text-[10px] text-slate-400 pt-1">
        {included.size} of {MODULE_GROUPS.reduce((sum, g) => sum + g.modules.length, 0)} modules included
      </div>
    </div>
  );
}