/**
 * LegacyPageBanner — displayed on V1/legacy pages to clearly mark them as non-production surfaces.
 * These pages are preserved for backward compatibility but are not part of the V2 production workflow.
 */
import { AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";

export default function LegacyPageBanner({ pageName, replacement, replacementPath }) {
  return (
    <div className="mx-6 mt-6 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 flex items-start gap-3">
      <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
      <div className="text-sm text-amber-800">
        <span className="font-semibold">Legacy / V1 Page:</span>{" "}
        <span className="font-medium">{pageName}</span> uses the old Truck/V1 data model and is not part of the V2 production workflow.
        {replacement && replacementPath && (
          <span>
            {" "}Use{" "}
            <Link to={replacementPath} className="underline font-semibold hover:text-amber-900">
              {replacement}
            </Link>{" "}
            instead.
          </span>
        )}
      </div>
    </div>
  );
}