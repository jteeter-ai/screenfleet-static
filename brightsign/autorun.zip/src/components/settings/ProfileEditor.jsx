import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Camera, Loader2, Save, Mail, Phone, Building2, MapPin, Globe, Briefcase, CreditCard } from "lucide-react";
import { toast } from "sonner";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import PlanUpgradeDialog from "@/components/organizations/PlanUpgradeDialog";

export default function ProfileEditor({ user, onUpdate }) {
  const [form, setForm] = useState({
    phone: user?.phone || "",
    job_title: user?.job_title || "",
    department: user?.department || "",
    company: user?.company || "",
    location: user?.location || "",
    website: user?.website || "",
    bio: user?.bio || "",
    avatar_url: user?.avatar_url || "",
  });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showPlanUpgrade, setShowPlanUpgrade] = useState(false);
  const queryClient = useQueryClient();

  // Get user's organization
  const { data: userOrgs = [] } = useQuery({
    queryKey: ["userOrgs"],
    queryFn: async () => {
      const members = await base44.entities.OrgMember.filter({ user_email: user?.email });
      const orgIds = [...new Set(members.map(m => m.org_id))];
      return Promise.all(orgIds.map(id => base44.entities.Organization.filter({ id })));
    },
  });

  const activeOrg = userOrgs.flat()?.[0];

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm((f) => ({ ...f, avatar_url: file_url }));
      toast.success("Photo uploaded");
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe(form);
      toast.success("Profile updated");
      onUpdate?.();
    } catch {
      toast.error("Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const initials = user?.full_name?.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2) || "U";

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="pt-6 space-y-6">
        {/* Avatar + identity */}
        <div className="flex items-start gap-5">
          <div className="relative group flex-shrink-0">
            {form.avatar_url ? (
              <img src={form.avatar_url} alt="avatar" className="w-20 h-20 rounded-2xl object-cover" />
            ) : (
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                <span className="text-white text-2xl font-bold">{initials}</span>
              </div>
            )}
            <label className="absolute inset-0 rounded-2xl bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
              {uploading ? <Loader2 className="w-5 h-5 text-white animate-spin" /> : <Camera className="w-5 h-5 text-white" />}
              <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploading} />
            </label>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-lg font-semibold text-slate-900">{user?.full_name}</p>
            <div className="flex items-center gap-1.5 mt-0.5">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              <p className="text-sm text-slate-500">{user?.email}</p>
            </div>
            <Badge variant="outline" className="mt-2 text-xs capitalize">{user?.role || "user"}</Badge>
          </div>
        </div>

        <Separator />

        {/* Fields */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5"><Briefcase className="w-3 h-3" /> Job Title</Label>
            <Input placeholder="e.g. Fleet Manager" value={form.job_title} onChange={(e) => setForm(f => ({ ...f, job_title: e.target.value }))} className="h-9" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5"><Building2 className="w-3 h-3" /> Department</Label>
            <Input placeholder="e.g. Operations" value={form.department} onChange={(e) => setForm(f => ({ ...f, department: e.target.value }))} className="h-9" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5"><Building2 className="w-3 h-3" /> Company</Label>
            <Input placeholder="Company name" value={form.company} onChange={(e) => setForm(f => ({ ...f, company: e.target.value }))} className="h-9" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5"><Phone className="w-3 h-3" /> Phone</Label>
            <Input placeholder="+1 555 000 0000" value={form.phone} onChange={(e) => setForm(f => ({ ...f, phone: e.target.value }))} className="h-9" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5"><MapPin className="w-3 h-3" /> Location</Label>
            <Input placeholder="City, State" value={form.location} onChange={(e) => setForm(f => ({ ...f, location: e.target.value }))} className="h-9" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs flex items-center gap-1.5"><Globe className="w-3 h-3" /> Website</Label>
            <Input placeholder="https://..." value={form.website} onChange={(e) => setForm(f => ({ ...f, website: e.target.value }))} className="h-9" />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs">Bio</Label>
          <textarea
            rows={3}
            placeholder="Short bio or notes..."
            value={form.bio}
            onChange={(e) => setForm(f => ({ ...f, bio: e.target.value }))}
            className="w-full text-sm rounded-lg border border-input bg-background px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={saving} className="gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Profile
          </Button>
        </div>
      </CardContent>

      {/* Plan Management */}
      {activeOrg && (
        <>
          <Separator className="mt-6" />
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                  <CreditCard className="w-4 h-4" /> Current Plan
                </h3>
                <p className="text-sm text-slate-500 mt-0.5">Organization: {activeOrg.name}</p>
                <Badge variant="outline" className="mt-2 capitalize text-xs">{activeOrg.plan_slug}</Badge>
              </div>
              <Button
                onClick={() => setShowPlanUpgrade(true)}
                variant="outline"
                className="gap-2"
              >
                <CreditCard className="w-3.5 h-3.5" /> Upgrade Plan
              </Button>
            </div>
          </CardContent>

          <PlanUpgradeDialog
            org={activeOrg}
            open={showPlanUpgrade}
            onOpenChange={setShowPlanUpgrade}
          />
        </>
      )}
    </Card>
  );
}