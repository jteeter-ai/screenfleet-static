import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Shield, MoreVertical, Pencil, UserX, Archive, ShieldCheck, Search } from "lucide-react";
import { toast } from "sonner";

const roleBadge = {
  admin: "bg-blue-50 text-blue-700 border-blue-200",
  user: "bg-slate-100 text-slate-600 border-slate-200",
  suspended: "bg-red-50 text-red-700 border-red-200",
  archived: "bg-amber-50 text-amber-700 border-amber-200",
};

export default function UserManagementTable({ users, currentUserId }) {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null);
  const [archiveTarget, setArchiveTarget] = useState(null);
  const [form, setForm] = useState({});

  const filtered = users.filter(
    (u) =>
      u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase())
  );

  const openEdit = (u) => {
    setEditing(u);
    setForm({
      role: u.role || "user",
      job_title: u.job_title || "",
      department: u.department || "",
      company: u.company || "",
      phone: u.phone || "",
    });
  };

  const saveEdit = async () => {
    await base44.entities.User.update(editing.id, form);
    queryClient.invalidateQueries({ queryKey: ["users"] });
    toast.success("User updated");
    setEditing(null);
  };

  const setStatus = async (u, newRole) => {
    await base44.entities.User.update(u.id, { role: newRole });
    queryClient.invalidateQueries({ queryKey: ["users"] });
    toast.success(`User ${newRole === "suspended" ? "suspended" : newRole === "archived" ? "archived" : "role updated"}`);
  };

  const confirmArchive = async () => {
    await base44.entities.User.update(archiveTarget.id, { role: "archived" });
    queryClient.invalidateQueries({ queryKey: ["users"] });
    toast.success("User archived");
    setArchiveTarget(null);
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="w-4 h-4" /> Team Members
          </CardTitle>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <Input
              placeholder="Search users..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-8 pl-8 w-52 text-sm"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-slate-100">
          {filtered.length === 0 && (
            <p className="text-sm text-slate-400 p-6">No users found.</p>
          )}
          {filtered.map((u) => {
            const isMe = u.id === currentUserId;
            const initials = u.full_name?.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2) || "?";
            return (
              <div key={u.id} className="flex items-center gap-4 px-6 py-4 hover:bg-slate-50 transition-colors">
                {/* Avatar */}
                <div className="flex-shrink-0">
                  {u.avatar_url ? (
                    <img src={u.avatar_url} alt="" className="w-10 h-10 rounded-xl object-cover" />
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-400 to-slate-600 flex items-center justify-center">
                      <span className="text-white text-sm font-bold">{initials}</span>
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-semibold text-slate-900 truncate">{u.full_name}</p>
                    {isMe && <span className="text-[10px] text-slate-400 font-medium">(you)</span>}
                  </div>
                  <p className="text-xs text-slate-500 truncate">{u.email}</p>
                  {(u.job_title || u.department) && (
                    <p className="text-xs text-slate-400 mt-0.5 truncate">
                      {[u.job_title, u.department].filter(Boolean).join(" · ")}
                    </p>
                  )}
                </div>

                {/* Role badge */}
                <Badge variant="outline" className={`text-xs capitalize flex-shrink-0 ${roleBadge[u.role] || roleBadge.user}`}>
                  {u.role || "user"}
                </Badge>

                {/* Actions (admin only, not self-archive) */}
                {!isMe && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openEdit(u)}>
                        <Pencil className="w-4 h-4 mr-2" /> Edit Details
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatus(u, "admin")}>
                        <ShieldCheck className="w-4 h-4 mr-2" /> Make Admin
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setStatus(u, "user")}>
                        <Shield className="w-4 h-4 mr-2" /> Set as User
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setStatus(u, "suspended")} className="text-amber-600">
                        <UserX className="w-4 h-4 mr-2" /> Suspend
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setArchiveTarget(u)} className="text-red-600">
                        <Archive className="w-4 h-4 mr-2" /> Archive
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>

      {/* Edit Dialog */}
      <Dialog open={!!editing} onOpenChange={() => setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit User — {editing?.full_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Role</Label>
              <Select value={form.role} onValueChange={(v) => setForm(f => ({ ...f, role: v }))}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Job Title</Label>
                <Input value={form.job_title} onChange={(e) => setForm(f => ({ ...f, job_title: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Department</Label>
                <Input value={form.department} onChange={(e) => setForm(f => ({ ...f, department: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Company</Label>
                <Input value={form.company} onChange={(e) => setForm(f => ({ ...f, company: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Phone</Label>
                <Input value={form.phone} onChange={(e) => setForm(f => ({ ...f, phone: e.target.value }))} className="h-9" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={saveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Archive Confirm */}
      <AlertDialog open={!!archiveTarget} onOpenChange={() => setArchiveTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Archive {archiveTarget?.full_name}?</AlertDialogTitle>
            <AlertDialogDescription>
              This will mark the user as archived. They will no longer be able to access the system. This can be undone by editing the user.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmArchive} className="bg-red-600 hover:bg-red-700">Archive</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}