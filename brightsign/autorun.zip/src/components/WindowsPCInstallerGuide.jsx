import React, { useState } from "react";
import { usePlayerOrigin } from "@/lib/playerUrls";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Download, Copy, Check, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function WindowsPCInstallerGuide({ assetId }) {
  const [loading, setLoading] = useState(false);
  // Player URLs come from the separate ScreenFleet Player app, not this CMS.
  const { origin: playerOrigin } = usePlayerOrigin();

  const handleGenerateInstaller = async () => {
    console.log('Button clicked, assetId:', assetId);
    if (!assetId) {
      console.log('No assetId, showing error');
      toast.error("Save asset first");
      return;
    }
    setLoading(true);
    try {
      if (!playerOrigin) {
        toast.error("Player app not configured. Set player_app_origin in AppConfig first.");
        setLoading(false);
        return;
      }
      console.log('Invoking generateWebView2Player with:', { truckId: assetId, playerUrl: playerOrigin });
      const response = await base44.functions.invoke('generateWebView2Player', { truckId: assetId, playerUrl: playerOrigin });
      console.log('Response:', response);
      const data = response.data;
      
      if (data.content && data.filename) {
        downloadFile(data.filename, data.content, 'text/plain');
        toast.success('run-screenfleet-player.bat downloaded! Double-click to run.');
      } else {
        console.warn('Missing content or filename in response', data);
        toast.error('Invalid response from server');
      }
    } catch (error) {
      console.error('Failed to generate installer:', error);
      toast.error('Failed to generate installer: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const downloadFile = (filename, content, mimeType) => {
    try {
      const blob = new Blob([content], { type: mimeType });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    } catch (err) {
      console.error('Download error:', err);
      toast.error('Failed to download file');
    }
  };



  return (
    <div className="space-y-4">
      <Card className="p-6 bg-blue-50 border-blue-200">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">Download Player</h3>
            <p className="text-sm text-blue-800 mb-4">
              Download a simple launcher that opens ScreenFleet in fullscreen. Just double-click to run—no installation needed.
            </p>
            <Button
              onClick={handleGenerateInstaller}
              disabled={loading}
              className="gap-2 bg-blue-600 hover:bg-blue-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Download Player (.bat)
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-6 bg-amber-50 border-amber-200">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-amber-900 mb-2">Requirements</h3>
            <ul className="text-sm text-amber-800 space-y-1">
              <li>• Windows 10 or later</li>
              <li>• Microsoft Edge (free download if not installed)</li>
              <li>• Internet connection to stream content</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}