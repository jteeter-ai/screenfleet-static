import { ShieldOff } from "lucide-react";

/**
 * AccessDenied — shown when a user lacks permission to view a page or section.
 * @param {string} message  - optional override message
 * @param {string} reason   - 'module' | 'platform' | 'permission' — controls subtitle
 */
export default function AccessDenied({ message, reason = "permission" }) {
  const subtitles = {
    platform: "This area is restricted to ScreenFleet platform administrators.",
    module:   "This feature is not included in your current plan.",
    permission: "You don't have permission to access this area. Contact your organization admin.",
  };

  return (
    <div className="flex items-center justify-center min-h-[60vh] p-8">
      <div className="text-center max-w-sm">
        <div className="w-14 h-14 rounded-2xl bg-red-50 flex items-center justify-center mx-auto mb-4">
          <ShieldOff className="w-7 h-7 text-red-400" />
        </div>
        <h2 className="text-lg font-semibold text-slate-800 mb-2">
          {message || "Access Denied"}
        </h2>
        <p className="text-sm text-slate-500">{subtitles[reason]}</p>
      </div>
    </div>
  );
}