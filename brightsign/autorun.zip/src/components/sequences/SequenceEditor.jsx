import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, GripVertical, ChevronUp, ChevronDown } from "lucide-react";
import { loadSequenceItems, validateSequenceItems } from "@/lib/sequenceEngine";

export default function SequenceEditor({ sequenceId, onSaved }) {
  const [sequence, setSequence] = useState(null);
  const [items, setItems] = useState([]);
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [newItemType, setNewItemType] = useState("playlist");
  const [newItemRefId, setNewItemRefId] = useState("");
  const queryClient = useQueryClient();

  // Fetch sequence
  const { data: sequenceData, isLoading } = useQuery({
    queryKey: ["sequence", sequenceId],
    queryFn: async () => {
      const result = await base44.entities.Sequence.filter({
        id: sequenceId,
      });
      return result[0] || null;
    },
  });

  useEffect(() => {
    if (sequenceData) {
      setSequence(sequenceData);
    }
  }, [sequenceData]);

  // Fetch items
  const { data: rawItems } = useQuery({
    queryKey: ["sequenceItems", sequenceId],
    queryFn: async () => {
      const result = await base44.entities.SequenceItem.filter({
        sequence_id: sequenceId,
      });
      return result;
    },
  });

  useEffect(() => {
    if (rawItems) {
      const ordered = loadSequenceItems(rawItems);
      setItems(ordered);
    }
  }, [rawItems]);

  // Fetch playlists and presentations
  const { data: playlists = [] } = useQuery({
    queryKey: ["playlists"],
    queryFn: () => base44.entities.Playlist.list(),
  });

  const { data: presentations = [] } = useQuery({
    queryKey: ["presentations"],
    queryFn: () => base44.entities.RoutePresentation.list(),
  });

  // Add item mutation
  const addItemMutation = useMutation({
    mutationFn: async () => {
      if (!newItemType || !newItemRefId) {
        throw new Error("Item type and reference are required");
      }

      const maxOrder = items.length > 0 ? Math.max(...items.map((i) => i.order)) : 0;

      const itemData = {
        sequence_id: sequenceId,
        order: maxOrder + 1,
        type: newItemType,
      };

      if (newItemType === "playlist") {
        itemData.playlist_id = newItemRefId;
      } else if (newItemType === "presentation") {
        itemData.presentation_id = newItemRefId;
      }

      return base44.entities.SequenceItem.create(itemData);
    },
    onSuccess: () => {
      setNewItemType("playlist");
      setNewItemRefId("");
      setIsAddingItem(false);
      queryClient.invalidateQueries({ queryKey: ["sequenceItems", sequenceId] });
      onSaved?.();
    },
  });

  // Delete item mutation
  const deleteItemMutation = useMutation({
    mutationFn: (itemId) => base44.entities.SequenceItem.delete(itemId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sequenceItems", sequenceId] });
      onSaved?.();
    },
  });

  // Reorder items mutation
  const reorderMutation = useMutation({
    mutationFn: async (newItems) => {
      await Promise.all(
        newItems.map((item, idx) =>
          base44.entities.SequenceItem.update(item.id, {
            order: idx + 1,
          })
        )
      );
      return newItems;
    },
    onSuccess: (newItems) => {
      setItems(loadSequenceItems(newItems));
      queryClient.invalidateQueries({ queryKey: ["sequenceItems", sequenceId] });
      onSaved?.();
    },
  });

  const handleMoveUp = (idx) => {
    if (idx === 0) return;
    const newItems = [...items];
    [newItems[idx - 1], newItems[idx]] = [newItems[idx], newItems[idx - 1]];
    reorderMutation.mutate(newItems);
  };

  const handleMoveDown = (idx) => {
    if (idx === items.length - 1) return;
    const newItems = [...items];
    [newItems[idx], newItems[idx + 1]] = [newItems[idx + 1], newItems[idx]];
    reorderMutation.mutate(newItems);
  };

  if (isLoading) {
    return <div className="p-4">Loading...</div>;
  }

  if (!sequence) {
    return <div className="p-4">Sequence not found</div>;
  }

  // Validation
  const validation = validateSequenceItems(items);

  return (
    <div className="space-y-4">
      {/* Sequence info */}
      <Card>
        <CardHeader>
          <CardTitle>{sequence.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600">
            {items.length === 0
              ? "No items in sequence"
              : `${items.length} item${items.length > 1 ? "s" : ""}`}
          </p>
        </CardContent>
      </Card>

      {/* Items list */}
      {items.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sequence Items</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {items.map((item, idx) => {
              const itemLabel =
                item.type === "playlist"
                  ? playlists.find((p) => p.id === item.playlist_id)?.name ||
                    `Playlist ${item.playlist_id}`
                  : presentations.find((p) => p.id === item.presentation_id)
                      ?.name || `Presentation ${item.presentation_id}`;

              return (
                <div
                  key={item.id}
                  className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200"
                >
                  <GripVertical className="w-4 h-4 text-slate-400" />
                  <div className="flex-1">
                    <div className="text-sm font-medium">
                      {idx + 1}. {itemLabel}
                    </div>
                    <div className="text-xs text-slate-500 capitalize">
                      {item.type}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleMoveUp(idx)}
                      disabled={idx === 0}
                    >
                      <ChevronUp className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleMoveDown(idx)}
                      disabled={idx === items.length - 1}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-red-600 hover:text-red-700"
                      onClick={() => deleteItemMutation.mutate(item.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Validation errors */}
      {!validation.valid && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="text-sm text-red-800">
              {validation.errors.map((err, i) => (
                <div key={i}>• {err}</div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add item form */}
      {!isAddingItem ? (
        <Button
          onClick={() => setIsAddingItem(true)}
          className="w-full gap-2"
          variant="outline"
        >
          <Plus className="w-4 h-4" /> Add Item
        </Button>
      ) : (
        <Card>
          <CardContent className="pt-6 space-y-3">
            <div>
              <label className="text-sm font-medium">Type</label>
              <Select value={newItemType} onValueChange={setNewItemType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="playlist">Playlist</SelectItem>
                  <SelectItem value="presentation">Route Presentation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">
                {newItemType === "playlist" ? "Playlist" : "Presentation"}
              </label>
              <Select value={newItemRefId} onValueChange={setNewItemRefId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent>
                  {newItemType === "playlist"
                    ? playlists.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name}
                        </SelectItem>
                      ))
                    : presentations.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name}
                        </SelectItem>
                      ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => addItemMutation.mutate()}
                disabled={addItemMutation.isPending || !newItemRefId}
              >
                Add
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddingItem(false);
                  setNewItemRefId("");
                }}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}