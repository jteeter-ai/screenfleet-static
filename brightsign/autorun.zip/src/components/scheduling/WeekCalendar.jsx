import React, { useRef, useEffect } from "react";

const HOURS = Array.from({ length: 24 }, (_, i) => i);
const DAYS_FULL = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const DAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function timeToMinutes(t) {
  if (!t) return 0;
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

function getWeekDates(baseDate) {
  const d = new Date(baseDate);
  const day = d.getDay();
  const sunday = new Date(d);
  sunday.setDate(d.getDate() - day);
  return Array.from({ length: 7 }, (_, i) => {
    const dd = new Date(sunday);
    dd.setDate(sunday.getDate() + i);
    return dd;
  });
}

const BLOCK_COLORS = [
  "bg-blue-500 border-blue-600 text-white",
  "bg-violet-500 border-violet-600 text-white",
  "bg-emerald-500 border-emerald-600 text-white",
  "bg-amber-500 border-amber-600 text-white",
  "bg-rose-500 border-rose-600 text-white",
  "bg-cyan-500 border-cyan-600 text-white",
  "bg-orange-500 border-orange-600 text-white",
];

function colorForSchedule(index) {
  return BLOCK_COLORS[index % BLOCK_COLORS.length];
}

function formatHour(h, use24h) {
  if (use24h) return `${String(h).padStart(2, "0")}:00`;
  if (h === 0) return "12 AM";
  if (h === 12) return "12 PM";
  return h < 12 ? `${h} AM` : `${h - 12} PM`;
}

function formatTime(t, use24h) {
  if (!t) return "";
  if (use24h) return t;
  const [h, m] = t.split(":").map(Number);
  const period = h < 12 ? "AM" : "PM";
  const hour = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${hour}:${String(m).padStart(2, "0")} ${period}`;
}

export default function WeekCalendar({ schedules, weekStart, onSelectSchedule, onDeleteSchedule, selectedScheduleId, use24h = true, getScheduleDisplayName }) {
  const scrollRef = useRef(null);
  const hourHeight = 48; // px per hour
  const weekDates = getWeekDates(weekStart);
  const today = new Date();

  useEffect(() => {
    // Scroll to 6am on mount
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 6 * hourHeight;
    }
  }, []);

  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  return (
    <div className="flex flex-col flex-1 overflow-hidden bg-white">
      <p className="text-xs text-slate-400 px-3 pb-1 md:hidden">← Scroll to see full week</p>

      {/* Horizontal scroll wrapper for mobile */}
      <div className="overflow-x-auto flex-shrink-0" style={{ WebkitOverflowScrolling: 'touch' }}>
        <div style={{ minWidth: '600px' }}>
          {/* Day headers */}
          <div className="flex border-b border-slate-200 bg-white z-10">
            <div className="w-14 flex-shrink-0 border-r border-slate-200" />
            {weekDates.map((date, i) => {
              const isToday =
                date.getFullYear() === today.getFullYear() &&
                date.getMonth() === today.getMonth() &&
                date.getDate() === today.getDate();
              return (
                <div
                  key={i}
                  className={`flex-1 text-center py-2 border-r border-slate-200 last:border-r-0 ${isToday ? "bg-blue-50" : ""}`}
                >
                  <div className={`text-xs font-semibold uppercase tracking-wide ${isToday ? "text-blue-600" : "text-slate-500"}`}>
                    {DAYS_SHORT[i]}
                  </div>
                  <div className={`text-sm font-bold ${isToday ? "text-blue-700" : "text-slate-700"}`}>
                    {date.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Scrollable time grid */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto overflow-x-auto relative" style={{ WebkitOverflowScrolling: 'touch' }}>
        <div style={{ height: hourHeight * 24, minWidth: '600px' }} className="flex relative">
          {/* Time labels */}
          <div className="w-14 flex-shrink-0 border-r border-slate-200 relative">
            {HOURS.map((h) => (
              <div
                key={h}
                className="absolute w-full text-right pr-2"
                style={{ top: h * hourHeight - 8, height: hourHeight }}
              >
                <span className="text-[10px] text-slate-400">
                  {h === 0 ? "" : formatHour(h, use24h)}
                </span>
              </div>
            ))}
          </div>

          {/* Day columns */}
          {weekDates.map((date, dayIndex) => {
            const isToday =
              date.getFullYear() === today.getFullYear() &&
              date.getMonth() === today.getMonth() &&
              date.getDate() === today.getDate();
            const dayOfWeek = date.getDay();

            const daySchedules = schedules.filter((s) =>
              s.play_all_day || (s.days_of_week || []).includes(dayOfWeek)
            );

            return (
              <div
                key={dayIndex}
                className={`flex-1 relative border-r border-slate-100 last:border-r-0 ${isToday ? "bg-blue-50/30" : ""}`}
              >
                {/* Hour lines */}
                {HOURS.map((h) => (
                  <div
                    key={h}
                    className="absolute w-full border-t border-slate-100"
                    style={{ top: h * hourHeight }}
                  />
                ))}
                {/* 30-min lines */}
                {HOURS.map((h) => (
                  <div
                    key={`half-${h}`}
                    className="absolute w-full border-t border-slate-50"
                    style={{ top: h * hourHeight + hourHeight / 2 }}
                  />
                ))}

                {/* Schedule blocks */}
                {daySchedules.map((s) => {
                  const globalIdx = schedules.indexOf(s);
                  const startMin = s.play_all_day ? 0 : timeToMinutes(s.start_time);
                  const endMin = s.play_all_day ? 24 * 60 : timeToMinutes(s.end_time || "23:59");
                  const duration = Math.max(endMin - startMin, 30);
                  const top = (startMin / 60) * hourHeight;
                  const height = (duration / 60) * hourHeight;
                  const displayName = getScheduleDisplayName ? getScheduleDisplayName(s) : s.name;
                  const isSelected = s.id === selectedScheduleId;
                  const colorClass = colorForSchedule(globalIdx);

                  return (
                    <div
                      key={s.id}
                      className={`absolute left-0.5 right-0.5 rounded border cursor-pointer transition-all group/block ${colorClass} ${
                        isSelected ? "ring-2 ring-white ring-offset-1 opacity-100" : "opacity-80 hover:opacity-100"
                      } ${!s.is_active ? "opacity-40 saturate-0" : ""}`}
                      style={{ top, height: Math.max(height, 20), zIndex: isSelected ? 10 : 5 }}
                      onClick={() => onSelectSchedule(s)}
                    >
                      <div className="px-1 py-0.5 overflow-hidden">
                        <div className="text-[9px] font-bold truncate leading-tight pr-4">{displayName}</div>
                        {height > 45 && (
                          <div className="text-[8px] opacity-70">{formatTime(s.start_time, use24h)}–{formatTime(s.end_time, use24h)}</div>
                        )}
                      </div>
                      {onDeleteSchedule && (
                        <button
                          className="absolute top-0.5 right-0.5 w-4 h-4 rounded flex items-center justify-center opacity-0 group-hover/block:opacity-100 transition-opacity bg-black/20 hover:bg-black/40 text-white leading-none text-[10px] font-bold"
                          onClick={(e) => { e.stopPropagation(); onDeleteSchedule(s.id); }}
                          title="Delete schedule"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  );
                })}

                {/* Current time line */}
                {isToday && (
                  <div
                    className="absolute left-0 right-0 border-t-2 border-red-500 z-20 pointer-events-none"
                    style={{ top: (nowMinutes / 60) * hourHeight }}
                  >
                    <div className="w-2 h-2 rounded-full bg-red-500 -mt-1 -ml-1 absolute" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}