import React from "react";
import { ListVideo, RefreshCw, Repeat2, Plus, Lock } from "lucide-react";
import { useFeatureAccess } from "@/lib/useFeatureAccess";

export default function RecentPresentations({ playlists, routePresentations, sequences, onSelect, disabled }) {
  const { canAccess } = useFeatureAccess();
  const canRoutePresentations = canAccess("route_presentations");
  const canSequences = canAccess("sequences");
   const Section = ({ label, items, icon: Icon, color, textColor, onItemClick }) => (
    <div className="mb-3">
      <div className="px-3 pt-2 pb-0.5">
        <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">{label}</span>
      </div>
      <div className="space-y-0.5 px-2">
        {items.length === 0 ? (
          <div className="px-2 py-2 text-center text-[10px] text-slate-400">None yet</div>
        ) : (
          items.map((item) => (
            <button
              key={item.id}
              onClick={() => onItemClick(item)}
              disabled={disabled}
              className={`w-full text-left group flex items-center gap-2 px-2 py-2 rounded-lg border border-transparent transition-all ${disabled ? "opacity-50 cursor-not-allowed" : "hover:bg-white hover:shadow-sm hover:border-slate-200"}`}
            >
              <div className={`w-6 h-6 rounded ${color} flex items-center justify-center flex-shrink-0`}>
                <Icon className={`w-3 h-3 ${textColor}`} />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-medium text-slate-700 truncate leading-tight">{item.name}</div>
                {item.updated_date && (
                  <div className="text-[10px] text-slate-400">
                    {new Date(item.updated_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                  </div>
                )}
              </div>
              <Plus className="w-3 h-3 text-blue-500 opacity-0 group-hover:opacity-100 ml-auto flex-shrink-0 transition-opacity" />
            </button>
          ))
        )}
      </div>
    </div>
  );

  return (
    <div className="w-52 flex-shrink-0 border-r border-slate-200 bg-slate-50 flex flex-col overflow-hidden">
      <div className="px-3 py-2.5 border-b border-slate-200 bg-white">
        <div className="flex items-center gap-2">
          <ListVideo className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Add to Schedule</span>
        </div>
        <p className="text-[10px] text-slate-400 mt-0.5">Click to schedule</p>
      </div>

      <div className="flex-1 overflow-y-auto py-1">
        <Section
          label="Playlists"
          items={playlists}
          icon={ListVideo}
          color="bg-blue-100"
          textColor="text-blue-600"
          onItemClick={(item) => onSelect({ content_type: "playlist", id: item.id, name: item.name })}
        />
        {canRoutePresentations ? (
          <>
            <div className="border-t border-slate-200 mx-3 my-1" />
            <Section
              label="Route Presentations"
              items={routePresentations}
              icon={RefreshCw}
              color="bg-amber-100"
              textColor="text-amber-600"
              onItemClick={(item) => onSelect({ content_type: "rotation", id: item.id, name: item.name })}
            />
          </>
        ) : (
          <>
            <div className="border-t border-slate-200 mx-3 my-1" />
            <div className="px-3 py-2">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest mb-1">Route Presentations</div>
              <div className="flex items-center gap-1 text-[10px] text-slate-400">
                <Lock className="w-3 h-3" /> Not in your plan
              </div>
            </div>
          </>
        )}
        {canSequences ? (
          <>
            <div className="border-t border-slate-200 mx-3 my-1" />
            <Section
              label="Sequences"
              items={sequences}
              icon={Repeat2}
              color="bg-purple-100"
              textColor="text-purple-600"
              onItemClick={(item) => onSelect({ content_type: "sequence", id: item.id, name: item.name })}
            />
          </>
        ) : (
          <>
            <div className="border-t border-slate-200 mx-3 my-1" />
            <div className="px-3 py-2">
              <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest mb-1">Sequences</div>
              <div className="flex items-center gap-1 text-[10px] text-slate-400">
                <Lock className="w-3 h-3" /> Not in your plan
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}