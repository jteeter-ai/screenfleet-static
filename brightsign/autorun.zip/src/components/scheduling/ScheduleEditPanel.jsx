import React from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Plus, Zap, Clock, ListVideo, RefreshCw, Repeat2, Lock } from "lucide-react";
import { useFeatureAccess } from "@/lib/useFeatureAccess";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const DAY_PRESETS = {
  "All Days": [0, 1, 2, 3, 4, 5, 6],
  "Weekdays": [1, 2, 3, 4, 5],
  "Weekends": [0, 6],
};

const CONTENT_TYPES = [
  { value: "playlist", label: "Playlist", icon: ListVideo },
  { value: "rotation", label: "Route Presentation", icon: RefreshCw },
  { value: "sequence", label: "Sequence", icon: Repeat2 },
];

export default function ScheduleEditPanel({ schedule, playlists, routePresentations, sequences, onUpdate, onDelete, onAdd }) {
  const { canAccess } = useFeatureAccess();
  if (!schedule) {
    return (
      <div className="w-72 flex-shrink-0 border-l border-slate-200 bg-slate-50 flex flex-col p-5 gap-4 overflow-y-auto">
        <p className="text-xs text-slate-400 text-center mt-4">
          Click an item on the left to schedule it,<br />or click a block on the calendar to edit it.
        </p>
        <Button size="sm" className="gap-1 bg-blue-600 hover:bg-blue-700 text-xs h-8" onClick={onAdd}>
          <Plus className="w-3.5 h-3.5" /> Add to Schedule
        </Button>
      </div>
    );
  }

  const days = schedule.days_of_week || [];
  const toggleDay = (i) => {
    const updated = days.includes(i) ? days.filter((d) => d !== i) : [...days, i];
    onUpdate({ days_of_week: updated });
  };

  const contentType = schedule.content_type || "playlist";

  // Filter content types to only those the org has access to
  const availableContentTypes = CONTENT_TYPES.filter((t) => {
    if (t.value === "playlist") return true;
    if (t.value === "rotation") return canAccess("route_presentations");
    if (t.value === "sequence") return canAccess("sequences");
    return true;
  });

  const handleContentTypeChange = (type) => {
    onUpdate({ content_type: type, playlist_id: undefined, rotation_id: undefined, sequence_id: undefined, name: "New Schedule" });
  };

  const handleItemChange = (id) => {
    let name = "New Schedule";
    if (contentType === "playlist") {
      name = playlists.find((p) => p.id === id)?.name || name;
      onUpdate({ playlist_id: id, name });
    } else if (contentType === "rotation") {
      name = routePresentations.find((r) => r.id === id)?.name || name;
      onUpdate({ rotation_id: id, name });
    } else if (contentType === "sequence") {
      name = sequences.find((s) => s.id === id)?.name || name;
      onUpdate({ sequence_id: id, name });
    }
  };

  const currentItemId =
    contentType === "playlist" ? schedule.playlist_id :
    contentType === "rotation" ? schedule.rotation_id :
    schedule.sequence_id;

  const currentItems =
    contentType === "playlist" ? playlists :
    contentType === "rotation" ? routePresentations :
    sequences;

  const typeConfig = CONTENT_TYPES.find((t) => t.value === contentType);
  const TypeIcon = typeConfig?.icon || ListVideo;

  return (
    <div className="w-72 flex-shrink-0 border-l border-slate-200 bg-white flex flex-col overflow-y-auto">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-800">Edit Schedule</h3>
        <Button variant="ghost" size="icon" className="h-7 w-7 text-red-400 hover:text-red-600 hover:bg-red-50" onClick={onDelete}>
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      <div className="p-4 space-y-4">
        {/* Content Type */}
        <div>
          <Label className="text-xs text-slate-500 uppercase tracking-wide">Schedule Type</Label>
          <Select value={contentType} onValueChange={handleContentTypeChange}>
            <SelectTrigger className="h-8 text-xs mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {availableContentTypes.map((t) => (
                <SelectItem key={t.value} value={t.value}>
                  <div className="flex items-center gap-2">
                    <t.icon className="w-3.5 h-3.5" />
                    {t.label}
                  </div>
                </SelectItem>
              ))}
              {availableContentTypes.length < CONTENT_TYPES.length && (
                <div className="flex items-center gap-1.5 px-2 py-1.5 text-[10px] text-slate-400 border-t border-slate-100">
                  <Lock className="w-3 h-3" /> Some types require a plan upgrade
                </div>
              )}
            </SelectContent>
          </Select>
        </div>

        {/* Item selector */}
        <div>
          <Label className="text-xs text-slate-500 uppercase tracking-wide flex items-center gap-1">
            <TypeIcon className="w-3 h-3" /> {typeConfig?.label}
          </Label>
          {currentItems.length === 0 ? (
            <div className="mt-1 p-2 rounded bg-amber-50 border border-amber-200 text-xs text-amber-700">
              No {typeConfig?.label}s found. Create one first.
            </div>
          ) : (
            <Select value={currentItemId || ""} onValueChange={handleItemChange}>
              <SelectTrigger className="h-8 text-xs mt-1">
                <SelectValue placeholder={`Choose ${typeConfig?.label}…`} />
              </SelectTrigger>
              <SelectContent>
                {currentItems.map((item) => (
                  <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Play All Day Every Day */}
        <div className="rounded-lg border border-slate-200 p-3 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-blue-500" />
              <Label className="text-sm font-medium text-slate-700">Play All Day, Every Day</Label>
            </div>
            <Switch
              checked={!!schedule.play_all_day}
              onCheckedChange={(v) => onUpdate({ play_all_day: v })}
            />
          </div>
          {schedule.play_all_day && (
            <p className="text-[11px] text-slate-500 leading-relaxed">
              This will play whenever the screen is on, ignoring time and day settings below.
            </p>
          )}
        </div>

        {/* Time + Days (hidden when play_all_day) */}
        {!schedule.play_all_day && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-slate-500 uppercase tracking-wide">Start</Label>
                <input type="time" value={schedule.start_time || "08:00"} onChange={(e) => onUpdate({ start_time: e.target.value })}
                  className="mt-1 h-8 w-full rounded-md border border-input bg-background px-2 text-xs focus:outline-none focus:ring-1 focus:ring-ring" />
              </div>
              <div>
                <Label className="text-xs text-slate-500 uppercase tracking-wide">End</Label>
                <input type="time" value={schedule.end_time || "20:00"} onChange={(e) => onUpdate({ end_time: e.target.value })}
                  className="mt-1 h-8 w-full rounded-md border border-input bg-background px-2 text-xs focus:outline-none focus:ring-1 focus:ring-ring" />
              </div>
            </div>

            <div>
              <Label className="text-xs text-slate-500 uppercase tracking-wide mb-2 block">Days</Label>
              <div className="flex flex-wrap gap-1 mb-2">
                {Object.entries(DAY_PRESETS).map(([label, dayNums]) => (
                  <button
                    key={label}
                    className={`text-[10px] px-2 py-1 rounded border transition-colors ${
                      JSON.stringify([...days].sort()) === JSON.stringify([...dayNums].sort())
                        ? "bg-blue-100 text-blue-700 border-blue-300"
                        : "text-slate-500 border-slate-200 hover:border-blue-200"
                    }`}
                    onClick={() => onUpdate({ days_of_week: dayNums })}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <div className="flex gap-1">
                {DAYS.map((day, i) => (
                  <button
                    key={i}
                    onClick={() => toggleDay(i)}
                    className={`w-8 h-8 rounded text-[10px] font-semibold transition-colors ${
                      days.includes(i) ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                    }`}
                  >
                    {day[0]}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Interrupt Others */}
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-amber-600" />
              <Label className="text-sm font-medium text-amber-800">Interrupt Other Presentations</Label>
            </div>
            <Switch
              checked={!!schedule.interrupt_others}
              onCheckedChange={(v) => onUpdate({ interrupt_others: v, priority: v ? 99 : 1 })}
            />
          </div>
          <p className="text-[11px] text-amber-700 leading-relaxed">
            When enabled, this plays on top of anything else scheduled at the same time.
          </p>
        </div>

        {/* Active */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <Label className="text-sm text-slate-700">Active</Label>
          <Switch checked={!!schedule.is_active} onCheckedChange={(v) => onUpdate({ is_active: v })} />
        </div>
      </div>

      <div className="mt-auto p-4 border-t border-slate-100">
        <Button size="sm" className="w-full gap-1 bg-blue-600 hover:bg-blue-700 text-xs h-8" onClick={onAdd}>
          <Plus className="w-3.5 h-3.5" /> Add to Schedule
        </Button>
      </div>
    </div>
  );
}