import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Truck, Monitor, Plus, LayoutGrid, ChevronRight,
  Trash2, Layers
} from "lucide-react";

function LayoutCard({ layout, truckScreens = [], zones = [], onEdit, onDelete }) {
  const screenCount = truckScreens.length;
  const layoutZones = zones.filter((z) => z.layout_id === layout.id);

  // Find bounding box across all zones to scale preview
  const maxX = layoutZones.reduce((m, z) => Math.max(m, (z.x || 0) + z.width), 1);
  const maxY = layoutZones.reduce((m, z) => Math.max(m, (z.y || 0) + z.height), 1);
  const PREVIEW_W = 200;
  const PREVIEW_H = 80;
  const scale = Math.min(PREVIEW_W / maxX, PREVIEW_H / maxY);

  const zoneColors = ["#bfdbfe","#a7f3d0","#ddd6fe","#fde68a","#fecaca","#bae6fd"];

  return (
    <div className="group relative bg-white border border-slate-200 rounded-xl p-4 hover:border-blue-400 hover:shadow-md transition-all cursor-pointer"
      onClick={() => onEdit(layout)}>
      {/* Zone preview */}
      <div className="w-full h-20 bg-slate-100 rounded-lg mb-3 flex items-center justify-center border border-slate-200 overflow-hidden">
        {layoutZones.length === 0 ? (
          <LayoutGrid className="w-8 h-8 text-slate-300" />
        ) : (
          <div className="relative" style={{ width: maxX * scale, height: maxY * scale }}>
            {layoutZones.map((zone, i) => (
              <div
                key={zone.id}
                className="absolute border border-white/60 rounded-sm"
                style={{
                  left: (zone.x || 0) * scale,
                  top: (zone.y || 0) * scale,
                  width: zone.width * scale,
                  height: zone.height * scale,
                  backgroundColor: zoneColors[i % zoneColors.length],
                }}
              />
            ))}
          </div>
        )}
      </div>

      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-slate-800 truncate">{layout.name}</p>
          <p className="text-xs text-slate-400 mt-0.5">
            {screenCount > 0 ? `${screenCount} screen${screenCount !== 1 ? "s" : ""}` : "No screens"}
          </p>
        </div>
        {layout.is_active && (
          <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px] flex-shrink-0 gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            Live
          </Badge>
        )}
      </div>

      {/* Action buttons */}
      <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          className="p-1.5 rounded-lg bg-white border border-slate-200 hover:bg-red-50 hover:border-red-300 text-red-400 shadow-sm"
          title="Delete layout"
          onClick={(e) => { e.stopPropagation(); onDelete(layout.id); }}
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}

export default function ScreenEditorLanding({ trucks, allScreens, onEnterEditor }) {
  const queryClient = useQueryClient();
  const [expandedTruckId, setExpandedTruckId] = useState(null);
  const [creatingForTruck, setCreatingForTruck] = useState(null);
  const [newLayoutName, setNewLayoutName] = useState("");

  const { data: allLayouts = [] } = useQuery({
    queryKey: ["allLayouts"],
    queryFn: async () => {
      const layouts = await base44.entities.Layout.list();
      return layouts;
    },
  });

  const { data: allZones = [] } = useQuery({
    queryKey: ["zones"],
    queryFn: () => base44.entities.Zone.list(),
  });

  const saveLayoutMutation = useMutation({
    mutationFn: ({ truckId, name }) =>
      base44.entities.Layout.create({ truck_id: truckId, name, is_active: false }),
    onSuccess: (newLayout) => {
      queryClient.invalidateQueries({ queryKey: ["layouts", newLayout.truck_id] });
      queryClient.invalidateQueries({ queryKey: ["allLayouts"] });
      setCreatingForTruck(null);
      setNewLayoutName("");
      // Enter editor for this new layout
      onEnterEditor(newLayout.truck_id, newLayout);
    },
  });

  const pushLayoutMutation = useMutation({
    mutationFn: async (layout) => {
      const truckLayouts = allLayouts.filter((l) => l.truck_id === layout.truck_id);
      await Promise.all(truckLayouts.map((l) => base44.entities.Layout.update(l.id, { is_active: false })));
      await base44.entities.Layout.update(layout.id, { is_active: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["layouts"] });
      queryClient.invalidateQueries({ queryKey: ["allLayouts"] });
    },
  });

  const deleteLayoutMutation = useMutation({
    mutationFn: async (layoutId) => {
      // Delete all zones linked to this layout
      const layoutZones = allZones.filter((z) => z.layout_id === layoutId);
      await Promise.all(layoutZones.map((z) => base44.entities.Zone.delete(z.id)));
      // Delete the layout
      await base44.entities.Layout.delete(layoutId);
    },
    onMutate: (id) => {
      queryClient.setQueryData(["allLayouts"], (old) => old?.filter((l) => l.id !== id) || []);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["layouts"] });
      queryClient.invalidateQueries({ queryKey: ["allLayouts"] });
      queryClient.invalidateQueries({ queryKey: ["zones"] });
    },
  });

  return (
    <div className="flex-1 overflow-auto bg-slate-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Screen Editor</h2>
          <p className="text-sm text-slate-500 mt-1">Select an asset to view or create layouts for its screens.</p>
        </div>

        {trucks.length === 0 && (
          <div className="text-center py-20 text-slate-400">
            <Truck className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No assets found. Add a truck first.</p>
          </div>
        )}

        {trucks.map((truck) => {
          const screens = allScreens.filter((s) => s.truck_id === truck.id);
          const layouts = allLayouts.filter((l) => l.truck_id === truck.id);
          const isExpanded = expandedTruckId === truck.id;

          return (
            <div key={truck.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              {/* Asset header */}
              <button
                className="w-full flex items-center gap-4 px-5 py-4 hover:bg-slate-50 transition-colors text-left"
                onClick={() => setExpandedTruckId(isExpanded ? null : truck.id)}
              >
                <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center flex-shrink-0">
                  <Truck className="w-5 h-5 text-blue-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{truck.name}</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {screens.length} screen{screens.length !== 1 ? "s" : ""} · {layouts.length} layout{layouts.length !== 1 ? "s" : ""}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {layouts.some((l) => l.is_active) && (
                    <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px] gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                      Live
                    </Badge>
                  )}
                  <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform ${isExpanded ? "rotate-90" : ""}`} />
                </div>
              </button>

              {/* Screens & layouts */}
              {isExpanded && (
                <div className="border-t border-slate-100 px-5 pb-5 pt-4">
                  {/* Screens summary row */}
                  {screens.length > 0 && (
                    <div className="flex items-center gap-2 mb-5 flex-wrap">
                      <span className="text-xs text-slate-400 font-medium uppercase tracking-wide">Screens:</span>
                      {screens.map((s) => (
                        <div key={s.id} className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 rounded-lg text-xs text-slate-600">
                          <Monitor className="w-3 h-3 text-slate-400" />
                          {s.name}
                          {s.width && s.height && <span className="text-slate-400">{s.width}×{s.height}</span>}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Layouts heading */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5" /> Saved Layouts
                    </span>
                    {creatingForTruck === truck.id ? (
                      <div className="flex items-center gap-1.5">
                        <Input
                          autoFocus
                          value={newLayoutName}
                          onChange={(e) => setNewLayoutName(e.target.value)}
                          placeholder="Layout name…"
                          className="h-7 text-xs w-40"
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && newLayoutName.trim()) {
                              saveLayoutMutation.mutate({ truckId: truck.id, name: newLayoutName.trim() });
                            }
                            if (e.key === "Escape") { setCreatingForTruck(null); setNewLayoutName(""); }
                          }}
                        />
                        <Button size="sm" className="h-7 text-xs px-2 bg-blue-600 hover:bg-blue-700"
                          onClick={() => newLayoutName.trim() && saveLayoutMutation.mutate({ truckId: truck.id, name: newLayoutName.trim() })}>
                          Create
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 text-xs px-2"
                          onClick={() => { setCreatingForTruck(null); setNewLayoutName(""); }}>
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <Button size="sm" variant="outline" className="h-7 text-xs gap-1"
                        onClick={() => setCreatingForTruck(truck.id)}>
                        <Plus className="w-3 h-3" /> New Layout
                      </Button>
                    )}
                  </div>

                  {/* Layout cards grid */}
                  {layouts.length === 0 ? (
                    <div
                      className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center cursor-pointer hover:border-blue-300 hover:bg-blue-50/30 transition-all"
                      onClick={(e) => { e.stopPropagation(); setCreatingForTruck(truck.id); }}
                    >
                      <LayoutGrid className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                      <p className="text-sm text-slate-500 font-medium">No layouts yet</p>
                      <p className="text-xs text-slate-400 mt-1">Click to create your first layout</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                      {layouts.map((layout) => (
                        <LayoutCard
                          key={layout.id}
                          layout={layout}
                          truckScreens={screens}
                          zones={allZones}
                          onEdit={(l) => onEnterEditor(truck.id, l)}
                          onDelete={(id) => deleteLayoutMutation.mutate(id)}
                        />
                      ))}
                      {/* + New card */}
                      <button
                        className="border-2 border-dashed border-slate-200 rounded-xl p-4 flex flex-col items-center justify-center gap-2 hover:border-blue-300 hover:bg-blue-50/30 transition-all text-slate-400 hover:text-blue-500 h-full min-h-[120px]"
                        onClick={(e) => { e.stopPropagation(); setCreatingForTruck(truck.id); }}
                      >
                        <Plus className="w-5 h-5" />
                        <span className="text-xs font-medium">New Layout</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}