import React, { useState, useRef, useCallback } from "react";
import { Move, Maximize2 } from "lucide-react";

export default function CanvasWorkspace({ screen, zones, selectedZoneId, onSelectZone, onUpdateZone, zoom = 100 }) {
  const containerRef = useRef(null);
  const [dragging, setDragging] = useState(null);
  const [resizing, setResizing] = useState(null);

  const canvasW = screen?.width || 3840;
  const canvasH = screen?.height || 2160;

  // Calculate scale to fit the canvas in the viewport, then apply zoom
  const getScale = useCallback(() => {
    if (!containerRef.current) return 0.2;
    const rect = containerRef.current.getBoundingClientRect();
    const scaleX = (rect.width - 40) / canvasW;
    const scaleY = (rect.height - 40) / canvasH;
    return Math.min(scaleX, scaleY, 1) * (zoom / 100);
  }, [canvasW, canvasH, zoom]);

  const scale = getScale();

  const handleMouseDown = (e, zone, mode) => {
    e.stopPropagation();
    e.preventDefault();
    onSelectZone(zone.id);

    const startX = e.clientX;
    const startY = e.clientY;
    const startZone = { x: zone.x || 0, y: zone.y || 0, width: zone.width, height: zone.height };

    const handleMouseMove = (moveE) => {
      const dx = (moveE.clientX - startX) / scale;
      const dy = (moveE.clientY - startY) / scale;

      if (mode === "move") {
        onUpdateZone(zone.id, {
          x: Math.max(0, Math.round(startZone.x + dx)),
          y: Math.max(0, Math.round(startZone.y + dy)),
        });
      } else if (mode === "resize") {
        onUpdateZone(zone.id, {
          width: Math.max(50, Math.round(startZone.width + dx)),
          height: Math.max(50, Math.round(startZone.height + dy)),
        });
      }
    };

    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      setDragging(null);
      setResizing(null);
    };

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
    
    if (mode === "move") setDragging(zone.id);
    else setResizing(zone.id);
  };

  const ZONE_COLORS = [
    "border-blue-400 bg-blue-400/10",
    "border-emerald-400 bg-emerald-400/10",
    "border-violet-400 bg-violet-400/10",
    "border-amber-400 bg-amber-400/10",
    "border-rose-400 bg-rose-400/10",
    "border-cyan-400 bg-cyan-400/10",
  ];

  return (
    <div ref={containerRef} className="flex-1 bg-slate-200 flex items-center justify-center overflow-auto p-5">
      <div
        className="relative bg-slate-100 border border-slate-300 shadow-lg"
        style={{
          width: canvasW * scale,
          height: canvasH * scale,
        }}
        onClick={() => onSelectZone(null)}
      >
        {/* Resolution label */}
        <div className="absolute -top-6 left-0 text-xs text-slate-600 font-mono">
          {canvasW} × {canvasH}
        </div>

        {zones.map((zone, i) => {
          const isSelected = zone.id === selectedZoneId;
          const colorClass = ZONE_COLORS[i % ZONE_COLORS.length];
          
          return (
            <div
              key={zone.id}
              className={`absolute border-2 ${colorClass} ${isSelected ? "zone-selected !border-blue-500" : ""} cursor-move transition-shadow`}
              style={{
                left: (zone.x || 0) * scale,
                top: (zone.y || 0) * scale,
                width: zone.width * scale,
                height: zone.height * scale,
                zIndex: zone.z_index || 1,
              }}
              onClick={(e) => { e.stopPropagation(); onSelectZone(zone.id); }}
              onMouseDown={(e) => handleMouseDown(e, zone, "move")}
            >
              {/* Zone label */}
              <div className="absolute top-1 left-1.5 flex items-center gap-1 pointer-events-none">
                <span className="text-[10px] font-medium text-white/80 bg-black/50 px-1.5 py-0.5 rounded">
                  {zone.name}
                </span>
                {zone.content_type !== "empty" && (
                  <span className="text-[9px] text-white/50 bg-black/40 px-1 py-0.5 rounded uppercase">
                    {zone.content_type}
                  </span>
                )}
              </div>

              {/* Media preview */}
              {zone.content_type === "image" && zone.media_url && (
                <img
                  src={zone.media_url}
                  alt=""
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                  style={{ objectFit: zone.fit_mode === "fit" ? "contain" : zone.fit_mode === "stretch" ? "fill" : "cover" }}
                />
              )}
              {zone.content_type === "video" && zone.media_url && (
                <video
                  src={zone.media_url}
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                  muted
                  loop
                  autoPlay
                />
              )}

              {/* Resize handle */}
              {isSelected && (
                <div
                  className="absolute -bottom-1.5 -right-1.5 w-4 h-4 bg-blue-500 rounded-sm cursor-se-resize flex items-center justify-center shadow-lg"
                  onMouseDown={(e) => handleMouseDown(e, zone, "resize")}
                >
                  <Maximize2 className="w-2.5 h-2.5 text-white" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}