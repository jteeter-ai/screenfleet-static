import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Trash2, Tv2, ListVideo, RefreshCw, MonitorPlay, Link, Copy, Repeat2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import SelectSourceDialog from "./SelectSourceDialog";

export default function ZonePropertiesPanel({ zone, onUpdate, onDelete, allScreens, currentScreenId, allZones = [], onEditingStateChange }) {
  const [sourceDialogOpen, setSourceDialogOpen] = useState(zone || {});
  const [editingZone, setEditingZone] = useState(zone || {});
  const [localZone, setLocalZone] = useState(zone || {});

  useEffect(() => {
    if (zone) {
      setLocalZone(zone);
      setEditingZone(zone);
    }
  }, [zone?.id, zone?.content_type]);

  if (!zone) {
    return (
      <div className="w-72 border-l border-slate-200 bg-white p-6 flex items-center justify-center">
        <p className="text-sm text-slate-400 text-center">Select a zone to edit its properties</p>
      </div>
    );
  }

  const handleFieldChange = (field, value) => {
    const updated = { ...editingZone, [field]: value };
    setEditingZone(updated);
    if (onEditingStateChange) {
      onEditingStateChange(updated);
    }
  };

  const handleSave = () => {
    onUpdate(zone.id, editingZone);
    setLocalZone(editingZone);
  };

  const isDirty = JSON.stringify(editingZone) !== JSON.stringify(localZone);

  return (
    <div className="w-72 border-l border-slate-200 bg-white overflow-y-auto flex-shrink-0">
      <div className="p-4 border-b border-slate-100">
        <h3 className="text-sm font-semibold text-slate-900">Zone Properties</h3>
        <p className="text-xs text-slate-400 mt-0.5">{editingZone?.name || "Untitled Zone"}</p>
        <p className="text-xs text-slate-500 mt-1">{editingZone?.width || 0}×{editingZone?.height || 0}px</p>
      </div>

      <SelectSourceDialog
        open={sourceDialogOpen}
        onOpenChange={setSourceDialogOpen}
        zone={editingZone}
        allZones={allZones}
        currentZoneId={editingZone?.id}
        layoutZones={allZones}
        onApply={(updates) => handleFieldChange('content_type', updates.content_type)}
      />

      <div className="p-4 space-y-5">
        {/* Select Source button */}
        {(() => {
          const sourceMap = {
            playlist: { label: "Playlist", icon: ListVideo },
            rotation: { label: "Rotation", icon: RefreshCw },
            sequence: { label: "Sequence", icon: Repeat2 },
            multi_content: { label: "Playlist/Rotation/Sequence", icon: ListVideo },
            hdmi_input: { label: "HDMI Input", icon: MonitorPlay },
            html: { label: "Online Link", icon: Link },
            duplicate: { label: "Duplicate", icon: Copy },
          };
          const active = sourceMap[editingZone?.content_type];
          const Icon = active ? active.icon : Tv2;
          return (
            <Button variant="outline" size="sm" className={`w-full text-xs h-8 ${active ? "border-blue-400 bg-blue-50 text-blue-700" : "border-blue-200 text-blue-700 hover:bg-blue-50"}`} onClick={() => setSourceDialogOpen(true)}>
              <Icon className="w-3.5 h-3.5 mr-1.5" />
              {active ? active.label : "Select Source"}
            </Button>
          );
        })()}

        {/* Name */}
        <div>
          <Label className="text-xs">Name</Label>
          <Input value={editingZone.name || ""} onChange={(e) => handleFieldChange("name", e.target.value)} className="h-8 text-sm" />
        </div>

        {/* Position */}
        <div>
          <Label className="text-xs mb-2 block">Position & Size</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-[10px] text-slate-400 uppercase">X</span>
              <Input type="number" value={editingZone.x || 0} onChange={(e) => handleFieldChange("x", Number(e.target.value))} className="h-8 text-sm" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase">Y</span>
              <Input type="number" value={editingZone.y || 0} onChange={(e) => handleFieldChange("y", Number(e.target.value))} className="h-8 text-sm" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase">W</span>
              <Input type="number" value={editingZone.width || 0} onChange={(e) => handleFieldChange("width", Number(e.target.value))} className="h-8 text-sm" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase">H</span>
              <Input type="number" value={editingZone.height || 0} onChange={(e) => handleFieldChange("height", Number(e.target.value))} className="h-8 text-sm" />
            </div>
          </div>
        </div>

        {/* Z-Index */}
        <div>
          <Label className="text-xs">Layer (Z-Index)</Label>
          <Input type="number" value={editingZone.z_index || 1} onChange={(e) => handleFieldChange("z_index", Number(e.target.value))} className="h-8 text-sm" />
        </div>

        {/* HDMI Input */}
        {editingZone?.content_type === "hdmi_input" && (
          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-amber-50 border border-amber-100">
              <p className="text-xs text-amber-700">HDMI input will capture from the connected device on the media player.</p>
            </div>
            <div>
              <Label className="text-xs">Volume</Label>
              <div className="flex items-center gap-2 mt-1">
                <input type="range" min={0} max={100} step={5} value={editingZone.volume ?? 100}
                  onChange={(e) => handleFieldChange("volume", Number(e.target.value))}
                  className="flex-1 h-2 accent-blue-600"
                />
                <span className="text-xs text-slate-600 w-9 text-right">{editingZone.volume ?? 100}%</span>
              </div>
            </div>
          </div>
        )}

        {/* HTML / Web embed */}
        {editingZone.content_type === "html" && (
          <div>
            <Label className="text-xs">Web / HTML URL</Label>
            <Input
              placeholder="https://example.com/embed"
              value={editingZone.html_url || ""}
              onChange={(e) => handleFieldChange("html_url", e.target.value)}
              className="h-8 text-sm mt-1"
            />
          </div>
        )}

        {/* Fit Mode */}
        <div>
          <Label className="text-xs">Fit Mode</Label>
          <Select value={editingZone.fit_mode || "fill"} onValueChange={(v) => handleFieldChange("fit_mode", v)}>
            <SelectTrigger className="h-8 text-sm mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="fill">Fill (scale to cover)</SelectItem>
              <SelectItem value="fit">Fit (letterbox)</SelectItem>
              <SelectItem value="stretch">Stretch</SelectItem>
              <SelectItem value="center">Center (no scale)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Background Color */}
        <div>
          <Label className="text-xs">Background Color</Label>
          <div className="flex gap-2 mt-1">
            <input
              type="color"
              value={editingZone.background_color || "#000000"}
              onChange={(e) => handleFieldChange("background_color", e.target.value)}
              className="w-8 h-8 rounded border border-slate-200 cursor-pointer"
            />
            <Input value={editingZone.background_color || "#000000"} onChange={(e) => handleFieldChange("background_color", e.target.value)} className="h-8 text-sm flex-1" />
          </div>
        </div>

        {/* Visibility */}
        <div className="flex items-center justify-between">
          <Label className="text-xs">Visible</Label>
          <Switch checked={editingZone.is_visible !== false} onCheckedChange={(v) => handleFieldChange("is_visible", v)} />
        </div>

        {/* Delete */}
        <Button variant="outline" size="sm" className="w-full text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700" onClick={() => onDelete(editingZone?.id)}>
          <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Delete Zone
        </Button>

        {/* Save Button */}
        {isDirty && (
          <Button size="sm" className="w-full" onClick={handleSave}>
            Save Zone
          </Button>
        )}
      </div>
    </div>
  );
}