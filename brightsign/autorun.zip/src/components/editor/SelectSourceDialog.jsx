import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ListVideo, Copy, MonitorPlay, Link, RefreshCw, Check, Repeat2 } from "lucide-react";

const SOURCE_TYPES = [
  { id: "content", label: "Playlist\nRotation\nSequence", icon: ListVideo, description: "Play a media playlist, ad rotation, or sequence", multiline: true },
  { id: "duplicate", label: "Duplicate", icon: Copy, description: "Mirror another screen/zone" },
  { id: "hdmi", label: "HDMI", icon: MonitorPlay, description: "HDMI device input" },
  { id: "online", label: "Online Link", icon: Link, description: "URL or HTML feed" },
];

export default function SelectSourceDialog({ open, onOpenChange, zone, onApply, allZones = [], currentZoneId, layoutZones = [] }) {
  const [selected, setSelected] = useState(null);
  const [duplicateZoneId, setDuplicateZoneId] = useState("");
  const [onlineUrl, setOnlineUrl] = useState(zone?.media_url || "");

  // Filter to only zones in the current layout
  const zonesToDuplicate = (layoutZones.length > 0 ? layoutZones : allZones).filter((z) => z.id !== currentZoneId);

  const handleApply = () => {
    if (!selected) return;
    if (selected === "content") {
      onApply({ content_type: "multi_content", playlist_id: null, rotation_id: null, sequence_id: null, media_url: null, fit_mode: "fill" });
    } else if (selected === "duplicate") {
      onApply({ content_type: "duplicate", duplicate_zone_id: duplicateZoneId, media_url: null, fit_mode: "fill" });
    } else if (selected === "hdmi") {
      onApply({ content_type: "hdmi_input", media_url: null, fit_mode: "fill" });
    } else if (selected === "online") {
      onApply({ content_type: "html", media_url: onlineUrl, fit_mode: "fill" });
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Select a Source</DialogTitle>
          <p className="text-sm text-slate-500">Choose the source of media content for this zone.</p>
        </DialogHeader>

        {/* Source type tiles */}
        <div className="grid grid-cols-5 gap-2 py-2">
          {SOURCE_TYPES.map((s) => {
            const Icon = s.icon;
            const isSelected = selected === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setSelected(s.id)}
                className={`flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all text-center ${
                  isSelected
                    ? "border-blue-500 bg-blue-50 text-blue-700"
                    : "border-slate-200 hover:border-slate-300 text-slate-600"
                }`}
              >
                <Icon className="w-6 h-6" />
                <span className="text-[11px] font-medium leading-tight whitespace-pre-line">{s.label}</span>
              </button>
            );
          })}
        </div>

        {/* Source-specific config */}
        {selected === "content" && (
          <div className="p-3 rounded-lg bg-blue-50 border border-blue-100">
            <p className="text-xs text-blue-700">
              This zone will display playlists, rotations, and sequences. Assign them in their respective sections.
            </p>
          </div>
        )}

        {selected === "duplicate" && (
          <div className="space-y-2">
            <Label className="text-xs">Select Zone to Duplicate</Label>
            {zonesToDuplicate.length === 0 ? (
              <p className="text-xs text-slate-400 italic">No other zones available.</p>
            ) : (
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {zonesToDuplicate.map((z) => (
                  <button
                    key={z.id}
                    onClick={() => setDuplicateZoneId(z.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border text-sm transition-all ${
                      duplicateZoneId === z.id ? "border-blue-400 bg-blue-50 text-blue-700" : "border-slate-200 hover:bg-slate-50"
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <Copy className="w-3.5 h-3.5" /> {z.name} ({z.width}×{z.height})
                    </span>
                    {duplicateZoneId === z.id && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {selected === "hdmi" && (
          <div className="p-3 rounded-lg bg-amber-50 border border-amber-100">
            <p className="text-xs text-amber-700">HDMI input will capture from the connected device on the media player.</p>
          </div>
        )}

        {selected === "online" && (
          <div className="space-y-2">
            <Label className="text-xs">URL or HTML Feed</Label>
            <Input
              placeholder="https://example.com or HTML content URL"
              value={onlineUrl}
              onChange={(e) => setOnlineUrl(e.target.value)}
              className="text-sm"
            />
          </div>
        )}

        <div className="flex gap-2 pt-1">
          <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button className="flex-1 bg-blue-600 hover:bg-blue-700" onClick={handleApply} disabled={!selected}>
            Apply
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}