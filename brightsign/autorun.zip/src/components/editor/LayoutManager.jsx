import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Layers, Check, Trash2, Play } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function LayoutManager({ truckId, onLoadLayout }) {
  const queryClient = useQueryClient();
  const [showSaveInput, setShowSaveInput] = useState(false);
  const [saveAsName, setSaveAsName] = useState("");

  const { data: layouts = [] } = useQuery({
    queryKey: ["layouts", truckId],
    queryFn: () => base44.entities.Layout.filter({ truck_id: truckId }),
    enabled: !!truckId,
  });

  // CRITICAL FIX: Load zones scoped by truck to avoid cross-truck pollution
  const { data: zones = [] } = useQuery({
    queryKey: ["zones", truckId],
    queryFn: async () => {
      if (!truckId) return [];
      const screens = await base44.entities.Screen.filter({ truck_id: truckId });
      const screenIds = screens.map(s => s.id);
      const allZones = await base44.entities.Zone.list();
      // Return zones for this truck's screens OR layouts belonging to this truck
      const truckLayouts = await base44.entities.Layout.filter({ truck_id: truckId });
      const layoutIds = truckLayouts.map(l => l.id);
      return allZones.filter(z => 
        screenIds.includes(z.screen_id) || layoutIds.includes(z.layout_id)
      );
    },
    enabled: !!truckId,
  });

  const saveLayoutMutation = useMutation({
    mutationFn: async (name) => {
      return base44.entities.Layout.create({
        truck_id: truckId,
        name,
        is_active: false,
      });
    },
    onSuccess: (newLayout) => {
      queryClient.invalidateQueries({ queryKey: ["layouts", truckId] });
      queryClient.invalidateQueries({ queryKey: ["allLayouts"] });
      setShowSaveInput(false);
      setSaveAsName("");
    },
  });

  const pushLayoutMutation = useMutation({
    mutationFn: async (layout) => {
      await Promise.all(layouts.map((l) => base44.entities.Layout.update(l.id, { is_active: false })));
      await base44.entities.Layout.update(layout.id, { is_active: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["layouts", truckId] });
      queryClient.invalidateQueries({ queryKey: ["allLayouts"] });
    },
  });

  const deleteLayoutMutation = useMutation({
    mutationFn: async (layoutId) => {
      // Delete all zones linked to this layout
      const layoutZones = zones.filter((z) => z.layout_id === layoutId);
      await Promise.all(layoutZones.map((z) => base44.entities.Zone.delete(z.id)));
      // Delete the layout
      await base44.entities.Layout.delete(layoutId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["layouts", truckId] });
      queryClient.invalidateQueries({ queryKey: ["allLayouts"] });
      queryClient.invalidateQueries({ queryKey: ["zones", truckId] });
    },
  });

  const activeLayout = layouts.find((l) => l.is_active);

  return (
    <div className="flex items-center gap-2">
      {activeLayout && (
        <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px] gap-1">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
          Live: {activeLayout.name}
        </Badge>
      )}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="h-8 text-xs gap-1" disabled={layouts.length === 0}>
            <Layers className="w-3.5 h-3.5" /> Layouts ({layouts.length}) <ChevronDown className="w-3 h-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {layouts.map((layout) => (
            <div key={layout.id} className="flex items-center group">
              <DropdownMenuItem
                className="flex-1 cursor-pointer gap-2"
                onClick={() => onLoadLayout && onLoadLayout(truckId, layout)}
              >
                {layout.is_active && <Check className="w-3.5 h-3.5 text-green-600" />}
                {!layout.is_active && <div className="w-3.5 h-3.5" />}
                <span className="flex-1 truncate">{layout.name}</span>
                {layout.is_active && <Badge className="text-[9px] bg-green-100 text-green-700">Live</Badge>}
              </DropdownMenuItem>
              <div className="flex gap-0.5 pr-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  className="p-1 rounded hover:bg-green-50 text-green-600"
                  title="Push live"
                  onClick={(e) => { e.stopPropagation(); pushLayoutMutation.mutate(layout); }}
                >
                  <Play className="w-3 h-3" />
                </button>
                <button
                  className="p-1 rounded hover:bg-red-50 text-red-400"
                  title="Delete"
                  onClick={(e) => { e.stopPropagation(); deleteLayoutMutation.mutate(layout.id); }}
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
          {layouts.length === 0 && (
            <DropdownMenuItem disabled>No saved layouts</DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}