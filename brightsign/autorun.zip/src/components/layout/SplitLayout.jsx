/**
 * SplitLayout
 * Reusable two-panel layout: left sidebar + main content.
 * On desktop: side-by-side (flex row).
 * On mobile (<768px): sidebar hidden, toggle button slides it in as overlay.
 *
 * Props:
 *   sidebar      – React node rendered in the left panel
 *   sidebarLabel – Label shown on the mobile toggle button (default: "Menu")
 *   children     – Main content area
 */
import React, { useState } from "react";
import { PanelLeftOpen, X } from "lucide-react";

export default function SplitLayout({ sidebar, sidebarLabel = "Menu", children }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="flex h-full relative">
      {/* Mobile overlay backdrop */}
      {open && (
        <div
          className="fixed inset-0 bg-black/40 z-40 md:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Sidebar panel */}
      <div
        className={`
          fixed md:static inset-y-0 left-0 z-50
          flex flex-col bg-white border-r border-slate-200
          transition-transform duration-300 ease-out
          w-56 flex-shrink-0
          ${open ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
        `}
      >
        {/* Mobile close button inside sidebar */}
        <button
          className="md:hidden absolute top-3 right-3 p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          onClick={() => setOpen(false)}
        >
          <X className="w-4 h-4" />
        </button>
        {sidebar}
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile toggle button — shows in the top-left of the content area */}
        <div className="md:hidden flex items-center px-3 py-2 border-b border-slate-100 bg-white">
          <button
            onClick={() => setOpen(true)}
            className="flex items-center gap-2 px-2 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors text-sm font-medium"
          >
            <PanelLeftOpen className="w-4 h-4" />
            {sidebarLabel}
          </button>
        </div>
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </div>
    </div>
  );
}