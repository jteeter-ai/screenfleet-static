/**
 * LiveOutputDashboard — canonical Live Output component.
 * Data source: getLiveOutputDashboard server function (auth + service role).
 * V2 ONLY — No Zone entity, no Truck, no Layout, no liveOutputData, no getScreenPayload.
 */

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useOrg } from "@/components/OrgContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, ExternalLink, CheckCircle2, Layers, RefreshCw, ImageOff, AlertTriangle, ChevronDown, ChevronRight, Bug } from "lucide-react";
import { toast } from "sonner";

function ScreenCard({ screen, playerOrigin }) {
  const [copied, setCopied] = useState(false);
  const playerUrl = (playerOrigin && screen.public_token) ? `${playerOrigin}/screen/${screen.public_token}` : null;
  const previewUrl = (playerOrigin && screen.public_token) ? `${playerOrigin}/screen/${screen.public_token}` : null;

  const firstMedia = (() => {
    const sorted = [...(screen.runtime_zones || [])].sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1));
    for (const zone of sorted) {
      const item = zone.playback_track?.items?.[0];
      if (item?.file_url) return item;
      if (item?.content_type === 'canvas_creative') return { ...item, is_canvas: true };
    }
    return null;
  })();

  const aspectW = screen.width || 1920;
  const aspectH = screen.height || 1080;

  const handleCopy = () => {
    if (!playerUrl) { toast.error("Player app not configured. Set player_app_origin in AppConfig."); return; }
    navigator.clipboard.writeText(playerUrl);
    setCopied(true);
    toast.success("Player URL copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
      <div className="relative bg-black" style={{ aspectRatio: `${aspectW} / ${aspectH}` }}>
        {firstMedia?.file_type === "image" && (
          <img src={firstMedia.file_url} alt="" className="absolute inset-0 w-full h-full object-cover" />
        )}
        {firstMedia?.file_type === "video" && (
          <video src={firstMedia.file_url} autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover" />
        )}
        {firstMedia?.is_canvas && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-800">
            <div className="text-center text-white/60">
              <div className="text-xs font-medium">Studio Creative</div>
              <div className="text-[10px] text-white/40 mt-1">{firstMedia.canvas_creative_id?.substring(0, 8)}…</div>
            </div>
          </div>
        )}
        {!firstMedia && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white/30">
              <ImageOff className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <div className="text-xs">No content</div>
            </div>
          </div>
        )}
        <div className="absolute top-2 left-2">
          <Badge className="bg-green-500/90 text-white border-0 text-[10px]">Published</Badge>
        </div>
      </div>

      <div className="p-3">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <div className="text-sm font-semibold text-slate-800">{screen.screen_name}</div>
            <div className="text-[11px] text-slate-400">{screen.width}×{screen.height}px{screen.position ? ` · ${screen.position}` : ""}</div>
          </div>
          {screen.published_at && (
            <div className="text-[10px] text-slate-400 text-right shrink-0">
              {new Date(screen.published_at).toLocaleDateString()}
            </div>
          )}
        </div>
        <div className="flex gap-1.5">
          <button
            onClick={handleCopy}
            className="flex-1 flex items-center justify-center gap-1 h-7 rounded-md border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs text-slate-600 transition-colors"
          >
            {copied ? <CheckCircle2 className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
            {copied ? "Copied!" : "Copy URL"}
          </button>
          {previewUrl ? (
            <a
              href={previewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1 h-7 px-3 rounded-md border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs text-slate-600 transition-colors"
            >
              <ExternalLink className="w-3 h-3" />
              Preview
            </a>
          ) : (
            <span className="flex items-center justify-center h-7 px-3 rounded-md border border-dashed border-slate-200 text-[10px] text-slate-400">
              Player app not configured
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

function AssetGroup({ group, playerOrigin }) {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-2 mb-3">
        <Layers className="w-4 h-4 text-slate-400" />
        <h2 className="text-sm font-semibold text-slate-700">{group.asset_name}</h2>
        {group.asset_type && <Badge variant="outline" className="text-[10px] text-slate-400">{group.asset_type}</Badge>}
        <span className="text-xs text-slate-400">{group.screens.length} screen{group.screens.length !== 1 ? "s" : ""}</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {group.screens.map(screen => (
          <ScreenCard key={screen.published_screen_id} screen={screen} playerOrigin={playerOrigin} />
        ))}
      </div>
    </div>
  );
}

function DebugPanel({ activeOrgId, data, isError, errorMessage, isPlatformAdmin, querySuppressed }) {
  const [open, setOpen] = useState(false);
  const params = new URLSearchParams(window.location.search);
  const debugMode = params.get('debug') === '1';
  if (!debugMode) return null;
  return (
    <div className="mb-4 border border-amber-200 rounded-lg bg-amber-50 text-xs font-mono">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-2 px-3 py-2 text-amber-700 hover:bg-amber-100 rounded-lg"
      >
        <Bug className="w-3.5 h-3.5" />
        <span className="font-semibold">Debug Panel</span>
        {open ? <ChevronDown className="w-3 h-3 ml-auto" /> : <ChevronRight className="w-3 h-3 ml-auto" />}
      </button>
      {open && (
        <div className="px-3 pb-3 space-y-1 text-amber-800">
          <div><span className="font-semibold">activeOrgId:</span> {activeOrgId || 'NONE'}</div>
          <div><span className="font-semibold">isPlatformAdmin:</span> {String(isPlatformAdmin)}</div>
          <div><span className="font-semibold">isRealOrgSelected:</span> {String(!!activeOrgId && activeOrgId !== 'PLATFORM_ADMIN')}</div>
          <div><span className="font-semibold">querySuppressed:</span> {String(querySuppressed)}{querySuppressed ? ' — reason: PLATFORM_ADMIN is not a real tenant org' : ''}</div>
          <div><span className="font-semibold">isError:</span> {String(isError)}</div>
          <div><span className="font-semibold">serverError:</span> {errorMessage || 'none'}</div>
          <div><span className="font-semibold">published_count:</span> {data?.published_count ?? 'N/A'}</div>
          <div><span className="font-semibold">asset_count:</span> {data?.assets?.length ?? 'N/A'}</div>
          {data?.warnings?.length > 0 && (
            <div><span className="font-semibold">warnings:</span> {data.warnings.join(' | ')}</div>
          )}
          {data?.debug && (
            <div className="space-y-0.5">
              <div><span className="font-semibold">published_screen_ids:</span> {(data.debug.published_screen_ids || []).join(', ') || 'none'}</div>
              <div><span className="font-semibold">screen_ids:</span> {(data.debug.screen_ids || []).join(', ') || 'none'}</div>
              <div><span className="font-semibold">asset_ids:</span> {(data.debug.asset_ids || []).join(', ') || 'none'}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function LiveOutputDashboard() {
  const { activeOrgId, isPlatformAdmin } = useOrg();
  const isPlatformAdminSentinel = activeOrgId === 'PLATFORM_ADMIN';
  const querySuppressed = !activeOrgId || isPlatformAdminSentinel;

  const { data: appConfig } = useQuery({
    queryKey: ["app_config"],
    queryFn: async () => {
      const result = await base44.functions.invoke('getAppConfig', {});
      return result?.data?.config || result?.data || null;
    },
  });
  const playerOrigin = appConfig?.player_app_origin?.replace(/\/$/, '') || null;

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["liveOutputDashboard", activeOrgId],
    queryFn: async () => {
      if (querySuppressed) return null;
      const res = await base44.functions.invoke("getLiveOutputDashboard", { org_id: activeOrgId });
      const payload = res.data;
      if (payload?.error) throw new Error(payload.error);
      console.log("[LIVE OUTPUT DASHBOARD RESULT]", {
        activeOrgId,
        isError: false,
        errorMessage: null,
        published_count: payload?.published_count,
        asset_count: payload?.assets?.length || 0,
        warnings: payload?.warnings || [],
        debug: payload?.debug || null,
      });
      return payload;
    },
    enabled: !querySuppressed,
    refetchInterval: 30000,
    retry: 1,
  });

  const serverErrorMessage = isError ? (error?.message || 'Unknown server error') : null;

  console.log("[LIVE OUTPUT DASHBOARD RESULT]", {
    activeOrgId,
    isPlatformAdminSentinel,
    querySuppressed,
    isError,
    errorMessage: serverErrorMessage,
    published_count: data?.published_count,
    asset_count: data?.assets?.length || 0,
  });

  const assets = data?.assets || [];
  const warnings = data?.warnings || [];
  const confirmedEmpty = !isError && data && data.published_count === 0;
  const degraded = !isError && data && data.published_count > 0 && assets.length === 0;

  const handleBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = '/';
    }
  };

  return (
    <div className="p-6 max-w-screen-2xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Live Output</h1>
          <p className="text-sm text-slate-500 mt-0.5">Live published screens for this organization</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" className="gap-1.5 text-slate-500" onClick={handleBack}>
            ← Back
          </Button>
          <a href="/LiveOutput" className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md border border-input bg-background text-sm font-medium shadow-sm hover:bg-accent hover:text-accent-foreground transition-colors">
            <ExternalLink className="w-3.5 h-3.5" /> Open Full Page
          </a>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => refetch()}>
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </Button>
        </div>
      </div>

      <DebugPanel
        activeOrgId={activeOrgId}
        data={data}
        isError={isError}
        errorMessage={serverErrorMessage}
        isPlatformAdmin={isPlatformAdmin}
        querySuppressed={querySuppressed}
      />

      {querySuppressed ? (
        <div className="text-center py-20 text-slate-400">
          <Layers className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm font-semibold text-slate-600">Select an organization</p>
          <p className="text-xs mt-1">Live Output is organization-scoped. Choose a sub-account organization to view published screens.</p>
        </div>
      ) : null}

      {!querySuppressed && warnings.length > 0 && (
        <div className="mb-4 p-3 rounded-lg border border-yellow-200 bg-yellow-50 space-y-1">
          {warnings.map((w, i) => (
            <div key={i} className="flex items-start gap-2 text-xs text-yellow-800">
              <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0 text-yellow-500" />
              {w}
            </div>
          ))}
        </div>
      )}

      {!querySuppressed && (isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-6 h-6 border-2 border-slate-200 border-t-slate-600 rounded-full animate-spin" />
        </div>
      ) : isError ? (
        <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-center">
          <AlertTriangle className="w-8 h-8 mx-auto mb-3 text-red-400" />
          <p className="text-sm font-semibold text-red-700 mb-1">Failed to load live output data</p>
          <p className="text-xs text-red-600 mb-1 font-mono">{serverErrorMessage}</p>
          <p className="text-[11px] text-red-400 mb-3">org_id: {activeOrgId || 'NONE'}</p>
          <Button size="sm" variant="outline" onClick={() => refetch()} className="gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" /> Retry
          </Button>
        </div>
      ) : confirmedEmpty ? (
        <div className="text-center py-20 text-slate-400">
          <Layers className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No published screens for this organization.</p>
          <p className="text-xs mt-1">Go to Scheduling and publish an asset to see screens here.</p>
        </div>
      ) : degraded ? (
        <div className="rounded-xl border border-yellow-200 bg-yellow-50 p-6 text-center">
          <AlertTriangle className="w-8 h-8 mx-auto mb-3 text-yellow-500" />
          <p className="text-sm font-semibold text-yellow-700 mb-1">Published screens found but could not be displayed</p>
          <p className="text-xs text-yellow-600 mb-3">
            published_count={data.published_count} but no renderable asset groups returned. Check warnings above or run <code className="bg-yellow-100 px-1 rounded">diagnoseLiveOutputPipeline</code>.
          </p>
          <Button size="sm" variant="outline" onClick={() => refetch()} className="gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" /> Retry
          </Button>
        </div>
      ) : (
        assets.map(group => <AssetGroup key={group.asset_id} group={group} playerOrigin={playerOrigin} />)
      ))}
    </div>
  );
}