import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Trash2, Loader2 } from "lucide-react";

export default function BulkDeleteDialog({ open, onOpenChange, selectedAssets, usageMap, onConfirm, isDeleting }) {
  const inUseAssets = selectedAssets.filter(a => usageMap[a.id]?.total > 0);
  const safeAssets = selectedAssets.filter(a => !usageMap[a.id]?.total);
  const hasInUse = inUseAssets.length > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <Trash2 className="w-5 h-5" />
            Delete {selectedAssets.length} file{selectedAssets.length !== 1 ? "s" : ""}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {hasInUse && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-amber-800">
                    {inUseAssets.length} file{inUseAssets.length !== 1 ? "s are" : " is"} currently in use
                  </p>
                  <p className="text-xs text-amber-700 mt-1">
                    These files are referenced by active playlists or presentations. Deleting them may remove media from playback.
                  </p>
                </div>
              </div>
              <div className="mt-2 space-y-1 max-h-40 overflow-y-auto">
                {inUseAssets.map(a => {
                  const usage = usageMap[a.id] || {};
                  return (
                    <div key={a.id} className="flex items-center justify-between text-xs bg-white rounded px-2 py-1.5 border border-amber-100">
                      <span className="truncate text-slate-700 max-w-[200px]">{a.name}</span>
                      <div className="flex gap-2 text-slate-500 flex-shrink-0 ml-2">
                        {usage.playlists > 0 && <span>{usage.playlists} playlist{usage.playlists !== 1 ? "s" : ""}</span>}
                        {usage.presentations > 0 && <span>{usage.presentations} presentation{usage.presentations !== 1 ? "s" : ""}</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {safeAssets.length > 0 && (
            <div>
              <p className="text-sm text-slate-500">
                {safeAssets.length} unused file{safeAssets.length !== 1 ? "s" : ""} will be permanently deleted.
              </p>
            </div>
          )}

          <p className="text-xs text-slate-400">This action cannot be undone.</p>
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} disabled={isDeleting}>
            Cancel
          </Button>
          <Button
            size="sm"
            className="bg-red-600 hover:bg-red-700 text-white"
            onClick={onConfirm}
            disabled={isDeleting}
          >
            {isDeleting ? (
              <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> Deleting…</>
            ) : (
              <><Trash2 className="w-3.5 h-3.5 mr-1.5" /> Delete {selectedAssets.length} file{selectedAssets.length !== 1 ? "s" : ""}</>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}