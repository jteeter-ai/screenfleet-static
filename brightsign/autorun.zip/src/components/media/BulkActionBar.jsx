import React from "react";
import { Button } from "@/components/ui/button";
import { FolderOpen, Trash2, X, CheckSquare } from "lucide-react";

export default function BulkActionBar({ selectedCount, totalCount, onSelectAll, onClearSelection, onMoveToFolder, onDelete }) {
  return (
    <div className="sticky top-0 z-20 flex items-center gap-3 px-5 py-2.5 bg-blue-600 text-white shadow-lg">
      <div className="flex items-center gap-2 flex-1">
        <CheckSquare className="w-4 h-4 opacity-80" />
        <span className="text-sm font-medium">{selectedCount} selected</span>
        {selectedCount < totalCount && (
          <button
            onClick={onSelectAll}
            className="text-xs text-blue-200 hover:text-white underline ml-1 transition-colors"
          >
            Select all {totalCount}
          </button>
        )}
      </div>
      <div className="flex items-center gap-2">
        <Button
          size="sm"
          variant="secondary"
          className="h-7 text-xs bg-white/20 hover:bg-white/30 text-white border-0"
          onClick={onMoveToFolder}
        >
          <FolderOpen className="w-3.5 h-3.5 mr-1.5" />
          Move to Folder
        </Button>
        <Button
          size="sm"
          variant="secondary"
          className="h-7 text-xs bg-white/20 hover:bg-red-500/80 text-white border-0"
          onClick={onDelete}
        >
          <Trash2 className="w-3.5 h-3.5 mr-1.5" />
          Delete
        </Button>
        <button
          onClick={onClearSelection}
          className="p-1.5 rounded hover:bg-white/20 transition-colors"
          title="Clear selection"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}