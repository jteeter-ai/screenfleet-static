import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Upload, Film, ImageIcon, Clock, ChevronDown, ChevronUp, X, Zap, Cpu, Loader2, Library, Search, Link2, Lock, LockOpen, Volume2, VolumeX } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useOrg } from "@/components/OrgContext";

export default function PlaylistItemCard({
  item,
  layoutZones = [],
  defaultDuration,
  onUpdateItem,
  onDeleteItem,
  onMoveItem,
  isFirst = false,
  isLast = false,
}) {
  const { activeOrgId } = useOrg();
  const [expanded, setExpanded] = useState(true);
  const [studioPickerOpen, setStudioPickerOpen] = useState(false);
  const [studioPickerZoneId, setStudioPickerZoneId] = useState(null);
  const [studioCreatives, setStudioCreatives] = useState([]);
  const [uploadingZoneId, setUploadingZoneId] = useState(null); // tracks which zone is uploading
  const [uploadError, setUploadError] = useState(null); // { zoneId, message }
  // Library picker state
  const [libraryPickerOpen, setLibraryPickerOpen] = useState(false);
  const [libraryPickerZoneId, setLibraryPickerZoneId] = useState(null);
  const [libraryAssets, setLibraryAssets] = useState([]);
  const [librarySearch, setLibrarySearch] = useState("");
  const [librarySelected, setLibrarySelected] = useState(null);
  const [libraryLoading, setLibraryLoading] = useState(false);
  const effectiveDuration = (item.duration === 0 || item.duration == null) ? defaultDuration : item.duration;
  const zoneAssignments = item.zone_assignments || {};

  // True if ANY zone in this item has a studio creative assigned
  const hasStudioCreative = Object.values(zoneAssignments).some(
    za => za?.content_type === 'canvas_creative'
  );

  // Debug: log zones to confirm is_duplicate_of is present
  console.log("[PlaylistItemCard] ZONE DATA:", layoutZones.map(z => ({ id: z.id, name: z.name, is_duplicate_of: z.is_duplicate_of ?? null })));

  // HDMI zones and derived (is_duplicate_of) zones are auto-satisfied — no media needed.
  // Only primary content zones count toward assignment completeness.
  const contentZones = layoutZones.filter(z => z.default_source_type !== 'hdmi' && !z.is_duplicate_of);
  const hdmiZones    = layoutZones.filter(z => z.default_source_type === 'hdmi');
  const derivedZones = layoutZones.filter(z => !!z.is_duplicate_of);
  const assignedContentCount = contentZones.filter(z => !!zoneAssignments[z.id]).length;
  // Fulfilled = assigned primary zones + HDMI zones + derived zones (all auto-satisfied)
  const fulfilledCount = assignedContentCount + hdmiZones.length + derivedZones.length;

  // Load studio creatives on mount
  useEffect(() => {
    if (activeOrgId) {
      base44.entities.CanvasCreative.filter({ org_id: activeOrgId })
        .then(setStudioCreatives)
        .catch(() => setStudioCreatives([]));
    }
  }, [activeOrgId]);

  const openLibraryPicker = (zoneId) => {
    setLibraryPickerZoneId(zoneId);
    setLibrarySelected(null);
    setLibrarySearch("");
    setLibraryAssets([]);
    setLibraryLoading(true);
    setLibraryPickerOpen(true);
  };

  // Fetch media once the dialog is actually open (deferred to next tick after state flush)
  useEffect(() => {
    if (!libraryPickerOpen) return;
    if (!activeOrgId) {
      console.warn("[Library] activeOrgId is not set");
      setLibraryLoading(false);
      return;
    }
    let cancelled = false;
    base44.entities.MediaAsset.filter({ org_id: activeOrgId }, '-created_date', 100).then(assets => {
      if (cancelled) return;
      const filtered = (assets || []).filter(a => a.file_type === "image" || a.file_type === "video");
      console.log("[Library] Media loaded:", filtered.length, "items. Sample:", filtered[0]);
      setLibraryAssets(filtered);
      setLibraryLoading(false);
    }).catch(err => {
      if (cancelled) return;
      console.error("[Library] Failed to load media:", err);
      toast.error("Could not load media library: " + err.message);
      setLibraryAssets([]);
      setLibraryLoading(false);
    });
    return () => { cancelled = true; };
  }, [libraryPickerOpen, activeOrgId]);

  const handleApplyLibraryAsset = async () => {
     if (!librarySelected || !libraryPickerZoneId) return;
     const latestItems = await base44.entities.PlaylistItem.filter({ playlist_id: item.playlist_id });
     const latest = latestItems.find(i => i.id === item.id);
     const merged = {
       ...(latest?.zone_assignments || {}),
       [libraryPickerZoneId]: {
         media_asset_id: librarySelected.id,
         file_url: librarySelected.file_url,
         file_type: librarySelected.file_type,
       },
     };

     const updateData = { zone_assignments: merged };
     if (librarySelected.file_type === 'video' && !item.detected_video_duration && !item.manual_duration_override) {
       const detectedDuration = await getVideoDuration(librarySelected.file_url);
       if (detectedDuration) {
         updateData.duration = detectedDuration;
         updateData.detected_video_duration = detectedDuration;
       }
     }

     onUpdateItem(item.id, updateData);
     setLibraryPickerOpen(false);
     setLibraryPickerZoneId(null);
     setLibrarySelected(null);
     toast.success("Media assigned from library");
   };

  const handleRemoveZoneMedia = async (zoneId) => {
    const latestItems = await base44.entities.PlaylistItem.filter({ playlist_id: item.playlist_id });
    const latest = latestItems.find(i => i.id === item.id);
    const merged = { ...(latest?.zone_assignments || {}) };
    delete merged[zoneId];
    onUpdateItem(item.id, { zone_assignments: merged });
    const remainingHasStudio = Object.values(merged).some(za => za?.content_type === 'canvas_creative');
    if (!remainingHasStudio) {
      onUpdateItem(item.id, { duration: defaultDuration });
    }
  };

  const handleSelectStudioCreative = (zoneId) => {
    setStudioPickerZoneId(zoneId);
    setStudioPickerOpen(true);
  };

  const handleApplyStudioCreative = async (creative) => {
    if (!studioPickerZoneId || !creative) return;
    const latestItems = await base44.entities.PlaylistItem.filter({ playlist_id: item.playlist_id });
    const latest = latestItems.find(i => i.id === item.id);
    const merged = {
      ...(latest?.zone_assignments || {}),
      [studioPickerZoneId]: { content_type: 'canvas_creative', canvas_creative_id: creative.id },
    };
    onUpdateItem(item.id, { zone_assignments: merged, duration: 0 });
    setStudioPickerOpen(false);
    setStudioPickerZoneId(null);
    toast.success('Studio creative assigned');
  };

  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB hard limit
  const WARN_FILE_SIZE = 2 * 1024 * 1024;  // 2MB soft warning

  // Hook for future compression — currently a passthrough
  const processImage = async (file) => file;

  const getVideoDuration = (source) => {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        if (source instanceof File) URL.revokeObjectURL(video.src);
        resolve(Math.round(video.duration));
      };
      video.onerror = () => resolve(null);
      if (source instanceof File) {
        video.src = URL.createObjectURL(source);
      } else {
        video.src = source;
      }
    });
  };

  const handleFileUpload = async (e, zoneId) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > MAX_FILE_SIZE) {
      toast.error("File too large. Maximum 50MB allowed.");
      return;
    }
    if (file.type.startsWith("image/") && file.size > WARN_FILE_SIZE) {
      toast.warning("Large image file detected. Recommended: under 2MB for best performance.");
    }

    const processedFile = await processImage(file);
    setUploadingZoneId(zoneId);
    setUploadError(null);

    try {
      // Compute checksum client-side before upload (browser has SubtleCrypto)
      const arrayBuffer = await processedFile.arrayBuffer();
      const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
      const checksum = Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0')).join('');

      // Upload the file to CDN
      const { file_url } = await base44.integrations.Core.UploadFile({ file: processedFile });
      const fileType = processedFile.type.startsWith("video") ? "video" : "image";

      // Check for duplicate using the pre-computed checksum (server only does DB lookup now)
      const checksumResult = await base44.functions.invoke("computeMediaAssetChecksum", { checksum });
      const { existingAssetId } = checksumResult.data;

      let mediaAssetId;
      if (existingAssetId) {
        mediaAssetId = existingAssetId;
        toast.info("Using existing media asset (duplicate)");
      } else {
        const asset = await base44.entities.MediaAsset.create({
          org_id: activeOrgId,
          name: file.name,
          file_url,
          file_type: fileType,
          checksum,
        });
        mediaAssetId = asset.id;
      }

      const latestItems = await base44.entities.PlaylistItem.filter({ playlist_id: item.playlist_id });
      const latest = latestItems.find(i => i.id === item.id);
      const merged = {
        ...(latest?.zone_assignments || {}),
        [zoneId]: { media_asset_id: mediaAssetId, file_url, file_type: fileType },
      };

      const updateData = { zone_assignments: merged };
      if (fileType === 'video') {
        const detectedDuration = await getVideoDuration(processedFile);
        if (detectedDuration && !item.manual_duration_override) {
          updateData.duration = detectedDuration;
          updateData.detected_video_duration = detectedDuration;
        }
      }

      onUpdateItem(item.id, updateData);
    } catch (err) {
      toast.error(`Upload failed: ${err.message}`);
      setUploadError({ zoneId, message: "Upload failed. Try again." });
    } finally {
      setUploadingZoneId(null);
    }
  };

  return (
    <Card className="border border-slate-200 shadow-sm">
      <CardHeader className="pb-2 pt-3 px-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <span className="text-sm font-bold text-slate-500 w-6">#{item.order}</span>
            <Badge
              variant="outline"
              className={`text-xs ${
                layoutZones.length === 0 ? 'text-slate-400'
                : fulfilledCount >= layoutZones.length ? 'text-green-600 border-green-300 bg-green-50'
                : 'text-slate-600'
              }`}
            >
              {fulfilledCount}/{layoutZones.length} zones
            </Badge>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center gap-0.5">
              <button
                onClick={(e) => { e.stopPropagation(); onMoveItem?.(-1); }}
                disabled={isFirst}
                title="Move up"
                className="w-6 h-6 flex items-center justify-center rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 disabled:opacity-25 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onMoveItem?.(1); }}
                disabled={isLast}
                title="Move down"
                className="w-6 h-6 flex items-center justify-center rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 disabled:opacity-25 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex items-center gap-1 text-xs text-slate-500">
               <Clock className="w-3 h-3" />
               {hasStudioCreative ? (
                 <span
                   className="h-6 px-2 flex items-center rounded bg-blue-50 text-blue-600 font-medium border border-blue-200 text-xs cursor-default"
                   title="Duration is controlled by the Studio creative"
                 >
                   Studio
                 </span>
               ) : (
                 <>
                   <Input
                     type="number"
                     min="1"
                     value={effectiveDuration}
                     onChange={(e) => onUpdateItem(item.id, { duration: Number(e.target.value), manual_duration_override: true })}
                     className="h-6 w-14 text-xs px-1.5 text-center"
                   />
                   <span>s</span>
                   {(() => {
                     const hasVideoZone = Object.values(zoneAssignments).some(za => za?.file_type === 'video');
                     if (!hasVideoZone) return null;
                     const isManualOverride = item.manual_duration_override;
                     return (
                       <button
                         onClick={() => {
                           const newOverride = !isManualOverride;
                           if (!newOverride && item.detected_video_duration) {
                             onUpdateItem(item.id, { manual_duration_override: newOverride, duration: item.detected_video_duration });
                           } else {
                             onUpdateItem(item.id, { manual_duration_override: newOverride });
                           }
                         }}
                         className="ml-0.5 h-4 w-4 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors"
                         title={isManualOverride ? "Click to use auto-detected duration" : "Click to set manual duration"}
                       >
                         {isManualOverride ? <Lock className="w-3 h-3" /> : <LockOpen className="w-3 h-3" />}
                       </button>
                     );
                   })()}
                   {!item.manual_duration_override && item.detected_video_duration && (
                     <span className="text-[10px] text-slate-400 ml-1">auto</span>
                   )}
                 </>
               )}
             </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-red-400 hover:text-red-600"
              onClick={() => onDeleteItem(item.id)}
              title="Remove item"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setExpanded(!expanded)}>
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </Button>
          </div>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="px-4 pb-4 pt-0 space-y-3">
          <div>
            <Label className="text-xs text-slate-500 mb-2 block">Assign Media to Zones</Label>
            <div className="space-y-2">
              {layoutZones.length === 0 && (
                <p className="text-xs text-slate-400 italic">No zones in this layout template.</p>
              )}
              {layoutZones.map((zone) => {
                const assignment = zoneAssignments[zone.id];
                const isHdmi = zone.default_source_type === 'hdmi';
                const isDerived = !!zone.is_duplicate_of;
                const sourceZone = isDerived ? layoutZones.find(z => z.id === zone.is_duplicate_of) : null;

                // Derived zone: inherits content from source zone — no media assignment allowed
                if (isDerived) {
                  return (
                    <div key={zone.id} className="flex items-center gap-2 p-2 border border-slate-200 rounded-lg bg-slate-50/60">
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-slate-500 italic">{zone.name}</div>
                        <div className="text-[10px] text-slate-400">{zone.width}×{zone.height}px</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="flex items-center gap-1 px-2 py-1 rounded bg-slate-100 border border-slate-200 text-xs text-slate-500 font-medium">
                          <Link2 className="w-3 h-3" />
                          Inherits from {sourceZone ? sourceZone.name : "source zone"}
                        </span>
                      </div>
                    </div>
                  );
                }

                const isUploadingThis = uploadingZoneId === zone.id;
                return (
                  <div key={zone.id} className={`flex items-center gap-2 p-2 border border-slate-200 rounded-lg bg-slate-50 ${isUploadingThis ? "opacity-60 pointer-events-none" : ""}`}>
                    <div className="flex-1">
                      <div className="text-xs font-medium text-slate-700">{zone.name}</div>
                      <div className="text-[10px] text-slate-400">{zone.width}×{zone.height}px</div>
                      {uploadError?.zoneId === zone.id && (
                        <div className="text-[10px] text-red-500 mt-0.5">{uploadError.message}</div>
                      )}
                    </div>

                    {isUploadingThis ? (
                      <div className="flex items-center gap-1.5 px-2 py-1 border border-blue-200 rounded bg-blue-50 text-xs text-blue-600">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        <span>Uploading…</span>
                      </div>
                    ) : (
                    <label className="flex items-center gap-1 px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer hover:bg-slate-50 transition-colors">
                      {assignment?.content_type === 'canvas_creative' ? (
                        <>
                          <Zap className="w-3 h-3 flex-shrink-0 text-blue-500" />
                          <span className="truncate max-w-[80px]" title="Studio Creative">Studio Creative</span>
                          <button
                            type="button"
                            onClick={(e) => { e.preventDefault(); handleRemoveZoneMedia(zone.id); }}
                            className="ml-auto -mr-1 hover:bg-red-100 rounded p-0.5"
                          >
                            <X className="w-2.5 h-2.5 text-red-500" />
                          </button>
                        </>
                      ) : assignment?.file_url ? (
                        <>
                          {assignment.file_type === 'video' ? (
                            <Film className="w-3 h-3 flex-shrink-0" />
                          ) : (
                            <ImageIcon className="w-3 h-3 flex-shrink-0" />
                          )}
                          <span className="truncate max-w-[80px]" title={assignment.file_url?.split('/').pop()}>
                            {assignment.file_url?.split('/').pop()?.split('_').slice(1).join('_') || assignment.file_url?.split('/').pop()}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => { e.preventDefault(); handleRemoveZoneMedia(zone.id); }}
                            className="ml-auto -mr-1 hover:bg-red-100 rounded p-0.5"
                          >
                            <X className="w-2.5 h-2.5 text-red-500" />
                          </button>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3 h-3 flex-shrink-0" />
                              <span>Upload</span>
                              <span className="text-[9px] text-slate-400 ml-1 hidden group-hover:inline">≤2MB</span>
                        </>
                      )}
                      {!assignment && (
                        <input
                          type="file"
                          accept="image/*,video/*"
                          className="hidden"
                          onChange={(e) => handleFileUpload(e, zone.id)}
                          disabled={!!uploadingZoneId}
                        />
                      )}
                    </label>
                    )}

                    {assignment?.file_url && assignment.file_type === 'video' && (
                      <div className="flex items-center gap-2 px-2 py-1.5 border border-slate-200 rounded bg-slate-50 text-xs">
                        <button
                          type="button"
                          onClick={() => {
                            const latestItems = base44.entities.PlaylistItem.filter({ playlist_id: item.playlist_id }).then(items => {
                              const latest = items.find(i => i.id === item.id);
                              const merged = { ...(latest?.zone_assignments || {}), [zone.id]: { ...assignment, muted: !assignment.muted } };
                              onUpdateItem(item.id, { zone_assignments: merged });
                            });
                          }}
                          className="flex items-center justify-center w-5 h-5 text-slate-500 hover:text-slate-700 transition-colors flex-shrink-0"
                          title={assignment.muted ? "Unmute" : "Mute"}
                        >
                          {assignment.muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                        </button>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          step="1"
                          value={assignment.volume ?? 100}
                          onChange={(e) => {
                            const newVolume = Number(e.target.value);
                            base44.entities.PlaylistItem.filter({ playlist_id: item.playlist_id }).then(items => {
                              const latest = items.find(i => i.id === item.id);
                              const merged = { ...(latest?.zone_assignments || {}), [zone.id]: { ...assignment, volume: newVolume, muted: newVolume === 0 } };
                              onUpdateItem(item.id, { zone_assignments: merged });
                            });
                          }}
                          className="flex-1 h-1 accent-slate-600 cursor-pointer"
                          disabled={!!uploadingZoneId}
                        />
                        <span className="text-[10px] text-slate-500 font-medium w-10 text-right">
                          {assignment.muted ? "Muted" : `${assignment.volume ?? 100}%`}
                        </span>
                      </div>
                    )}

                    {!assignment && !isUploadingThis && (
                      <>
                        <button
                          onClick={() => handleSelectStudioCreative(zone.id)}
                          className="flex items-center gap-1 px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer hover:bg-blue-50 transition-colors text-blue-600"
                        >
                          <Zap className="w-3 h-3" />
                          <span>Studio</span>
                        </button>
                        <button
                          onClick={() => openLibraryPicker(zone.id)}
                          className="flex items-center gap-1 px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer hover:bg-green-50 transition-colors text-green-700"
                        >
                          <Library className="w-3 h-3" />
                          <span>Library</span>
                        </button>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <Label className="text-xs text-slate-500 mb-2 block">Transition</Label>
            <Select
              value={item.transition || "fade"}
              onValueChange={(v) => onUpdateItem(item.id, { transition: v })}
            >
              <SelectTrigger className="h-7 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="fade">Fade</SelectItem>
                <SelectItem value="slide_left">Slide Left</SelectItem>
                <SelectItem value="slide_right">Slide Right</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      )}

      <Dialog open={libraryPickerOpen} onOpenChange={setLibraryPickerOpen}>
          <DialogContent className="max-w-2xl" aria-describedby={undefined}>
            <DialogHeader><DialogTitle>Select from Media Library</DialogTitle></DialogHeader>

            {/* DEBUG: log every render of this modal */}
            {(() => {
              const renderedItems = libraryAssets.filter(a => !librarySearch || a.name?.toLowerCase().includes(librarySearch.toLowerCase()));
              console.log("[LibraryModal] Rendering — open:", libraryPickerOpen, "loading:", libraryLoading, "libraryAssets:", libraryAssets.length, "renderedItems:", renderedItems.length, "sample:", libraryAssets[0]);
              return null;
            })()}

            <div style={{marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8}}>
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search by name…"
                value={librarySearch}
                onChange={e => setLibrarySearch(e.target.value)}
                style={{flex: 1, fontSize: 13, border: '1px solid #e2e8f0', borderRadius: 4, padding: '4px 8px', outline: 'none'}}
              />
            </div>

            {libraryLoading && (
              <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '48px 0', color: '#94a3b8'}}>
                <Loader2 className="w-5 h-5 animate-spin" style={{marginRight: 8}} />
                <span>Loading media…</span>
              </div>
            )}

            {!libraryLoading && libraryAssets.length === 0 && (
              <div style={{textAlign: 'center', padding: '48px 0', color: '#94a3b8', fontSize: 14}}>
                No media found. Upload files in the Media Library first.
              </div>
            )}

            {!libraryLoading && libraryAssets.length > 0 && (() => {
              const renderedItems = libraryAssets.filter(a => !librarySearch || a.name?.toLowerCase().includes(librarySearch.toLowerCase()));
              return (
                <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fill, 200px)', gap: 12, maxHeight: 420, overflowY: 'auto', paddingRight: 4, justifyContent: 'flex-start'}}>
                  {renderedItems.length === 0 && (
                    <div style={{gridColumn: '1 / -1', textAlign: 'center', padding: '24px 0', color: '#94a3b8', fontSize: 13}}>No results for "{librarySearch}"</div>
                  )}
                  {renderedItems.map(asset => (
                    <button
                      key={asset.id}
                      type="button"
                      onClick={() => { setLibrarySelected(asset); }}
                      style={{
                        width: 200,
                        height: 166,
                        flexShrink: 0,
                        border: librarySelected?.id === asset.id ? '2px solid #4CAF50' : '2px solid #e2e8f0',
                        borderRadius: 8,
                        overflow: 'hidden',
                        background: 'white',
                        cursor: 'pointer',
                        textAlign: 'left',
                        padding: 0,
                        position: 'relative',
                        display: 'flex',
                        flexDirection: 'column',
                        boxShadow: librarySelected?.id === asset.id ? '0 0 0 3px rgba(76,175,80,0.2)' : 'none',
                        transition: 'border-color 0.15s ease, box-shadow 0.15s ease',
                      }}
                      onMouseEnter={e => { if (librarySelected?.id !== asset.id) e.currentTarget.style.borderColor = '#94a3b8'; }}
                      onMouseLeave={e => { if (librarySelected?.id !== asset.id) e.currentTarget.style.borderColor = '#e2e8f0'; }}
                    >
                      {/* Preview area */}
                      <div style={{width: '100%', height: 140, minHeight: 140, flexShrink: 0, background: '#1e293b', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', position: 'relative'}}>
                        {asset.file_type === 'video' ? (
                          <>
                            <video
                              src={asset.file_url}
                              muted
                              style={{width: '100%', height: '100%', objectFit: 'contain', background: '#000'}}
                            />
                            {/* Play icon overlay */}
                            <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.25)'}}>
                              <div style={{width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,255,255,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                                <Film className="w-4 h-4" style={{color: '#334155'}} />
                              </div>
                            </div>
                          </>
                        ) : (
                          <img
                            src={asset.file_url}
                            alt={asset.name}
                            style={{width: '100%', height: '100%', objectFit: 'contain', background: '#000'}}
                            onError={(e) => { e.target.style.display = 'none'; e.target.parentNode.style.background = '#fef2f2'; }}
                          />
                        )}
                        {/* Selected checkmark */}
                        {librarySelected?.id === asset.id && (
                          <div style={{position: 'absolute', top: 6, right: 6, width: 22, height: 22, borderRadius: '50%', background: '#4CAF50', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.3)'}}>
                            <span style={{color: 'white', fontSize: 11, fontWeight: 'bold', lineHeight: 1}}>✓</span>
                          </div>
                        )}
                      </div>
                      {/* Name */}
                      <div style={{fontSize: 12, padding: '6px 8px', textAlign: 'center', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: '#334155', background: 'white'}}>
                        {asset.name}
                      </div>
                    </button>
                  ))}
                </div>
              );
            })()}

            <div style={{display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 12, paddingTop: 12, borderTop: '1px solid #f1f5f9'}}>
              <button
                type="button"
                onClick={() => { setLibraryPickerOpen(false); setLibrarySelected(null); }}
                style={{padding: '6px 12px', fontSize: 13, border: '1px solid #e2e8f0', borderRadius: 6, cursor: 'pointer', background: 'white'}}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApplyLibraryAsset}
                disabled={!librarySelected}
                style={{padding: '6px 12px', fontSize: 13, background: librarySelected ? '#16a34a' : '#d1fae5', color: librarySelected ? 'white' : '#86efac', borderRadius: 6, border: 'none', cursor: librarySelected ? 'pointer' : 'not-allowed', fontWeight: 500}}
              >
                Use Selected Media
              </button>
            </div>
          </DialogContent>
        </Dialog>

      {studioPickerOpen && (
        <Dialog open={studioPickerOpen} onOpenChange={setStudioPickerOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Select Studio Creative</DialogTitle></DialogHeader>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {studioCreatives.length === 0 && (
                <p className="text-sm text-slate-500 text-center py-4">No studio creatives found</p>
              )}
              {studioCreatives.map((creative) => (
                <button
                  key={creative.id}
                  onClick={() => handleApplyStudioCreative(creative)}
                  className="w-full flex items-center gap-3 p-2 border border-slate-200 rounded hover:bg-blue-50 transition-colors text-left"
                >
                  <Zap className="w-4 h-4 text-blue-500 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-slate-700 truncate">{creative.name}</div>
                    <div className="text-[10px] text-slate-400">{creative.width}×{creative.height}px</div>
                  </div>
                </button>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
}