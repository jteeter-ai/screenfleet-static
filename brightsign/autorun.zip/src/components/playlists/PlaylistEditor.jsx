import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, ListVideo, CalendarClock, LayoutGrid, Save, CheckCircle2, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import PlaylistItemCard from "./PlaylistItemCard";
import { toast } from "sonner";
import { useOrg } from "@/components/OrgContext";

export default function PlaylistEditor({ playlistId }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { activeOrgId } = useOrg();
  const [localName, setLocalName] = useState("");
  const nameDebounce = useRef(null);
  const isFocused = useRef(false);
  const [selectedLayoutTemplateId, setSelectedLayoutTemplateId] = useState("");
  const [savingItems, setSavingItems] = useState(false);
  const [savedItems, setSavedItems] = useState(false);

  // V2 Playlist query — now uses layout_template_id
  const { data: playlist } = useQuery({
    queryKey: ["playlist", playlistId],
    queryFn: async () => {
      const all = await base44.entities.Playlist.filter({ org_id: activeOrgId });
      const found = all.find((p) => p.id === playlistId);
      console.log(`[PlaylistEditor] Loaded V2 playlist ${playlistId}:`, { name: found?.name, layout_template_id: found?.layout_template_id });
      return found;
    },
    enabled: !!playlistId && !!activeOrgId,
    staleTime: 0,
    refetchOnMount: "stale",
  });

  // V2: Load LayoutTemplates scoped by org
  const { data: layoutTemplates = [] } = useQuery({
    queryKey: ["layoutTemplates", activeOrgId],
    queryFn: () => activeOrgId ? base44.entities.LayoutTemplate.filter({ org_id: activeOrgId }) : Promise.resolve([]),
    enabled: !!activeOrgId,
    staleTime: 0,
    refetchOnMount: "stale",
  });

  // V2: Load LayoutZones for selected LayoutTemplate
  const { data: layoutZones = [] } = useQuery({
    queryKey: ["layoutZonesForTemplate", selectedLayoutTemplateId],
    queryFn: async () => {
      if (!selectedLayoutTemplateId) return [];
      const zones = await base44.entities.LayoutZone.filter({ layout_template_id: selectedLayoutTemplateId });
      console.log(`[PlaylistEditor] Loaded ${zones.length} LayoutZones for template ${selectedLayoutTemplateId}`);
      return zones;
    },
    enabled: !!selectedLayoutTemplateId,
    staleTime: 0,
    refetchOnMount: "stale",
  });

  // Auto-save template selection
  const isRestoringTemplate = useRef(true);
  useEffect(() => {
    if (isRestoringTemplate.current) return;
    if (!playlistId) return;
    updatePlaylistMutation.mutate({ layout_template_id: selectedLayoutTemplateId || null });
  }, [selectedLayoutTemplateId, playlistId]);

  // Restore template selection from playlist
  useEffect(() => {
    if (playlist?.name !== undefined && !isFocused.current) setLocalName(playlist.name);
    if (playlist?.layout_template_id && layoutTemplates.length > 0) {
      const found = layoutTemplates.find(t => t.id === playlist.layout_template_id);
      if (found) {
        console.log(`[PlaylistEditor] Restored layout_template_id ${playlist.layout_template_id}`);
        isRestoringTemplate.current = true;
        setSelectedLayoutTemplateId(playlist.layout_template_id);
        setTimeout(() => { isRestoringTemplate.current = false; }, 100);
      } else {
        setSelectedLayoutTemplateId("");
      }
    } else if (playlist && !playlist.layout_template_id) {
      setSelectedLayoutTemplateId("");
    }
  }, [playlist?.id, playlist?.layout_template_id, layoutTemplates]);

  // V2: Load PlaylistItems for this playlist
  const { data: playlistItems = [] } = useQuery({
    queryKey: ["playlistItems", playlistId],
    queryFn: () => playlistId ? base44.entities.PlaylistItem.filter({ playlist_id: playlistId }) : Promise.resolve([]),
    enabled: !!playlistId,
    staleTime: 0,
  });

  const sortedItems = [...playlistItems].sort((a, b) => (a.order || 0) - (b.order || 0));

  // V2 Mutations
  const updatePlaylistMutation = useMutation({
    mutationFn: (data) => base44.entities.Playlist.update(playlistId, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["playlist", playlistId] }),
  });

  const addItemMutation = useMutation({
    mutationFn: () => base44.entities.PlaylistItem.create({
      playlist_id: playlistId,
      order: (sortedItems[sortedItems.length - 1]?.order || 0) + 1,
      duration: playlist?.default_duration || 8,
      transition: playlist?.default_transition || "fade",
      zone_assignments: {}, // Empty, user fills in
    }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["playlistItems", playlistId] }),
  });

  const updateItemMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PlaylistItem.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["playlistItems", playlistId] }),
  });

  const deleteItemMutation = useMutation({
    mutationFn: (id) => base44.entities.PlaylistItem.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["playlistItems", playlistId] }),
  });

  const moveItem = async (itemId, direction) => {
    const arr = [...sortedItems];
    const idx = arr.findIndex(i => i.id === itemId);
    if (idx < 0) return;
    const swapIdx = idx + direction;
    if (swapIdx < 0 || swapIdx >= arr.length) return;
    const aOrder = arr[idx].order ?? idx;
    const bOrder = arr[swapIdx].order ?? swapIdx;
    await Promise.all([
      updateItemMutation.mutateAsync({ id: arr[idx].id, data: { order: bOrder } }),
      updateItemMutation.mutateAsync({ id: arr[swapIdx].id, data: { order: aOrder } }),
    ]);
  };

  // V2: Validate and save items with zone assignments
  const handleSaveItems = async () => {
    setSavingItems(true);
    try {
      // Wire in validatePlaylistZones
      if (selectedLayoutTemplateId && sortedItems.length > 0) {
        const allZoneAssignments = {};
        sortedItems.forEach(item => {
          Object.assign(allZoneAssignments, item.zone_assignments || {});
        });

        const validationResult = await base44.functions.invoke("validatePlaylistZones", {
          layout_template_id: selectedLayoutTemplateId,
          zone_assignments: allZoneAssignments,
        });

        if (!validationResult.data.valid) {
          toast.error(`Invalid zones: ${validationResult.data.error}`);
          setSavingItems(false);
          return;
        }
      }

      setSavedItems(true);
      setTimeout(() => setSavedItems(false), 3000);
      toast.success("Playlist saved!");
    } catch (e) {
      toast.error(`Validation failed: ${e.message}`);
    } finally {
      setSavingItems(false);
    }
  };

  const handlePublish = async () => {
    await handleSaveItems();
    navigate(createPageUrl("Scheduling"));
  };

  if (!playlist) return (
    <div className="flex-1 flex items-center justify-center bg-slate-50">
      <div className="text-center text-slate-400">
        <ListVideo className="w-10 h-10 mx-auto mb-2 opacity-30" />
        <p className="text-sm">Select or create a playlist</p>
      </div>
    </div>
  );

  const totalDuration = sortedItems.reduce((sum, s) => sum + (s.duration || playlist.default_duration || 8), 0);

  return (
    <div className="flex-1 overflow-auto bg-slate-50 p-6 space-y-5">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-wrap gap-5 items-end">
        <div>
          <Label className="text-xs text-slate-500">Playlist Name</Label>
          <Input
            value={localName}
            onFocus={() => { isFocused.current = true; }}
            onBlur={(e) => {
              isFocused.current = false;
              clearTimeout(nameDebounce.current);
              updatePlaylistMutation.mutate({ name: e.target.value });
            }}
            onChange={(e) => {
              setLocalName(e.target.value);
              clearTimeout(nameDebounce.current);
              nameDebounce.current = setTimeout(() => {
                updatePlaylistMutation.mutate({ name: e.target.value });
              }, 1500);
            }}
            className="h-8 text-sm w-48 mt-1"
          />
        </div>
        <div>
          <Label className="text-xs text-slate-500">Default Duration (s)</Label>
          <Input
            type="number" min="1"
            value={playlist.default_duration || 8}
            onChange={(e) => updatePlaylistMutation.mutate({ default_duration: Number(e.target.value) })}
            className="h-8 text-sm w-20 mt-1"
          />
        </div>
        <div className="flex items-center gap-2">
          <Switch checked={playlist.loop} onCheckedChange={(v) => updatePlaylistMutation.mutate({ loop: v })} />
          <Label className="text-sm">Loop</Label>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <span className="text-xs text-slate-400 self-center">
            {sortedItems.length} item{sortedItems.length !== 1 ? "s" : ""} · {totalDuration}s total
          </span>
          <Button
            size="sm"
            className="h-8 bg-blue-600 hover:bg-blue-700 text-xs gap-1.5 px-4 font-semibold"
            onClick={() => navigate(createPageUrl("Scheduling"))}
          >
            <CalendarClock className="w-3.5 h-3.5" />
            Schedule
          </Button>
        </div>
      </div>

      {/* V2: Layout Template & Zone Assignment */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4">
        <div className="flex items-center gap-2">
          <LayoutGrid className="w-4 h-4 text-blue-500" />
          <h3 className="text-sm font-semibold text-slate-700">
            Assign Layout Template &amp; Zones
            {selectedLayoutTemplateId && layoutZones.length > 0 && (
              <span className="ml-2 text-xs font-normal text-slate-400">
                • {layoutZones.length} zone{layoutZones.length !== 1 ? 's' : ''} available
              </span>
            )}
          </h3>
          {savingItems && <span className="text-xs text-slate-400 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> Saving…</span>}
          {savedItems && !savingItems && <span className="text-xs text-green-600 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Saved</span>}
        </div>

        <div>
          <Label className="text-xs text-slate-500 mb-1 block">
            Select a Layout Template
            {playlist?.layout_template_id && selectedLayoutTemplateId && (
              <span className="ml-2 text-[10px] font-normal text-green-600">
                ✓ Saved
              </span>
            )}
          </Label>
          <Select value={selectedLayoutTemplateId || ""} onValueChange={(v) => {
            console.log(`[PlaylistEditor] User selected layout_template ${v}`);
            setSelectedLayoutTemplateId(v);
            isRestoringTemplate.current = false;
          }}>
            <SelectTrigger className="h-8 text-sm w-64">
              <SelectValue placeholder="Choose a layout template…" />
            </SelectTrigger>
            <SelectContent>
              {layoutTemplates.length === 0 && <SelectItem value="_none" disabled>No templates — create in Layout Templates page</SelectItem>}
              {layoutTemplates.map((t) => (
                <SelectItem key={t.id} value={t.id}>
                  {t.name} ({t.canvas_width}×{t.canvas_height})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* V2: Playlist Items */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-700">Items ({sortedItems.length})</h3>
          <Button
            variant="outline"
            size="sm"
            className="h-7 text-xs gap-1"
            onClick={() => addItemMutation.mutate()}
            disabled={addItemMutation.isPending || !selectedLayoutTemplateId}
            title={!selectedLayoutTemplateId ? "Select a layout template first" : ""}
          >
            <Plus className="w-3 h-3" /> Add Item
          </Button>
        </div>

        {sortedItems.length === 0 && (
          <div
            className="border-2 border-dashed border-slate-200 rounded-xl p-10 text-center text-sm text-slate-400 cursor-pointer hover:border-blue-300 transition-colors bg-white"
            onClick={() => selectedLayoutTemplateId && addItemMutation.mutate()}
          >
            <ListVideo className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p>Click "Add Item" to get started</p>
            <p className="text-xs mt-1">Each item can have media assigned to multiple zones</p>
          </div>
        )}

        {sortedItems.map((item, index) => (
          <PlaylistItemCard
            key={item.id}
            item={item}
            layoutZones={layoutZones}
            defaultDuration={playlist.default_duration || 8}
            onUpdateItem={(id, data) => updateItemMutation.mutate({ id, data })}
            onDeleteItem={(id) => deleteItemMutation.mutate(id)}
            onMoveItem={(direction) => moveItem(item.id, direction)}
            isFirst={index === 0}
            isLast={index === sortedItems.length - 1}
          />
        ))}

        {sortedItems.length > 0 && (
          <div className="flex gap-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              className="h-8 text-xs gap-1.5"
              onClick={handleSaveItems}
              disabled={savingItems}
            >
              {savingItems ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Saving…</> : savedItems ? <><CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> Saved!</> : <><Save className="w-3.5 h-3.5" /> Save Items</>}
            </Button>
            <Button
              size="sm"
              className="h-8 bg-blue-600 hover:bg-blue-700 text-xs gap-1.5"
              onClick={handlePublish}
              disabled={savingItems}
            >
              <CalendarClock className="w-3.5 h-3.5" /> Save &amp; Go to Schedule
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}