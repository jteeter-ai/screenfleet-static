import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2, Upload, Film, ImageIcon, Clock, ChevronDown, ChevronUp, Monitor, X } from "lucide-react";

export default function PlaylistSpotCard({
  spot,
  creatives,
  defaultDwellTime,
  onUpdateSpot,
  onDeleteSpot,
  onAddCreative,
  onDeleteCreative,
  onUpdateCreative,
  playlistZones = [], // zones with content_type === "playlist"
  // legacy props kept for compat
  hasSidePlaylist = false,
  hasRearPlaylist = false,
  hasFrontPlaylist = false,
  assetHasFrontScreen = false,
}) {
  const [expanded, setExpanded] = useState(true);
  const effectiveDwell = spot.dwell_time ?? defaultDwellTime;

  return (
    <Card className="border border-slate-200 shadow-sm">
      <CardHeader className="pb-2 pt-3 px-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <span className="text-sm font-bold text-slate-500 w-6">#{spot.spot_number}</span>
            <Badge variant="outline" className="text-xs text-slate-600">{creatives.length} creative{creatives.length !== 1 ? "s" : ""}</Badge>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center gap-1 text-xs text-slate-500">
              <Clock className="w-3 h-3" />
              <Input
                type="number"
                min="1"
                value={effectiveDwell}
                onChange={(e) => onUpdateSpot(spot.id, { dwell_time: Number(e.target.value) })}
                className="h-6 w-14 text-xs px-1.5 text-center"
              />
              <span>s</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-red-400 hover:text-red-600"
              onClick={() => onDeleteSpot(spot.id)}
              title="Remove spot"
            >
              <Trash2 className="w-3 h-3" />
            </Button>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setExpanded(!expanded)}>
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </Button>
          </div>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="px-4 pb-4 pt-0 space-y-3">
          {/* Front screen toggle — only show if asset has a front screen AND front zone has playlist */}
          {assetHasFrontScreen && hasFrontPlaylist && (
            <div className="flex items-center justify-between p-2 bg-purple-50 border border-purple-100 rounded-lg">
              <div className="flex items-center gap-2">
                <Monitor className="w-3.5 h-3.5 text-purple-500" />
                <div>
                  <Label className="text-xs font-medium text-purple-800">Front Screen</Label>
                  <p className="text-[10px] text-purple-500">
                    {spot.front_uses_side !== false ? "Mirrors side screen" : "Independent creative"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-purple-600">Own creative</span>
                <Switch
                  checked={spot.front_uses_side === false}
                  onCheckedChange={(v) => onUpdateSpot(spot.id, { front_uses_side: !v })}
                />
              </div>
            </div>
          )}

          {/* Creatives */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-[10px] text-slate-500 uppercase tracking-wide">
                Creatives ({creatives.length})
              </Label>
              <Button
                variant="outline"
                size="sm"
                className="h-6 text-xs gap-1 px-2"
                onClick={() => onAddCreative(spot.id)}
              >
                <Plus className="w-3 h-3" /> Add Creative
              </Button>
            </div>

            <div className="space-y-1.5">
              {creatives.length === 0 && (
                <div
                  className="border-2 border-dashed border-slate-200 rounded-lg p-3 text-center text-xs text-slate-400 cursor-pointer hover:border-blue-300 hover:text-blue-400 transition-colors"
                  onClick={() => onAddCreative(spot.id)}
                >
                  <Plus className="w-4 h-4 mx-auto mb-1" />
                  Click to add first creative
                </div>
              )}
              {creatives.map((creative, idx) => (
                <PlaylistCreativeRow
                  key={creative.id}
                  creative={creative}
                  index={idx}
                  playlistZones={playlistZones}
                  onUpdate={(data) => onUpdateCreative(creative.id, data)}
                  onDelete={() => onDeleteCreative(creative.id)}
                />
              ))}
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

// Zone-keyed upload: stores file_url per zone id in creative.zone_files = { [zoneId]: { file_url, file_type } }
function PlaylistCreativeRow({ creative, index, onUpdate, onDelete, playlistZones = [] }) {
  const [uploading, setUploading] = useState({});

  const handleFileUpload = async (e, zoneId) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading((u) => ({ ...u, [zoneId]: true }));
    const { base44 } = await import("@/api/base44Client");
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const fileType = file.type.startsWith("video") ? "video" : "image";
    const zoneFiles = { ...(creative.zone_files || {}) };
    zoneFiles[zoneId] = { file_url, file_type: fileType };
    onUpdate({ zone_files: zoneFiles });
    setUploading((u) => ({ ...u, [zoneId]: false }));
  };

  const zoneFiles = creative.zone_files || {};

  // Color palette per zone index
  const colorSets = [
    { active: "border-blue-200 bg-blue-50 text-blue-700", inactive: "border-slate-200 bg-white text-slate-500 hover:border-blue-300" },
    { active: "border-emerald-200 bg-emerald-50 text-emerald-700", inactive: "border-slate-200 bg-white text-slate-500 hover:border-emerald-300" },
    { active: "border-purple-200 bg-purple-50 text-purple-700", inactive: "border-slate-200 bg-white text-slate-500 hover:border-purple-300" },
    { active: "border-amber-200 bg-amber-50 text-amber-700", inactive: "border-slate-200 bg-white text-slate-500 hover:border-amber-300" },
  ];

  return (
    <div className="bg-white rounded p-2 border border-slate-100 space-y-2">
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] font-bold text-slate-400 w-3">{index + 1}</span>
        <div className="flex-1 flex flex-wrap gap-1.5">
          {playlistZones.length === 0 && (
            <span className="text-xs text-slate-400 italic">No playlist zones configured in layout.</span>
          )}
          {playlistZones.filter((z) => z.content_type !== "duplicate").map((zone, zi) => {
            const colors = colorSets[zi % colorSets.length];
            const zf = zoneFiles[zone.id];
            const isUploading = uploading[zone.id];
            return (
              <div key={zone.id} className="flex-1 min-w-[100px]">
                <label className="block">
                  <div className={`flex items-center gap-1.5 rounded px-2 py-1 border cursor-pointer text-xs transition-colors ${zf ? colors.active : colors.inactive}`}>
                    {isUploading ? (
                      <span className="text-[10px]">Uploading…</span>
                    ) : zf ? (
                      <>
                        {zf.file_type === "video" ? <Film className="w-3 h-3 flex-shrink-0" /> : <ImageIcon className="w-3 h-3 flex-shrink-0" />}
                        <span className="truncate max-w-[80px]" title={zf.file_url.split("/").pop()}>
                          {zf.file_url.split("/").pop().split("_").slice(1).join("_") || zf.file_url.split("/").pop()}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            const newFiles = { ...zoneFiles };
                            delete newFiles[zone.id];
                            onUpdate({ zone_files: newFiles });
                          }}
                          className="ml-auto -mr-1 hover:bg-red-100 rounded p-0.5"
                        >
                          <X className="w-2.5 h-2.5 text-red-500" />
                        </button>
                      </>
                    ) : (
                      <>
                        <Upload className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{zone.name}</span>
                      </>
                    )}
                  </div>
                  <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => handleFileUpload(e, zone.id)} />
                </label>
              </div>
            );
          })}
        </div>
        <div className="flex items-center gap-0.5 flex-shrink-0">
          <Input
            type="number"
            min="1"
            placeholder="—"
            value={creative.dwell_time_override || ""}
            onChange={(e) => onUpdate({ dwell_time_override: e.target.value ? Number(e.target.value) : null })}
            className="h-6 w-10 text-xs px-1 text-center"
            title="Dwell override (seconds)"
          />
          <span className="text-[10px] text-slate-400">s</span>
        </div>
        <Button variant="ghost" size="sm" className="h-5 w-5 p-0 text-red-400 hover:text-red-600 flex-shrink-0" onClick={onDelete}>
          <Trash2 className="w-3 h-3" />
        </Button>
      </div>
    </div>
  );
}