import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GripVertical, Trash2, Film, ImageIcon, Clock } from "lucide-react";
import { Draggable } from "@hello-pangea/dnd";

export default function PlaylistItemRow({ item, index, onUpdate, onDelete }) {
  const [uploading, setUploading] = useState(false);
  const [localName, setLocalName] = useState(item.name || "");
  const isFocused = useRef(false);
  const nameDebounce = useRef(null);

  // Only sync from server when the field is NOT focused
  useEffect(() => {
    if (!isFocused.current) {
      setLocalName(item.name || "");
    }
  }, [item.name]);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const file_type = file.type.startsWith("video") ? "video" : "image";
    onUpdate({ file_url, file_type, name: item.name || file.name });
    setUploading(false);
  };

  const isVideo = item.file_type === "video";

  return (
    <Draggable draggableId={item.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={`flex items-center gap-2 bg-white border rounded-lg px-2 py-1.5 transition-shadow
            ${snapshot.isDragging ? "shadow-lg border-blue-300" : "border-slate-200 hover:border-slate-300"}`}
        >
          <div {...provided.dragHandleProps} className="text-slate-300 hover:text-slate-500 cursor-grab">
            <GripVertical className="w-4 h-4" />
          </div>

          <span className="text-xs text-slate-400 w-5 text-right">{index + 1}</span>

          {/* Thumbnail */}
          <div className="w-12 h-8 rounded bg-slate-100 flex-shrink-0 overflow-hidden flex items-center justify-center">
            {item.file_url ? (
              isVideo
                ? <video src={item.file_url} className="w-full h-full object-cover" muted />
                : <img src={item.file_url} alt="" className="w-full h-full object-cover" />
            ) : (
              <label className="cursor-pointer w-full h-full flex items-center justify-center hover:bg-slate-200 transition-colors">
                <input type="file" accept="image/*,video/*" className="hidden" onChange={handleFileUpload} />
                <span className="text-[9px] text-slate-400">{uploading ? "…" : "+ file"}</span>
              </label>
            )}
          </div>

          {/* File type icon */}
          {item.file_url && (
            <label className="cursor-pointer flex-shrink-0" title="Replace file">
              <input type="file" accept="image/*,video/*" className="hidden" onChange={handleFileUpload} />
              {isVideo ? <Film className="w-3.5 h-3.5 text-slate-400" /> : <ImageIcon className="w-3.5 h-3.5 text-slate-400" />}
            </label>
          )}

          {/* Name */}
          <Input
            value={localName}
            onFocus={() => { isFocused.current = true; }}
            onBlur={(e) => {
              isFocused.current = false;
              clearTimeout(nameDebounce.current);
              onUpdate({ name: e.target.value });
            }}
            onChange={(e) => {
              setLocalName(e.target.value);
              clearTimeout(nameDebounce.current);
              nameDebounce.current = setTimeout(() => {
                onUpdate({ name: e.target.value });
              }, 1500);
            }}
            placeholder="Item name…"
            className="h-7 text-xs flex-1 min-w-0"
          />

          {/* Duration */}
          <div className="flex items-center gap-1 flex-shrink-0">
            <Clock className="w-3 h-3 text-slate-400" />
            <Input
              type="number"
              min="1"
              value={item.duration || ""}
              onChange={(e) => onUpdate({ duration: e.target.value ? Number(e.target.value) : null })}
              placeholder="—"
              className="h-7 w-14 text-xs text-center px-1"
              title="Duration (s)"
            />
            <span className="text-[10px] text-slate-400">s</span>
          </div>

          {/* Transition */}
          <Select value={item.transition || "fade"} onValueChange={(v) => onUpdate({ transition: v })}>
            <SelectTrigger className="h-7 w-20 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None</SelectItem>
              <SelectItem value="fade">Fade</SelectItem>
              <SelectItem value="slide_left">Slide ←</SelectItem>
              <SelectItem value="slide_right">Slide →</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-red-400 hover:text-red-600 flex-shrink-0" onClick={onDelete}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      )}
    </Draggable>
  );
}