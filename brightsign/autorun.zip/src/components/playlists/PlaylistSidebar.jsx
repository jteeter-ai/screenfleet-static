import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, ListVideo, Trash2, Search, ArrowDownAZ, Clock } from "lucide-react";
import { useOrg } from "@/components/OrgContext";

export default function PlaylistSidebar({ playlists, selectedId, onSelect }) {
  const { activeOrgId } = useOrg();
  const validOrgId = activeOrgId && activeOrgId !== "PLATFORM_ADMIN" ? activeOrgId : null;
  const queryClient = useQueryClient();
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newTemplateId, setNewTemplateId] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortMode, setSortMode] = useState("recent");

  const { data: layoutTemplates = [] } = useQuery({
    queryKey: ["layoutTemplates", validOrgId],
    queryFn: () =>
      validOrgId
        ? base44.entities.LayoutTemplate.filter({ org_id: validOrgId })
        : Promise.resolve([]),
    enabled: !!validOrgId,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Playlist.create(data),
    onSuccess: (pl) => {
      queryClient.invalidateQueries({ queryKey: ["playlists"] });
      onSelect(pl.id);
      setCreating(false);
      setNewName("");
      setNewTemplateId("");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Playlist.delete(id),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["playlists"] }),
  });

  const handleCreate = () => {
    if (newName.trim() && newTemplateId) {
      createMutation.mutate({
        name: newName.trim(),
        org_id: validOrgId,
        layout_template_id: newTemplateId,
        loop: true,
        default_duration: 8,
        default_transition: "fade",
      });
    }
  };

  const handleCancel = () => {
    setCreating(false);
    setNewName("");
    setNewTemplateId("");
  };

  const handleDelete = (id) => {
    deleteMutation.mutate(id);
  };

  const displayedPlaylists = useMemo(() => {
    let result = playlists;
    if (searchQuery.trim()) {
      result = result.filter(p => p.name?.toLowerCase().includes(searchQuery.toLowerCase()));
    }
    if (sortMode === "alpha") {
      result = [...result].sort((a, b) => (a.name || "").localeCompare(b.name || ""));
    } else {
      result = [...result].sort((a, b) =>
        new Date(b.updated_date || b.created_date) - new Date(a.updated_date || a.created_date)
      );
    }
    return result;
  }, [playlists, searchQuery, sortMode]);

  return (
    <div className="w-56 border-r border-slate-200 bg-white flex flex-col flex-shrink-0">
      {/* Header */}
      <div className="p-3 border-b border-slate-100 flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-widest">
          Playlists
        </span>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0"
          onClick={() => setCreating(true)}
        >
          <Plus className="w-3.5 h-3.5" />
        </Button>
      </div>

      {/* Search + Sort */}
      <div className="px-2 pt-2 pb-1 flex items-center gap-1 border-b border-slate-100">
        <div className="relative flex-1">
          <Search className="absolute left-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search playlists…"
            className="w-full pl-6 pr-2 py-1 text-xs border border-slate-200 rounded outline-none focus:ring-1 focus:ring-blue-300 bg-slate-50"
          />
        </div>
        <button
          title={sortMode === "recent" ? "Sort: Recent" : "Sort: A–Z"}
          onClick={() => setSortMode(s => s === "recent" ? "alpha" : "recent")}
          className="flex-shrink-0 p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
        >
          {sortMode === "recent" ? <Clock className="w-3.5 h-3.5" /> : <ArrowDownAZ className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Create Form */}
      {creating ? (
        <div className="p-2 border-b border-slate-100 space-y-2">
          <Input
            autoFocus
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Playlist name…"
            className="h-7 text-xs"
            onKeyDown={(e) => {
              if (e.key === "Enter" && newName.trim() && newTemplateId) {
                handleCreate();
              }
              if (e.key === "Escape") handleCancel();
            }}
          />
          <Select value={newTemplateId} onValueChange={setNewTemplateId}>
            <SelectTrigger className="h-7 text-xs">
              <SelectValue placeholder="Select layout template…" />
            </SelectTrigger>
            <SelectContent>
              {layoutTemplates.map((template) => (
                <SelectItem key={template.id} value={template.id}>
                  {template.name} ({template.canvas_width}×{template.canvas_height})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex gap-1">
            <Button
              size="sm"
              className="h-7 px-2 text-xs flex-1"
              onClick={handleCreate}
              disabled={
                !newName.trim() || !newTemplateId || createMutation.isPending
              }
            >
              Create
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-7 px-2 text-xs"
              onClick={handleCancel}
            >
              Cancel
            </Button>
          </div>
        </div>
      ) : null}

      {/* Playlist List */}
      <div className="flex-1 overflow-y-auto py-1">
        {displayedPlaylists.map((pl) => {
          const template = layoutTemplates.find(
            (t) => t.id === pl.layout_template_id
          );
          const isSelected = selectedId === pl.id;

          return (
            <div
              key={pl.id}
              className={`group flex items-center justify-between px-3 py-2 cursor-pointer rounded-lg mx-1 transition-colors ${
                isSelected
                  ? "bg-blue-50 text-blue-700"
                  : "hover:bg-slate-50 text-slate-700"
              }`}
              onClick={() => onSelect(pl.id)}
            >
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <ListVideo className="w-3.5 h-3.5 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="text-sm truncate">{pl.name}</div>
                  {template ? (
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {template.name} ({template.canvas_width}×{template.canvas_height})
                    </div>
                  ) : (
                    <div className="text-[10px] text-amber-500 mt-0.5">
                      ⚠ No template
                    </div>
                  )}
                </div>
              </div>
              <button
                className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-600 transition-opacity flex-shrink-0"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(pl.id);
                }}
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          );
        })}

        {displayedPlaylists.length === 0 && !creating ? (
          <p className="text-xs text-slate-400 text-center py-8">
            No playlists yet
          </p>
        ) : null}
      </div>
    </div>
  );
}