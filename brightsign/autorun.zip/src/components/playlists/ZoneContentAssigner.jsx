import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { RefreshCw, Tv2, Globe, Volume2, Upload } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function ZoneContentAssigner({ zone, zoneContent }) {
  const ct = zoneContent?.content_type || zone.content_type || "empty";

  const { data: rotations = [] } = useQuery({
    queryKey: ["rotations"],
    queryFn: () => base44.entities.Rotation.list(),
    enabled: ct === "rotation",
  });

  return (
    <div className="border border-slate-200 rounded-xl bg-white p-4 space-y-3">
      {/* Zone label */}
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-sm bg-blue-400 flex-shrink-0" />
        <span className="text-sm font-semibold text-slate-700">{zone.name}</span>
        <span className="text-[10px] text-slate-400 ml-auto">{zone.width}×{zone.height}</span>
      </div>

      {/* Content type — read-only from Screen Editor */}
      <div>
        <Label className="text-xs text-slate-500 mb-1 block">Content Type (set in Screen Editor)</Label>
        <div className="h-8 px-3 flex items-center border border-slate-200 rounded-md bg-slate-50 text-sm text-slate-600">
          {ct === "playlist" && "Playlist (Upload Media)"}
          {ct === "rotation" && "Route Presentation"}
          {ct === "hdmi_input" && "HDMI Input"}
          {ct === "html" && "HTML / Web Link"}
          {ct === "empty" && <span className="text-slate-400 italic">Empty</span>}
          {!["playlist","rotation","hdmi_input","html","empty"].includes(ct) && ct}
        </div>
      </div>

      {/* Playlist info */}
      {ct === "playlist" && (
        <p className="text-xs text-slate-500 italic border-t border-slate-100 pt-2">
          Assign media to zones by creating Spots and Creatives below. Each Spot can contain multiple creatives that cycle through your assigned screens.
        </p>
      )}

      {/* Rotation — show selected rotation name read-only */}
      {ct === "rotation" && (
        <div className="border-t border-slate-100 pt-2">
          <Label className="text-xs text-slate-500 mb-1 block">Route Presentation</Label>
          <div className="h-8 px-3 flex items-center border border-slate-200 rounded-md bg-slate-50 text-sm text-slate-600 gap-2">
            <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
            {rotations.find((r) => r.id === (zoneContent?.rotation_id || zone.rotation_id))?.name || <span className="text-slate-400 italic">None assigned</span>}
          </div>
        </div>
      )}

      {/* HDMI */}
      {ct === "hdmi_input" && (
        <div className="border-t border-slate-100 pt-2 flex items-center gap-2 p-3 bg-amber-50 border border-amber-100 rounded-lg">
          <Tv2 className="w-4 h-4 text-amber-500 flex-shrink-0" />
          <p className="text-xs text-amber-700">HDMI input — volume configured in Screen Editor.</p>
        </div>
      )}

      {/* HTML */}
      {ct === "html" && (
        <div className="border-t border-slate-100 pt-2">
          <Label className="text-xs text-slate-500 mb-1 block">Web / HTML URL</Label>
          <div className="h-8 px-3 flex items-center border border-slate-200 rounded-md bg-slate-50 text-sm text-slate-600 gap-2">
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            {zoneContent?.html_url || zone.html_url || <span className="text-slate-400 italic">No URL set</span>}
          </div>
        </div>
      )}
    </div>
  );
}