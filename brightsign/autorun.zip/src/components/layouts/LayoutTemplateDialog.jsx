import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function LayoutTemplateDialog({ mode, template, orgId, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: template?.name || "",
    description: template?.description || "",
    canvas_width: template?.canvas_width || "",
    canvas_height: template?.canvas_height || "",
    is_archived: template?.is_archived || false,
  });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!Number(form.canvas_width) || Number(form.canvas_width) <= 0) e.canvas_width = "Must be > 0";
    if (!Number(form.canvas_height) || Number(form.canvas_height) <= 0) e.canvas_height = "Must be > 0";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = async () => {
    if (!validate()) return;
    setSaving(true);
    const data = {
      ...form,
      canvas_width: Number(form.canvas_width),
      canvas_height: Number(form.canvas_height),
      org_id: orgId,
    };
    if (mode === "create") {
      await base44.entities.LayoutTemplate.create(data);
    } else {
      await base44.entities.LayoutTemplate.update(template.id, data);
    }
    setSaving(false);
    onSaved();
  };

  const set = (key) => (e) => setForm(f => ({ ...f, [key]: e.target?.value ?? e }));

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "New Layout Template" : "Edit Layout Template"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div>
            <Label>Name *</Label>
            <Input value={form.name} onChange={set("name")} placeholder="e.g. Standard 1280×640" />
            {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
          </div>
          <div>
            <Label>Description</Label>
            <Input value={form.description} onChange={set("description")} placeholder="Optional description" />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">
            Canvas dimensions must exactly match the screen dimensions this template will be assigned to.
            A template can be reused on any screen with the same dimensions.
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Canvas Width (px) *</Label>
              <Input type="number" value={form.canvas_width} onChange={set("canvas_width")} placeholder="e.g. 1280" min="1" />
              {errors.canvas_width && <p className="text-xs text-red-500 mt-1">{errors.canvas_width}</p>}
            </div>
            <div>
              <Label>Canvas Height (px) *</Label>
              <Input type="number" value={form.canvas_height} onChange={set("canvas_height")} placeholder="e.g. 640" min="1" />
              {errors.canvas_height && <p className="text-xs text-red-500 mt-1">{errors.canvas_height}</p>}
            </div>
          </div>

          {mode === "edit" && (
            <div className="flex items-center gap-3">
              <Switch
                checked={form.is_archived}
                onCheckedChange={(v) => setForm(f => ({ ...f, is_archived: v }))}
              />
              <Label>Archive this template</Label>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={save} disabled={saving}>
              {saving ? "Saving..." : mode === "create" ? "Create Template" : "Save Changes"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}