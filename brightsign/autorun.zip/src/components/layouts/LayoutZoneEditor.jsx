import React, { useState, useRef, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Trash2, Save, ZoomIn, ZoomOut, Maximize, Percent } from "lucide-react";

const SOURCE_TYPES = ["media", "playlist", "route_presentation", "html", "hdmi", "empty"];
const SOURCE_TYPE_LABELS = {
  media: "Single Media (image/video)",
  playlist: "Playlist",
  route_presentation: "Route Presentation",
  html: "HTML Content",
  hdmi: "HDMI Input",
  empty: "Empty",
};
const SOURCE_TYPE_DISPLAY = {
  media: "Single Media",
  playlist: "Playlist",
  route_presentation: "Route Presentation",
  html: "HTML",
  hdmi: "HDMI",
  empty: "Empty",
};
const SOURCE_TYPE_HELP = {
  media: "Displays one image or video file (no rotation or playlist)",
  playlist: "Displays multiple items in sequence",
  route_presentation: "Displays advertising spots with creative rotations",
  html: "Displays external or internal HTML content",
  hdmi: "Displays external input source (hardware-driven)",
  empty: "No content, shows background only",
};
const FIT_MODES = ["fill", "fit", "stretch", "center"];

const ZOOM_MIN = 0.1;
const ZOOM_MAX = 8.0;
const ZOOM_STEP = 0.25;

export default function LayoutZoneEditor({ template, onBack }) {
  const qc = useQueryClient();
  const containerRef = useRef(null); // outer scrollable wrapper — measured for fit scale
  const [containerSize, setContainerSize] = useState({ width: 800, height: 600 });
  const [zoomLevel, setZoomLevel] = useState(1.0); // multiplier on top of fitScale
  const [selectedId, setSelectedId] = useState(null);
  const [editForm, setEditForm] = useState(null);
  const [editingZone, setEditingZone] = useState(null);
  const [duplicateFromId, setDuplicateFromId] = useState(null);
  const [duplicateSourceId, setDuplicateSourceId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [validationError, setValidationError] = useState(null);
  const [autosaveStatus, setAutosaveStatus] = useState(null);
  const autosaveTimeoutRef = useRef(null);
  const savedZoneRef = useRef(null);
  const formZoneIdRef = useRef(null); // tracks which zone the form was last initialized for
  // Local string state for numeric fields — prevents parent re-renders from overwriting mid-type
  const [localNums, setLocalNums] = useState({ x: "", y: "", width: "", height: "", z_index: "" });

  // fitScale: scale canvas so both dimensions fit inside the available container
  const fitScale = Math.min(
    (containerSize.width - 64) / template.canvas_width,
    (containerSize.height - 64) / template.canvas_height,
    1  // never upscale beyond 100% in fit mode
  );
  // Final render scale = fit baseline × user zoom multiplier
  const scale = fitScale * zoomLevel;

  const zoomIn  = () => setZoomLevel(z => Math.min(ZOOM_MAX, parseFloat((z + ZOOM_STEP).toFixed(2))));
  const zoomOut = () => setZoomLevel(z => Math.max(ZOOM_MIN, parseFloat((z - ZOOM_STEP).toFixed(2))));
  const zoomFit  = () => setZoomLevel(1.0);                                       // Fit to screen
  const zoom100  = () => setZoomLevel(parseFloat((1 / fitScale).toFixed(4)));     // 1:1 actual pixels

  const { data: zones = [] } = useQuery({
    queryKey: ["layout_zones", template.id],
    queryFn: () => base44.entities.LayoutZone.filter({ layout_template_id: template.id }),
  });

  // Measure outer container size (both axes) — debounced via rAF
  useEffect(() => {
    if (!containerRef.current) return;
    let rafId;
    const obs = new ResizeObserver(([entry]) => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        setContainerSize({
          width: entry.contentRect.width || 800,
          height: entry.contentRect.height || 600,
        });
      });
    });
    obs.observe(containerRef.current);
    return () => { obs.disconnect(); cancelAnimationFrame(rafId); };
  }, []);

  // Populate form when selected zone changes.
  // Guard: only reinitialize when selectedId actually changes, NOT on every zones refetch.
  // This prevents autosave-triggered query invalidations from overwriting mid-typing.
  useEffect(() => {
    const zone = zones.find(z => z.id === selectedId);
    if (!zone) {
      // Zone deselected or deleted
      setEditForm(null);
      setEditingZone(null);
      savedZoneRef.current = null;
      formZoneIdRef.current = null;
      setLocalNums({ x: "", y: "", width: "", height: "", z_index: "" });
      setValidationError(null);
      setAutosaveStatus(null);
      return;
    }
    // Skip re-init if this is just a zones refetch for the same zone (e.g. after autosave)
    if (formZoneIdRef.current === selectedId) return;
    // New zone selected — initialize all state fresh
    formZoneIdRef.current = selectedId;
    setEditForm({ ...zone });
    setEditingZone({ ...zone });
    savedZoneRef.current = { ...zone };
    setLocalNums({
      x: String(zone.x ?? 0),
      y: String(zone.y ?? 0),
      width: String(zone.width ?? ""),
      height: String(zone.height ?? ""),
      z_index: String(zone.z_index ?? 1),
    });
    // Restore duplicate-from state from persisted is_duplicate_of field
    setDuplicateSourceId(zone.is_duplicate_of || null);
    setDuplicateFromId(null);
    setValidationError(null);
    setAutosaveStatus(null);
  }, [selectedId, zones]);

  // Cleanup autosave timeout on unmount
  useEffect(() => {
    return () => clearTimeout(autosaveTimeoutRef.current);
  }, []);

  const addZone = async () => {
    const zone = await base44.entities.LayoutZone.create({
      layout_template_id: template.id,
      name: `Zone ${zones.length + 1}`,
      x: 0, y: 0,
      width: Math.round(template.canvas_width / 2),
      height: Math.round(template.canvas_height / 2),
      z_index: zones.length + 1,
      fit_mode_default: "fill",
      background_color_default: "#000000",
      volume_default: 100,
    });
    qc.invalidateQueries({ queryKey: ["layout_zones", template.id] });
    setSelectedId(zone.id);
  };

  const validateZone = (f) => {
    const x = Number(f.x) || 0;
    const y = Number(f.y) || 0;
    const w = Number(f.width);
    const h = Number(f.height);
    if (!w || w <= 0) return "Width must be > 0";
    if (!h || h <= 0) return "Height must be > 0";
    if (x + w > template.canvas_width)
      return `Zone extends beyond right edge (canvas width: ${template.canvas_width}px)`;
    if (y + h > template.canvas_height)
      return `Zone extends beyond bottom edge (canvas height: ${template.canvas_height}px)`;
    return null;
  };

  const hasChanges = () => {
    if (!editingZone || !savedZoneRef.current) return false;
    const keys = ['name', 'x', 'y', 'width', 'height', 'z_index', 'default_source_type', 'hdmi_audio_output', 'fit_mode_default', 'background_color_default', 'volume_default'];
    return keys.some(key => editingZone[key] !== savedZoneRef.current[key]);
  };

  const autosave = async () => {
    if (!editingZone || !hasChanges()) return;
    const err = validateZone(editingZone);
    if (err) return;
    setAutosaveStatus('saving');
    try {
      await base44.entities.LayoutZone.update(selectedId, {
        name: editingZone.name,
        x: Number(editingZone.x) || 0,
        y: Number(editingZone.y) || 0,
        width: Number(editingZone.width),
        height: Number(editingZone.height),
        z_index: Number(editingZone.z_index) || 1,
        default_source_type: editingZone.default_source_type || null,
        hdmi_audio_output: editingZone.hdmi_audio_output || 'aux',
        fit_mode_default: editingZone.fit_mode_default ?? "fill",
        background_color_default: editingZone.background_color_default || "#000000",
        volume_default: Number(editingZone.volume_default) ?? 100,
        is_duplicate_of: editingZone.is_duplicate_of || null,
      });
      savedZoneRef.current = { ...editingZone };
      setAutosaveStatus('saved');
      setTimeout(() => setAutosaveStatus(null), 1500);
      qc.invalidateQueries({ queryKey: ["layout_zones", template.id] });
    } catch (err) {
      setAutosaveStatus(null);
    }
  };

  const scheduleAutosave = () => {
    clearTimeout(autosaveTimeoutRef.current);
    autosaveTimeoutRef.current = setTimeout(autosave, 700);
  };

  const saveZone = async () => {
    if (!editForm) return;
    const err = validateZone(editingZone);
    if (err) { setValidationError(err); return; }
    setSaving(true);
    setValidationError(null);
    clearTimeout(autosaveTimeoutRef.current);
    await base44.entities.LayoutZone.update(selectedId, {
      name: editingZone.name,
      x: Number(editingZone.x) || 0,
      y: Number(editingZone.y) || 0,
      width: Number(editingZone.width),
      height: Number(editingZone.height),
      z_index: Number(editingZone.z_index) || 1,
      default_source_type: editingZone.default_source_type || null,
      hdmi_audio_output: editingZone.hdmi_audio_output || 'aux',
      fit_mode_default: editingZone.fit_mode_default ?? "fill",
      background_color_default: editingZone.background_color_default || "#000000",
      volume_default: Number(editingZone.volume_default) ?? 100,
      is_duplicate_of: editingZone.is_duplicate_of || null,
    });
    savedZoneRef.current = { ...editingZone };
    setSaving(false);
    setAutosaveStatus(null);
    qc.invalidateQueries({ queryKey: ["layout_zones", template.id] });
  };

  const deleteZone = async (id) => {
    await base44.entities.LayoutZone.delete(id);
    setSelectedId(null);
    setEditingZone(null);
    qc.invalidateQueries({ queryKey: ["layout_zones", template.id] });
  };

  const handleDuplicateFrom = (sourceZoneId) => {
    if (!sourceZoneId) return;
    const sourceZone = zones.find(z => z.id === sourceZoneId);
    if (!sourceZone) return;
    setEditingZone(z => ({
      ...z,
      width: sourceZone.width,
      height: sourceZone.height,
      fit_mode_default: sourceZone.fit_mode_default,
      background_color_default: sourceZone.background_color_default,
      allowed_source_types: sourceZone.allowed_source_types,
      default_source_type: sourceZone.default_source_type,
      is_duplicate_of: sourceZoneId,
    }));
    setEditForm(f => ({
      ...f,
      width: sourceZone.width,
      height: sourceZone.height,
      fit_mode_default: sourceZone.fit_mode_default,
      background_color_default: sourceZone.background_color_default,
      allowed_source_types: sourceZone.allowed_source_types,
      default_source_type: sourceZone.default_source_type,
      is_duplicate_of: sourceZoneId,
    }));
    setDuplicateSourceId(sourceZoneId);
    setDuplicateFromId(null);
    scheduleAutosave();
  };

  const handleClearDuplicate = () => {
    setDuplicateSourceId(null);
    setEditingZone(z => ({ ...z, is_duplicate_of: null }));
    setEditForm(f => ({ ...f, is_duplicate_of: null }));
    scheduleAutosave();
  };

  const setField = (key) => (e) => {
    const value = e.target?.value ?? e;
    setEditForm(f => ({ ...f, [key]: value }));
    setEditingZone(z => ({ ...z, [key]: value }));
    scheduleAutosave();
  };

  const handleFieldBlur = () => {
    clearTimeout(autosaveTimeoutRef.current);
    autosave();
  };

  return (
    <div className="flex h-screen bg-slate-900 overflow-hidden">
      {/* ─── Canvas panel ───────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* Top bar */}
        <div className="h-14 bg-slate-800 border-b border-slate-700 flex items-center gap-3 px-4 flex-shrink-0">
          <Button size="sm" variant="ghost" onClick={onBack} className="text-slate-300 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-1" /> Back
          </Button>
          <div className="text-white font-semibold">{template.name}</div>
          <div className="text-slate-400 text-sm font-mono">{template.canvas_width}×{template.canvas_height}px</div>
          <div className="flex-1" />
          <Button size="sm" onClick={addZone} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-1" /> Add Zone
          </Button>
        </div>

        {/* Zoom toolbar */}
        <div className="flex items-center gap-1 px-4 py-1.5 bg-slate-800 border-b border-slate-700 flex-shrink-0">
          <button
            onClick={zoomOut}
            disabled={scale <= ZOOM_MIN * fitScale}
            title="Zoom Out"
            className="p-1.5 rounded hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={zoomIn}
            disabled={scale >= ZOOM_MAX}
            title="Zoom In"
            className="p-1.5 rounded hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          <div className="w-px h-4 bg-slate-600 mx-1" />

          <button
            onClick={zoomFit}
            title="Fit to screen"
            className="flex items-center gap-1 px-2.5 py-1 rounded hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
          >
            <Maximize className="w-3 h-3" /> Fit
          </button>
          <button
            onClick={zoom100}
            title="Actual pixel size (1:1)"
            className="flex items-center gap-1 px-2.5 py-1 rounded hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
          >
            <Percent className="w-3 h-3" /> 100%
          </button>

          <div className="w-px h-4 bg-slate-600 mx-1" />

          <span className="text-slate-400 text-xs font-mono min-w-[52px] text-center">
            {Math.round(scale * 100)}%
          </span>
          <span className="text-slate-600 text-[10px] ml-3 hidden sm:inline">
            Scroll to pan · All positions saved in true pixels
          </span>
        </div>

        {/* Scrollable canvas area — allows pan via scrollbars when zoomed in */}
        <div
          ref={containerRef}
          className="flex-1 overflow-auto bg-slate-900"
          style={{ padding: 32 }}
        >
          {/* Inner wrapper sized to the scaled canvas so scrollbars appear correctly */}
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "flex-start",
              minWidth: template.canvas_width * scale + 64,
              minHeight: template.canvas_height * scale + 64,
            }}
          >
            {/* The canvas itself — rendered at scaled pixel size */}
            <div
              className="relative bg-slate-950 border border-slate-600 cursor-default flex-shrink-0"
              style={{
                width: template.canvas_width * scale,
                height: template.canvas_height * scale,
              }}
              onClick={() => setSelectedId(null)}
            >
              {/* Grid overlay — visual only, scaled */}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  backgroundImage:
                    "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
                  backgroundSize: `${Math.max(4, 20 * scale)}px ${Math.max(4, 20 * scale)}px`,
                }}
              />

              <div className="absolute top-2 right-2 text-[10px] text-white/20 font-mono select-none">
                {template.canvas_width}×{template.canvas_height}
              </div>

              {/* Zone rectangles — positions/sizes multiplied by scale for rendering only */}
              {zones
                .slice()
                .sort((a, b) => (a.z_index || 0) - (b.z_index || 0))
                .map(zone => {
                  const isSelected = zone.id === selectedId;
                  // Live-preview editingZone values for selected zone; saved values for others
                  const displayZone = isSelected && editingZone ? editingZone : zone;
                  const sourceTypeLabel = displayZone.default_source_type
                    ? SOURCE_TYPE_DISPLAY[displayZone.default_source_type]
                    : null;
                  return (
                    <div
                      key={zone.id}
                      onClick={(e) => { e.stopPropagation(); setSelectedId(zone.id); }}
                      className={`absolute cursor-pointer border-2 rounded-sm transition-all ${
                        isSelected
                          ? (displayZone.default_source_type === 'hdmi' ? 'border-amber-400 bg-amber-500/20 shadow-lg shadow-amber-500/20' : 'border-blue-400 bg-blue-500/20 shadow-lg shadow-blue-500/20')
                          : (displayZone.default_source_type === 'hdmi' ? 'border-amber-600/60 bg-amber-900/10 hover:border-amber-500/80' : 'border-slate-500/50 bg-slate-700/10 hover:border-slate-400/70')
                      }`}
                      style={{
                        // All coordinates multiplied by scale for CSS rendering only
                        left:   (displayZone.x || 0) * scale,
                        top:    (displayZone.y || 0) * scale,
                        width:  displayZone.width  * scale,
                        height: displayZone.height * scale,
                        zIndex: displayZone.z_index || 1,
                      }}
                    >
                      <div className="p-1">
                        <div className="text-[10px] text-white/60 truncate leading-none">{displayZone.name}</div>
                        <div className="text-[8px] text-white/30 leading-none mt-0.5">{displayZone.width}×{displayZone.height}</div>
                        {sourceTypeLabel && (
                          <div className="text-[7px] text-white/40 leading-none mt-0.5">{sourceTypeLabel}</div>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>

      {/* ─── Properties panel ───────────────────────────────────────────── */}
      <div className="w-72 bg-slate-800 border-l border-slate-700 flex flex-col flex-shrink-0">
        <div className="px-4 py-3 border-b border-slate-700">
          <div className="text-white text-sm font-semibold">Zone Properties</div>
          <div className="text-slate-400 text-xs mt-0.5">{zones.length} zone{zones.length !== 1 ? "s" : ""} defined</div>
        </div>

        {editForm ? (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {validationError && (
              <div className="text-xs text-red-400 bg-red-900/20 border border-red-700/40 rounded p-2">
                {validationError}
              </div>
            )}
            <div className="flex items-center justify-between text-[10px] text-blue-400/60 bg-blue-900/20 border border-blue-700/30 rounded p-2">
              <span>Changes preview live on canvas as you type</span>
              {autosaveStatus === 'saving' && <span className="text-blue-400">Autosaving...</span>}
              {autosaveStatus === 'saved'  && <span className="text-green-400">Saved</span>}
            </div>

            <div>
              <Label className="text-slate-300 text-xs">Name</Label>
              <Input
                value={editForm.name}
                onChange={setField("name")}
                onBlur={handleFieldBlur}
                className="bg-slate-700 border-slate-600 text-white text-sm h-8"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[["x","X"], ["y","Y"], ["width","Width (px)"], ["height","Height (px)"]].map(([key, label]) => (
                <div key={key}>
                  <Label className="text-slate-300 text-xs">{label}</Label>
                  <Input
                    type="text"
                    inputMode="numeric"
                    value={localNums[key]}
                    onChange={(e) => {
                      const raw = e.target.value;
                      setLocalNums(n => ({ ...n, [key]: raw }));
                      // Live canvas preview: only update editingZone when value is a valid integer
                      if (/^\d+$/.test(raw)) {
                        const num = Number(raw);
                        setEditingZone(z => ({ ...z, [key]: num }));
                        scheduleAutosave();
                      }
                    }}
                    onBlur={() => {
                      const num = localNums[key] === "" ? 0 : (Number(localNums[key]) || 0);
                      setLocalNums(n => ({ ...n, [key]: String(num) }));
                      setEditForm(f => ({ ...f, [key]: num }));
                      setEditingZone(z => ({ ...z, [key]: num }));
                      clearTimeout(autosaveTimeoutRef.current);
                      autosave();
                    }}
                    className="bg-slate-700 border-slate-600 text-white text-sm h-8"
                  />
                </div>
              ))}
            </div>

            <div>
              <Label className="text-slate-300 text-xs">Z-Index</Label>
              <Input
                type="text"
                inputMode="numeric"
                value={localNums.z_index}
                onChange={(e) => {
                  const raw = e.target.value;
                  setLocalNums(n => ({ ...n, z_index: raw }));
                  if (/^\d+$/.test(raw)) {
                    setEditingZone(z => ({ ...z, z_index: Number(raw) }));
                    scheduleAutosave();
                  }
                }}
                onBlur={() => {
                  const num = localNums.z_index === "" ? 1 : (Number(localNums.z_index) || 1);
                  setLocalNums(n => ({ ...n, z_index: String(num) }));
                  setEditForm(f => ({ ...f, z_index: num }));
                  setEditingZone(z => ({ ...z, z_index: num }));
                  clearTimeout(autosaveTimeoutRef.current);
                  autosave();
                }}
                className="bg-slate-700 border-slate-600 text-white text-sm h-8"
                min="1"
              />
            </div>

            <div>
              <Label className="text-slate-300 text-xs">Duplicate From</Label>
              <Select
                value={editForm?.is_duplicate_of || ""}
                onValueChange={(v) => {
                  if (!v) handleClearDuplicate();
                  else handleDuplicateFrom(v);
                }}
              >
                <SelectTrigger className={`bg-slate-700 border-slate-600 text-white text-sm h-8 ${editForm?.is_duplicate_of ? "border-blue-500 ring-1 ring-blue-500/40" : ""}`}>
                  <SelectValue placeholder="Copy properties from another zone…" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None</SelectItem>
                  {zones
                    .filter(z => z.id !== selectedId)
                    .map(z => (
                      <SelectItem key={z.id} value={z.id}>
                        {z.name} ({z.width}×{z.height})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              {editForm?.is_duplicate_of ? (() => {
                const srcZone = zones.find(z => z.id === editForm.is_duplicate_of);
                return (
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-xs text-blue-400">↳ Inheriting content from <span className="font-semibold">{srcZone?.name || editForm.is_duplicate_of}</span></p>
                    <button onClick={handleClearDuplicate} className="text-xs text-slate-400 hover:text-slate-200 underline">Clear</button>
                  </div>
                );
              })() : (
                <p className="text-xs text-slate-500 mt-1">Copies: size, fit mode, colors, and source types</p>
              )}
            </div>

            <div>
              <Label className="text-slate-300 text-xs">Default Source Type <span className="text-slate-500">(UI hint)</span></Label>
              <Select
                value={editForm.default_source_type || ""}
                onValueChange={(v) => {
                  const val = v || null;
                  setEditForm(f => ({ ...f, default_source_type: val }));
                  setEditingZone(z => ({ ...z, default_source_type: val }));
                  scheduleAutosave();
                }}
                disabled={!!duplicateSourceId}
              >
                <SelectTrigger className={`bg-slate-700 border-slate-600 text-white text-sm h-8 ${duplicateSourceId ? "opacity-50 cursor-not-allowed" : ""}`}>
                  <SelectValue placeholder="Any (no restriction)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Any (no restriction)</SelectItem>
                  {SOURCE_TYPES.map(t => (
                    <SelectItem key={t} value={t} title={SOURCE_TYPE_HELP[t]}>
                      {SOURCE_TYPE_LABELS[t]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {duplicateSourceId ? (
                <p className="text-xs text-green-400 mt-1.5">Inherited from duplicated zone</p>
              ) : editForm.default_source_type && SOURCE_TYPE_HELP[editForm.default_source_type] ? (
                <p className="text-xs text-slate-400 mt-1.5">{SOURCE_TYPE_HELP[editForm.default_source_type]}</p>
              ) : null}
            </div>

            {/* HDMI Audio Output — only shown when source type is hdmi */}
            {editForm.default_source_type === 'hdmi' && (
              <div className="rounded-lg border border-amber-800/40 bg-amber-950/20 p-3 space-y-2">
                <div className="rounded border border-amber-700/50 bg-amber-900/30 px-2.5 py-2 text-[10px] text-amber-300 leading-snug">
                  <div className="font-semibold mb-0.5">⚡ Native Player Only</div>
                  <div className="text-amber-500/80">HDMI input requires the native ScreenFleet player package deployed to the device. It is <span className="text-amber-400">not supported</span> when ScreenFleet is loaded as an HTML URL inside BrightAuthor or another host presentation.</div>
                </div>
                <Label className="text-amber-300 text-xs font-semibold">HDMI Audio Output</Label>
                <Select
                  value={editForm.hdmi_audio_output || 'aux'}
                  onValueChange={(v) => {
                    setEditForm(f => ({ ...f, hdmi_audio_output: v }));
                    setEditingZone(z => ({ ...z, hdmi_audio_output: v }));
                    scheduleAutosave();
                  }}
                >
                  <SelectTrigger className="bg-slate-700 border-amber-700/40 text-white text-sm h-8"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aux">Aux (AnalogAudio)</SelectItem>
                    <SelectItem value="hdmi">HDMI Out</SelectItem>
                    <SelectItem value="both">Both (Aux + HDMI)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[10px] text-amber-600/70">
                  {(editForm.hdmi_audio_output || 'aux') === 'aux' && 'PCM only via analog. Compressed (AC3/DTS) not routed.'}
                  {(editForm.hdmi_audio_output || 'aux') === 'hdmi' && 'PCM + compressed via HDMI output.'}
                  {(editForm.hdmi_audio_output || 'aux') === 'both' && 'PCM via analog + HDMI. Compressed via HDMI only.'}
                </p>
              </div>
            )}

            <div>
              <Label className="text-slate-300 text-xs">Default Fit Mode</Label>
              <Select
                value={editForm.fit_mode_default ?? "fill"}
                onValueChange={(v) => {
                  setEditForm(f => ({ ...f, fit_mode_default: v }));
                  setEditingZone(z => ({ ...z, fit_mode_default: v }));
                  scheduleAutosave();
                }}
              >
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white text-sm h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FIT_MODES.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-300 text-xs">Background Color</Label>
              <div className="flex gap-2">
                <input
                  type="color"
                  value={editForm.background_color_default || "#000000"}
                  onChange={setField("background_color_default")}
                  onBlur={handleFieldBlur}
                  className="w-9 h-8 rounded border border-slate-600 bg-slate-700 cursor-pointer p-0.5"
                />
                <Input
                  value={editForm.background_color_default || "#000000"}
                  onChange={setField("background_color_default")}
                  onBlur={handleFieldBlur}
                  className="bg-slate-700 border-slate-600 text-white text-sm h-8 flex-1 font-mono"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-700">
              <Button
                onClick={saveZone}
                disabled={saving}
                className="flex-1 bg-blue-600 hover:bg-blue-700 h-8 text-sm"
              >
                <Save className="w-3 h-3 mr-1" />
                {saving ? "Saving..." : "Save Zone"}
              </Button>
              <Button
                variant="ghost"
                className="text-red-400 hover:text-red-300 hover:bg-red-900/20 h-8"
                onClick={() => deleteZone(selectedId)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-500 text-sm text-center p-6">
            Click a zone on the canvas to edit its properties, or add a new zone.
          </div>
        )}
      </div>
    </div>
  );
}