import { Component, useCallback, useRef } from "react";
import SlideshowLayer from "./SlideshowLayer";
import HtmlWidgetLayer from "./HtmlWidgetLayer";
import WeatherWidgetLayer from "./WeatherWidgetLayer";
import ClockWidgetLayer from "./ClockWidgetLayer";
import VideoCarouselLayer from "./VideoCarouselLayer";

// Per-layer error boundary — ALWAYS renders the positioning wrapper div.
// This is critical: children use position:absolute inset:0, so they need
// a positioned parent. The boundary IS that parent.
class LayerErrorBoundary extends Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(error) { return { error }; }
  render() {
    const { style, layerType, scale = 1 } = this.props;
    const wrapperStyle = {
      ...style,
      position: "absolute",
      overflow: "hidden",
    };
    if (this.state.error) {
      return (
        <div style={{ ...wrapperStyle, background: "rgba(239,68,68,0.15)", border: "1px solid #ef4444", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4 }}>
          <span style={{ color: "#ef4444", fontSize: 11 * scale, fontFamily: "monospace", textAlign: "center", padding: "0 8px" }}>
            [{layerType}] render error
          </span>
          <span style={{ color: "#f87171", fontSize: 9 * scale, fontFamily: "monospace", textAlign: "center", padding: "0 8px" }}>
            {String(this.state.error?.message || this.state.error).slice(0, 80)}
          </span>
        </div>
      );
    }
    // Always render the positioned wrapper — children rely on it for inset:0 anchoring
    return <div style={wrapperStyle}>{this.props.children}</div>;
  }
}

export default function CanvasCreativeRenderer({ creative, scale = 1, onComplete }) {
  const syncMode = creative?.sync_mode || 'independent';
  const layers_json = creative?.layers_json || [];

  // Sync tracking refs — must be before any early return
  const layerCompletionsRef = useRef({});
  const completedOnceRef = useRef(false);

  const handleLayerComplete = useCallback((layerId) => {
    if (syncMode === 'independent' || !onComplete) return;

    layerCompletionsRef.current[layerId] = true;
    const completedIds = Object.keys(layerCompletionsRef.current);

    if (syncMode === 'shortest') {
      if (!completedOnceRef.current) {
        completedOnceRef.current = true;
        onComplete();
      }
    } else if (syncMode === 'longest') {
      // Count only cyclic layers (slideshow, video_carousel); single video/image layers always complete instantly
      const cyclicLayers = layers_json.filter(l => l.type === 'slideshow' || l.type === 'video_carousel');
      const targetCount = cyclicLayers.length > 0 ? cyclicLayers.length : layers_json.length;
      if (completedIds.length >= targetCount && !completedOnceRef.current) {
        completedOnceRef.current = true;
        onComplete();
      }
    }
  }, [syncMode, onComplete, layers_json]);

  if (!creative) return null;
  const { width, height, background_color = "#000000" } = creative;

  console.log(`[CanvasCreativeRenderer] mounting creative="${creative.name}" ${width}x${height} scale=${scale} layers=${layers_json.length}`);

  return (
    <div style={{
      position: "relative",
      width: width * scale,
      height: height * scale,
      backgroundColor: background_color,
      overflow: "hidden",
      flexShrink: 0,
    }}>
      {[...layers_json]
        .sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1))
        .map(layer => (
          <LayerErrorBoundary key={layer.id} layerType={layer.type} scale={scale} style={{
            position: "absolute",
            left: layer.x * scale,
            top: layer.y * scale,
            width: layer.width * scale,
            height: layer.height * scale,
            zIndex: layer.z_index ?? 1,
          }}>
            <LayerRenderer
              layer={layer}
              scale={scale}
              onCycleComplete={syncMode !== 'independent' ? () => handleLayerComplete(layer.id) : undefined}
            />
          </LayerErrorBoundary>
        ))}
    </div>
  );
}

// fillStyle: fills the LayerErrorBoundary container (which already handles position/size)
const FILL = { position: "absolute", inset: 0, width: "100%", height: "100%", overflow: "hidden" };

function LayerRenderer({ layer, scale, onCycleComplete }) {
  const s = scale;
  // NOTE: LayerErrorBoundary already renders position:absolute with correct coords.
  // LayerRenderer children must fill 100%x100% — do NOT re-apply absolute coords.
  const p = layer.props || {};

  console.log(`[LayerRenderer] type=${layer.type} id=${layer.id} scale=${s} props_keys=${Object.keys(p).join(",")}`);

  if (!layer.type) {
    return <div style={{ ...FILL, background: "#1e293b", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#64748b", fontSize: 10 }}>no type</span></div>;
  }

  if (layer.type === "text") {
    return (
      <div style={{
        ...FILL,
        display: "flex",
        alignItems: p.verticalAlign === "bottom" ? "flex-end" : p.verticalAlign === "middle" ? "center" : "flex-start",
        justifyContent: p.textAlign === "center" ? "center" : p.textAlign === "right" ? "flex-end" : "flex-start",
        padding: (p.padding ?? 4) * s,
        fontFamily: p.fontFamily || "sans-serif",
        fontSize: (p.fontSize ?? 24) * s,
        fontWeight: p.bold ? "bold" : "normal",
        fontStyle: p.italic ? "italic" : "normal",
        color: p.color || "#ffffff",
        lineHeight: p.lineHeight || 1.2,
        wordBreak: "break-word",
        boxSizing: "border-box",
        opacity: layer.opacity ?? 1,
        transform: layer.rotation ? `rotate(${layer.rotation}deg)` : undefined,
      }}>
        {p.text || ""}
      </div>
    );
  }

  if (layer.type === "image") {
    return (
      <div style={{ ...FILL, opacity: layer.opacity ?? 1 }}>
        {p.src
          ? <img src={p.src} alt="" style={{ width: "100%", height: "100%", objectFit: p.objectFit || "contain", display: "block" }} />
          : <div style={{ width: "100%", height: "100%", background: "#1e293b", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#64748b", fontSize: 12 * s }}>No image src</span></div>
        }
      </div>
    );
  }

  if (layer.type === "video") {
    return (
      <div style={{ ...FILL, opacity: layer.opacity ?? 1 }}>
        {p.src
          ? <video src={p.src} autoPlay loop={p.loop !== false} muted={p.muted !== false} playsInline style={{ width: "100%", height: "100%", objectFit: p.objectFit || "contain", display: "block" }} />
          : <div style={{ width: "100%", height: "100%", background: "#1e293b", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#64748b", fontSize: 12 * s }}>No video src</span></div>
        }
      </div>
    );
  }

  if (layer.type === "shape") {
    return (
      <div style={{
        ...FILL,
        backgroundColor: p.fillColor || "#3b82f6",
        borderRadius: p.borderRadius ? (p.borderRadius * s) : (p.shape === "circle" ? "50%" : 0),
        border: p.borderWidth ? `${p.borderWidth * s}px solid ${p.borderColor || "#fff"}` : undefined,
        opacity: layer.opacity ?? 1,
      }} />
    );
  }

  if (layer.type === "slideshow") {
    return <SlideshowLayer props={p} style={FILL} onCycleComplete={onCycleComplete} />;
  }

  if (layer.type === "html_widget") {
    return <HtmlWidgetLayer props={p} style={FILL} />;
  }

  if (layer.type === "weather_widget") {
    return <WeatherWidgetLayer props={p} style={FILL} scale={scale} />;
  }

  if (layer.type === "clock_widget") {
    return <ClockWidgetLayer props={p} style={FILL} />;
  }

  if (layer.type === "video_carousel") {
    return <VideoCarouselLayer props={p} style={FILL} onCycleComplete={onCycleComplete} />;
  }

  // Unrecognized type — visible purple debug box
  return (
    <div style={{ ...FILL, background: "rgba(99,102,241,0.15)", border: "1px dashed #6366f1", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <span style={{ color: "#818cf8", fontSize: 10 * s, fontFamily: "monospace" }}>unknown: {layer.type}</span>
    </div>
  );
}