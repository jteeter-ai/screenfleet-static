import { useState, useEffect, useRef, useCallback } from "react";
import { Clapperboard } from "lucide-react";

export default function VideoCarouselLayer({ props: p = {}, style = {}, onCycleComplete }) {
  const items = Array.isArray(p.items) ? p.items : [];
  const fit = p.objectFit || "cover";
  const muted = p.muted !== false;
  const loopAll = p.loop_all !== false;
  const transition = p.transition || "cut";

  const [idx, setIdx] = useState(0);
  const [visible, setVisible] = useState(true);
  const videoRef = useRef(null);
  const skipRef = useRef(false);

  const advance = useCallback(() => {
    if (items.length <= 1) {
      // Single item — one full playthrough counts as one cycle
      if (onCycleComplete) onCycleComplete();
      if (loopAll && videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch(() => {});
      }
      return;
    }
    skipRef.current = true;
    if (transition === "fade") {
      setVisible(false);
      setTimeout(() => {
        setIdx(i => {
          const next = (i + 1) % items.length;
          if (next === 0 && onCycleComplete) onCycleComplete();
          return next;
        });
        setVisible(true);
        skipRef.current = false;
      }, 400);
    } else {
      setIdx(i => {
        const next = (i + 1) % items.length;
        if (next === 0 && onCycleComplete) onCycleComplete();
        return next;
      });
      skipRef.current = false;
    }
  }, [items.length, loopAll, transition, onCycleComplete]);

  useEffect(() => { setIdx(0); }, [items.length]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = 0;
    v.play().catch(() => {});
  }, [idx]);

  const handleEnded = () => {
    if (skipRef.current) return;
    if (!loopAll && idx === items.length - 1) return;
    advance();
  };

  if (items.length === 0) {
    return (
      <div style={{ ...style, background: "#1e293b", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, overflow: "hidden" }}>
        <Clapperboard style={{ width: 24, height: 24, color: "#475569" }} />
        <span style={{ color: "#64748b", fontSize: 12 }}>No videos added</span>
      </div>
    );
  }

  const item = items[idx] || items[0];
  const fadeStyle = transition === "fade" ? { transition: "opacity 0.4s ease", opacity: visible ? 1 : 0 } : {};

  return (
    <div style={{ ...style, overflow: "hidden", background: "#000", position: style.position || "relative" }}>
      <div key={idx} style={{ width: "100%", height: "100%", ...fadeStyle }}>
        <video
          ref={videoRef}
          src={item.src}
          autoPlay
          muted={muted}
          playsInline
          loop={false}
          onEnded={handleEnded}
          onError={() => setTimeout(advance, 1500)}
          style={{ width: "100%", height: "100%", objectFit: fit, display: "block", pointerEvents: "none" }}
        />
      </div>
      {items.length > 1 && (
        <div style={{ position: "absolute", bottom: 6, right: 8, fontSize: 10, color: "rgba(255,255,255,0.6)", background: "rgba(0,0,0,0.4)", padding: "1px 5px", borderRadius: 4, pointerEvents: "none" }}>
          {idx + 1}/{items.length}
        </div>
      )}
    </div>
  );
}