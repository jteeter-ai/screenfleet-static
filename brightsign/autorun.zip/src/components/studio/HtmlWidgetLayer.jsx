/**
 * HtmlWidgetLayer — renders html_widget layers in Studio preview and Player.
 * Uses a sandboxed iframe to safely render arbitrary HTML/CSS.
 * No scripts execute unless explicitly whitelisted via allow attribute.
 */
export default function HtmlWidgetLayer({ props: p, style }) {
  const html = p?.html_content || "";
  const bg = p?.transparent ? "transparent" : (p?.background_color || "#1e293b");
  const padding = p?.padding ?? 0;
  const borderRadius = p?.border_radius ?? 0;
  const overflow = p?.overflow || "hidden";

  const fullHtml = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    width: 100%; height: 100%;
    background: ${bg};
    padding: ${padding}px;
    border-radius: ${borderRadius}px;
    overflow: ${overflow};
    font-family: sans-serif;
    color: #fff;
  }
</style>
</head>
<body>${html}</body>
</html>`;

  const blob = typeof Blob !== "undefined"
    ? URL.createObjectURL(new Blob([fullHtml], { type: "text/html" }))
    : null;

  if (!html) {
    return (
      <div style={{ ...style, background: bg, borderRadius, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <span style={{ color: "#475569", fontSize: 11, textAlign: "center", padding: 8 }}>HTML Widget<br /><span style={{ opacity: 0.5, fontSize: 9 }}>Add HTML content in properties</span></span>
      </div>
    );
  }

  return (
    <div style={{ ...style, background: bg, borderRadius, overflow: "hidden" }}>
      <iframe
        srcDoc={fullHtml}
        sandbox="allow-same-origin allow-forms"
        style={{ width: "100%", height: "100%", border: "none", background: "transparent", borderRadius }}
        title="HTML Widget"
      />
    </div>
  );
}