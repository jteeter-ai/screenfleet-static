import { Type, ImageIcon, Film, Square, Images, Code2, CloudSun, Clock, Clapperboard } from "lucide-react";

const WIDGETS = [
  { type: "text",           label: "Text",        Icon: Type,      color: "bg-blue-500",    defaultProps: { text: "Text", fontSize: 32, color: "#ffffff", bold: false, italic: false, textAlign: "left", verticalAlign: "top", padding: 8 } },
  { type: "image",          label: "Image",        Icon: ImageIcon, color: "bg-emerald-500", defaultProps: { src: "", objectFit: "contain" } },
  { type: "video",          label: "Video",        Icon: Film,      color: "bg-violet-500",  defaultProps: { src: "", objectFit: "contain", loop: true, muted: true } },
  { type: "shape",          label: "Shape",        Icon: Square,    color: "bg-slate-500",   defaultProps: { fillColor: "#3b82f6", shape: "rectangle", borderRadius: 0, borderWidth: 0, borderColor: "#ffffff" } },
  { type: "slideshow",      label: "Slideshow",    Icon: Images,    color: "bg-pink-500",    defaultProps: { slides: [], defaultDwellSeconds: 5, objectFit: "cover" } },
  { type: "video_carousel", label: "Video Carousel", Icon: Clapperboard, color: "bg-red-500", defaultProps: { items: [], objectFit: "cover", muted: true, loop_all: true, show_controls: false, transition: "cut", autoplay: true } },
  { type: "html_widget",    label: "HTML",         Icon: Code2,     color: "bg-orange-500",  defaultProps: { html_content: "<h2 style='color:#fff;font-family:sans-serif'>Hello!</h2>", background_color: "#1e293b", transparent: false, padding: 12, border_radius: 0, overflow: "hidden" } },
  { type: "weather_widget", label: "Weather",      Icon: CloudSun,  color: "bg-sky-500",     defaultProps: { location_name: "My City", latitude: null, longitude: null, units: "F", style_variant: "horizontal", show_current_temp: true, show_condition: true, show_icon: true, show_daily_forecast: true, forecast_days: 5, background_color: "rgba(10,20,40,0.92)", text_color: "#ffffff", accent_color: "#3b9eff" } },
  { type: "clock_widget",   label: "Clock",        Icon: Clock,     color: "bg-indigo-500",  defaultProps: { timezone: "local", time_format: "12h", show_seconds: true, show_ampm: true, show_date: true, date_format: "Weekday Month Day", date_position: "below", text_color: "#ffffff", background_color: "transparent", text_align: "center", font_family: "'Arial', sans-serif", font_weight: "700", font_size: null, padding: 8, border_radius: 0, border_width: 0, border_color: "rgba(255,255,255,0.2)" } },
];

export default function WidgetPanel({ onAddWidget }) {
  return (
    <div className="w-48 bg-slate-900 border-r border-slate-700 flex flex-col">
      <div className="px-3 py-3 border-b border-slate-700">
        <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Widgets</p>
      </div>
      <div className="p-2 flex-1 overflow-y-auto space-y-1">
        {WIDGETS.map(({ type, label, Icon, color, defaultProps }) => (
          <button
            key={type}
            onClick={() => onAddWidget(type, defaultProps)}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm text-slate-300 hover:bg-slate-800 hover:text-white transition-colors text-left"
          >
            <div className={`w-6 h-6 rounded flex items-center justify-center flex-shrink-0 ${color}`}>
              <Icon className="w-3.5 h-3.5 text-white" />
            </div>
            {label}
          </button>
        ))}
      </div>
      <div className="px-3 py-3 border-t border-slate-700">
        <p className="text-[10px] text-slate-500 leading-snug">Click to add a widget layer</p>
      </div>
    </div>
  );
}