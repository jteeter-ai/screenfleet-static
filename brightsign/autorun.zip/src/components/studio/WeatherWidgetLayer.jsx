/**
 * WeatherWidgetLayer — renders weather_widget layers in Studio preview and Player.
 * Optimized for large-format digital signage: all sizing is derived from the
 * actual rendered container height, not fixed px values.
 *
 * Scaling system:
 *   base      = containerHeight * 0.14
 *   currentTemp    = base * 2.2
 *   currentIcon    = base * 2.0
 *   conditionLabel = base * 0.7
 *   locationLabel  = base * 0.55
 *   dayLabel       = base * 0.65
 *   forecastIcon   = base * 1.4
 *   hiTemp         = base * 0.85
 *   loTemp         = base * 0.7
 */
import { useState, useEffect, useRef } from "react";

// SVG-based icon component — works on all browsers without emoji font support
function WeatherIcon({ code, size = 32 }) {
  const c = Math.round(size);

  // Clear / Sunny
  if (code === 0 || code === 1) return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="6" fill="#FFD700" />
      {[0,45,90,135,180,225,270,315].map(a => (
        <line key={a} x1="16" y1="4" x2="16" y2="7"
          stroke="#FFD700" strokeWidth="2" strokeLinecap="round"
          transform={`rotate(${a} 16 16)`} />
      ))}
    </svg>
  );

  // Partly Cloudy
  if (code === 2) return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <circle cx="13" cy="14" r="5" fill="#FFD700" />
      {[0,60,120,180,240,300].map(a => (
        <line key={a} x1="13" y1="5" x2="13" y2="8"
          stroke="#FFD700" strokeWidth="1.5" strokeLinecap="round"
          transform={`rotate(${a} 13 14)`} />
      ))}
      <rect x="8" y="17" width="16" height="9" rx="4.5" fill="#B0C4DE" />
      <rect x="12" y="14" width="12" height="7" rx="3.5" fill="#C8D8E8" />
    </svg>
  );

  // Overcast
  if (code === 3) return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <rect x="4" y="16" width="24" height="11" rx="5.5" fill="#8A9BB0" />
      <rect x="8" y="11" width="18" height="10" rx="5" fill="#A0B4C8" />
    </svg>
  );

  // Fog
  if (code === 45 || code === 48) return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <rect x="4" y="10" width="24" height="3" rx="1.5" fill="#A0A0A0" opacity="0.7"/>
      <rect x="6" y="15" width="20" height="3" rx="1.5" fill="#A0A0A0" opacity="0.6"/>
      <rect x="4" y="20" width="24" height="3" rx="1.5" fill="#A0A0A0" opacity="0.5"/>
    </svg>
  );

  // Rain / Drizzle / Showers (codes 51-65, 80-82)
  if ([51,53,55,61,63,65,80,81,82].includes(code)) return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <rect x="5" y="7" width="22" height="11" rx="5.5" fill="#7A9BBF" />
      <rect x="9" y="4" width="16" height="9" rx="4.5" fill="#8FB0D0" />
      {[10,16,22].map((x,i) => (
        <line key={i} x1={x} y1="21" x2={x-2} y2="28"
          stroke="#5B8DB8" strokeWidth="2" strokeLinecap="round" />
      ))}
    </svg>
  );

  // Snow (71-75)
  if ([71,73,75].includes(code)) return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <rect x="5" y="7" width="22" height="11" rx="5.5" fill="#B0C8E0" />
      {[10,16,22].map((x,i) => (
        <g key={i}>
          <circle cx={x} cy="24" r="1.5" fill="white" opacity="0.9"/>
          <line x1={x} y1="20" x2={x} y2="28" stroke="white" strokeWidth="1.5" strokeLinecap="round" opacity="0.7"/>
          <line x1={x-3} y1="22" x2={x+3} y2="26" stroke="white" strokeWidth="1" strokeLinecap="round" opacity="0.6"/>
          <line x1={x+3} y1="22" x2={x-3} y2="26" stroke="white" strokeWidth="1" strokeLinecap="round" opacity="0.6"/>
        </g>
      ))}
    </svg>
  );

  // Thunderstorm (95, 96, 99)
  if ([95,96,99].includes(code)) return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <rect x="4" y="6" width="24" height="12" rx="6" fill="#4A5568" />
      <rect x="8" y="3" width="18" height="10" rx="5" fill="#5A6478" />
      <polygon points="18,16 13,24 17,24 14,31 22,21 17,21" fill="#FFE135" />
    </svg>
  );

  // Default fallback — thermometer
  return (
    <svg width={c} height={c} viewBox="0 0 32 32" fill="none">
      <rect x="13" y="6" width="6" height="16" rx="3" fill="#C0C0C0" />
      <circle cx="16" cy="24" r="4" fill="#E05555" />
      <rect x="14" y="14" width="4" height="10" fill="#E05555" />
    </svg>
  );
}

const WMO_CODES = {
  0:  { label: "Clear" },
  1:  { label: "Mostly Clear" },
  2:  { label: "Partly Cloudy" },
  3:  { label: "Overcast" },
  45: { label: "Fog" },
  48: { label: "Icy Fog" },
  51: { label: "Drizzle" },
  53: { label: "Drizzle" },
  55: { label: "Heavy Drizzle" },
  61: { label: "Rain" },
  63: { label: "Rain" },
  65: { label: "Heavy Rain" },
  71: { label: "Snow" },
  73: { label: "Snow" },
  75: { label: "Heavy Snow" },
  80: { label: "Showers" },
  81: { label: "Showers" },
  82: { label: "Heavy Showers" },
  95: { label: "Thunderstorm" },
  96: { label: "T-Storm w/ Hail" },
  99: { label: "T-Storm w/ Hail" },
};

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function getWmo(code) {
  return WMO_CODES[code] || { label: "Unknown" };
}

function celsiusToF(c) {
  return Math.round(c * 9 / 5 + 32);
}

function formatTemp(c, units) {
  if (c == null) return "--";
  return units === "C" ? `${Math.round(c)}°` : `${celsiusToF(c)}°`;
}

// Module-level cache: key = `lat,lon,forecastDays`
const weatherCache = {};

export default function WeatherWidgetLayer({ props: p, style }) {
  const [weather, setWeather] = useState(null);
  const [error, setError]     = useState(null);
  const [dims, setDims]       = useState({ w: 0, h: 0 });
  const containerRef = useRef(null);
  const fetchingRef  = useRef(false);

  // ── Measure container for proportional scaling ──────────────────────────────
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect;
      setDims({ w: width, h: height });
    });
    ro.observe(el);
    // Initial read
    setDims({ w: el.offsetWidth, h: el.offsetHeight });
    return () => ro.disconnect();
  }, []);

  // ── Props ───────────────────────────────────────────────────────────────────
  const lat          = p?.latitude;
  const lon          = p?.longitude;
  const units        = p?.units || "F";
  const variant      = p?.style_variant || "horizontal";
  const bgColor      = p?.background_color || "rgba(10,20,40,0.92)";
  const textColor    = p?.text_color  || "#ffffff";
  const accentColor  = p?.accent_color || "#3b9eff";
  const locationName = p?.location_name || "My Location";
  const showForecast = p?.show_daily_forecast !== false;
  const forecastDays = Math.min(p?.forecast_days || 5, 7);
  const showIcon     = p?.show_icon    !== false;
  const showCondition = p?.show_condition !== false;

  // ── Fetch weather ───────────────────────────────────────────────────────────
  useEffect(() => {
    if (!lat || !lon) return;
    const cacheKey = `${lat},${lon},${forecastDays}`;
    const cached = weatherCache[cacheKey];
    if (cached && Date.now() - cached.ts < 10 * 60 * 1000) {
      setWeather(cached.data);
      return;
    }
    if (fetchingRef.current) return;
    fetchingRef.current = true;

    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&daily=temperature_2m_max,temperature_2m_min,weathercode&timezone=auto&forecast_days=${forecastDays}`;

    fetch(url)
      .then(r => r.json())
      .then(data => {
        weatherCache[cacheKey] = { data, ts: Date.now() };
        setWeather(data);
      })
      .catch(() => setError("Weather unavailable"))
      .finally(() => { fetchingRef.current = false; });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lat, lon, forecastDays]);

  // ── Proportional scale system ───────────────────────────────────────────────
  const h    = dims.h || 80;
  const w    = dims.w || 320;
  const base = Math.max(h * 0.14, 10);

  const scaleCurrentTemp  = p?.scale_current_temp  ?? 1.0;
  const scaleCurrentIcon  = p?.scale_current_icon  ?? 1.0;
  const scaleForecastIcon = p?.scale_forecast_icon ?? 1.0;
  const scaleDayLabel     = p?.scale_day_label     ?? 1.0;
  const scaleHiTemp       = p?.scale_hi_temp       ?? 1.0;
  const scaleLoTemp       = p?.scale_lo_temp       ?? 1.0;
  const scaleCondition    = p?.scale_condition      ?? 1.0;
  const scaleLocation     = p?.scale_location       ?? 1.0;

  const sz = {
    currentTemp:    base * 2.2  * scaleCurrentTemp,
    currentIcon:    base * 2.0  * scaleCurrentIcon,
    conditionLabel: base * 0.7  * scaleCondition,
    locationLabel:  base * 0.55 * scaleLocation,
    dividerLabel:   base * 0.5,
    dayLabel:       base * 0.65 * scaleDayLabel,
    forecastIcon:   base * 1.4  * scaleForecastIcon,
    hiTemp:         base * 0.85 * scaleHiTemp,
    loTemp:         base * 0.7  * scaleLoTemp,
  };

  // Shared container style
  const rootStyle = {
    ...style,
    background:  bgColor,
    overflow:    "hidden",
    fontFamily:  "'Arial', sans-serif",
    boxSizing:   "border-box",
  };

  // ── Placeholder (no location) ───────────────────────────────────────────────
  if (!lat || !lon) {
    return (
      <div ref={containerRef} style={{ ...rootStyle, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: sz.dayLabel }}>
        <WeatherIcon code={2} size={sz.currentIcon} />
        <span style={{ color: textColor, fontSize: sz.conditionLabel, opacity: 0.7, textAlign: "center" }}>
          Weather Widget
        </span>
        <span style={{ color: textColor, fontSize: sz.locationLabel, opacity: 0.4, textAlign: "center" }}>
          Set location in properties
        </span>
      </div>
    );
  }

  // ── Error ───────────────────────────────────────────────────────────────────
  if (error) {
    return (
      <div ref={containerRef} style={{ ...rootStyle, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <span style={{ color: textColor, opacity: 0.5, fontSize: sz.conditionLabel, textAlign: "center" }}>{error}</span>
      </div>
    );
  }

  // ── Loading ─────────────────────────────────────────────────────────────────
  if (!weather) {
    return (
      <div ref={containerRef} style={{ ...rootStyle, display: "flex", alignItems: "center", justifyContent: "center", gap: base }}>
        <WeatherIcon code={2} size={sz.currentIcon} />
        <span style={{ color: textColor, opacity: 0.5, fontSize: sz.conditionLabel }}>Loading…</span>
      </div>
    );
  }

  const current    = weather.current_weather || {};
  const daily      = weather.daily || {};
  const currentWmo = getWmo(current.weathercode);
  const currentTemp = formatTemp(current.temperature, units);

  // ════════════════════════════════════════════════════════════════════════════
  // HORIZONTAL STRIP
  // ════════════════════════════════════════════════════════════════════════════
  if (variant === "horizontal") {
    return (
      <div ref={containerRef} style={{ ...rootStyle, display: "flex", alignItems: "stretch", width: "100%", height: "100%" }}>

        {/* ── Current weather panel ── */}
        <div style={{
          display:        "flex",
          flexDirection:  "column",
          alignItems:     "center",
          justifyContent: "center",
          padding:        `0 ${base * 1.2}px`,
          borderRight:    "1px solid rgba(255,255,255,0.12)",
          flexShrink:     0,
          gap:            base * 0.2,
          minWidth:       w * 0.22,
        }}>
          {showIcon && (
            <WeatherIcon code={current.weathercode} size={sz.currentIcon} />
          )}
          <div style={{
            color:      textColor,
            fontSize:   sz.currentTemp,
            fontWeight: 800,
            lineHeight: 1,
            letterSpacing: "-0.02em",
          }}>
            {currentTemp}
          </div>
          {showCondition && (
            <div style={{ color: accentColor, fontSize: sz.conditionLabel, fontWeight: 600, textAlign: "center" }}>
              {currentWmo.label}
            </div>
          )}
          <div style={{ color: textColor, fontSize: sz.locationLabel, opacity: 0.55, textAlign: "center", marginTop: base * 0.1 }}>
            {locationName}
          </div>
        </div>

        {/* ── Daily forecast columns ── */}
        {showForecast && daily.time && (
          <div style={{ display: "flex", flex: 1, alignItems: "stretch" }}>
            {daily.time.slice(0, forecastDays).map((dateStr, i) => {
              const dayName = i === 0 ? "Today" : DAYS[new Date(dateStr + "T12:00:00").getDay()];
              const hi = formatTemp(daily.temperature_2m_max?.[i], units);
              const lo = formatTemp(daily.temperature_2m_min?.[i], units);
              const wmo = getWmo(daily.weathercode?.[i]);
              return (
                <div
                  key={i}
                  style={{
                    flex:           1,
                    display:        "flex",
                    flexDirection:  "column",
                    alignItems:     "center",
                    justifyContent: "center",
                    borderRight:    i < forecastDays - 1 ? "1px solid rgba(255,255,255,0.07)" : undefined,
                    padding:        `${base * 0.3}px ${base * 0.2}px`,
                    gap:            base * 0.15,
                  }}
                >
                  {/* Day label */}
                  <div style={{
                    color:       textColor,
                    fontSize:    sz.dayLabel,
                    fontWeight:  700,
                    opacity:     0.7,
                    textTransform: "uppercase",
                    letterSpacing: "0.04em",
                  }}>
                    {dayName}
                  </div>

                  {/* Icon */}
                  {showIcon && (
                    <WeatherIcon code={daily.weathercode?.[i]} size={sz.forecastIcon} />
                  )}

                  {/* High temp */}
                  <div style={{
                    color:      textColor,
                    fontSize:   sz.hiTemp,
                    fontWeight: 700,
                    lineHeight: 1,
                  }}>
                    {hi}
                  </div>

                  {/* Low temp */}
                  <div style={{
                    color:      accentColor,
                    fontSize:   sz.loTemp,
                    opacity:    0.85,
                    fontWeight: 500,
                  }}>
                    {lo}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════════════════════
  // COMPACT CARD
  // ════════════════════════════════════════════════════════════════════════════
  return (
    <div ref={containerRef} style={{ ...rootStyle, display: "flex", flexDirection: "column", padding: `${base * 0.6}px ${base * 0.8}px`, gap: base * 0.4, width: "100%", height: "100%", boxSizing: "border-box" }}>

      {/* Header: temp + icon */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flex: "0 0 auto" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: base * 0.15 }}>
          <div style={{ color: textColor, fontSize: sz.locationLabel, opacity: 0.6, fontWeight: 500 }}>
            {locationName}
          </div>
          <div style={{ color: textColor, fontSize: sz.currentTemp, fontWeight: 800, lineHeight: 1, letterSpacing: "-0.02em" }}>
            {currentTemp}
          </div>
          {showCondition && (
            <div style={{ color: accentColor, fontSize: sz.conditionLabel, fontWeight: 600 }}>
              {currentWmo.label}
            </div>
          )}
        </div>
        {showIcon && (
          <WeatherIcon code={current.weathercode} size={sz.currentIcon} />
        )}
      </div>

      {/* Forecast row */}
      {showForecast && daily.time && (
        <>
          <div style={{ height: 1, background: "rgba(255,255,255,0.12)", flexShrink: 0 }} />
          <div style={{ display: "flex", flex: 1, alignItems: "stretch", gap: 0 }}>
            {daily.time.slice(0, Math.min(forecastDays, 5)).map((dateStr, i) => {
              const dayName = i === 0 ? "Today" : DAYS[new Date(dateStr + "T12:00:00").getDay()];
              const hi = formatTemp(daily.temperature_2m_max?.[i], units);
              const lo = formatTemp(daily.temperature_2m_min?.[i], units);
              return (
                <div key={i} style={{
                  flex:           1,
                  display:        "flex",
                  flexDirection:  "column",
                  alignItems:     "center",
                  justifyContent: "center",
                  gap:            base * 0.12,
                  borderRight:    i < forecastDays - 1 ? "1px solid rgba(255,255,255,0.07)" : undefined,
                }}>
                  <div style={{ color: textColor, fontSize: sz.dayLabel, opacity: 0.6, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em" }}>
                    {dayName}
                  </div>
                  {showIcon && <WeatherIcon code={daily.weathercode?.[i]} size={sz.forecastIcon} />}
                  <div style={{ color: textColor, fontSize: sz.hiTemp, fontWeight: 700, lineHeight: 1 }}>{hi}</div>
                  <div style={{ color: accentColor, fontSize: sz.loTemp, opacity: 0.8, fontWeight: 500 }}>{lo}</div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}