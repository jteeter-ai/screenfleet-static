import { useRef, useEffect, useCallback } from "react";
import { Type, ImageIcon, Film, Square, Images, Cpu, Code2, CloudSun, Clapperboard } from "lucide-react";
import SlideshowLayer from "./SlideshowLayer";
import VideoCarouselLayer from "./VideoCarouselLayer";
import HtmlWidgetLayer from "./HtmlWidgetLayer";
import WeatherWidgetLayer from "./WeatherWidgetLayer";
import ClockWidgetLayer from "./ClockWidgetLayer";

import { Clock } from "lucide-react";
const LAYER_ICONS = { text: Type, image: ImageIcon, video: Film, shape: Square, slideshow: Images, hdmi_input: Cpu, html_widget: Code2, weather_widget: CloudSun, clock_widget: Clock, video_carousel: Clapperboard };
const HANDLE_SIZE = 8;

export default function CanvasArea({ creative, selectedId, onSelectLayer, onUpdateLayer, scale = 1 }) {
  const { width, height, background_color = "#000000", layers_json = [] } = creative;
  const dragState = useRef(null);
  const canvasRef = useRef(null);

  const getLayerById = useCallback((id) => layers_json.find(l => l.id === id), [layers_json]);

  const onMouseDown = (e, layerId, mode) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    e.preventDefault();
    const layer = getLayerById(layerId);
    if (!layer || layer.locked) return;
    onSelectLayer(layerId);
    dragState.current = {
      mode,
      layerId,
      startX: e.clientX,
      startY: e.clientY,
      origX: layer.x,
      origY: layer.y,
      origW: layer.width,
      origH: layer.height,
    };
  };

  useEffect(() => {
    const onMouseMove = (e) => {
      if (!dragState.current) return;
      const { mode, layerId, startX, startY, origX, origY, origW, origH } = dragState.current;
      const dx = (e.clientX - startX) / scale;
      const dy = (e.clientY - startY) / scale;

      if (mode === "drag") {
        onUpdateLayer(layerId, { x: Math.round(origX + dx), y: Math.round(origY + dy) });
      } else if (mode === "resize-se") {
        onUpdateLayer(layerId, { width: Math.max(20, Math.round(origW + dx)), height: Math.max(20, Math.round(origH + dy)) });
      } else if (mode === "resize-e") {
        onUpdateLayer(layerId, { width: Math.max(20, Math.round(origW + dx)) });
      } else if (mode === "resize-s") {
        onUpdateLayer(layerId, { height: Math.max(20, Math.round(origH + dy)) });
      }
    };
    const onMouseUp = () => { dragState.current = null; };
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => { window.removeEventListener("mousemove", onMouseMove); window.removeEventListener("mouseup", onMouseUp); };
  }, [scale, onUpdateLayer]);

  const sorted = [...layers_json].sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1));

  return (
    <div
      ref={canvasRef}
      style={{ position: "relative", width: width * scale, height: height * scale, backgroundColor: background_color, flexShrink: 0, cursor: "default" }}
      onMouseDown={() => onSelectLayer(null)}
    >
      {sorted.filter(l => l.visible !== false).map(layer => {
        const isSelected = layer.id === selectedId;
        const isHdmi = layer.type === "hdmi_input";
        const Icon = LAYER_ICONS[layer.type] || Square;
        const borderStyle = isHdmi
          ? (isSelected ? "2px solid #d97706" : "2px dashed #92400e")
          : (isSelected ? "2px solid #3b82f6" : "1px dashed #475569");
        return (
          <div key={layer.id} style={{ position: "absolute", left: layer.x * scale, top: layer.y * scale, width: layer.width * scale, height: layer.height * scale, zIndex: layer.z_index ?? 1, opacity: layer.opacity ?? 1, transform: layer.rotation ? `rotate(${layer.rotation}deg)` : undefined, cursor: isHdmi ? "default" : (layer.locked ? "not-allowed" : "move"), boxSizing: "border-box", border: borderStyle, overflow: "hidden" }}
            onMouseDown={(e) => onMouseDown(e, layer.id, "drag")}
          >
            <LayerPreview layer={layer} scale={scale} />

            {/* Selection label */}
            {isSelected && (
              <div style={{ position: "absolute", top: -20, left: 0, background: isHdmi ? "#d97706" : "#3b82f6", color: "#fff", fontSize: 10, padding: "1px 5px", borderRadius: 3, whiteSpace: "nowrap", pointerEvents: "none", zIndex: 9999 }}>
                <Icon style={{ display: "inline", width: 10, height: 10, marginRight: 3 }} />{isHdmi ? "HDMI Input" : layer.type}
              </div>
            )}

            {/* Resize handles */}
            {isSelected && !layer.locked && (
              <>
                <div onMouseDown={(e) => onMouseDown(e, layer.id, "resize-e")}
                  style={{ position: "absolute", right: -HANDLE_SIZE/2, top: "50%", transform: "translateY(-50%)", width: HANDLE_SIZE, height: HANDLE_SIZE, background: "#fff", border: "1px solid #3b82f6", borderRadius: 2, cursor: "e-resize", zIndex: 10000 }} />
                <div onMouseDown={(e) => onMouseDown(e, layer.id, "resize-s")}
                  style={{ position: "absolute", bottom: -HANDLE_SIZE/2, left: "50%", transform: "translateX(-50%)", width: HANDLE_SIZE, height: HANDLE_SIZE, background: "#fff", border: "1px solid #3b82f6", borderRadius: 2, cursor: "s-resize", zIndex: 10000 }} />
                <div onMouseDown={(e) => onMouseDown(e, layer.id, "resize-se")}
                  style={{ position: "absolute", bottom: -HANDLE_SIZE/2, right: -HANDLE_SIZE/2, width: HANDLE_SIZE, height: HANDLE_SIZE, background: "#3b82f6", border: "1px solid #fff", borderRadius: 2, cursor: "se-resize", zIndex: 10000 }} />
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}

function LayerPreview({ layer, scale }) {
  const s = scale;
  const p = layer.props || {};

  if (layer.type === "text") {
    return (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: p.verticalAlign === "bottom" ? "flex-end" : p.verticalAlign === "middle" ? "center" : "flex-start", justifyContent: p.textAlign === "center" ? "center" : p.textAlign === "right" ? "flex-end" : "flex-start", padding: (p.padding ?? 8) * s, fontFamily: p.fontFamily || "sans-serif", fontSize: (p.fontSize ?? 32) * s, fontWeight: p.bold ? "bold" : "normal", fontStyle: p.italic ? "italic" : "normal", color: p.color || "#ffffff", lineHeight: p.lineHeight || 1.2, wordBreak: "break-word", boxSizing: "border-box", pointerEvents: "none" }}>
        {p.text || <span style={{ opacity: 0.4 }}>Text</span>}
      </div>
    );
  }
  if (layer.type === "image") {
    return p.src
      ? <img src={p.src} alt="" style={{ width: "100%", height: "100%", objectFit: p.objectFit || "contain", pointerEvents: "none" }} />
      : <div style={{ width: "100%", height: "100%", background: "#1e293b", display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}><ImageIcon style={{ width: 20 * s, height: 20 * s, color: "#475569" }} /></div>;
  }
  if (layer.type === "video") {
    return p.src
      ? <video src={p.src} autoPlay loop={p.loop !== false} muted={p.muted !== false} playsInline style={{ width: "100%", height: "100%", objectFit: p.objectFit || "contain", pointerEvents: "none" }} />
      : <div style={{ width: "100%", height: "100%", background: "#1e293b", display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}><Film style={{ width: 20 * s, height: 20 * s, color: "#475569" }} /></div>;
  }
  if (layer.type === "shape") {
    return (
      <div style={{ width: "100%", height: "100%", backgroundColor: p.fillColor || "#3b82f6", borderRadius: p.borderRadius ? (p.borderRadius * s) : (p.shape === "circle" ? "50%" : 0), border: p.borderWidth ? `${p.borderWidth * s}px solid ${p.borderColor || "#fff"}` : undefined, pointerEvents: "none" }} />
    );
  }
  if (layer.type === "slideshow") {
    return <SlideshowLayer props={p} style={{ position: "relative", width: "100%", height: "100%" }} />;
  }
  if (layer.type === "video_carousel") {
    return <VideoCarouselLayer props={p} style={{ position: "relative", width: "100%", height: "100%" }} />;
  }
  if (layer.type === "hdmi_input") {
    return (
      <div style={{ width: "100%", height: "100%", background: "rgba(120,53,15,0.35)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", pointerEvents: "none", gap: 6 }}>
        <Cpu style={{ width: 28 * scale, height: 28 * scale, color: "#f59e0b", flexShrink: 0 }} />
        <div style={{ textAlign: "center", lineHeight: 1.3 }}>
          <div style={{ fontSize: 11 * scale, fontWeight: 700, color: "#fbbf24", letterSpacing: 0.5 }}>HDMI Input</div>
          <div style={{ fontSize: 9 * scale, color: "#92400e", marginTop: 2 }}>BrightSign XT hardware only</div>
          <div style={{ fontSize: 8 * scale, color: "#78350f", marginTop: 1 }}>Browser: placeholder only</div>
        </div>
      </div>
    );
  }
  if (layer.type === "html_widget") {
    return (
      <div style={{ width: "100%", height: "100%", pointerEvents: "none" }}>
        <HtmlWidgetLayer props={layer.props} style={{ position: "relative", width: "100%", height: "100%" }} />
      </div>
    );
  }
  if (layer.type === "weather_widget") {
    return (
      <div style={{ width: "100%", height: "100%", pointerEvents: "none" }}>
        <WeatherWidgetLayer props={layer.props} style={{ position: "relative", width: "100%", height: "100%" }} scale={scale} />
      </div>
    );
  }
  if (layer.type === "clock_widget") {
    return (
      <div style={{ width: "100%", height: "100%", pointerEvents: "none" }}>
        <ClockWidgetLayer props={layer.props} style={{ position: "relative", width: "100%", height: "100%" }} />
      </div>
    );
  }
  return null;
}