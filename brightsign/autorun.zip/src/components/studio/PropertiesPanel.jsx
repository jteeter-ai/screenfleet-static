import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Lock, Unlock, ChevronUp, ChevronDown, X, GripVertical, Cpu } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useState, useRef } from "react";

export default function PropertiesPanel({ creative, selectedLayer, onUpdateLayer, onDeleteLayer, onUpdateCreative, onReorderLayer }) {
  if (!selectedLayer) {
    return (
      <div className="w-64 bg-slate-900 border-l border-slate-700 flex flex-col">
        <div className="px-3 py-3 border-b border-slate-700">
          <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Canvas</p>
        </div>
        <div className="p-3 space-y-3">
          <Field label="Background Color">
            <div className="flex gap-2 items-center">
              <input type="color" value={creative.background_color || "#000000"}
                onChange={(e) => onUpdateCreative({ background_color: e.target.value })}
                className="w-8 h-8 rounded cursor-pointer border border-slate-600" />
              <Input value={creative.background_color || "#000000"}
                onChange={(e) => onUpdateCreative({ background_color: e.target.value })}
                className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
            </div>
          </Field>
          <Field label="Canvas Size">
            <div className="flex gap-1 items-center">
              <Input type="number" value={creative.width} onChange={(e) => onUpdateCreative({ width: Number(e.target.value) })} className="h-7 text-xs bg-slate-800 border-slate-600 text-white w-20" />
              <span className="text-slate-500 text-xs">×</span>
              <Input type="number" value={creative.height} onChange={(e) => onUpdateCreative({ height: Number(e.target.value) })} className="h-7 text-xs bg-slate-800 border-slate-600 text-white w-20" />
            </div>
          </Field>
        </div>
        <div className="mt-auto p-3 border-t border-slate-700">
          <p className="text-[10px] text-slate-500">Select a widget to edit its properties</p>
        </div>
      </div>
    );
  }

  // HDMI Input: show dedicated hardware source panel, no media controls
  if (selectedLayer.type === "hdmi_input") {
    const update = (field, value) => onUpdateLayer(selectedLayer.id, { [field]: value });
    const hdmiProps = selectedLayer.props || {};
    const updateHdmiProp = (key, value) => onUpdateLayer(selectedLayer.id, { props: { ...hdmiProps, [key]: value } });
    const audioOutput = hdmiProps.audioOutput || 'aux';
    const audioLabel = audioOutput === 'both' ? 'AnalogAudio + HDMI' : audioOutput === 'hdmi' ? 'HDMI' : 'AnalogAudio (Aux)';
    return (
      <div className="w-64 bg-slate-900 border-l border-slate-700 flex flex-col overflow-y-auto">
        <div className="px-3 py-3 border-b border-amber-800/40 bg-amber-950/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <p className="text-[10px] font-semibold text-amber-400 uppercase tracking-widest">HDMI Input Zone</p>
          </div>
          <Button variant="ghost" size="icon" className="h-6 w-6 text-red-400 hover:text-red-300"
            onClick={() => onDeleteLayer(selectedLayer.id)}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>

        <div className="p-3 space-y-4">
          {/* Zone name */}
          <Section label="Zone Name">
            <input
              type="text"
              value={selectedLayer.name || "HDMI Feed"}
              onChange={(e) => onUpdateLayer(selectedLayer.id, { name: e.target.value })}
              placeholder="Zone name…"
              className="w-full h-7 text-xs bg-slate-800 border border-slate-600 text-white rounded px-2"
            />
          </Section>

          {/* Hardware notice */}
          <div className="rounded-lg border border-amber-800/40 bg-amber-950/20 p-3 space-y-1.5">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              <span className="text-xs font-semibold text-amber-300">Hardware Source</span>
            </div>
            <p className="text-[10px] text-amber-500/80 leading-relaxed">
              Driven by the device's physical HDMI In port at runtime.
            </p>
            <p className="text-[10px] text-slate-500 leading-relaxed">
              Requires BrightSign XT series (XT1144/XT1145/XT244/XT245). Browser preview shows placeholder only.
            </p>
          </div>

          {/* Audio Output Selector */}
          <Section label="Audio Output">
            <Select value={audioOutput} onValueChange={(v) => updateHdmiProp('audioOutput', v)}>
              <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="aux">Aux (AnalogAudio)</SelectItem>
                <SelectItem value="hdmi">HDMI Out</SelectItem>
                <SelectItem value="both">Both (Aux + HDMI)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[9px] text-slate-500 mt-1">
              BrightScript: SetPcmAudioOutputs([{'{'}AudioOutput: "{audioLabel}"{'}'}])
            </p>
            {audioOutput === 'aux' && (
              <p className="text-[9px] text-amber-600/80 mt-0.5">Compressed (AC3/DTS) passthrough not supported on analog — PCM only.</p>
            )}
          </Section>

          {/* Zone position/size - still editable to define BrightScript rectangle */}
          <Section label="Zone Rectangle">
            <p className="text-[9px] text-slate-500 mb-1.5">Defines the roVideoPlayer.SetRectangle() values sent to BrightSign at runtime.</p>
            <div className="grid grid-cols-2 gap-1.5">
              <Field label="X"><Input type="number" value={selectedLayer.x} onChange={(e) => update("x", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
              <Field label="Y"><Input type="number" value={selectedLayer.y} onChange={(e) => update("y", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
              <Field label="W"><Input type="number" min="1" value={selectedLayer.width} onChange={(e) => update("width", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
              <Field label="H"><Input type="number" min="1" value={selectedLayer.height} onChange={(e) => update("height", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
            </div>
          </Section>

          {/* Runtime info */}
          <Section label="Runtime Info">
            <div className="space-y-1 text-[10px] text-slate-400">
              <div className="flex justify-between"><span>Connector</span><span className="text-slate-300">HDMI In (port 0)</span></div>
              <div className="flex justify-between"><span>API object</span><span className="text-slate-300">roVideoPlayer</span></div>
              <div className="flex justify-between"><span>PCM outputs</span><span className="text-slate-300">{audioLabel}</span></div>
              <div className="flex justify-between"><span>Compressed</span><span className="text-slate-300">{audioOutput === 'aux' ? 'Not routed' : audioOutput === 'hdmi' ? 'HDMI' : 'HDMI'}</span></div>
              <div className="flex justify-between"><span>Multi-zone</span><span className="text-amber-400">One source only</span></div>
            </div>
          </Section>
        </div>
      </div>
    );
  }

  const p = selectedLayer.props || {};
  const update = (field, value) => onUpdateLayer(selectedLayer.id, { [field]: value });
  const updateProp = (key, value) => onUpdateLayer(selectedLayer.id, { props: { ...p, [key]: value } });

  const handleMediaUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      updateProp("src", file_url);
    } catch (err) {
      toast.error("Upload failed");
    }
  };

  return (
    <div className="w-64 bg-slate-900 border-l border-slate-700 flex flex-col overflow-y-auto">
      <div className="px-3 py-3 border-b border-slate-700 flex items-center justify-between">
        <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest capitalize">{selectedLayer.type}</p>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-white"
            onClick={() => onReorderLayer(selectedLayer.id, "up")} title="Bring forward">
            <ChevronUp className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-white"
            onClick={() => onReorderLayer(selectedLayer.id, "down")} title="Send backward">
            <ChevronDown className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-white"
            onClick={() => update("locked", !selectedLayer.locked)} title={selectedLayer.locked ? "Unlock" : "Lock"}>
            {selectedLayer.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6 text-red-400 hover:text-red-300"
            onClick={() => onDeleteLayer(selectedLayer.id)}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      <div className="p-3 space-y-3 flex-1">
        {/* Layer name */}
        <Section label="Name">
          <input
            type="text"
            value={selectedLayer.name || ""}
            onChange={(e) => onUpdateLayer(selectedLayer.id, { name: e.target.value })}
            placeholder={selectedLayer.type}
            className="w-full h-7 text-xs bg-slate-800 border border-slate-600 text-white rounded px-2"
          />
        </Section>

        {/* Position & Size */}
        <Section label="Position & Size">
          <div className="grid grid-cols-2 gap-1.5">
            <Field label="X"><Input type="number" value={selectedLayer.x} onChange={(e) => update("x", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
            <Field label="Y"><Input type="number" value={selectedLayer.y} onChange={(e) => update("y", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
            <Field label="W"><Input type="number" min="1" value={selectedLayer.width} onChange={(e) => update("width", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
            <Field label="H"><Input type="number" min="1" value={selectedLayer.height} onChange={(e) => update("height", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
            <Field label="Rotation"><Input type="number" value={selectedLayer.rotation || 0} onChange={(e) => update("rotation", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
            <Field label="Opacity"><Input type="number" min="0" max="1" step="0.05" value={selectedLayer.opacity ?? 1} onChange={(e) => update("opacity", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
          </div>
        </Section>

        {/* Text props */}
        {selectedLayer.type === "text" && (
          <Section label="Text">
            <Field label="Content">
              <textarea value={p.text || ""} onChange={(e) => updateProp("text", e.target.value)}
                className="w-full text-xs bg-slate-800 border border-slate-600 text-white rounded p-2 min-h-[60px] resize-none" />
            </Field>
            <Field label="Font Size"><Input type="number" min="8" value={p.fontSize ?? 32} onChange={(e) => updateProp("fontSize", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" /></Field>
            <Field label="Color">
              <div className="flex gap-2 items-center">
                <input type="color" value={p.color || "#ffffff"} onChange={(e) => updateProp("color", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
                <Input value={p.color || "#ffffff"} onChange={(e) => updateProp("color", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
              </div>
            </Field>
            <Field label="Align">
              <Select value={p.textAlign || "left"} onValueChange={(v) => updateProp("textAlign", v)}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="left">Left</SelectItem><SelectItem value="center">Center</SelectItem><SelectItem value="right">Right</SelectItem></SelectContent>
              </Select>
            </Field>
            <div className="flex gap-2">
              <button onClick={() => updateProp("bold", !p.bold)} className={`flex-1 py-1 rounded text-xs border transition-colors ${p.bold ? "bg-blue-600 border-blue-500 text-white" : "bg-slate-800 border-slate-600 text-slate-300"}`}>B</button>
              <button onClick={() => updateProp("italic", !p.italic)} className={`flex-1 py-1 rounded text-xs border transition-colors italic ${p.italic ? "bg-blue-600 border-blue-500 text-white" : "bg-slate-800 border-slate-600 text-slate-300"}`}>I</button>
            </div>
          </Section>
        )}

        {/* Image props */}
        {selectedLayer.type === "image" && (
          <Section label="Image">
            <Field label="Source">
              {p.src ? <img src={p.src} alt="" className="w-full rounded border border-slate-600 max-h-20 object-contain mb-2 bg-slate-800" /> : null}
              <label className="block w-full py-1.5 px-2 rounded border border-slate-600 text-xs text-slate-300 cursor-pointer hover:bg-slate-800 text-center">
                Upload Image
                <input type="file" accept="image/*" className="hidden" onChange={handleMediaUpload} />
              </label>
            </Field>
            <Field label="Fit">
              <Select value={p.objectFit || "contain"} onValueChange={(v) => updateProp("objectFit", v)}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="contain">Contain</SelectItem><SelectItem value="cover">Cover</SelectItem><SelectItem value="fill">Stretch</SelectItem></SelectContent>
              </Select>
            </Field>
          </Section>
        )}

        {/* Video props */}
        {selectedLayer.type === "video" && (
          <Section label="Video">
            <Field label="Source">
              <label className="block w-full py-1.5 px-2 rounded border border-slate-600 text-xs text-slate-300 cursor-pointer hover:bg-slate-800 text-center">
                {p.src ? "Replace Video" : "Upload Video"}
                <input type="file" accept="video/*" className="hidden" onChange={handleMediaUpload} />
              </label>
              {p.src && <p className="text-[10px] text-slate-400 mt-1 truncate">{p.src.split("/").pop()}</p>}
            </Field>
            <Field label="Fit">
              <Select value={p.objectFit || "contain"} onValueChange={(v) => updateProp("objectFit", v)}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="contain">Contain</SelectItem><SelectItem value="cover">Cover</SelectItem><SelectItem value="fill">Stretch</SelectItem></SelectContent>
              </Select>
            </Field>
            <div className="flex gap-2 mt-1">
              <label className="flex items-center gap-1.5 text-xs text-slate-400 cursor-pointer">
                <input type="checkbox" checked={p.loop !== false} onChange={(e) => updateProp("loop", e.target.checked)} className="accent-blue-500" /> Loop
              </label>
              <label className="flex items-center gap-1.5 text-xs text-slate-400 cursor-pointer">
                <input type="checkbox" checked={p.muted !== false} onChange={(e) => updateProp("muted", e.target.checked)} className="accent-blue-500" /> Muted
              </label>
            </div>
          </Section>
        )}

        {/* Shape props */}
        {selectedLayer.type === "shape" && (
          <Section label="Shape">
            <Field label="Fill Color">
              <div className="flex gap-2 items-center">
                <input type="color" value={p.fillColor || "#3b82f6"} onChange={(e) => updateProp("fillColor", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
                <Input value={p.fillColor || "#3b82f6"} onChange={(e) => updateProp("fillColor", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
              </div>
            </Field>
            <Field label="Shape">
              <Select value={p.shape || "rectangle"} onValueChange={(v) => updateProp("shape", v)}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="rectangle">Rectangle</SelectItem><SelectItem value="circle">Circle</SelectItem></SelectContent>
              </Select>
            </Field>
            <Field label="Border Radius">
              <Input type="number" min="0" value={p.borderRadius || 0} onChange={(e) => updateProp("borderRadius", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
            </Field>
            <Field label="Border Width">
              <Input type="number" min="0" value={p.borderWidth || 0} onChange={(e) => updateProp("borderWidth", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
            </Field>
            {(p.borderWidth > 0) && (
              <Field label="Border Color">
                <div className="flex gap-2 items-center">
                  <input type="color" value={p.borderColor || "#ffffff"} onChange={(e) => updateProp("borderColor", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
                  <Input value={p.borderColor || "#ffffff"} onChange={(e) => updateProp("borderColor", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
                </div>
              </Field>
            )}
          </Section>
        )}

        {/* Slideshow props */}
        {selectedLayer.type === "slideshow" && (
          <SlideshowProps p={p} updateProp={updateProp} selectedLayer={selectedLayer} onUpdateLayer={onUpdateLayer} />
        )}

        {/* Video Carousel props */}
        {selectedLayer.type === "video_carousel" && (
          <VideoCarouselProps p={p} updateProp={updateProp} selectedLayer={selectedLayer} onUpdateLayer={onUpdateLayer} />
        )}

        {/* HTML Widget props */}
        {selectedLayer.type === "html_widget" && (
          <HtmlWidgetProps p={p} updateProp={updateProp} />
        )}

        {/* Weather Widget props */}
        {selectedLayer.type === "weather_widget" && (
          <WeatherWidgetProps p={p} updateProp={updateProp} selectedLayer={selectedLayer} onUpdateLayer={onUpdateLayer} />
        )}

        {/* Clock Widget props */}
        {selectedLayer.type === "clock_widget" && (
          <ClockWidgetProps p={p} updateProp={updateProp} />
        )}
      </div>
    </div>
  );
}

/** Normalize legacy slides → items */
function getItems(p) {
  if (Array.isArray(p.items) && p.items.length > 0) return p.items;
  if (Array.isArray(p.slides) && p.slides.length > 0) {
    return p.slides.map(s => ({ id: s.id, mediaType: "image", src: s.src, name: s.name, dwellSeconds: s.dwellSeconds ?? null, dwellMode: "fixed" }));
  }
  return [];
}

function isVideo(file) {
  return file.type.startsWith("video/");
}

function SlideshowProps({ p, updateProp, selectedLayer, onUpdateLayer }) {
  const items = getItems(p);
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  // CRITICAL: must be a single onUpdateLayer call — two separate updateProp calls
  // each spread from the same stale `p` snapshot and the second overwrites the first.
  const setItems = (newItems) => {
    onUpdateLayer(selectedLayer.id, {
      props: { ...p, items: newItems, slides: undefined },
    });
  };

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploading(true);
    try {
      const uploaded = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          const vid = isVideo(file);
          return {
            id: `item_${Date.now()}_${Math.random().toString(36).slice(2)}`,
            mediaType: vid ? "video" : "image",
            src: file_url,
            name: file.name,
            dwellSeconds: vid ? null : null,
            dwellMode: vid ? "video_length" : "fixed",
          };
        })
      );
      setItems([...items, ...uploaded]);
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const removeItem = (id) => setItems(items.filter(s => s.id !== id));

  const moveItem = (id, dir) => {
    const arr = [...items];
    const i = arr.findIndex(s => s.id === id);
    if (i < 0) return;
    const j = i + dir;
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    setItems(arr);
  };

  const updateItem = (id, key, value) => {
    setItems(items.map(s => s.id === id ? { ...s, [key]: value } : s));
  };

  return (
    <>
      <Section label="Slideshow">
        <Field label="Default Dwell (sec)">
          <Input type="number" min="1" max="300" value={p.defaultDwellSeconds ?? 5}
            onChange={(e) => updateProp("defaultDwellSeconds", Math.max(1, Number(e.target.value)))}
            className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        <Field label="Fit">
          <Select value={p.objectFit || "cover"} onValueChange={(v) => updateProp("objectFit", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="cover">Cover</SelectItem>
              <SelectItem value="contain">Contain</SelectItem>
              <SelectItem value="fill">Stretch</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Transition">
          <Select value={p.transition || "cut"} onValueChange={(v) => updateProp("transition", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="cut">Cut</SelectItem>
              <SelectItem value="fade">Fade</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <div className="flex flex-col gap-1 mt-1">
          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
            <input type="checkbox" checked={p.muteVideos !== false} onChange={(e) => updateProp("muteVideos", e.target.checked)} className="accent-blue-500" />
            Mute videos
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
            <input type="checkbox" checked={p.loopVideos === true} onChange={(e) => updateProp("loopVideos", e.target.checked)} className="accent-blue-500" />
            Loop single video
          </label>
        </div>
      </Section>

      <Section label={`Playlist (${items.length})`}>
        <label className={`block w-full py-1.5 px-2 rounded border border-slate-600 text-xs text-center cursor-pointer transition-colors ${uploading ? "opacity-50 pointer-events-none" : "text-slate-300 hover:bg-slate-800"}`}>
          {uploading ? "Uploading..." : items.length === 0 ? "Upload Media" : "Add Media"}
          <input ref={fileInputRef} type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp,video/mp4,video/webm,video/quicktime"
            multiple className="hidden" onChange={handleUpload} disabled={uploading} />
        </label>

        {items.length === 0 && (
          <p className="text-[10px] text-slate-500 text-center mt-1">No media yet — upload images or videos</p>
        )}

        <div className="space-y-1.5 mt-1">
          {items.map((item, i) => (
            <div key={item.id} className="bg-slate-800 rounded border border-slate-700 p-1.5">
              <div className="flex items-center gap-1.5">
                {item.mediaType === "video" ? (
                  <div className="w-10 h-7 flex-shrink-0 bg-slate-700 rounded flex items-center justify-center">
                    <span className="text-[9px] text-slate-400">▶</span>
                  </div>
                ) : (
                  <img src={item.src} alt="" className="w-10 h-7 object-cover rounded flex-shrink-0 bg-slate-700" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] text-slate-300 truncate">{item.name || `Item ${i + 1}`}</div>
                  <span className={`text-[9px] font-medium px-1 rounded ${item.mediaType === "video" ? "text-violet-400" : "text-emerald-400"}`}>
                    {item.mediaType}
                  </span>
                </div>
                <div className="flex gap-0.5">
                  <button onClick={() => moveItem(item.id, -1)} disabled={i === 0} className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-white disabled:opacity-30">
                    <ChevronUp className="w-3 h-3" />
                  </button>
                  <button onClick={() => moveItem(item.id, 1)} disabled={i === items.length - 1} className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-white disabled:opacity-30">
                    <ChevronDown className="w-3 h-3" />
                  </button>
                  <button onClick={() => removeItem(item.id)} className="w-5 h-5 flex items-center justify-center text-red-400 hover:text-red-300">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Per-item controls */}
              {item.mediaType === "image" && (
                <div className="mt-1 flex items-center gap-1">
                  <span className="text-[9px] text-slate-500">Dwell (sec)</span>
                  <Input type="number" min="1" max="300" placeholder={String(p.defaultDwellSeconds ?? 5)}
                    value={item.dwellSeconds ?? ""}
                    onChange={(e) => updateItem(item.id, "dwellSeconds", e.target.value === "" ? null : Math.max(1, Number(e.target.value)))}
                    className="h-5 text-[10px] bg-slate-700 border-slate-600 text-white w-14" />
                </div>
              )}

              {item.mediaType === "video" && (
                <div className="mt-1 space-y-1">
                  <div className="flex items-center gap-1">
                    <span className="text-[9px] text-slate-500">Duration</span>
                    <select
                      value={item.dwellMode || "video_length"}
                      onChange={(e) => updateItem(item.id, "dwellMode", e.target.value)}
                      className="flex-1 h-5 text-[9px] bg-slate-700 border border-slate-600 text-white rounded px-1"
                    >
                      <option value="video_length">Full video</option>
                      <option value="fixed">Fixed time</option>
                    </select>
                  </div>
                  {item.dwellMode === "fixed" && (
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-slate-500">Sec</span>
                      <Input type="number" min="1" max="300" placeholder={String(p.defaultDwellSeconds ?? 5)}
                        value={item.dwellSeconds ?? ""}
                        onChange={(e) => updateItem(item.id, "dwellSeconds", e.target.value === "" ? null : Math.max(1, Number(e.target.value)))}
                        className="h-5 text-[10px] bg-slate-700 border-slate-600 text-white w-14" />
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

function Section({ label, children }) {
  return (
    <div className="space-y-2">
      <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest">{label}</p>
      {children}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <Label className="text-[10px] text-slate-500 mb-0.5 block">{label}</Label>
      {children}
    </div>
  );
}

// ─── Video Carousel Properties ────────────────────────────────────────────────
function VideoCarouselProps({ p, updateProp, selectedLayer, onUpdateLayer }) {
  const items = Array.isArray(p.items) ? p.items : [];
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const setItems = (newItems) => {
    onUpdateLayer(selectedLayer.id, { props: { ...p, items: newItems } });
  };

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files || []).filter(f => f.type.startsWith("video/"));
    if (!files.length) return;
    setUploading(true);
    try {
      const uploaded = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          return {
            id: `vid_${Date.now()}_${Math.random().toString(36).slice(2)}`,
            src: file_url,
            name: file.name,
          };
        })
      );
      setItems([...items, ...uploaded]);
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const removeItem = (id) => setItems(items.filter(v => v.id !== id));
  const moveItem = (id, dir) => {
    const arr = [...items];
    const i = arr.findIndex(v => v.id === id);
    if (i < 0) return;
    const j = i + dir;
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    setItems(arr);
  };

  return (
    <>
      <Section label="Playback">
        <Field label="Fit">
          <Select value={p.objectFit || "cover"} onValueChange={(v) => updateProp("objectFit", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="cover">Cover</SelectItem>
              <SelectItem value="contain">Contain</SelectItem>
              <SelectItem value="fill">Stretch</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Transition">
          <Select value={p.transition || "cut"} onValueChange={(v) => updateProp("transition", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="cut">Cut</SelectItem>
              <SelectItem value="fade">Fade</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <div className="space-y-1 mt-1">
          {[
            ["muted", "Mute audio"],
            ["loop_all", "Loop playlist"],
          ].map(([key, label]) => (
            <label key={key} className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
              <input type="checkbox" checked={p[key] !== false} onChange={(e) => updateProp(key, e.target.checked)} className="accent-blue-500" />
              {label}
            </label>
          ))}
        </div>
      </Section>

      <Section label={`Videos (${items.length})`}>
        <label className={`block w-full py-1.5 px-2 rounded border border-slate-600 text-xs text-center cursor-pointer transition-colors ${uploading ? "opacity-50 pointer-events-none" : "text-slate-300 hover:bg-slate-800"}`}>
          {uploading ? "Uploading..." : items.length === 0 ? "Upload Videos" : "Add Videos"}
          <input ref={fileInputRef} type="file" accept="video/mp4,video/webm,video/quicktime,video/mov" multiple className="hidden" onChange={handleUpload} disabled={uploading} />
        </label>
        <div className="space-y-1 mt-1">
          {items.map((item, i) => (
            <div key={item.id} className="flex items-center gap-1 bg-slate-800 rounded px-2 py-1">
              <span className="text-[10px] text-slate-400 w-4 shrink-0">{i + 1}</span>
              <span className="flex-1 text-xs text-slate-300 truncate">{item.name || "Video"}</span>
              <button onClick={() => moveItem(item.id, -1)} disabled={i === 0} className="text-slate-500 hover:text-white disabled:opacity-20 px-0.5">↑</button>
              <button onClick={() => moveItem(item.id, 1)} disabled={i === items.length - 1} className="text-slate-500 hover:text-white disabled:opacity-20 px-0.5">↓</button>
              <button onClick={() => removeItem(item.id)} className="text-red-400 hover:text-red-300 px-0.5">×</button>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

// ─── HTML Widget Properties ───────────────────────────────────────────────────
function HtmlWidgetProps({ p, updateProp }) {
  return (
    <>
      <Section label="HTML Content">
        <Field label="HTML / CSS">
          <textarea
            value={p.html_content || ""}
            onChange={(e) => updateProp("html_content", e.target.value)}
            placeholder="<h1 style='color:white'>Hello</h1>"
            className="w-full text-xs bg-slate-800 border border-slate-600 text-white rounded p-2 min-h-[100px] resize-none font-mono"
          />
          <p className="text-[9px] text-slate-500 mt-1">Inline HTML + CSS. No external scripts. Sandboxed iframe.</p>
        </Field>
      </Section>
      <Section label="Appearance">
        <Field label="Background Color">
          <div className="flex gap-2 items-center">
            <input type="color" value={p.background_color || "#1e293b"} onChange={(e) => updateProp("background_color", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
            <Input value={p.background_color || "#1e293b"} onChange={(e) => updateProp("background_color", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
          </div>
        </Field>
        <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
          <input type="checkbox" checked={!!p.transparent} onChange={(e) => updateProp("transparent", e.target.checked)} className="accent-blue-500" />
          Transparent Background
        </label>
        <Field label="Padding (px)">
          <Input type="number" min="0" value={p.padding ?? 0} onChange={(e) => updateProp("padding", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        <Field label="Border Radius (px)">
          <Input type="number" min="0" value={p.border_radius ?? 0} onChange={(e) => updateProp("border_radius", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        <Field label="Overflow">
          <Select value={p.overflow || "hidden"} onValueChange={(v) => updateProp("overflow", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="hidden">Hidden</SelectItem>
              <SelectItem value="auto">Scroll</SelectItem>
              <SelectItem value="visible">Visible</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      </Section>
    </>
  );
}

// ─── Clock Widget Properties ──────────────────────────────────────────────────
const CLOCK_TIMEZONES = [
  { value: "local",                  label: "Local (device)" },
  { value: "America/New_York",       label: "Eastern (ET)" },
  { value: "America/Chicago",        label: "Central (CT)" },
  { value: "America/Denver",         label: "Mountain (MT)" },
  { value: "America/Los_Angeles",    label: "Pacific (PT)" },
  { value: "America/Phoenix",        label: "Arizona (MST)" },
  { value: "America/Anchorage",      label: "Alaska (AKT)" },
  { value: "Pacific/Honolulu",       label: "Hawaii (HST)" },
  { value: "Europe/London",          label: "London (GMT/BST)" },
  { value: "Europe/Paris",           label: "Paris (CET)" },
  { value: "Europe/Berlin",          label: "Berlin (CET)" },
  { value: "Europe/Moscow",          label: "Moscow (MSK)" },
  { value: "Asia/Dubai",             label: "Dubai (GST)" },
  { value: "Asia/Kolkata",           label: "India (IST)" },
  { value: "Asia/Singapore",         label: "Singapore (SGT)" },
  { value: "Asia/Tokyo",             label: "Tokyo (JST)" },
  { value: "Australia/Sydney",       label: "Sydney (AEST)" },
  { value: "Pacific/Auckland",       label: "Auckland (NZST)" },
];

const DATE_FORMATS = [
  "Weekday Month Day",
  "Weekday",
  "Month Day",
  "Mon DD",
  "Mon DD, YYYY",
  "MM/DD/YYYY",
  "DD/MM/YYYY",
  "YYYY-MM-DD",
];

const FONT_FAMILIES = [
  { value: "'Arial', sans-serif",           label: "Arial" },
  { value: "'Helvetica Neue', sans-serif",  label: "Helvetica Neue" },
  { value: "'Georgia', serif",              label: "Georgia" },
  { value: "'Times New Roman', serif",      label: "Times New Roman" },
  { value: "'Courier New', monospace",      label: "Courier New (Mono)" },
  { value: "'Trebuchet MS', sans-serif",    label: "Trebuchet MS" },
  { value: "'Verdana', sans-serif",         label: "Verdana" },
  { value: "'Impact', sans-serif",          label: "Impact" },
];

function ClockWidgetProps({ p, updateProp }) {
  return (
    <>
      <Section label="Time">
        <Field label="Timezone">
          <Select value={p.timezone || "local"} onValueChange={(v) => updateProp("timezone", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              {CLOCK_TIMEZONES.map(tz => (
                <SelectItem key={tz.value} value={tz.value}>{tz.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Format">
          <Select value={p.time_format || "12h"} onValueChange={(v) => updateProp("time_format", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="12h">12-hour (1:00 PM)</SelectItem>
              <SelectItem value="24h">24-hour (13:00)</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <div className="space-y-1">
          {[
            ["show_seconds", "Show Seconds"],
            ...(p.time_format !== "24h" ? [["show_ampm", "Show AM/PM"]] : []),
          ].map(([key, label]) => (
            <label key={key} className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
              <input type="checkbox" checked={p[key] !== false} onChange={(e) => updateProp(key, e.target.checked)} className="accent-blue-500" />
              {label}
            </label>
          ))}
        </div>
      </Section>

      <Section label="Date">
        <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
          <input type="checkbox" checked={p.show_date !== false} onChange={(e) => updateProp("show_date", e.target.checked)} className="accent-blue-500" />
          Show Date
        </label>
        {p.show_date !== false && (
          <>
            <Field label="Date Format">
              <Select value={p.date_format || "Weekday Month Day"} onValueChange={(v) => updateProp("date_format", v)}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {DATE_FORMATS.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Date Position">
              <Select value={p.date_position || "below"} onValueChange={(v) => updateProp("date_position", v)}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="above">Above time</SelectItem>
                  <SelectItem value="below">Below time</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </>
        )}
      </Section>

      <Section label="Typography">
        <Field label="Font Family">
          <Select value={p.font_family || "'Arial', sans-serif"} onValueChange={(v) => updateProp("font_family", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              {FONT_FAMILIES.map(f => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Font Weight">
          <Select value={p.font_weight || "700"} onValueChange={(v) => updateProp("font_weight", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="300">Light (300)</SelectItem>
              <SelectItem value="400">Regular (400)</SelectItem>
              <SelectItem value="600">Semi-Bold (600)</SelectItem>
              <SelectItem value="700">Bold (700)</SelectItem>
              <SelectItem value="800">Extra Bold (800)</SelectItem>
              <SelectItem value="900">Black (900)</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Font Size (px, 0 = auto)">
          <Input type="number" min="0" value={p.font_size || ""} placeholder="Auto (container %)"
            onChange={(e) => updateProp("font_size", Number(e.target.value) || null)}
            className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        <Field label="Text Align">
          <Select value={p.text_align || "center"} onValueChange={(v) => updateProp("text_align", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="left">Left</SelectItem>
              <SelectItem value="center">Center</SelectItem>
              <SelectItem value="right">Right</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      </Section>

      <Section label="Colors">
        <Field label="Text Color">
          <div className="flex gap-2 items-center">
            <input type="color" value={p.text_color || "#ffffff"} onChange={(e) => updateProp("text_color", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
            <Input value={p.text_color || "#ffffff"} onChange={(e) => updateProp("text_color", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
          </div>
        </Field>
        <Field label="Background">
          <Input value={p.background_color || "transparent"} onChange={(e) => updateProp("background_color", e.target.value)} placeholder="transparent or rgba()" className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
      </Section>

      <Section label="Layout">
        <Field label="Padding (px)">
          <Input type="number" min="0" value={p.padding ?? 8} onChange={(e) => updateProp("padding", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        <Field label="Border Radius (px)">
          <Input type="number" min="0" value={p.border_radius ?? 0} onChange={(e) => updateProp("border_radius", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        <Field label="Border Width (px)">
          <Input type="number" min="0" value={p.border_width ?? 0} onChange={(e) => updateProp("border_width", Number(e.target.value))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        {(p.border_width > 0) && (
          <Field label="Border Color">
            <div className="flex gap-2 items-center">
              <input type="color" value={p.border_color || "#ffffff"} onChange={(e) => updateProp("border_color", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
              <Input value={p.border_color || "#ffffff"} onChange={(e) => updateProp("border_color", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
            </div>
          </Field>
        )}
      </Section>
    </>
  );
}

// ─── Weather Widget Properties ────────────────────────────────────────────────
function WeatherWidgetProps({ p, updateProp, selectedLayer, onUpdateLayer }) {
  const [geocoding, setGeocoding] = useState(false);
  const [cityInput, setCityInput] = useState(p.location_name || "");

  const resolveCity = async () => {
    if (!cityInput.trim()) return;
    setGeocoding(true);
    try {
      const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(cityInput)}&format=json&limit=1`;
      const res = await fetch(url, { headers: { "Accept-Language": "en" } });
      const data = await res.json();
      if (data[0]) {
        // CRITICAL: single updateProp call — multiple separate calls each spread from
        // the same stale `p` snapshot and the last one overwrites all the others.
        onUpdateLayer(selectedLayer.id, {
          props: {
            ...p,
            latitude: parseFloat(data[0].lat),
            longitude: parseFloat(data[0].lon),
            location_name: cityInput.trim(),
          },
        });
        toast.success(`Location set: ${data[0].display_name.split(",")[0]}`);
      } else {
        toast.error("Location not found");
      }
    } catch {
      toast.error("Geocoding failed");
    } finally {
      setGeocoding(false);
    }
  };

  return (
    <>
      <Section label="Location">
        <Field label="City / Address">
          <div className="flex gap-1">
            <Input
              value={cityInput}
              onChange={(e) => setCityInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") resolveCity(); }}
              placeholder="e.g. Des Moines, IA"
              className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1"
            />
            <Button size="sm" variant="outline" className="h-7 text-xs px-2 border-slate-600 text-slate-300 hover:text-white" onClick={resolveCity} disabled={geocoding}>
              {geocoding ? "…" : "Set"}
            </Button>
          </div>
          <p className="text-[9px] text-slate-500 mt-1">Press Set or Enter to resolve coordinates</p>
        </Field>
        <div className="grid grid-cols-2 gap-1.5">
          <Field label="Latitude">
            <Input type="number" step="0.0001" value={p.latitude || ""} onChange={(e) => updateProp("latitude", parseFloat(e.target.value) || null)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
          </Field>
          <Field label="Longitude">
            <Input type="number" step="0.0001" value={p.longitude || ""} onChange={(e) => updateProp("longitude", parseFloat(e.target.value) || null)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
          </Field>
        </div>
      </Section>

      <Section label="Display">
        <Field label="Style">
          <Select value={p.style_variant || "horizontal"} onValueChange={(v) => updateProp("style_variant", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="horizontal">Horizontal Strip</SelectItem>
              <SelectItem value="card">Compact Card</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Units">
          <Select value={p.units || "F"} onValueChange={(v) => updateProp("units", v)}>
            <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-600 text-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="F">Fahrenheit (°F)</SelectItem>
              <SelectItem value="C">Celsius (°C)</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Forecast Days">
          <Input type="number" min="1" max="7" value={p.forecast_days || 5} onChange={(e) => updateProp("forecast_days", Math.min(7, Math.max(1, Number(e.target.value))))} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" />
        </Field>
        <div className="space-y-1">
          {[
            ["show_icon", "Show Icons"],
            ["show_condition", "Show Condition Label"],
            ["show_daily_forecast", "Show Daily Forecast"],
          ].map(([key, label]) => (
            <label key={key} className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
              <input type="checkbox" checked={p[key] !== false} onChange={(e) => updateProp(key, e.target.checked)} className="accent-blue-500" />
              {label}
            </label>
          ))}
        </div>
      </Section>

      <Section label="Colors">
        <Field label="Background">
          <Input value={p.background_color || "rgba(10,20,40,0.92)"} onChange={(e) => updateProp("background_color", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white" placeholder="rgba() or hex" />
        </Field>
        <Field label="Text Color">
          <div className="flex gap-2 items-center">
            <input type="color" value={p.text_color || "#ffffff"} onChange={(e) => updateProp("text_color", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
            <Input value={p.text_color || "#ffffff"} onChange={(e) => updateProp("text_color", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
          </div>
        </Field>
        <Field label="Accent Color">
          <div className="flex gap-2 items-center">
            <input type="color" value={p.accent_color || "#3b9eff"} onChange={(e) => updateProp("accent_color", e.target.value)} className="w-7 h-7 rounded cursor-pointer border border-slate-600" />
            <Input value={p.accent_color || "#3b9eff"} onChange={(e) => updateProp("accent_color", e.target.value)} className="h-7 text-xs bg-slate-800 border-slate-600 text-white flex-1" />
          </div>
        </Field>
      </Section>

      <Section label="Font & Icon Scale">
        <p className="text-[9px] text-slate-500 mb-2">
          1.0 = default. Increase to make larger, decrease to make smaller.
        </p>
        {[
          ["scale_current_temp",  "Current Temp Size"],
          ["scale_current_icon",  "Current Icon Size"],
          ["scale_forecast_icon", "Forecast Icon Size"],
          ["scale_day_label",     "Day of Week Size"],
          ["scale_hi_temp",       "High Temp Size"],
          ["scale_lo_temp",       "Low Temp Size"],
          ["scale_condition",     "Condition Label Size"],
          ["scale_location",      "Location Label Size"],
        ].map(([key, label]) => (
          <Field key={key} label={label}>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="0.4"
                max="2.5"
                step="0.05"
                value={p[key] ?? 1.0}
                onChange={(e) => updateProp(key, parseFloat(e.target.value))}
                className="flex-1 accent-blue-500"
              />
              <span className="text-xs text-slate-300 w-8 text-right">
                {(p[key] ?? 1.0).toFixed(2)}
              </span>
            </div>
          </Field>
        ))}
      </Section>
    </>
  );
}