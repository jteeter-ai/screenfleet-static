import { useState } from "react";
import { ChevronUp, ChevronDown, Eye, EyeOff, Lock, Unlock, Type, ImageIcon, Film, Square, Images, Pencil, Code2, CloudSun, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";

const TYPE_META = {
  text:           { label: "Text",      color: "bg-blue-500",    Icon: Type      },
  image:          { label: "Image",     color: "bg-emerald-500", Icon: ImageIcon },
  video:          { label: "Video",     color: "bg-violet-500",  Icon: Film      },
  shape:          { label: "Shape",     color: "bg-slate-500",   Icon: Square    },
  slideshow:      { label: "Slideshow", color: "bg-pink-500",    Icon: Images    },
  html_widget:    { label: "HTML",      color: "bg-orange-500",  Icon: Code2     },
  weather_widget: { label: "Weather",   color: "bg-sky-500",     Icon: CloudSun  },
  clock_widget:   { label: "Clock",     color: "bg-indigo-500",  Icon: Clock     },
};

export default function ZoneLayersPanel({ layers, selectedId, onSelect, onReorder, onToggleVisible, onToggleLock, onRename }) {
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");

  function startRename(e, layer) {
    e.stopPropagation();
    setEditingId(layer.id);
    setEditName(layer.name || "");
  }

  function commitRename(id) {
    if (editName.trim()) onRename(id, editName.trim());
    setEditingId(null);
  }

  // Descending z_index = top of stack shows first — exclude any legacy hdmi_input layers
  const sorted = [...layers]
    .filter(l => l.type !== 'hdmi_input')
    .sort((a, b) => (b.z_index ?? 1) - (a.z_index ?? 1));


  function LayerRow({ layer, i, totalInGroup }) {
    const meta = TYPE_META[layer.type] || { label: layer.type, color: "bg-slate-500", Icon: Square };
    const isSelected = layer.id === selectedId;
    const isVisible  = layer.visible !== false;
    const displayName = layer.name || meta.label;
    // For reorder: use global sorted index
    const globalIdx = sorted.findIndex(l => l.id === layer.id);
    const isFirst = globalIdx === 0;
    const isLast  = globalIdx === sorted.length - 1;

    return (
      <div
        key={layer.id}
        onClick={() => onSelect(layer.id)}
        className={`flex items-center gap-1.5 px-2 py-1.5 rounded-md cursor-pointer transition-colors group border ${
          isSelected ? "bg-blue-900/40 border-blue-700/50" : "hover:bg-slate-800 border-transparent"
        } ${!isVisible ? "opacity-40" : ""}`}
      >
        {/* Type icon */}
        <div className={`w-5 h-5 rounded flex items-center justify-center flex-shrink-0 ${meta.color}`}>
          <meta.Icon className="w-3 h-3 text-white" />
        </div>

        {/* Name + meta */}
        <div className="flex-1 min-w-0">
          {editingId === layer.id ? (
            <Input
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              onBlur={() => commitRename(layer.id)}
              onKeyDown={(e) => {
                if (e.key === "Enter") commitRename(layer.id);
                if (e.key === "Escape") setEditingId(null);
              }}
              className="h-5 text-[10px] bg-slate-700 border-slate-600 text-white px-1"
              autoFocus
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <span className="text-[11px] text-slate-200 truncate leading-tight">{displayName}</span>
          )}
          <div className="text-[9px] text-slate-500 leading-tight">{meta.label} · z{layer.z_index ?? 1}</div>
        </div>

        {/* Controls — visible on hover */}
        <div
          className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={(e) => startRename(e, layer)}
            className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-white"
            title="Rename"
          >
            <Pencil className="w-2.5 h-2.5" />
          </button>
          <button
            onClick={() => onToggleVisible(layer.id)}
            className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-white"
            title={isVisible ? "Hide" : "Show"}
          >
            {isVisible ? <Eye className="w-2.5 h-2.5" /> : <EyeOff className="w-2.5 h-2.5" />}
          </button>
          <button
            onClick={() => onToggleLock(layer.id)}
            className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-white"
            title={layer.locked ? "Unlock" : "Lock"}
          >
            {layer.locked ? <Lock className="w-2.5 h-2.5" /> : <Unlock className="w-2.5 h-2.5" />}
          </button>
          <button
            onClick={() => onReorder(layer.id, "up")}
            disabled={isFirst}
            className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-white disabled:opacity-20"
            title="Bring forward"
          >
            <ChevronUp className="w-2.5 h-2.5" />
          </button>
          <button
            onClick={() => onReorder(layer.id, "down")}
            disabled={isLast}
            className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-white disabled:opacity-20"
            title="Send backward"
          >
            <ChevronDown className="w-2.5 h-2.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-52 bg-slate-900 border-r border-slate-700 flex flex-col">
      <div className="px-3 py-2.5 border-b border-slate-700 flex items-center justify-between flex-shrink-0">
        <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Zone Layers</p>
        <span className="text-[10px] text-slate-600">{layers.length}</span>
      </div>

      <div className="flex-1 overflow-y-auto p-1.5">
        {sorted.length === 0 && (
          <p className="text-[10px] text-slate-600 text-center py-6">No layers yet.<br />Add a widget from the panel.</p>
        )}
        <div className="space-y-0.5">
          {sorted.map((layer, i) => (
            <LayerRow key={layer.id} layer={layer} i={i} totalInGroup={sorted.length} />
          ))}
        </div>
      </div>

      <div className="px-3 py-2 border-t border-slate-700 flex-shrink-0">
        <p className="text-[9px] text-slate-600 leading-snug">Higher z = in front · Hover row for controls</p>
      </div>
    </div>
  );
}