/**
 * SlideshowLayer — mixed media playlist widget renderer.
 * Handles images and videos in a single layer, with dwell timing and fade transitions.
 * Used in CanvasArea (Studio editor) and CanvasCreativeRenderer (Live Output / player).
 *
 * Backward compatible: if props contain `slides` (old format), they are normalized to `items`.
 */
import { useState, useEffect, useRef, useCallback } from "react";
import { Images } from "lucide-react";

/** Normalize legacy `slides` array → `items` with mediaType: "image" */
function normalizeItems(p) {
  if (Array.isArray(p.items) && p.items.length > 0) return p.items;
  if (Array.isArray(p.slides) && p.slides.length > 0) {
    return p.slides.map(s => ({
      id: s.id,
      mediaType: "image",
      src: s.src,
      name: s.name,
      dwellSeconds: s.dwellSeconds ?? null,
      dwellMode: "fixed",
    }));
  }
  return [];
}

export default function SlideshowLayer({ props: p = {}, style = {}, onCycleComplete }) {
  const items = normalizeItems(p);
  const defaultDwell = Math.max(1, p.defaultDwellSeconds ?? 5);
  const fit = p.objectFit || "cover";
  const muteVideos = p.muteVideos !== false;
  const loopVideos = p.loopVideos === true;
  const transition = p.transition || "cut"; // "cut" | "fade"

  const [idx, setIdx] = useState(0);
  const [visible, setVisible] = useState(true); // for fade
  const timerRef = useRef(null);
  const videoRef = useRef(null);
  const skipRef = useRef(false); // prevent double-advance

  const advance = useCallback(() => {
    if (items.length <= 1) {
      // Single item — one full playthrough counts as one cycle
      if (onCycleComplete) onCycleComplete();
      return;
    }
    if (transition === "fade") {
      setVisible(false);
      setTimeout(() => {
        setIdx(i => {
          const next = (i + 1) % items.length;
          if (next === 0 && onCycleComplete) onCycleComplete();
          return next;
        });
        setVisible(true);
      }, 300);
    } else {
      setIdx(i => {
        const next = (i + 1) % items.length;
        if (next === 0 && onCycleComplete) onCycleComplete();
        return next;
      });
    }
  }, [items.length, transition, onCycleComplete]);

  // Schedule advance for current item
  useEffect(() => {
    if (items.length <= 1) return;
    skipRef.current = false;
    clearTimeout(timerRef.current);

    const item = items[idx];
    if (!item) return;

    if (item.mediaType === "video" && item.dwellMode !== "fixed") {
      // Advance is triggered by onEnded — no timer needed unless video fails
      timerRef.current = setTimeout(advance, 60000); // safety fallback 60s
    } else {
      const dwell = Math.max(1, item.dwellSeconds ?? defaultDwell) * 1000;
      timerRef.current = setTimeout(advance, dwell);
    }

    return () => clearTimeout(timerRef.current);
  }, [idx, items.length, advance, defaultDwell]);

  // Reset to 0 when items array changes length
  useEffect(() => { setIdx(0); }, [items.length]);

  if (items.length === 0) {
    return (
      <div style={{ ...style, background: "#1e293b", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, overflow: "hidden", position: style.position || "absolute" }}>
        <Images style={{ width: 24, height: 24, color: "#475569" }} />
        <span style={{ color: "#64748b", fontSize: 12 }}>No media added</span>
      </div>
    );
  }

  const item = items[idx] || items[0];
  const fadeStyle = transition === "fade"
    ? { transition: "opacity 0.3s ease", opacity: visible ? 1 : 0 }
    : {};

  const handleVideoEnded = () => {
    if (skipRef.current) return;
    skipRef.current = true;
    clearTimeout(timerRef.current);
    advance();
  };

  const handleVideoError = () => {
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(advance, 1500);
  };

  const handleImgError = (e) => {
    e.target.style.display = "none";
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(advance, 1500);
  };

  return (
    <div style={{ ...style, overflow: "hidden", background: "#000" }}>
      <div key={item.id} style={{ width: "100%", height: "100%", ...fadeStyle }}>
        {item.mediaType === "video" ? (
          <video
            ref={videoRef}
            src={item.src}
            autoPlay
            muted={muteVideos}
            loop={loopVideos && items.length === 1}
            playsInline
            onEnded={item.dwellMode !== "fixed" ? handleVideoEnded : undefined}
            onError={handleVideoError}
            style={{ width: "100%", height: "100%", objectFit: fit, display: "block", pointerEvents: "none" }}
          />
        ) : (
          <img
            src={item.src}
            alt={item.name || ""}
            onError={handleImgError}
            style={{ width: "100%", height: "100%", objectFit: fit, display: "block", pointerEvents: "none" }}
          />
        )}
      </div>

      {items.length > 1 && (
        <div style={{ position: "absolute", bottom: 6, right: 8, fontSize: 10, color: "rgba(255,255,255,0.6)", background: "rgba(0,0,0,0.4)", padding: "1px 5px", borderRadius: 4, pointerEvents: "none" }}>
          {idx + 1}/{items.length}
        </div>
      )}
    </div>
  );
}