/**
 * ClockWidgetLayer — live digital clock widget for Studio and Player.
 * Optimized for large-format digital signage.
 *
 * Scaling system (container-height-based):
 *   base      = containerHeight * 0.30  (clamped to font_size if set)
 *   timeSize  = base
 *   dateSize  = base * 0.30
 *   ampmSize  = base * 0.28
 */
import { useState, useEffect, useRef } from "react";

const TIMEZONES = [
  "local",
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Phoenix",
  "America/Anchorage",
  "Pacific/Honolulu",
  "Europe/London",
  "Europe/Paris",
  "Europe/Berlin",
  "Europe/Moscow",
  "Asia/Dubai",
  "Asia/Kolkata",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Australia/Sydney",
  "Pacific/Auckland",
];

function formatDate(date, fmt) {
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const shortMonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  const d = date.getDate();
  const m = date.getMonth();
  const y = date.getFullYear();
  const dow = date.getDay();
  const mm = String(m + 1).padStart(2, "0");
  const dd = String(d).padStart(2, "0");

  switch (fmt) {
    case "MM/DD/YYYY":     return `${mm}/${dd}/${y}`;
    case "DD/MM/YYYY":     return `${dd}/${mm}/${y}`;
    case "YYYY-MM-DD":     return `${y}-${mm}-${dd}`;
    case "Month Day":      return `${months[m]} ${d}`;
    case "Mon DD":         return `${shortMonths[m]} ${d}`;
    case "Weekday Month Day": return `${days[dow]}, ${months[m]} ${d}`;
    case "Weekday":        return days[dow];
    case "Mon DD, YYYY":   return `${shortMonths[m]} ${d}, ${y}`;
    default:               return `${mm}/${dd}/${y}`;
  }
}

function getDateInTz(tz) {
  if (!tz || tz === "local") return new Date();
  try {
    // Use Intl to get parts in the target timezone, then build a Date
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
      hour12: false,
    }).formatToParts(new Date());
    const get = (type) => parts.find(p => p.type === type)?.value;
    const iso = `${get("year")}-${get("month")}-${get("day")}T${get("hour")}:${get("minute")}:${get("second")}`;
    return new Date(iso);
  } catch {
    return new Date();
  }
}

export default function ClockWidgetLayer({ props: p, style }) {
  const [now, setNow] = useState(() => new Date());
  const [dims, setDims] = useState({ w: 0, h: 0 });
  const containerRef = useRef(null);

  // Live clock tick
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Measure container for proportional scaling
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect;
      setDims({ w: width, h: height });
    });
    ro.observe(el);
    setDims({ w: el.offsetWidth, h: el.offsetHeight });
    return () => ro.disconnect();
  }, []);

  // Props with defaults
  const timezone      = p?.timezone     || "local";
  const timeFormat    = p?.time_format  || "12h";
  const showSeconds   = p?.show_seconds !== false;
  const showAmPm      = p?.show_ampm    !== false;
  const showDate      = p?.show_date    !== false;
  const dateFormat    = p?.date_format  || "Weekday Month Day";
  const datePosition  = p?.date_position || "below";
  const textColor     = p?.text_color   || "#ffffff";
  const secondsColor  = p?.seconds_color || textColor;
  const bgColor       = p?.background_color || "transparent";
  const textAlign     = p?.text_align   || "center";
  const fontFamily    = p?.font_family  || "'Arial', sans-serif";
  const fontWeight    = p?.font_weight  || "700";
  const padding       = p?.padding      ?? 0;
  const borderRadius  = p?.border_radius ?? 0;
  const borderWidth   = p?.border_width  ?? 0;
  const borderColor   = p?.border_color  || "rgba(255,255,255,0.2)";
  const manualFontSize = p?.font_size    || null;

  // Proportional scaling from container height
  const h = dims.h || 120;
  const base = manualFontSize || Math.max(h * 0.30, 14);
  const timeSize = base;
  const dateSize = Math.max(base * 0.28, 12);
  const ampmSize = Math.max(base * 0.28, 12);
  const secsSize = Math.max(base * 0.42, 12);

  // Compute time in target timezone
  const displayDate = getDateInTz(timezone);

  let hours = displayDate.getHours();
  const minutes = String(displayDate.getMinutes()).padStart(2, "0");
  const seconds = String(displayDate.getSeconds()).padStart(2, "0");
  let ampm = "";

  if (timeFormat === "12h") {
    ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12 || 12;
  }
  const hoursStr = String(hours).padStart(timeFormat === "24h" ? 2 : 0, "0");
  const timeStr = showSeconds ? `${hoursStr}:${minutes}:${seconds}` : `${hoursStr}:${minutes}`;
  const dateStr = showDate ? formatDate(displayDate, dateFormat) : null;

  const alignItems = textAlign === "center" ? "center" : textAlign === "right" ? "flex-end" : "flex-start";
  const justifyContent = "center";

  const rootStyle = {
    ...style,
    background:   bgColor,
    borderRadius: borderRadius,
    border:       borderWidth > 0 ? `${borderWidth}px solid ${borderColor}` : undefined,
    overflow:     "hidden",
    padding:      padding,
    boxSizing:    "border-box",
    display:      "flex",
    flexDirection: "column",
    alignItems,
    justifyContent,
    fontFamily,
    userSelect:   "none",
  };

  const dateBlock = dateStr ? (
    <div style={{
      color:      textColor,
      fontSize:   dateSize,
      fontWeight: "500",
      opacity:    0.75,
      lineHeight: 1.2,
      textAlign,
      letterSpacing: "0.02em",
    }}>
      {dateStr}
    </div>
  ) : null;

  return (
    <div ref={containerRef} style={rootStyle}>
      {datePosition === "above" && dateBlock}

      {/* Time row */}
      <div style={{ display: "flex", alignItems: "baseline", gap: base * 0.08, lineHeight: 1 }}>
        <span style={{
          color:       textColor,
          fontSize:    timeSize,
          fontWeight,
          letterSpacing: "-0.03em",
          lineHeight:  1,
          fontVariantNumeric: "tabular-nums",
        }}>
          {showSeconds
            ? `${hoursStr}:${minutes}:`
            : `${hoursStr}:${minutes}`
          }
        </span>
        {showSeconds && (
          <span style={{
            color:       secondsColor,
            fontSize:    secsSize,
            fontWeight,
            opacity:     0.8,
            letterSpacing: "-0.02em",
            lineHeight:  1,
            fontVariantNumeric: "tabular-nums",
            alignSelf:   "baseline",
            paddingBottom: base * 0.02,
          }}>
            {seconds}
          </span>
        )}
        {timeFormat === "12h" && showAmPm && (
          <span style={{
            color:       textColor,
            fontSize:    ampmSize,
            fontWeight:  "600",
            opacity:     0.7,
            lineHeight:  1,
            alignSelf:   "flex-end",
            paddingBottom: base * 0.04,
            letterSpacing: "0.03em",
          }}>
            {ampm}
          </span>
        )}
      </div>

      {datePosition !== "above" && dateBlock}
    </div>
  );
}

export { TIMEZONES, formatDate };