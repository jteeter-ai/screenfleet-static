/**
 * Shared V2 Runtime Canvas
 * Used by both /player and /ScreenPlayer routes.
 * Renders RuntimeZone.playback_track.items[] directly.
 * No V1 logic. No schedule resolution. Pure rendering.
 */

import React, { useState, useEffect, useRef, useCallback } from "react";
import CanvasCreativeRenderer from "@/components/studio/CanvasCreativeRenderer";

// ─── Image preload cache (module-level, persists across renders) ──────────────
const imageCache = {};

const loadImageWithTimeout = (src, timeout = 8000) => {
  if (imageCache[src]) return Promise.resolve(imageCache[src]);
  const load = new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => { imageCache[src] = src; resolve(src); };
    img.onerror = () => reject(new Error(`Failed to load: ${src}`));
    img.src = src;
  });
  const timer = new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), timeout));
  return Promise.race([load, timer]);
};

function toObjectFit(fitMode) {
  switch (fitMode) {
    case "contain": return "contain";   // safe fit — no crop, letterbox ok
    case "cover":   return "cover";     // fill zone, intentional crop
    case "stretch": return "fill";      // force exact fit, distort ok
    case "fill":    return "fill";      // alias for stretch (backward compat)
    case "fit":     return "contain";   // legacy alias
    case "center":  return "none";      // no scaling
    default:        return "contain";   // safe default — never crops
  }
}

// ─── Cycles through playback_track.items[] for one zone ──────────────────────
function TrackZone({ zone }) {
  const items = zone.playback_track?.items || [];
  const loop  = zone.playback_track?.loop !== false;
  const [index, setIndex] = useState(0);
  // epoch increments every time we advance, even when index wraps back to 0.
  // This ensures the React key always changes, forcing a video/image remount on loop.
  const [epoch, setEpoch] = useState(0);
  const [loadedSrc, setLoadedSrc] = useState(null);
  const timerRef = useRef(null);

  const advance = useCallback(() => {
    setIndex(prev => {
      const next = prev + 1 >= items.length ? (loop ? 0 : prev) : prev + 1;
      return next;
    });
    // Always bump epoch so the key changes even on a single-item loop (0 → 0)
    if (loop || index + 1 < items.length) {
      setEpoch(e => e + 1);
    }
  }, [items.length, loop, index]);

  // Reset index when zone content changes
  useEffect(() => { setIndex(0); setEpoch(0); setLoadedSrc(null); }, [zone.id, zone.content_source_id]);

  // Preload current image, then preload next in background
  useEffect(() => {
    if (!items.length) return;
    const item = items[index];
    if (!item || item.file_type === "video" || item.content_type === "canvas_creative") return;
    if (!item.file_url) return;

    let cancelled = false;
    loadImageWithTimeout(item.file_url)
      .then((src) => { if (!cancelled) setLoadedSrc(src); })
      .catch(() => { if (!cancelled) setLoadedSrc(item.file_url); }); // fall back to direct src on error

    // Preload next item in background (fire-and-forget)
    const nextItem = items[(index + 1) % items.length];
    if (nextItem?.file_url && nextItem.file_type !== "video") {
      loadImageWithTimeout(nextItem.file_url).catch(() => {});
    }

    return () => { cancelled = true; };
  }, [index, items]);

  // Timer for images (and canvas creatives)
  useEffect(() => {
    if (!items.length) return;
    const item = items[index];
    if (!item || item.file_type === "video") return;
    const dur = (item.duration ?? 8) * 1000;
    timerRef.current = setTimeout(advance, dur);
    return () => clearTimeout(timerRef.current);
  }, [index, items, advance]);

  const style = {
    position: "absolute",
    left:   zone.x ?? 0,
    top:    zone.y ?? 0,
    width:  zone.width,
    height: zone.height,
    zIndex: zone.z_index ?? 1,
    backgroundColor: zone.background_color || "#000000",
    overflow: "hidden",
  };

  // Canvas creative zone — full zone is a Studio creative (no playback track)
  if (zone.content_source_type === 'canvas_creative') {
    const cc = zone.canvas_creative_data;
    if (!cc || !cc.layers_json) {
      const fontSize = Math.min(zone.width, zone.height) * 0.06;
      console.warn(`[RuntimeCanvas] canvas_creative zone missing canvas_creative_data. zone_id=${zone.id}`);
      return (
        <div style={{ ...style, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#1e1e2e' }}>
          <div style={{ color: '#f87171', fontSize, fontFamily: 'monospace', textAlign: 'center' }}>
            Studio creative data missing
          </div>
        </div>
      );
    }
    const scaleX = zone.width / (cc.width || zone.width);
    const scaleY = zone.height / (cc.height || zone.height);
    const scale = Math.min(scaleX, scaleY);
    console.log(`[RuntimeCanvas] canvas_creative zone id=${zone.id} cc="${cc.name}" ${cc.width}x${cc.height} layers=${cc.layers_json?.length ?? 0} scale=${scale.toFixed(3)}`);
    return (
      <div style={{ ...style, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CanvasCreativeRenderer creative={cc} scale={scale} />
      </div>
    );
  }

  // HDMI Input zone — BrightSign XT renders this via hardware; browser shows a placeholder
  if (zone.content_source_type === 'hdmi_input') {
    const fontSize = Math.min(zone.width, zone.height) * 0.08;
    return (
      <div style={{ ...style, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#0c1a2e', border: '1px solid #1e3a5f' }}>
        <div style={{ color: '#60a5fa', fontSize, fontWeight: 'bold', fontFamily: 'monospace', letterSpacing: '0.1em' }}>HDMI INPUT</div>
        <div style={{ color: '#334155', fontSize: fontSize * 0.6, marginTop: 4, fontFamily: 'monospace' }}>BrightSign XT · aux audio</div>
      </div>
    );
  }

  if (!items.length) return <div style={style} />;

  const item = items[index];

  // Canvas creative item — Studio project embedded in playlist
  if (item.content_type === 'canvas_creative') {
    if (!item.canvas_creative) {
      // Unresolvable studio creative — show visible error instead of black
      console.error(`[RuntimeCanvas] canvas_creative item has no canvas_creative object. id=${item.canvas_creative_id} error="${item.error}"`);
      const fontSize = Math.min(zone.width, zone.height) * 0.06;
      return (
        <div style={{ ...style, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#1e1e2e', gap: 8 }}>
          <div style={{ color: '#f87171', fontSize, fontFamily: 'monospace', textAlign: 'center', padding: '0 12px' }}>
            Studio creative not found
          </div>
          <div style={{ color: '#475569', fontSize: fontSize * 0.7, fontFamily: 'monospace' }}>
            id: {item.canvas_creative_id}
          </div>
        </div>
      );
    }
    const cc = item.canvas_creative;
    const scaleX = zone.width / (cc.width || zone.width);
    const scaleY = zone.height / (cc.height || zone.height);
    const scale = Math.min(scaleX, scaleY);
    console.log(`[RuntimeCanvas] rendering canvas_creative id=${cc.id} name="${cc.name}" layers=${cc.layers_json?.length ?? 0} scale=${scale.toFixed(3)}`);
    return (
      <div style={{ ...style, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CanvasCreativeRenderer creative={cc} scale={scale} />
      </div>
    );
  }

  const fit  = toObjectFit(item.fit_mode || zone.fit_mode);

  if (item.file_type === "video") {
    return (
      <div style={style}>
        <video
          key={`${zone.id}-${index}-${epoch}`}
          src={item.file_url}
          autoPlay
          playsInline
          muted={zone.volume === 0}
          onEnded={advance}
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: fit }}
        />
      </div>
    );
  }

  // Show nothing until image is preloaded (prevents partial/line-by-line rendering)
  // Falls back to item.file_url if loadedSrc is somehow mismatched
  const srcToRender = loadedSrc || item.file_url;

  return (
    <div style={style}>
      <img
        key={`${srcToRender}-${epoch}`}
        src={srcToRender}
        alt=""
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: fit, opacity: loadedSrc ? 1 : 0, transition: "opacity 0.15s ease" }}
      />
    </div>
  );
}

// ─── Full canvas of RuntimeZones ─────────────────────────────────────────────
export default function RuntimeCanvas({ zones = [], width, height, performanceMode }) {
  // Safety guard: default to full if missing or invalid
  const mode = performanceMode === "limited" ? "limited" : "full";
  console.log("ScreenFleet Mode:", mode);
  console.log(`[RuntimeCanvas] canvas=${width}x${height}, zones=${zones.length}`);
  zones.forEach(z => console.log(`[RuntimeCanvas] zone "${z.name}" x=${z.x} y=${z.y} w=${z.width} h=${z.height} z=${z.z_index}`));

  return (
    <div style={{
      position: "relative",
      width: typeof width === 'number' ? `${width}px` : width,
      height: typeof height === 'number' ? `${height}px` : height,
      overflow: "hidden",
      background: "#000",
      flexShrink: 0,
    }}>
      {(() => {
        const visibleZones = zones
          .filter(z => z.is_visible !== false)
          .sort((a, b) => (a.z_index ?? 1) - (b.z_index ?? 1));
        // Limited mode: render ONLY the first zone, no preloading, simplified rendering
        if (mode === "limited") {
          const firstZone = visibleZones[0];
          return firstZone ? <TrackZone key={firstZone.id} zone={firstZone} /> : null;
        }
        // Full mode: existing behavior, unchanged
        return visibleZones.map(zone => <TrackZone key={zone.id} zone={zone} />);
      })()}
    </div>
  );
}