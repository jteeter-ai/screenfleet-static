' ScreenFleet autozip.brs
' BrightSign OS 9.x extracts all zip contents to SD automatically
' before running this script. We just need to delete ourselves
' then reboot so next boot runs autorun.brs directly.
Sub Main()
    print "ScreenFleet: autozip.brs - cleaning up and rebooting"
    ' Delete autozip.brs from SD so next boot goes to autorun.brs
    ' BrightSign already extracted all other files from the zip to SD
    DeleteFile("SD:/autozip.brs")
    CreateDirectory("SD:/brightsign-dumps")
    print "ScreenFleet: Rebooting into autorun.brs..."
    RebootSystem()
End Sub
