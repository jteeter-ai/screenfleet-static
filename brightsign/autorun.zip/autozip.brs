' ScreenFleet autozip.brs
' Required by BrightSign OS to extract autorun.zip on first boot.
' BrightSign looks for this file inside the zip. On finding it,
' it extracts all files to the storage device root and reboots.
' The extraction is handled by BrightSign OS — this script just
' needs to exist and run successfully for extraction to proceed.
Sub Main()
    ' Create brightsign-dumps folder before anything else
    ' This is required by BrightSign partner specs
    MkDir("SD:/brightsign-dumps")

    ' Signal to BrightSign OS that extraction is complete
    ' The OS will reboot the player after this script exits
    print "ScreenFleet: autozip.brs complete. Rebooting into autorun.brs."
End Sub
