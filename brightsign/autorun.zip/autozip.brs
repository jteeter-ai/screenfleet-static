' ScreenFleet autozip.brs - OS 9.x manual extraction
' BrightSign OS 9.x does NOT auto-extract zip contents.
' We must use roBrightPackage to unpack, then reboot.
Sub Main()
    print "ScreenFleet: autozip.brs starting extraction"

    ' The zip is at TMP:/autorun.zip when downloaded by BSN.cloud
    zipFile = "TMP:/autorun.zip"

    ' Verify zip exists in TMP
    If Not CheckFile(zipFile) Then
        ' Try SD as fallback (manual SD card install)
        zipFile = "SD:/autorun.zip"
        If Not CheckFile(zipFile) Then
            print "ScreenFleet: ERROR - autorun.zip not found in TMP or SD"
            Return
        End If
    End If

    print "ScreenFleet: Found zip at " + zipFile

    ' Extract zip to SD:/
    ' roBrightPackage.Unpack() extracts to the destination set via SetDestination
    pkg = CreateObject("roBrightPackage", zipFile)
    If pkg = Invalid Then
        print "ScreenFleet: ERROR - roBrightPackage failed"
        Return
    End If

    pkg.SetDestination("SD:/")
    pkg.Unpack()
    print "ScreenFleet: Unpack complete"

    ' Create required folder
    CreateDirectory("SD:/brightsign-dumps")

    ' CRITICAL: Delete autozip.brs from SD so next boot runs autorun.brs
    DeleteFile("SD:/autozip.brs")

    print "ScreenFleet: Rebooting..."
    RebootSystem()
End Sub
